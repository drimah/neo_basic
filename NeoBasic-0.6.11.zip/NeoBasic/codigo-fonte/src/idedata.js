// ===== NeoBasic — importar planilhas (CSV/TSV) e painel Data (arrastar campos para o formulário) =====
'use strict';

// ---------- leitura de CSV / TSV ----------
function parseDelimited(text) {
  text = text.replace(/^﻿/, '');
  const first = text.split(/\r?\n/, 1)[0] || '';
  const count = ch => first.split(ch).length - 1;
  const delim = ['\t', ';', ','].sort((a, b) => count(b) - count(a))[0];
  const rows = []; let row = [], cell = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c; continue; }
    if (c === '"' && cell === '') { q = true; continue; }
    if (c === delim) { row.push(cell); cell = ''; continue; }
    if (c === '\r') continue;
    if (c === '\n') { row.push(cell); rows.push(row); row = []; cell = ''; continue; }
    cell += c;
  }
  if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
  while (rows.length && rows[rows.length - 1].every(x => x === '')) rows.pop();
  return rows;
}

// nome de campo limpo: "Integralização de Créditos" -> IntegralizacaoDeCreditos
function fieldIdent(h, i) {
  const words = String(h || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Za-z0-9]+/g, ' ').trim().split(' ').filter(Boolean);
  let s = words.map(w => /^[A-Z0-9]+$/.test(w) && w.length <= 4 ? w : w[0].toUpperCase() + w.slice(1).toLowerCase()).join('');
  if (!s) s = 'Campo' + (i + 1);
  if (/^\d/.test(s)) s = 'C' + s;
  return s;
}

const DATE_RE = /^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{2,4})$/;
const ISO_RE = /^(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/;
const BOOL_WORDS = { sim: 1, s: 1, yes: 1, y: 1, true: 1, verdadeiro: 1, x: 1, '1': 1, 'não': 0, nao: 0, n: 0, no: 0, false: 0, falso: 0, '0': 0 };

function guessColumn(vals) {
  const ne = vals.map(v => String(v).trim()).filter(v => v !== '');
  const r = { type: 'text', dmy: true };
  if (!ne.length) return r;
  if (ne.every(v => DATE_RE.test(v) || ISO_RE.test(v))) {
    let dmy = 0, mdy = 0; for (const v of ne) { const m = DATE_RE.exec(v); if (m) { if (+m[1] > 12) dmy++; if (+m[2] > 12) mdy++; } }
    r.type = 'date'; r.dmy = mdy <= dmy || LOCALE !== 'en-US' && mdy === 0; if (mdy > dmy) r.dmy = false; return r;
  }
  if (ne.every(v => /^-?\d{1,9}$/.test(v) && !/^-?0\d/.test(v))) { r.type = 'long'; return r; }
  if (ne.every(v => /^-?(\d{1,3}(\.\d{3})+|\d+)(,\d+)?$/.test(v) || /^-?\d+(\.\d+)?$/.test(v))) { r.type = 'double'; return r; }
  const low = new Set(ne.map(v => v.toLowerCase()));
  if (low.size <= 2 && [...low].every(v => v in BOOL_WORDS) && !(low.size === 1 && /^\d$/.test([...low][0]))) { r.type = 'bool'; return r; }
  const distinct = new Set(ne);
  const maxLen = Math.max(...ne.map(v => v.length)); const avg = ne.reduce((a, v) => a + v.length, 0) / ne.length;
  if (ne.some(v => v.includes('\n')) || avg > 100) { r.type = 'memo'; return r; }
  if (distinct.size >= 2 && distinct.size <= 15 && ne.length >= distinct.size * 2 && maxLen <= 60) { r.type = 'list'; return r; }
  return r;
}
const IMPORT_TYPES = [['text', 'Text'], ['memo', 'Long text'], ['long', 'Number'], ['double', 'Decimal'], ['date', 'Date'], ['bool', 'Yes/No'], ['list', 'List']];
const DAO_OF = { text: 10, memo: 12, long: 4, double: 7, date: 8, bool: 1, list: 10 };
const SQLT_OF = { text: 'TEXT COLLATE NOCASE', memo: 'TEXT COLLATE NOCASE', long: 'INTEGER', double: 'REAL', date: 'TEXT', bool: 'INTEGER', list: 'TEXT COLLATE NOCASE' };

function convertCell(v, col) {
  v = String(v == null ? '' : v).trim(); if (v === '') return null;
  switch (col.type) {
    case 'long': { const n = parseInt(v.replace(/\./g, ''), 10); return isNaN(n) ? null : n; }
    case 'double': { const t = /,\d+$/.test(v) || /\.\d{3}(,|$)/.test(v) ? v.replace(/\./g, '').replace(',', '.') : v; const n = parseFloat(t); return isNaN(n) ? null : n; }
    case 'bool': return BOOL_WORDS[v.toLowerCase()] ? -1 : 0;
    case 'date': {
      let m = ISO_RE.exec(v); if (m) return `${m[1]}-${pad(m[2])}-${pad(m[3])} ${pad(m[4] || 0)}:${pad(m[5] || 0)}:${pad(m[6] || 0)}`;
      m = DATE_RE.exec(v); if (!m) return v;
      let [d, mo] = col.dmy ? [m[1], m[2]] : [m[2], m[1]]; let y = +m[3]; if (y < 100) y += y < 50 ? 2000 : 1900;
      return `${y}-${pad(mo)}-${pad(d)} 00:00:00`;
    }
  }
  return v;
}

// ---------- bancos do projeto dentro da IDE ----------
async function ideOpenDb(name) { return daoOpenDatabase({ host: IDE.host }, name, false); }
function ideDbNames() {
  const P = IDE.project; const seen = new Map();
  for (const f of (P && P.dbFiles) || []) { const st = f.name.toLowerCase().replace(/\.[^.]*$/, ''); if (!seen.has(st) || /\.(db|sqlite3?)$/i.test(f.name)) seen.set(st, f.name); }
  return [...seen.values()];
}
function ensureMetaTables(sq) {
  sq.run('CREATE TABLE IF NOT EXISTS _nb_cols (tbl TEXT, col TEXT, type INTEGER, size INTEGER, pos INTEGER, auto INTEGER)');
  sq.run('CREATE TABLE IF NOT EXISTS _nb_fieldui (tbl TEXT, col TEXT, ui TEXT, label TEXT)');
}
function fieldUi(db, table) {
  const out = new Map();
  try { const r = db.sqlite.exec('SELECT col, ui, label FROM _nb_fieldui WHERE tbl = ?', [table])[0]; if (r) for (const [c, ui, label] of r.values) out.set(String(c).toLowerCase(), { ui, label }); } catch (e) { }
  return out;
}

// ---------- Project > Import Spreadsheet… ----------
function importSpreadsheet() {
  if (!IDE.project || IDE.running) return;
  pickFiles('.csv,.tsv,.txt', async files => {
    const f = files[0]; if (!f) return;
    let text = await f.text();
    if (text.includes('�')) { try { text = new TextDecoder('windows-1252').decode(await f.arrayBuffer()); } catch (e) { } }
    const rows = parseDelimited(text);
    if (rows.length < 1 || !rows[0].length) { IDE.ui.msgBox('The file is empty or could not be read.', 48, APP_NAME); return; }
    const head = rows[0]; const data = rows.slice(1);
    const used = new Set();
    const cols = head.map((h, i) => {
      let id = fieldIdent(h, i); let k = 2; const base = id; while (used.has(id.toLowerCase())) id = base + (k++); used.add(id.toLowerCase());
      const g = guessColumn(data.map(r => r[i] ?? ''));
      const sample = (data.find(r => String(r[i] ?? '').trim() !== '') || [])[i] || '';
      return { i, header: String(h).trim() || id, name: id, type: g.type, dmy: g.dmy, sample, use: data.some(r => String(r[i] ?? '').trim() !== '') || data.length === 0 };
    });
    importDialog(f.name, cols, data);
  });
}
function importDialog(fileName, cols, data) {
  const P = IDE.project;
  const dbs = ideDbNames(); const newDb = (P.name || 'Project') + '.db';
  const tblDefault = fieldIdent(fileName.replace(/\.[^.]*$/, '').replace(/[_-]?\d{6,}$/, ''), 0);
  return ideDialog('Import Spreadsheet', (c, done) => {
    c.innerHTML = `<div style="margin-bottom:8px"><b>${esc(fileName)}</b> — ${data.length} rows, ${cols.length} columns</div>
      <div class="row"><label style="width:90px">Table</label><input type="text" class="it" style="width:200px"></div>
      <div class="row"><label style="width:90px">Database</label><select class="idb" style="width:206px"></select></div>
      <div class="row idbnew"><label style="width:90px">New name</label><input type="text" class="idbn" spellcheck="false" style="width:170px"><span style="color:var(--muted)">.db</span></div>
      <div class="imp-cols"></div>
      <div style="color:var(--muted);margin-top:6px">Dates like 11/08/2025 are read as ${'day/month/year'} unless the data shows otherwise.</div>
      <div class="btns"><button class="nb-btn">Import</button><button class="nb-btn">Cancel</button></div>`;
    $('.it', c).value = tblDefault;
    const sel = $('.idb', c); for (const n of dbs) sel.appendChild(h('option', { value: n }, n)); sel.appendChild(h('option', { value: '*new' }, 'New database…')); sel.value = dbs[0] || '*new';
    const dbn = $('.idbn', c); dbn.value = newDb.replace(/\.db$/i, ''); const showNew = () => { $('.idbnew', c).style.display = sel.value === '*new' ? '' : 'none'; }; sel.onchange = showNew; showNew();
    const box = $('.imp-cols', c);
    box.appendChild(h('div', { class: 'imp-row imp-head', html: '<span></span><span>Column</span><span>Field name</span><span>Type</span><span>Example</span>' }));
    for (const col of cols) {
      const r = h('div', { class: 'imp-row' });
      const ck = h('input', { type: 'checkbox' }); ck.checked = col.use; ck.onchange = () => { col.use = ck.checked; r.classList.toggle('off', !ck.checked); };
      const nm = h('input', { type: 'text', value: col.name }); nm.oninput = () => { col.name = nm.value.trim(); };
      const ty = h('select'); for (const [v, l] of IMPORT_TYPES) ty.appendChild(h('option', { value: v }, l)); ty.value = col.type; ty.onchange = () => { col.type = ty.value; };
      r.append(ck, h('span', { title: col.header }, col.header), nm, ty, h('span', { class: 'ex', title: col.sample }, col.sample));
      if (!col.use) r.classList.add('off');
      box.appendChild(r);
    }
    const [ok, ca] = c.querySelectorAll('.btns button');
    ok.onclick = async () => {
      const tbl = $('.it', c).value.trim();
      if (!/^[A-Za-z_][\w ]*$/.test(tbl)) { IDE.ui.msgBox('Invalid table name.', 48, APP_NAME); return; }
      const use = cols.filter(x => x.use);
      if (!use.length) return;
      const names = new Set(); for (const x of use) { if (!/^[A-Za-z_]\w*$/.test(x.name) || names.has(x.name.toLowerCase())) { IDE.ui.msgBox(`Invalid or repeated field name: ${x.name}`, 48, APP_NAME); return; } names.add(x.name.toLowerCase()); }
      let target = sel.value;
      if (target === '*new') { const nn = dbn.value.trim().replace(/\.(db|sqlite3?|mdb|accdb)$/i, ''); if (!/^[\w\- ]{1,60}$/.test(nn)) { IDE.ui.msgBox('Invalid database name. Use letters, numbers, spaces, - and _.', 48, APP_NAME); return; } const ex = dbs.find(n => n.replace(/\.[^.]*$/, '').toLowerCase() === nn.toLowerCase()); target = ex || nn + '.db'; }
      done(true);
      try { await doImport(tbl, target, use, data); }
      catch (e) { IDE.ui.msgBox('Import failed: ' + (e.description || e.message), 16, APP_NAME); }
    };
    ca.onclick = () => done(false); return ok;
  });
}
async function doImport(tbl, dbName, cols, data) {
  const P = IDE.project; setStatus('Importing…');
  const stem = dbName.toLowerCase().replace(/\.[^.]*$/, '');
  const cache = IDE.host.dbCache || (IDE.host.dbCache = new Map());
  if (!cache.has(stem) && !findDbFile(dbName)) {
    // banco novo do projeto
    const SQL = await nbSqlEngine(); const db = new SQL.Database(); registerSqlFunctions(db);
    cache.set(stem, { name: dbName, stem, db, dirty: true, onChange: IDE.host.onDbChange, fromAccess: false });
    P.dbFiles = P.dbFiles || []; P.dbFiles.push({ name: dbName, path: dbName, bytes: new Uint8Array(0), inFolder: false });
  }
  const db = await ideOpenDb(dbName); const sq = db.sqlite;
  if (db.findTable(tbl)) {
    const r = await IDE.ui.msgBox(`The table "${tbl}" already exists in ${dbName}.\n\nReplace it with the spreadsheet data?`, 4 + 32, APP_NAME);
    if (r !== 6) { setStatus('Import cancelled.'); return; }
    sq.run(`DROP TABLE ${qi(tbl)}`);
  }
  ensureMetaTables(sq);
  sq.run('DELETE FROM _nb_cols WHERE tbl = ?', [tbl]); sq.run('DELETE FROM _nb_fieldui WHERE tbl = ?', [tbl]);
  sq.run('BEGIN');
  sq.run(`CREATE TABLE ${qi(tbl)} (${cols.map(x => qi(x.name) + ' ' + SQLT_OF[x.type]).join(', ')})`);
  cols.forEach((x, k) => { sq.run('INSERT INTO _nb_cols VALUES (?,?,?,?,?,0)', [tbl, x.name, DAO_OF[x.type], x.type === 'text' || x.type === 'list' ? 255 : 0, k]); sq.run('INSERT INTO _nb_fieldui VALUES (?,?,?,?)', [tbl, x.name, x.type, x.header]); });
  const st = sq.prepare(`INSERT INTO ${qi(tbl)} VALUES (${cols.map(() => '?').join(',')})`);
  for (const row of data) st.run(cols.map(x => convertCell(row[x.i], x)));
  st.free(); sq.run('COMMIT');
  const entry = cache.get(stem); if (entry) { entry.dirty = true; entry.colMeta = null; }
  P.dbDirty = true; markDirty(); refreshExplorer(); await refreshDataPanel();
  setStatus(`Imported ${data.length} rows into ${dbName} › ${tbl}. Drag the table or its fields from the Data panel onto a form.`);
}

// ---------- painel Data ----------
const FIELD_ICON = { 10: 'Aa', 12: '¶', 4: '#', 3: '#', 2: '#', 7: '#.', 6: '#.', 5: '$', 8: '📅', 1: '☑' };
async function refreshDataPanel() {
  const tree = $('#dtree'); if (!tree) return;
  buildDataOpts();
  const P = IDE.project; const panel = $('#datapanel');
  const names = ideDbNames();
  if (panel) panel.style.display = names.length ? '' : 'none';
  if (!names.length) { tree.innerHTML = ''; return; }
  const parts = [];
  for (const n of names) {
    let db; try { db = await ideOpenDb(n); } catch (e) { parts.push({ n, err: e.description || e.message }); continue; }
    const tables = db.tables().map(t => { const ui = fieldUi(db, t); const rs = new DAORecordset(db, t, 4); try { rs.load(); } catch (e) { return { t, cols: [] }; } return { t, cols: rs.cols.map(c => ({ name: c.name, type: c.type, ui: (ui.get(c.name.toLowerCase()) || {}).ui })), count: rs.rows.length }; });
    parts.push({ n, tables });
  }
  if (IDE.project !== P) return;
  tree.innerHTML = '';
  for (const p of parts) {
    { const gn = h('div', { class: 'node grp dbname', title: 'Double-click (or ✎) to rename the database', html: `<span class="ic">${TB_ICONS.db}</span>${esc(p.n)}<span class="dbren" title="Rename database">✎</span>` }); gn.ondblclick = () => renameDatabaseDialog(p.n); $('.dbren', gn).onclick = e => { e.stopPropagation(); renameDatabaseDialog(p.n); }; tree.appendChild(gn); }
    if (p.err) { tree.appendChild(h('div', { class: 'node', style: 'color:var(--danger)' }, p.err)); continue; }
    for (const t of p.tables) {
      const tn = h('div', { class: 'node dtable', draggable: 'true', title: `${t.t} — ${t.count} records. Drag onto a form to build a complete screen.`, html: `<span class="ic">▦</span><b>${esc(t.t)}</b> <span class="fn">${t.count}</span>` });
      tn.addEventListener('dragstart', e => { e.dataTransfer.setData('application/x-nb-data', JSON.stringify({ db: p.n, table: t.t })); e.dataTransfer.effectAllowed = 'copy'; });
      tn.onclick = () => tn.classList.toggle('open');
      tree.appendChild(tn);
      const kids = h('div', { class: 'kids dfields' });
      // marcar / desmarcar todos
      const allRow = h('div', { class: 'node dall', html: '<label><input type="checkbox"> All fields</label>' });
      const allCk = $('input', allRow); kids.appendChild(allRow);
      const syncAll = () => { const ons = t.cols.filter(c => isFieldOn(p.n, t.t, c.name)).length; allCk.checked = ons === t.cols.length; allCk.indeterminate = ons > 0 && ons < t.cols.length; };
      allCk.onchange = () => { for (const c of t.cols) setFieldOn(p.n, t.t, c.name, allCk.checked); kids.querySelectorAll('.dfield input').forEach(x => { x.checked = allCk.checked; }); syncAll(); };
      for (const c of t.cols) {
        const ic = c.ui === 'list' ? '▾' : (FIELD_ICON[c.type] || 'Aa');
        const fnode = h('div', { class: 'node dfield', draggable: 'true', title: `Checked fields go into the screen when you drag the table. Drag this field alone to add just it.`, html: `<input type="checkbox"><span class="ftype">${ic}</span>${esc(c.name)}` });
        const ck = $('input', fnode); ck.checked = isFieldOn(p.n, t.t, c.name);
        ck.onchange = () => { setFieldOn(p.n, t.t, c.name, ck.checked); syncAll(); }; ck.onmousedown = e => e.stopPropagation(); ck.draggable = false;
        fnode.addEventListener('dragstart', e => { e.dataTransfer.setData('application/x-nb-data', JSON.stringify({ db: p.n, table: t.t, field: c.name })); e.dataTransfer.effectAllowed = 'copy'; });
        kids.appendChild(fnode);
      }
      syncAll();
      tree.appendChild(kids);
    }
  }
}

// ---------- campos marcados (quais entram ao arrastar a tabela) ----------
function offFields() { try { return JSON.parse(localStorage.getItem('neobasic.dataoff') || '{}'); } catch (e) { return {}; } }
function fieldKey(db, t) { return (db + '|' + t).toLowerCase(); }
function isFieldOn(db, t, f) { return !(offFields()[fieldKey(db, t)] || []).includes(String(f).toLowerCase()); }
function setFieldOn(db, t, f, on) { const all = offFields(); const k = fieldKey(db, t); const set = new Set(all[k] || []); const lf = String(f).toLowerCase(); if (on) set.delete(lf); else set.add(lf); all[k] = [...set]; try { localStorage.setItem('neobasic.dataoff', JSON.stringify(all)); } catch (e) { } }

// ---------- opções dos rótulos (painel Data) ----------
function lblOpts() { const o = IDE.opts.dataLabel || {}; return { pos: o.pos === 'top' ? 'top' : 'left', size: Number(o.size) || 8.25, bold: !!o.bold }; }
function setLblOpts(o) { IDE.opts.dataLabel = Object.assign(lblOpts(), o); try { localStorage.setItem('neobasic.opts', JSON.stringify(IDE.opts)); } catch (e) { } }
function buildDataOpts() {
  const panel = $('#datapanel'); if (!panel || $('.dopts', panel)) return;
  const o = lblOpts();
  const bar = h('div', { class: 'dopts', html: `<span title="Where the label goes">Label</span>
    <span class="seg"><button data-p="left" title="Label beside the field">Beside</button><button data-p="top" title="Label above the field">Above</button></span>
    <select class="dsz" title="Label font size">${[8.25, 9, 10, 11, 12, 14, 16].map(v => `<option value="${v}">${v === 8.25 ? 8 : v}</option>`).join('')}</select>
    <button class="dbold" title="Bold labels"><b>B</b></button>` });
  const sync = () => { const q = lblOpts(); bar.querySelectorAll('.seg button').forEach(b => b.classList.toggle('on', b.dataset.p === q.pos)); $('.dsz', bar).value = String(q.size); $('.dbold', bar).classList.toggle('on', q.bold); };
  bar.querySelectorAll('.seg button').forEach(b => b.onclick = () => { setLblOpts({ pos: b.dataset.p }); sync(); });
  $('.dsz', bar).onchange = e => setLblOpts({ size: Number(e.target.value) });
  $('.dbold', bar).onclick = () => { setLblOpts({ bold: !lblOpts().bold }); sync(); };
  panel.insertBefore(bar, $('#dtree')); sync();
}
function styleLabel(n) {
  const o = lblOpts(); if (o.size === 8.25 && !o.bold) return;
  n.blocks = n.blocks.filter(x => x.name.toLowerCase() !== 'font');
  const blk = fontToBlock({ name: 'MS Sans Serif', size: o.size, bold: o.bold, italic: false, underline: false, strikethrough: false, charset: 0 }); blk.at = 0; n.blocks.push(blk);
}

// ---------- soltar no formulário ----------
function nbFreeName(m, base) { const names = new Set(allNodes(m).map(n => n.name.toLowerCase())); names.add(m.name.toLowerCase()); if (!names.has(base.toLowerCase())) return base; let i = 2; while (names.has((base + i).toLowerCase())) i++; return base + i; }
function nbAddCtl(m, type, name, L, T, W, H, raw) {
  const n = createNode(m, type, m.frm.root, L, T, W, H);
  n.name = nbFreeName(m, name);
  if (n.findProp('Caption')) n.setRaw('Caption', quote(n.name)); if (n.findProp('Text')) n.setRaw('Text', '""');
  for (const [k, v] of Object.entries(raw || {})) n.setRaw(k, v);
  return n;
}
function findDataCtl(m, dbName, table) {
  return allNodes(m).find(n => n.type === 'VB.Data' && String(n.get('RecordSource', '')).toLowerCase() === table.toLowerCase());
}
function addCodeIfMissing(m, procName, body) {
  const code = m.frm.code || '';
  if (new RegExp('Sub\\s+' + procName + '\\s*\\(', 'i').test(code)) return false;
  m.frm.code = code.replace(/\s*$/, '') + `\r\n\r\nPrivate Sub ${procName}()\r\n${body.map(l => '  ' + l).join('\r\n')}\r\nEnd Sub\r\n`;
  return true;
}
function addToFormLoad(m, lines) {
  let code = m.frm.code || ''; const re = /(Private\s+Sub\s+Form_Load\s*\(\s*\)[^\r\n]*\r?\n)/i;
  if (re.test(code)) code = code.replace(re, `$1${lines.map(l => '  ' + l).join('\r\n')}\r\n`);
  else code = code.replace(/\s*$/, '') + `\r\n\r\nPrivate Sub Form_Load()\r\n${lines.map(l => '  ' + l).join('\r\n')}\r\nEnd Sub\r\n`;
  m.frm.code = code;
}
function ensureDataCtl(m, dbName, table, L, T, W) {
  let dn = findDataCtl(m, dbName, table);
  if (dn) return dn;
  dn = nbAddCtl(m, 'VB.Data', 'dat' + fieldIdent(table, 0), L, T, W, 345, { DatabaseName: quote(dbName), RecordSource: quote(table), Caption: quote(table) });
  addCodeIfMissing(m, dn.name + '_Reposition', [`If ${dn.name}.Recordset.RecordCount = 0 Then`, `  ${dn.name}.Caption = "${table}: (empty)"`, 'Else', `  ${dn.name}.Caption = "${table}: " & (${dn.name}.Recordset.AbsolutePosition + 1) & " / " & ${dn.name}.Recordset.RecordCount`, 'End If']);
  return dn;
}
// cria Label + controle ligado para um campo; devolve a altura usada
// largura do rótulo pelo texto mais comprido (em twips)
function labelWidth(labels) { const k = lblOpts().size / 8.25 * (lblOpts().bold ? 1.1 : 1); const mx = Math.max(...labels.map(t => String(t).length)); return Math.min(6000, Math.max(1200, Math.round(mx * 95 * k / 120 + 1) * 120)); }
async function placeField(m, db, table, colName, ui, dataName, L, T, LW) {
  const rs = new DAORecordset(db, table, 4); rs.load();
  const col = rs.cols[rs.colIndex(colName)]; const label = (ui && ui.label) || colName;
  const kind = (ui && ui.ui) || ({ 1: 'bool', 8: 'date', 12: 'memo', 4: 'long', 3: 'long', 2: 'long', 7: 'double', 6: 'double', 5: 'double' }[col.type] || 'text');
  const bind = { DataSource: quote(dataName), DataField: quote(col.name) };
  const id = fieldIdent(col.name, 0);
  if (!LW) LW = labelWidth([label]);
  const o = lblOpts(); const top = o.pos === 'top'; const LH = Math.round(285 * Math.max(1, o.size / 8.25));
  const CX = top ? L : L + LW + 120; const lblT = top ? T : T + 45; T = top ? T + LH + 30 : T; const extra = top ? LH + 30 : 0;
  if (kind === 'bool') { const ck = nbAddCtl(m, 'VB.CheckBox', 'chk' + id, top ? L : CX, top ? lblT : T, 3600, 315, Object.assign({ Caption: quote(label) }, bind)); styleLabel(ck); return 315; }
  const lb = nbAddCtl(m, 'VB.Label', 'lbl' + id, L, lblT, top ? Math.max(LW, 3600) : LW, LH, { Caption: quote(label) }); styleLabel(lb);
  if (kind === 'list') {
    const cb = nbAddCtl(m, 'VB.ComboBox', 'cbo' + id, CX, T, 3600, 315, bind);
    const vals = [...new Set(rs.rows.map(r => r[col.src]).filter(v => v != null && String(v).trim() !== '').map(String))].sort((a, b) => a.localeCompare(b)).slice(0, 200);
    if (vals.length) addToFormLoad(m, vals.map(v => `${cb.name}.AddItem "${v.replace(/"/g, '""')}"`));
    return 315 + extra;
  }
  if (kind === 'memo') { nbAddCtl(m, 'VB.TextBox', 'txt' + id, CX, T, 3600, 900, Object.assign({ MultiLine: '-1', ScrollBars: '2' }, bind)); return 900 + extra; }
  nbAddCtl(m, 'VB.TextBox', 'txt' + id, CX, T, kind === 'date' ? 1600 : 3600, 315, Object.assign(kind === 'long' || kind === 'double' ? { Alignment: '1' } : {}, bind));
  return 315 + extra;
}
async function dropDataOnForm(d, info, px, py) {
  const m = d.mod; pushUndo(m);
  const db = await ideOpenDb(info.db); const ui = fieldUi(db, info.table);
  const root = m.frm.root; const P = nodeProps(root);
  let L = snap(Math.max(120, px * 15)), T = snap(Math.max(120, py * 15));
  if (info.field) {
    const dn = findDataCtl(m, info.db, info.table) || ensureDataCtl(m, info.db, info.table, 240, Math.max(240, (P.clientheight || 3195) - 585), 6120);
    await placeField(m, db, info.table, info.field, ui.get(info.field.toLowerCase()), dn.name, L, T);
  } else {
    // tela completa
    const rs = new DAORecordset(db, info.table, 4); rs.load();
    let y = T; const dname = 'dat' + fieldIdent(info.table, 0);
    const dn0 = findDataCtl(m, info.db, info.table); const dataName = dn0 ? dn0.name : nbFreeName(m, dname);
    const useCols = rs.cols.filter(c => isFieldOn(info.db, info.table, c.name));
    if (!useCols.length) { IDE.ui.msgBox('No fields are checked for this table in the Data panel.', 48, APP_NAME); return; }
    const LW = labelWidth(useCols.map(c => ((ui.get(c.name.toLowerCase()) || {}).label || c.name)));
    for (const c of useCols) { const hgt = await placeField(m, db, info.table, c.name, ui.get(c.name.toLowerCase()), dataName, L, y, LW); y += hgt + 105; }
    y += 120;
    const bN = nbAddCtl(m, 'VB.CommandButton', 'cmdNovo', L, y, 1335, 420, { Caption: '"&Novo"' });
    const bS = nbAddCtl(m, 'VB.CommandButton', 'cmdSalvar', L + 1440, y, 1335, 420, { Caption: '"&Salvar"' });
    const bE = nbAddCtl(m, 'VB.CommandButton', 'cmdExcluir', L + 2880, y, 1335, 420, { Caption: '"&Excluir"' });
    y += 540;
    const dn = dn0 || ensureDataCtl(m, info.db, info.table, L, y, 6120);
    if (dn.name !== dataName) dn.name = dataName; // mantém o nome usado nos controles ligados
    y += 465;
    const dnm = dn.name;
    addCodeIfMissing(m, bN.name + '_Click', [`${dnm}.Recordset.AddNew`]);
    addCodeIfMissing(m, bS.name + '_Click', [`Dim novo As Boolean`, `novo = (${dnm}.Recordset.EditMode = dbEditAdd)`, `${dnm}.UpdateRecord`, `If novo Then ${dnm}.Recordset.Bookmark = ${dnm}.Recordset.LastModified`, `MsgBox "Registro salvo.", vbInformation`]);
    addCodeIfMissing(m, bE.name + '_Click', [`If ${dnm}.Recordset.RecordCount = 0 Then Exit Sub`, `If MsgBox("Excluir este registro?", vbYesNo + vbQuestion) = vbNo Then Exit Sub`, `${dnm}.Recordset.Delete`, `${dnm}.Recordset.MoveNext`, `If ${dnm}.Recordset.EOF Then ${dnm}.Recordset.MoveLast`]);
    // aumenta o formulário para caber tudo
    const needW = Math.max(L + 6360, lblOpts().pos === 'top' ? L + Math.max(LW, 3600) : L + LW + 120 + 3600) + 240, needH = y + 120;
    if ((P.clientwidth || 0) < needW) { root.setRaw('ClientWidth', String(needW)); if (root.findProp('ScaleWidth')) root.setRaw('ScaleWidth', String(needW)); }
    if ((P.clientheight || 0) < needH) { root.setRaw('ClientHeight', String(needH)); if (root.findProp('ScaleHeight')) root.setRaw('ScaleHeight', String(needH)); }
  }
  // aumenta o formulário se algum controle ficou para fora
  { let mr = 0, mb = 0; for (const n of root.children) { const q = nodeProps(n); if (q.left == null) continue; mr = Math.max(mr, (q.left || 0) + (q.width || 0)); mb = Math.max(mb, (q.top || 0) + (q.height || 0)); }
    const P2 = nodeProps(root);
    if (mr + 240 > (P2.clientwidth || 0)) { root.setRaw('ClientWidth', String(mr + 240)); if (root.findProp('ScaleWidth')) root.setRaw('ScaleWidth', String(mr + 240)); }
    if (mb + 240 > (P2.clientheight || 0)) { root.setRaw('ClientHeight', String(mb + 240)); if (root.findProp('ScaleHeight')) root.setRaw('ScaleHeight', String(mb + 240)); } }
  m.dirty = true; markDirty(); renderDesigner(d); refreshExplorer();
  for (const cd of IDE.docs.filter(x => x.mod === m && x.kind === 'code')) loadEditorText(cd);
  setStatus(info.field ? `Field ${info.field} added (bound to ${info.table}).` : `Screen for ${info.table} created. Press F5 to try it.`);
}
function setupDataDrop() {
  document.addEventListener('dragover', e => { if (e.dataTransfer && [...e.dataTransfer.types].includes('application/x-nb-data') && e.target.closest && e.target.closest('.dsurf')) { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; } });
  document.addEventListener('drop', e => {
    if (!e.dataTransfer || ![...e.dataTransfer.types].includes('application/x-nb-data')) return;
    e.preventDefault(); e.stopPropagation();
    const d = IDE.activeDoc; if (!d || d.kind !== 'design' || IDE.running || !d.client) { setStatus('Open a form (design view) and drop the field on it.'); return; }
    let info; try { info = JSON.parse(e.dataTransfer.getData('application/x-nb-data')); } catch (er) { return; }
    const r = d.client.getBoundingClientRect();
    dropDataOnForm(d, info, e.clientX - r.left, e.clientY - r.top).catch(er => IDE.ui.msgBox('Could not add the field: ' + (er.description || er.message), 16, APP_NAME));
  }, true);
}
