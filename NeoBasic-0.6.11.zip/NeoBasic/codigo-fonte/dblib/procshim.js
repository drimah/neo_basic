import p from 'process/browser.js'; import { Buffer } from 'buffer'; export { p as process, Buffer };
