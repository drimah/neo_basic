// ===== NeoBasic — IDE =====
'use strict';
const APP_NAME = 'NeoBasic';
const APP_VERSION = '0.6.4';
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => [...(r || document).querySelectorAll(s)];
const h = (tag, attrs, ...kids) => { const e = document.createElement(tag); if (attrs) for (const k in attrs) { if (k === 'class') e.className = attrs[k]; else if (k.startsWith('on')) e.addEventListener(k.slice(2), attrs[k]); else if (k === 'html') e.innerHTML = attrs[k]; else if (attrs[k] !== undefined && attrs[k] !== null) e.setAttribute(k, attrs[k]); } for (const c of kids) if (c != null) e.append(c); return e; };
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

// ---------- Ícones (traço, cor do tema) ----------
const I = (inner) => `<svg class="i" viewBox="0 0 24 24">${inner}</svg>`;
const TOOL_ICONS = {
  pointer: I('<path d="M6 3l12 9-5.6 1.1L15.5 19l-2.4 1.1-2.9-6L6 17.2z"/>'),
  'VB.PictureBox': I('<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 16l5-5 4 4 3-3 6 6"/><circle cx="16" cy="8.5" r="1.5"/>'),
  'VB.Label': I('<path d="M5 19L11 5h2l6 14M8 14.5h8"/>'),
  'VB.TextBox': I('<rect x="2" y="6" width="20" height="12" rx="2.5"/><path d="M6.5 9.5v5"/>'),
  'VB.Frame': I('<path d="M10 6h9a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h1"/><path d="M6.5 4.5h2"/>'),
  'VB.CommandButton': I('<rect x="3" y="7" width="18" height="10" rx="3.5"/><path d="M9 12h6"/>'),
  'VB.CheckBox': I('<rect x="4" y="4" width="16" height="16" rx="3.5"/><path d="M8 12.2l2.8 2.8L16 9.5"/>'),
  'VB.OptionButton': I('<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3" fill="currentColor" stroke="none"/>'),
  'VB.ComboBox': I('<rect x="2" y="6" width="20" height="12" rx="2.5"/><path d="M15 6v12M17 11l1.5 1.5L20 11"/>'),
  'VB.ListBox': I('<rect x="3" y="3" width="18" height="18" rx="2.5"/><path d="M7 8h7M7 12h7M7 16h7M17.5 7v4"/>'),
  'VB.HScrollBar': I('<rect x="2" y="8" width="20" height="8" rx="4"/><rect x="9" y="10.2" width="6" height="3.6" rx="1.8" fill="currentColor" stroke="none"/>'),
  'VB.VScrollBar': I('<rect x="8" y="2" width="8" height="20" rx="4"/><rect x="10.2" y="8" width="3.6" height="6" rx="1.8" fill="currentColor" stroke="none"/>'),
  'VB.Timer': I('<circle cx="12" cy="13" r="8"/><path d="M12 9v4l3 2M10 2h4"/>'),
  'VB.DriveListBox': I('<rect x="3" y="8" width="18" height="8" rx="2.5"/><path d="M7 12h6"/><circle cx="17" cy="12" r="1" fill="currentColor"/>'),
  'VB.DirListBox': I('<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H9l2 2h7.5A2.5 2.5 0 0 1 21 9.5v7a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 16.5z"/>'),
  'VB.FileListBox': I('<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4"/>'),
  'VB.Shape': I('<rect x="3" y="3" width="9" height="9" rx="1.5"/><circle cx="15.5" cy="15.5" r="5.5"/>'),
  'VB.Line': I('<path d="M5 19L19 5"/>'),
  'VB.Image': I('<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 17l5-5 4 4 2-2 4 4"/><circle cx="8.5" cy="9" r="1.5"/>'),
  'VB.Data': I('<rect x="2" y="7" width="20" height="10" rx="2.5"/><path d="M8 10l-2 2 2 2M16 10l2 2-2 2"/>'),
  unknown: I('<rect x="4" y="4" width="16" height="16" rx="3" stroke-dasharray="3 3"/><path d="M10 10a2 2 0 1 1 2 2v1.5M12 16.5v.01"/>'),
};
// ---------- Caixa de ferramentas 2027: ícones grandes e coloridos, inspirados na caixa do VB de 1997 ----------
const TA = (inner) => `<svg class="ta" viewBox="0 0 32 32" aria-hidden="true">${inner}</svg>`;
const TOOL_ART = {
  pointer: { label: 'Pointer', svg: TA('<path d="M9 4.5l15.5 12.2-7 1.2 4 7.6-3.3 1.7-4-7.7L9 24.6z" fill="currentColor" stroke="#fff" stroke-width="1.6" stroke-linejoin="round"/>') },
  'VB.PictureBox': { label: 'Picture', svg: TA('<rect x="3.5" y="5.5" width="25" height="21" rx="4" fill="#fff" stroke="currentColor" stroke-width="2"/><rect x="6.5" y="8.5" width="19" height="15" rx="2" fill="currentColor" fill-opacity="0.18"/><circle cx="21" cy="12.5" r="2.4" fill="currentColor" fill-opacity="0.6"/><path d="M6.5 21l5.5-6 4 4.3 3-3 6.5 6.2v.5a1.5 1.5 0 0 1-1.5 1.5H8a1.5 1.5 0 0 1-1.5-1.5z" fill="currentColor"/>') },
  'VB.Label': { label: 'Label', svg: TA('<path d="M7 26L14.3 6h3.4L25 26h-4l-1.8-5.2h-6.4L11 26zm6.9-8.6h4.2L16 11.2z" fill="currentColor"/><rect x="5" y="27.5" width="22" height="2" rx="1" fill="currentColor" fill-opacity="0.45"/>') },
  'VB.TextBox': { label: 'TextBox', svg: TA('<rect x="2.5" y="8" width="27" height="16" rx="4" fill="#fff" stroke="currentColor" stroke-width="2"/><text x="6.5" y="20" font-family="NB Inter, Inter, sans-serif" font-size="10.5" font-weight="700" fill="currentColor">ab</text><rect x="21.5" y="11.5" width="2" height="9" rx="1" fill="currentColor"/>') },
  'VB.Frame': { label: 'Frame', svg: TA('<path d="M15.5 7.5h10a3 3 0 0 1 3 3v14a3 3 0 0 1-3 3h-19a3 3 0 0 1-3-3v-14a3 3 0 0 1 3-3" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><text x="7.4" y="10" font-family="NB Inter, Inter, sans-serif" font-size="7.5" font-weight="700" fill="currentColor">xy</text><rect x="8" y="14" width="10" height="3" rx="1.5" fill="currentColor" fill-opacity="0.4"/><rect x="8" y="19.5" width="15" height="3" rx="1.5" fill="currentColor" fill-opacity="0.4"/>') },
  'VB.CommandButton': { label: 'Button', svg: TA('<rect x="2.5" y="9" width="27" height="14" rx="7" fill="currentColor"/><rect x="3.5" y="9.8" width="25" height="5" rx="2.5" fill="#fff" opacity=".3"/><rect x="10" y="15" width="12" height="2.4" rx="1.2" fill="#fff"/>') },
  'VB.CheckBox': { label: 'CheckBox', svg: TA('<rect x="5" y="5" width="22" height="22" rx="6" fill="currentColor"/><path d="M10.5 16.3l4 4L22 12" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>') },
  'VB.OptionButton': { label: 'Option', svg: TA('<circle cx="16" cy="16" r="11" fill="#fff" stroke="currentColor" stroke-width="2.4"/><circle cx="16" cy="16" r="5.5" fill="currentColor"/>') },
  'VB.ComboBox': { label: 'ComboBox', svg: TA('<rect x="2.5" y="8" width="27" height="16" rx="4" fill="#fff" stroke="currentColor" stroke-width="2"/><path d="M20 9h5.5a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H20z" fill="currentColor"/><path d="M21.7 14.5l2.5 2.6 2.5-2.6" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><rect x="6.5" y="14.8" width="10" height="2.4" rx="1.2" fill="currentColor" fill-opacity="0.45"/>') },
  'VB.ListBox': { label: 'ListBox', svg: TA('<rect x="4.5" y="3.5" width="23" height="25" rx="4" fill="#fff" stroke="currentColor" stroke-width="2"/><rect x="7.5" y="7" width="17" height="2.6" rx="1.3" fill="currentColor" fill-opacity="0.45"/><rect x="6.5" y="12" width="19" height="5" rx="2.5" fill="currentColor"/><rect x="8.5" y="13.3" width="11" height="2.4" rx="1.2" fill="#fff"/><rect x="7.5" y="19.5" width="17" height="2.6" rx="1.3" fill="currentColor" fill-opacity="0.45"/><rect x="7.5" y="24" width="12" height="2.2" rx="1.1" fill="currentColor" fill-opacity="0.3"/>') },
  'VB.HScrollBar': { label: 'HScroll', svg: TA('<rect x="2" y="10.5" width="28" height="11" rx="5.5" fill="currentColor" fill-opacity="0.15" stroke="currentColor" stroke-opacity="0.5" stroke-width="1.6"/><path d="M7.5 13.2L5 16l2.5 2.8M24.5 13.2L27 16l-2.5 2.8" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/><rect x="11.5" y="12.8" width="9" height="6.4" rx="3.2" fill="currentColor"/>') },
  'VB.VScrollBar': { label: 'VScroll', svg: TA('<rect x="10.5" y="2" width="11" height="28" rx="5.5" fill="currentColor" fill-opacity="0.15" stroke="currentColor" stroke-opacity="0.5" stroke-width="1.6"/><path d="M13.2 7.5L16 5l2.8 2.5M13.2 24.5L16 27l2.8-2.5" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/><rect x="12.8" y="11.5" width="6.4" height="9" rx="3.2" fill="currentColor"/>') },
  'VB.Timer': { label: 'Timer', svg: TA('<rect x="13" y="2.5" width="6" height="3.5" rx="1.5" fill="currentColor"/><circle cx="16" cy="17.5" r="11" fill="currentColor"/><circle cx="16" cy="17.5" r="8.3" fill="#fff"/><path d="M16 12v5.8l3.6 2.2" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/><rect x="24.2" y="6.5" width="3" height="4.5" rx="1.4" transform="rotate(45 25.7 8.7)" fill="currentColor"/>') },
  'VB.DriveListBox': { label: 'Drive', svg: TA('<rect x="3" y="9" width="26" height="14" rx="4" fill="currentColor"/><rect x="3" y="9" width="26" height="6.5" rx="3.2" fill="currentColor" fill-opacity="0.55"/><rect x="6.5" y="17.6" width="12" height="2.4" rx="1.2" fill="#fff"/><circle cx="24" cy="18.8" r="1.9" fill="#fff"/>') },
  'VB.DirListBox': { label: 'Folders', svg: TA('<path d="M3 9.5A3.5 3.5 0 0 1 6.5 6h6l3 3h10A3.5 3.5 0 0 1 29 12.5V23a3.5 3.5 0 0 1-3.5 3.5h-19A3.5 3.5 0 0 1 3 23z" fill="currentColor"/><path d="M3 13.5A2.5 2.5 0 0 1 5.5 11h21a2.5 2.5 0 0 1 2.5 2.5V23a3.5 3.5 0 0 1-3.5 3.5h-19A3.5 3.5 0 0 1 3 23z" fill="currentColor" fill-opacity="0.55"/>') },
  'VB.FileListBox': { label: 'Files', svg: TA('<path d="M8 3h11l7 7v16a3 3 0 0 1-3 3H8a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3z" fill="#fff" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M19 3v5a2 2 0 0 0 2 2h5" fill="currentColor" fill-opacity="0.18" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><rect x="9" y="14" width="12" height="2.4" rx="1.2" fill="currentColor"/><rect x="9" y="18.6" width="12" height="2.4" rx="1.2" fill="currentColor" fill-opacity="0.45"/><rect x="9" y="23.2" width="8" height="2.4" rx="1.2" fill="currentColor" fill-opacity="0.45"/>') },
  'VB.Shape': { label: 'Shape', svg: TA('<rect x="3.5" y="4" width="15" height="15" rx="3.5" fill="currentColor" fill-opacity="0.4"/><circle cx="20" cy="20" r="9" fill="currentColor"/>') },
  'VB.Line': { label: 'Line', svg: TA('<path d="M7 25L25 7" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><circle cx="7" cy="25" r="3.2" fill="#fff" stroke="currentColor" stroke-width="2"/><circle cx="25" cy="7" r="3.2" fill="#fff" stroke="currentColor" stroke-width="2"/>') },
  'VB.Image': { label: 'Image', svg: TA('<rect x="3" y="5" width="26" height="22" rx="4.5" fill="currentColor" fill-opacity="0.35"/><circle cx="10.5" cy="11.5" r="2.6" fill="#fff"/><path d="M3 22.5l7.5-7.5 5 5 4-4 9.5 8.5V22.5a4.5 4.5 0 0 1-4.5 4.5h-17A4.5 4.5 0 0 1 3 22.5z" fill="currentColor"/>') },
  'VB.Data': { label: 'Data', svg: TA('<ellipse cx="16" cy="7.5" rx="10" ry="4" fill="currentColor" fill-opacity="0.55"/><path d="M6 7.5v15c0 2.2 4.5 4 10 4s10-1.8 10-4v-15c0 2.2-4.5 4-10 4S6 9.7 6 7.5z" fill="currentColor"/><path d="M6 15c0 2.2 4.5 4 10 4s10-1.8 10-4" fill="none" stroke="#fff" stroke-width="1.4"/><ellipse cx="16" cy="7.5" rx="10" ry="4" fill="none" stroke="#fff" stroke-width="1.2"/>') },
  unknown: { label: 'Control', svg: TA('<rect x="5" y="5" width="22" height="22" rx="6" fill="none" stroke="currentColor" stroke-opacity="0.5" stroke-width="2" stroke-dasharray="4 3"/><path d="M13 13a3 3 0 1 1 3 3v2.5M16 22.5v.1" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>') },
};
const TB_ICONS = {
  db: I('<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v12c0 1.7 3.1 3 7 3s7-1.3 7-3V6M5 12c0 1.7 3.1 3 7 3s7-1.3 7-3"/>'),
  addProject: I('<path d="M12 3l8 4-8 4-8-4z"/><path d="M4 11.5l8 4 4-2"/><path d="M18.5 14v6M15.5 17h6"/>'),
  addForm: I('<rect x="3" y="4" width="15" height="12" rx="2"/><path d="M3 7.5h15"/><path d="M18.5 14v6M15.5 17h6"/>'),
  addModule: I('<path d="M5 3h7l4 4v5"/><path d="M5 3v15h7"/><path d="M12 3v4h4M8 10h5M8 13.5h3"/><path d="M18.5 14v6M15.5 17h6"/>'),
  menuEd: I('<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 8h18M6.5 6h2M10.5 6h2"/><rect x="6.5" y="10.5" width="7" height="7" rx="1"/><path d="M8.5 13h3M8.5 15.5h3"/>'),
  cut: I('<circle cx="6.5" cy="17.5" r="2.8"/><circle cx="17.5" cy="17.5" r="2.8"/><path d="M8.6 15.6L18 4M15.4 15.6L6 4"/>'),
  copy: I('<rect x="8" y="8" width="12" height="13" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h2"/>'),
  paste: I('<path d="M9 4H6.5A1.5 1.5 0 0 0 5 5.5v14A1.5 1.5 0 0 0 6.5 21h11a1.5 1.5 0 0 0 1.5-1.5v-14A1.5 1.5 0 0 0 17.5 4H15"/><rect x="9" y="2.5" width="6" height="3.5" rx="1"/><path d="M9 11h6M9 14.5h6M9 18h3.5"/>'),
  undo: I('<path d="M9 14L4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/>'),
  redo: I('<path d="M15 14l5-5-5-5"/><path d="M20 9H9.5a5.5 5.5 0 0 0 0 11H13"/>'),
  start: '<svg class="i fill" viewBox="0 0 24 24"><path d="M7 4.8v14.4a1 1 0 0 0 1.5.86l11.4-7.2a1 1 0 0 0 0-1.7L8.5 3.94A1 1 0 0 0 7 4.8z"/></svg>',
  brk: '<svg class="i fill" viewBox="0 0 24 24"><rect x="6" y="5" width="4" height="14" rx="1.2"/><rect x="14" y="5" width="4" height="14" rx="1.2"/></svg>',
  end: '<svg class="i fill" viewBox="0 0 24 24"><rect x="5.5" y="5.5" width="13" height="13" rx="2.2"/></svg>',
  layout: I('<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M9 21h6M12 17v4"/><rect x="7" y="7" width="7" height="5" rx="1"/>'),
  pos: I('<path d="M4 9V4h5M15 4h5v5M20 15v5h-5M9 20H4v-5"/><path d="M12 9v6M9 12h6"/>'),
  size: I('<rect x="4" y="4" width="16" height="16" rx="1.5" stroke-dasharray="3 2.5"/><path d="M9 15l6-6M11 9h4v4"/>'),

  new: I('<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M12 11v6M9 14h6"/>'),
  open: I('<path d="M3 18V6.5A1.5 1.5 0 0 1 4.5 5H9l2 2h6.5A1.5 1.5 0 0 1 19 8.5V10"/><path d="M3 18l3.2-7h15.3L18 18z"/>'),
  save: I('<path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7"/><path d="M7 3v4a1 1 0 0 0 1 1h7"/>'),
  zip: I('<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>'),
  form: I('<rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="M3 8.5h18"/><circle cx="6" cy="6.3" r=".5" fill="currentColor"/>'),
  module: I('<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M9 12h6M9 16h4"/>'),
  cls: I('<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path d="M12 12l8-4.5M12 12v9M12 12L4 7.5"/>'),
  code: I('<path d="M8 8l-4 4 4 4M16 8l4 4-4 4M13.5 6l-3 12"/>'),
  props: I('<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>'),
  explorer: I('<path d="M4 4h5M6.5 4v13h4.5M6.5 10.5H11"/><rect x="13" y="8.5" width="7" height="4" rx="1.2"/><rect x="13" y="15" width="7" height="4" rx="1.2"/>'),
  toolbox: I('<rect x="3" y="8" width="18" height="12" rx="2"/><path d="M8 8V5.5A1.5 1.5 0 0 1 9.5 4h5A1.5 1.5 0 0 1 16 5.5V8M3 13h18M10 13v2h4v-2"/>'),
  imm: I('<rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="M7 9l3 3-3 3M12.5 15H17"/>'),
  app: I('<rect x="3" y="3" width="18" height="18" rx="4"/><path d="M9 8.5l6 3.5-6 3.5z"/>'),
  run: '<svg viewBox="0 0 24 24"><path d="M7 4.5v15a1 1 0 0 0 1.5.9l12-7.5a1 1 0 0 0 0-1.7l-12-7.5A1 1 0 0 0 7 4.5z"/></svg>',
  stop: '<svg viewBox="0 0 24 24"><rect x="5" y="5" width="14" height="14" rx="2.5"/></svg>',
  search: I('<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/>'),
  folder: I('<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H9l2 2h7.5A2.5 2.5 0 0 1 21 9.5v7a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 16.5z"/>'),
  project: I('<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>'),
  theme: I('<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>'),
  sparkle: I('<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M18 6l-2.5 2.5M8.5 15.5L6 18"/>'),
};
const LOGO = '<svg viewBox="0 0 64 64" width="26" height="26"><defs><linearGradient id="nbg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5b9bff"/><stop offset="1" stop-color="#2346c9"/></linearGradient></defs><rect x="2" y="2" width="60" height="60" rx="15" fill="url(#nbg)"/><text x="31" y="43" font-family="NB Inter, Inter, sans-serif" font-weight="700" font-size="27" fill="#fff" text-anchor="middle">NB</text><circle cx="49" cy="15" r="5.5" fill="#ffcc33"/></svg>';

// ---------- Estado ----------
const IDE = { project: null, docs: [], activeDoc: null, sel: null, tool: null, running: false, rt: null, host: null, clip: null, undo: new Map(), opts: { grid: true, locale: 'pt-BR', autoCase: true, theme: 'light', skin: 'modern' }, dirHandle: null };

// ---------- Modelo do projeto ----------
let MOD_SEQ = 1;
function newFormFrm(name, mdi) {
  const root = new CtlNode(mdi ? 'VB.MDIForm' : 'VB.Form', name);
  root.setRaw('BackColor', '&H8000000C&');
  if (!mdi) root.remove('BackColor');
  root.setRaw('Caption', quote(name));
  root.setRaw('ClientHeight', '3195'); root.setRaw('ClientLeft', '60'); root.setRaw('ClientTop', '345'); root.setRaw('ClientWidth', '4680');
  root.setRaw('LinkTopic', quote(name));
  if (!mdi) { root.setRaw('ScaleHeight', '3195'); root.setRaw('ScaleWidth', '4680'); }
  root.setRaw('StartUpPosition', '3', 'Windows Default');
  return { header: ['VERSION 5.00'], root, attributes: defaultFormAttributes(name), code: '', name, isMDI: !!mdi };
}
function makeModule(kind, name, extra) { return Object.assign({ id: MOD_SEQ++, kind, name, fileName: name + ({ form: '.frm', std: '.bas', class: '.cls' }[kind]), frx: {}, dirty: true }, extra || {}); }
function newProject() {
  const f = makeModule('form', 'Form1', { frm: newFormFrm('Form1') });
  return { name: 'Project1', title: '', startup: 'Form1', modules: [f], vbp: null, fileName: 'Project1.vbp', extra: [], dirty: false };
}
const getCode = m => m.kind === 'form' ? m.frm.code : m.code;
const setCode = (m, s) => { if (m.kind === 'form') m.frm.code = s; else m.code = s; m.dirty = true; markDirty(); };
function frxLookupFor(m) { return (name) => { if (!name) return null; const k = name.toLowerCase().split(/[\\/]/).pop(); for (const n in m.frx) if (n.toLowerCase() === k) return m.frx[n]; return null; }; }
function allNodes(m) { const out = []; if (m.kind !== 'form') return out; m.frm.root.walk(n => { if (n !== m.frm.root) out.push(n); }); return out; }
function findModule(name) { const k = String(name).toLowerCase(); return IDE.project.modules.find(m => m.name.toLowerCase() === k); }
function uniqueModuleName(base) { let i = 1; while (findModule(base + i)) i++; return base + i; }
function markDirty() { if (IDE.project) IDE.project.dirty = true; scheduleAutosave(); updateTitle(); }

// ---------- Leitura de projetos ----------
async function readFileEntries(list) {
  // list: [{path, file}] -> Map(caminhoMinúsculo -> {name, path, bytes})
  const map = new Map();
  for (const it of list) {
    const bytes = new Uint8Array(await it.file.arrayBuffer());
    const path = it.path.replace(/\\/g, '/');
    map.set(path.toLowerCase(), { name: path.split('/').pop(), path, bytes, handle: it.handle });
  }
  return map;
}
function resolveRel(map, baseDir, rel) {
  const parts = (baseDir ? baseDir + '/' : '') + rel.replace(/\\/g, '/');
  const stack = [];
  for (const p of parts.split('/')) { if (p === '..') stack.pop(); else if (p && p !== '.') stack.push(p); }
  const key = stack.join('/').toLowerCase();
  if (map.has(key)) return map.get(key);
  // tolerante: procura só pelo nome
  const nm = rel.replace(/\\/g, '/').split('/').pop().toLowerCase();
  for (const [k, v] of map) if (k.split('/').pop() === nm) return v;
  return null;
}
function loadProjectFromMap(map, vbpKey) {
  const warnings = [];
  const proj = { name: 'Project1', title: '', startup: '', modules: [], vbp: null, extra: [], dirty: false };
  const addFile = (entry, kind, baseDir) => {
    const txt = decodeText(entry.bytes);
    const rel = entry.path.slice(baseDir ? baseDir.length + 1 : 0);
    if (kind === 'form') {
      const frm = parseFrm(txt, entry.name);
      const m = makeModule('form', frm.name, { frm, fileName: rel || entry.name, dirty: false });
      // .frx
      const frxNames = new Set(); frm.root.walk(n => { for (const p of n.props) { const mm = /^\$?"([^"]+\.frx)":/i.exec(p.raw); if (mm) frxNames.add(mm[1]); } });
      const dir = entry.path.includes('/') ? entry.path.slice(0, entry.path.lastIndexOf('/')) : '';
      for (const fn of frxNames) { const fx = resolveRel(map, dir, fn); if (fx) m.frx[fn] = fx.bytes; else warnings.push(`File ${fn} not found (used by ${entry.name})`); }
      proj.modules.push(m);
    } else if (kind === 'std') { const b = parseBas(txt, entry.name); proj.modules.push(makeModule('std', b.name, { code: b.code, attributes: b.attributes, fileName: rel || entry.name, dirty: false })); }
    else if (kind === 'class') { const c = parseCls(txt, entry.name); proj.modules.push(makeModule('class', c.name, { code: c.code, attributes: c.attributes, header: c.header, defaultMember: c.defaultMember, fileName: rel || entry.name, dirty: false })); }
  };
  if (vbpKey) {
    const ve = map.get(vbpKey);
    const vbp = parseVbp(decodeText(ve.bytes), ve.name);
    const baseDir = ve.path.includes('/') ? ve.path.slice(0, ve.path.lastIndexOf('/')) : '';
    proj.vbp = vbp; proj.name = vbp.name; proj.title = vbp.title; proj.startup = vbp.startup; proj.fileName = ve.name;
    for (const f of vbp.forms) { const e = resolveRel(map, baseDir, f); if (e) addFile(e, 'form', baseDir); else warnings.push('Form not found: ' + f); }
    for (const f of vbp.modules) { const e = resolveRel(map, baseDir, f.file); if (e) addFile(e, 'std', baseDir); else warnings.push('Module not found: ' + f.file); }
    for (const f of vbp.classes) { const e = resolveRel(map, baseDir, f.file); if (e) addFile(e, 'class', baseDir); else warnings.push('Class not found: ' + f.file); }
    for (const o of vbp.others) warnings.push(`Not supported yet (${o.key}): ${o.val}`);
    // nomes de arquivo relativos ao vbp
    for (const m of proj.modules) m.fileName = m.fileName.replace(/\//g, '\\');
  } else {
    for (const [k, e] of map) { const ext = k.split('.').pop(); if (ext === 'frm') addFile(e, 'form', ''); else if (ext === 'bas') addFile(e, 'std', ''); else if (ext === 'cls') addFile(e, 'class', ''); }
    proj.startup = (proj.modules.find(m => m.kind === 'form') || {}).name || 'Sub Main';
    proj.fileName = 'Project1.vbp';
    warnings.push('No .vbp file was opened, so only the selected files were loaded. To open a whole project, use File > Open Project Folder and choose the folder that contains the .vbp file.');
  }
  proj.dbFiles = [];
  for (const [k, e] of map) if (/\.(mdb|accdb|db|sqlite|sqlite3)$/i.test(k)) proj.dbFiles.push({ name: e.name, path: e.path, bytes: e.bytes, inFolder: true });
  // projetos de banco de dados (DAO/Jet) precisam do arquivo do banco
  const dbRe = /\b(OpenDatabase|DBEngine|Workspaces\s*\(|As\s+(Database|Recordset|TableDef|QueryDef|Field|Workspace)\b|dbOpen\w+|vbRSType\w+)/i;
  const usesDb = proj.modules.some(m => { const t = m.kind === 'form' ? (m.frm && m.frm.code || '') : (m.code || m.text || ''); return dbRe.test(typeof t === 'string' ? t : ''); }) || (proj.vbp && (proj.vbp.lines || []).some(l => /^Reference=.*(DAO|Jet)/i.test(l)));
  if (usesDb && !proj.dbFiles.length) warnings.push('This project uses a database (Access .mdb), but no database file was found in the folder. Use Project > Add Database File… to add it (for example BIBLIO.MDB).');
  if (!proj.modules.length) throw new Error('No forms or modules found.');
  if (!proj.startup) proj.startup = (proj.modules.find(m => m.kind === 'form') || {}).name || 'Sub Main';
  return { proj, warnings };
}
async function openProjectFromList(list, dirHandle) {
  const map = await readFileEntries(list);
  const vbps = [...map.keys()].filter(k => k.endsWith('.vbp'));
  let vbpKey = null;
  if (vbps.length === 1) vbpKey = vbps[0];
  else if (vbps.length > 1) { vbpKey = await chooseDialog('Open Project', 'This folder contains several projects. Choose one:', vbps.map(k => ({ label: map.get(k).path, value: k }))); if (!vbpKey) return; }
  let res;
  try { res = loadProjectFromMap(map, vbpKey); } catch (e) { await IDE.ui.msgBox('Could not open the project:\n\n' + e.message, 16, APP_NAME); return; }
  if (vbpKey && dirHandle) {
    // diretório do projeto (subpasta do que foi escolhido)
    const sub = map.get(vbpKey).path.split('/').slice(0, -1);
    let dh = dirHandle; try { for (const s of sub) dh = await dh.getDirectoryHandle(s); } catch (e) { dh = null; }
    IDE.dirHandle = dh;
  } else IDE.dirHandle = dirHandle || null;
  setProject(res.proj);
  log(`Project "${res.proj.name}" opened (${res.proj.modules.length} modules).`);
  if (res.warnings.length) imm("' Warnings while opening:\n" + res.warnings.map(w => "'   " + w).join('\n') + '\n');
  const important = res.warnings.filter(w => /^(No \.vbp|This project uses a database)/.test(w));
  if (important.length) await IDE.ui.msgBox(important.join('\n\n'), 48, APP_NAME);
}
// limite de segurança: escolher uma pasta enorme (ex.: o CD inteiro ou o drive D:) não pode travar o computador
const MAX_PROJECT_FILES = 3000;
async function pickFolder() {
  if (window.showDirectoryPicker) {
    let dh; try { dh = await window.showDirectoryPicker({ id: 'neobasic', mode: 'readwrite' }); } catch (e) { if (e.name !== 'AbortError') { try { dh = await window.showDirectoryPicker({ id: 'neobasic' }); } catch (e2) { return; } } else return; }
    const list = [];
    const walk = async (d, pre, depth) => { for await (const [name, hd] of d.entries()) { if (hd.kind === 'file') { if (list.length < MAX_PROJECT_FILES && /\.(vbp|frm|frx|bas|cls|ctl|ctx|res|mdb|accdb|db|sqlite|sqlite3)$/i.test(name)) list.push({ path: pre + name, file: await hd.getFile(), handle: hd }); } else if (depth < 3) await walk(hd, pre + name + '/', depth + 1); } };
    setStatus('Reading folder…'); await walk(dh, '', 0); setStatus('Ready');
    await openProjectFromList(list, dh);
  } else {
    const inp = h('input', { type: 'file', webkitdirectory: '', multiple: '' });
    inp.addEventListener('change', async () => { const list = [...inp.files].filter(f => /\.(vbp|frm|frx|bas|cls|ctl|ctx|res|mdb|accdb|db|sqlite|sqlite3)$/i.test(f.name) && (f.webkitRelativePath || f.name).split('/').length <= 5).slice(0, MAX_PROJECT_FILES).map(f => ({ path: f.webkitRelativePath || f.name, file: f })); await openProjectFromList(list, null); });
    inp.click();
  }
}
function pickFiles(accept, cb) { const inp = h('input', { type: 'file', multiple: '', accept }); inp.addEventListener('change', () => cb([...inp.files])); inp.click(); }

// ---------- Gravação ----------
function buildFrx(m) {
  // devolve {name: bytes} incluindo blobs novos (_pending)
  const frm = m.frm; const out = Object.assign({}, m.frx);
  const pend = []; frm.root.walk(n => { if (n._pending && Object.keys(n._pending).length) pend.push(n); });
  if (!pend.length) return out;
  const frxName = (m.fileName.split(/[\\/]/).pop().replace(/\.frm$/i, '') || m.name) + '.frx';
  let base = out[Object.keys(out).find(k => k.toLowerCase() === frxName.toLowerCase())] || new Uint8Array(0);
  const chunks = [base]; let off = base.length;
  const u32 = v => { const b = new Uint8Array(4); new DataView(b.buffer).setUint32(0, v, true); return b; };
  const u16 = v => { const b = new Uint8Array(2); new DataView(b.buffer).setUint16(0, v, true); return b; };
  const add = (parts) => { const start = off; for (const p of parts) { chunks.push(p); off += p.length; } return start; };
  const ref = (o) => `"${frxName}":${o.toString(16).toUpperCase().padStart(4, '0')}`;
  for (const n of pend) {
    for (const k in n._pending) {
      const v = n._pending[k];
      if (v && v.bytes) { const sz = v.bytes.length; const o = add([u32(sz + 8), new Uint8Array([0x6C, 0x74, 0, 0]), u32(sz), v.bytes]); n.setRaw(propCase(k), ref(o)); }
      else if (v === null) { n.remove(propCase(k)); }
      else if (Array.isArray(v)) { const parts = [u16(v.length)]; for (const it of v) { const b = encode1252(String(it)); parts.push(u16(b.length), b); } const o = add(parts); n.setRaw(propCase(k), ref(o)); }
      else if (typeof v === 'string') { const b = encode1252(v); const o = b.length < 255 ? add([new Uint8Array([b.length]), b]) : add([new Uint8Array([0xFF]), u16(b.length), b]); n.setRaw(propCase(k), ref(o)); }
    }
    n._pending = null;
  }
  const total = new Uint8Array(off); let p = 0; for (const c of chunks) { total.set(c, p); p += c.length; }
  for (const k of Object.keys(out)) if (k.toLowerCase() === frxName.toLowerCase()) delete out[k];
  out[frxName] = total; m.frx = out;
  return out;
}
function propCase(k) { const map = { picture: 'Picture', icon: 'Icon', list: 'List', itemdata: 'ItemData', text: 'Text', caption: 'Caption', downpicture: 'DownPicture', disabledpicture: 'DisabledPicture', mouseicon: 'MouseIcon' }; return map[k] || k[0].toUpperCase() + k.slice(1); }
function projectFiles() {
  syncEditors();
  const P = IDE.project; const files = [];
  const vbp = P.vbp ? Object.assign({}, P.vbp) : { lines: ['Type=Exe', 'Reference=*\\G{00020430-0000-0000-C000-000000000046}#2.0#0#..\\..\\WINDOWS\\SYSTEM\\STDOLE2.TLB#OLE Automation', 'HelpFile=""', 'Command32=""', 'HelpContextID="0"', 'CompatibleMode="0"', 'MajorVer=1', 'MinorVer=0', 'RevisionVer=0', 'AutoIncrementVer=0', 'ServerSupportFiles=0', 'CompilationType=0', 'OptimizationType=0', 'FavorPentiumPro(tm)=0', 'CodeViewDebugInfo=0', 'NoAliasing=0', 'BoundsCheck=0', 'OverflowCheck=0', 'FlPointCheck=0', 'FDIVCheck=0', 'UnroundedFP=0', 'StartMode=0', 'Unattended=0', 'Retained=0', 'ThreadPerObject=0', 'MaxNumberOfThreads=1'] };
  vbp.forms = P.modules.filter(m => m.kind === 'form').map(m => m.fileName);
  vbp.modules = P.modules.filter(m => m.kind === 'std').map(m => ({ name: m.name, file: m.fileName }));
  vbp.classes = P.modules.filter(m => m.kind === 'class').map(m => ({ name: m.name, file: m.fileName }));
  vbp.startup = P.startup; vbp.name = P.name; vbp.title = P.title;
  files.push({ path: P.fileName || (P.name + '.vbp'), data: encode1252(serializeVbp(vbp)) });
  for (const m of P.modules) {
    if (m.kind === 'form') {
      const frx = buildFrx(m);
      m.frm.name = m.name; m.frm.root.name = m.name;
      files.push({ path: m.fileName, data: encode1252(serializeFrm(m.frm)) });
      const dir = m.fileName.includes('\\') ? m.fileName.slice(0, m.fileName.lastIndexOf('\\') + 1) : '';
      for (const k in frx) files.push({ path: dir + k, data: frx[k] });
    } else if (m.kind === 'std') files.push({ path: m.fileName, data: encode1252(serializeBas(m)) });
    else files.push({ path: m.fileName, data: encode1252(serializeCls(m)) });
  }
  return files;
}
async function saveProject(asNew) {
  if (IDE.running) return;
  const files = projectFiles().concat(dbFilesToSave(!IDE.dirHandle || asNew));
  if (!asNew && IDE.dirHandle) {
    try {
      if (IDE.dirHandle.requestPermission) { const p = await IDE.dirHandle.requestPermission({ mode: 'readwrite' }); if (p !== 'granted') throw new Error('Write permission denied'); }
      for (const f of files) {
        const parts = f.path.split(/[\\/]/); let d = IDE.dirHandle;
        for (const s of parts.slice(0, -1)) d = await d.getDirectoryHandle(s, { create: true });
        const fh = await d.getFileHandle(parts[parts.length - 1], { create: true }); const w = await fh.createWritable(); await w.write(f.data); await w.close();
      }
      for (const m of IDE.project.modules) m.dirty = false; IDE.project.dirty = false; afterDbSaved(files.filter(f => f.entry)); updateTitle(); refreshExplorer();
      setStatus(`Project saved to the folder (${files.length} files).`); return;
    } catch (e) { await IDE.ui.msgBox('Could not write to the folder: ' + e.message + '\n\nThe project will be downloaded as a ZIP file instead.', 48, APP_NAME); }
  }
  // sem pasta definida (projeto novo, aberto por arrastar ou por arquivos soltos): pergunta onde salvar, como o "Save Project As" do VB
  if (window.showDirectoryPicker) {
    try { IDE.dirHandle = await window.showDirectoryPicker({ id: 'neobasic-save', mode: 'readwrite' }); return saveProject(false); } catch (e) { if (e.name === 'AbortError') return; }
  }
  downloadZip(files);
}
function downloadZip(files) {
  files = files || projectFiles().concat(dbFilesToSave(true));
  const zip = makeZip(files.map(f => ({ name: f.path.replace(/\\/g, '/'), data: f.data })));
  downloadBlob(new Blob([zip], { type: 'application/zip' }), (IDE.project.name || 'Project') + '.zip');
  afterDbSaved(files.filter(f => f.entry));
  for (const m of IDE.project.modules) m.dirty = false; IDE.project.dirty = false; updateTitle(); refreshExplorer();
  setStatus('Project downloaded as ZIP.');
}

// ---------- Salvamento automático (navegador) ----------
let autosaveT = null;
function scheduleAutosave() { clearTimeout(autosaveT); autosaveT = setTimeout(autosave, 1500); }
function u8ToB64(u8) { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); }
function b64ToU8(b) { const s = atob(b); const u = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i); return u; }
function snapshotProject() {
  syncEditors();
  const P = IDE.project;
  return { v: 1, name: P.name, title: P.title, startup: P.startup, fileName: P.fileName, vbp: P.vbp ? { lines: P.vbp.lines } : null, modules: P.modules.map(m => ({ kind: m.kind, name: m.name, fileName: m.fileName, text: m.kind === 'form' ? serializeFrmWithPending(m) : m.kind === 'std' ? serializeBas(m) : serializeCls(m), frx: Object.fromEntries(Object.entries(m.kind === 'form' ? buildFrxCopy(m) : {}).map(([k, v]) => [k, u8ToB64(v)])) })) };
}
function serializeFrmWithPending(m) { const copy = { frm: Object.assign({}, m.frm, { root: m.frm.root.clone() }), frx: Object.assign({}, m.frx), fileName: m.fileName, name: m.name }; copyPending(m.frm.root, copy.frm.root); buildFrx(copy); return serializeFrm(copy.frm); }
function buildFrxCopy(m) { const copy = { frm: Object.assign({}, m.frm, { root: m.frm.root.clone() }), frx: Object.assign({}, m.frx), fileName: m.fileName, name: m.name }; copyPending(m.frm.root, copy.frm.root); return buildFrx(copy); }
function copyPending(a, b) { if (a._pending) b._pending = Object.assign({}, a._pending); a.children.forEach((c, i) => copyPending(c, b.children[i])); }
function restoreSnapshot(s) {
  const proj = { name: s.name, title: s.title, startup: s.startup, fileName: s.fileName, vbp: s.vbp ? { lines: s.vbp.lines, forms: [], modules: [], classes: [], others: [] } : null, modules: [], extra: [], dirty: false };
  for (const mm of s.modules) {
    if (mm.kind === 'form') { const frm = parseFrm(mm.text, mm.fileName); const m = makeModule('form', mm.name, { frm, fileName: mm.fileName, dirty: false }); for (const k in mm.frx) m.frx[k] = b64ToU8(mm.frx[k]); proj.modules.push(m); }
    else if (mm.kind === 'std') { const b = parseBas(mm.text, mm.fileName); proj.modules.push(makeModule('std', mm.name, { code: b.code, attributes: b.attributes, fileName: mm.fileName, dirty: false })); }
    else { const c = parseCls(mm.text, mm.fileName); proj.modules.push(makeModule('class', mm.name, { code: c.code, attributes: c.attributes, header: c.header, defaultMember: c.defaultMember, fileName: mm.fileName, dirty: false })); }
  }
  return proj;
}
function autosave() { if (!IDE.project) return; try { localStorage.setItem('neobasic.autosave', JSON.stringify(snapshotProject())); } catch (e) { /* cheio */ } }

// ---------- Interface ----------
function buildShell() {
  document.body.innerHTML = '';
  applyTheme();
  const app = h('div', { id: 'app', class: 'nb-root' });
  app.innerHTML = `
  <div id="titlebar"><span class="logo" title="${APP_NAME} ${APP_VERSION}">${LOGO}</span><span id="ttext">NeoBasic 2027</span><span class="window-controls"><b>−</b><b>□</b><b>×</b></span></div>
  <div id="topbar"><div id="menubar"></div></div>
  <div id="toolrow">
    <div id="toolbar"></div>
    <span class="vsep"></span>
    <div id="projchip" title="Project Properties"><span class="dot"></span><span id="pjname">No project</span></div>
    <div class="grow"></div>
    <button id="cmdk" title="Search commands (Ctrl+K)">${TB_ICONS.search}<span>Search commands</span><kbd>Ctrl K</kbd></button>
    <div id="runbtns"><button id="bRun" title="Start (F5)">${TB_ICONS.run}<span>Start</span></button><button id="bStop" title="End">${TB_ICONS.stop}</button></div>
  </div>
  <div id="main">
    <div id="toolbox" class="panel"><div class="ptitle">General</div><div class="tools"></div></div>
    <div id="center"><div id="tabs"></div><div id="docs"><div class="welcome" id="welcome"></div></div></div>
    <div id="right">
      <div id="projpanel" class="panel"><div class="ptitle">Project</div><div class="pbtns"><button title="View Code (F7)" id="bViewCode">${TB_ICONS.code}</button><button title="View Object (Shift+F7)" id="bViewObj">${TB_ICONS.form}</button></div><div class="tree" id="tree"></div></div>
      <div id="datapanel" class="panel" style="display:none"><div class="ptitle">Data</div><div class="tree dtree" id="dtree"></div></div>
      <div id="proppanel" class="panel"><div class="ptitle">Properties <span id="ppname"></span></div><select id="propsel"></select><div class="ptabs"><span class="on" data-t="a">Alphabetic</span><span data-t="c">Categorized</span></div><input class="psearch" id="psearch" placeholder="Filter properties…" spellcheck="false"><div class="pgrid" id="pgrid"></div><div class="pdesc" id="pdesc"></div></div>
    </div>
    <div id="runstage" class="nb-root"><div class="runlabel">[run] — click ■ to end</div></div>
    <div id="dropnote">Drop a VB project folder or files here</div>
  </div>
  <div id="immediate" class="panel"><div class="ptitle">Immediate <span class="x" id="immclear" title="Clear"></span></div><div class="io"><div id="immout"></div><input id="immin" placeholder="? expression  or a statement — press Enter" spellcheck="false"></div></div>
  <div id="statusbar"><span id="status">Ready</span><span id="spos">&nbsp;</span><span id="ssize">&nbsp;</span><span id="sskin"></span></div>`;
  document.body.appendChild(app);
  if (IDE.appMode) document.body.classList.add('appmode');
  buildMenus(); buildToolbar(); buildToolbox();
  $('#bViewCode').onclick = () => viewCode(); $('#bViewObj').onclick = () => viewObject();
  $('#bRun').onclick = () => cmd('run'); $('#bStop').onclick = () => cmd('stop');
  $('#cmdk').onclick = () => openPalette();
  $('#projchip').onclick = () => { if (IDE.project && !IDE.running) projectPropsDialog(); };
  $('#propsel').onchange = e => { const [mid, path] = e.target.value.split('|'); const m = IDE.project.modules.find(x => x.id === Number(mid)); selectNode(m, path ? nodeByPath(m, path) : m.frm.root); };
  $$('.ptabs span').forEach(s => s.onclick = () => { $$('.ptabs span').forEach(x => x.classList.toggle('on', x === s)); IDE.propTab = s.dataset.t; renderProps(); });
  $('#psearch').addEventListener('input', () => { IDE.propFilter = $('#psearch').value.trim().toLowerCase(); renderProps(); });
  $('#immin').addEventListener('keydown', e => { if (e.key === 'Enter') { const v = e.target.value; e.target.value = ''; immediateExec(v); } });
  $('#immclear').onclick = () => { $('#immout').textContent = ''; };
  IDE.stage = $('#runstage');
  IDE.host = new RunHost(IDE.stage, { debugPrint: s => imm(s), onEnd: () => onRunEnd(), onError: e => onRunError(e), beep: true, onFormsChanged: () => { } });
  IDE.host.getDbFile = p => findDbFile(p);
  IDE.host.dbHint = '\n\nAdd the database file to the project with Project > Add Database File… (or open the project folder that contains it).';
  IDE.host.onDbChange = () => { if (IDE.project) { IDE.project.dbDirty = true; markDirty(); } };
  IDE.ui = new RunHost(document.body, { dialogClass: 'ide-dlg', zBase: 400000 });
  IDE.ui.appName = APP_NAME;
  setupDrop(); setupDataDrop();
  document.addEventListener('keydown', globalKeys, true);
  window.addEventListener('beforeunload', e => { autosave(); });
  window.addEventListener('resize', () => updateSelection());
  updateSkinLabel();
}
function applyTheme() {
  document.body.classList.toggle('theme-dark', IDE.opts.theme !== 'light');
  document.body.classList.toggle('theme-light', IDE.opts.theme === 'light');
  setSkin(IDE.opts.skin || 'modern');
}
function updateSkinLabel() { const s = $('#sskin'); if (s) s.textContent = 'App style: ' + (IDE.opts.skin === 'classic' ? 'Classic 2000' : 'Modern'); }
function renderWelcome() {
  const w = $('#welcome'); if (!w) return;
  w.innerHTML = `<div style="width:84px;height:84px">${LOGO.replace(/width="\d+" height="\d+"/, 'width="84" height="84"')}</div><h1>${APP_NAME}</h1><div class="sub">The Visual Basic you know, built for today.</div><div class="cards"></div><div class="tip">Tip: <kbd>Ctrl K</kbd> searches any command · <kbd>F5</kbd> starts · drop a project folder here</div>`;
  const cards = $('.cards', w);
  const C = (icon, title, sub, id) => { const c = h('div', { class: 'card', html: `${icon}<div><b>${title}</b><small>${sub}</small></div>` }); c.onclick = () => cmd(id); cards.appendChild(c); };
  C(TB_ICONS.new, 'New Project', 'Standard EXE with one form', 'new');
  C(TB_ICONS.folder, 'Open Project Folder', 'VB5 and VB6 .vbp projects', 'openFolder');
  C(TB_ICONS.open, 'Open Files', '.vbp, .frm, .frx, .bas, .cls', 'openFiles');
  C(TB_ICONS.sparkle, 'Sample Project', 'See NeoBasic in action', 'demo');
}

// ---------- Paleta de comandos (Ctrl+K) ----------
function paletteItems() {
  const out = [];
  for (const [cap, items] of MENUS) for (const it of items) { if (it === '-') continue; out.push({ g: stripMnemonic(cap), label: it[0].replace(/…$/, ''), sc: it[2] || '', run: () => cmd(it[1]), dis: () => isCmdDisabled(it[1]) }); }
  if (IDE.project) {
    for (const m of IDE.project.modules) {
      if (m.kind === 'form') out.push({ g: 'Open', label: `${m.name} (form)`, run: () => openDesigner(m) });
      out.push({ g: 'Open', label: `${m.name} (code)`, run: () => openCode(m) });
    }
    for (const t of TOOL_ORDER) out.push({ g: 'Control', label: 'Add ' + ctlDef(t).tool, run: () => { const d = IDE.activeDoc; if (!d || d.kind !== 'design') { const f = IDE.project.modules.find(x => x.kind === 'form'); if (f) openDesigner(f); } addControlDefault(t); }, dis: () => IDE.running });
  }
  out.push({ g: 'Appearance', label: 'Dark theme', run: () => setOpt('theme', 'dark') }, { g: 'Appearance', label: 'Light theme', run: () => setOpt('theme', 'light') });
  out.push({ g: 'Appearance', label: 'Modern app style', run: () => setOpt('skin', 'modern') }, { g: 'Appearance', label: 'Classic 2000 app style', run: () => setOpt('skin', 'classic') });
  return out;
}
function setOpt(k, v) { IDE.opts[k] = v; try { localStorage.setItem('neobasic.opts', JSON.stringify(IDE.opts)); } catch (e) { } applyTheme(); updateSkinLabel(); rerenderActive(); }
function openPalette() {
  if ($('.palette-shade')) return;
  closeIdeMenu();
  const shade = h('div', { class: 'palette-shade' });
  const box = h('div', { class: 'palette' }); shade.appendChild(box);
  const inp = h('input', { placeholder: 'Type a command, a form or a control…', spellcheck: 'false' });
  const list = h('div', { class: 'list' }); box.append(inp, list);
  const all = paletteItems(); let shown = [], cur = 0;
  const norm = s => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  const render = () => {
    const q = norm(inp.value.trim());
    shown = all.filter(it => !(it.dis && it.dis())).filter(it => !q || q.split(/\s+/).every(w => norm(it.label + ' ' + it.g).includes(w))).slice(0, 60);
    cur = Math.min(cur, Math.max(0, shown.length - 1));
    list.innerHTML = '';
    if (!shown.length) { list.appendChild(h('div', { class: 'empty' }, 'No matches.')); return; }
    shown.forEach((it, i) => { const r = h('div', { class: 'it' + (i === cur ? ' on' : ''), html: `<span class="g">${esc(it.g)}</span><span>${esc(it.label)}</span><span class="sc">${esc(it.sc || '')}</span>` }); r.onmousemove = () => { if (cur !== i) { cur = i; render(); } }; r.onclick = () => go(i); list.appendChild(r); });
    const on = list.querySelector('.on'); if (on) on.scrollIntoView({ block: 'nearest' });
  };
  const close = () => shade.remove();
  const go = (i) => { const it = shown[i]; close(); if (it) it.run(); };
  inp.addEventListener('input', () => { cur = 0; render(); });
  inp.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown') { e.preventDefault(); cur = Math.min(shown.length - 1, cur + 1); render(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); cur = Math.max(0, cur - 1); render(); }
    else if (e.key === 'Enter') { e.preventDefault(); go(cur); }
    else if (e.key === 'Escape') { e.preventDefault(); close(); }
    e.stopPropagation();
  });
  shade.addEventListener('mousedown', e => { if (e.target === shade) close(); });
  document.body.appendChild(shade); render(); inp.focus();
}

// ---------- Menus da IDE ----------
const MENUS = [
  ['&File', [['New Project', 'new', 'Ctrl+N'], ['Open Project Folder…', 'openFolder', 'Ctrl+O'], ['Open Files…', 'openFiles'], ['Sample Project', 'demo'], '-', ['Save Project', 'save', 'Ctrl+S'], ['Save Project to Another Folder…', 'saveAs'], ['Download Project as ZIP', 'zip'], '-', ['Make App (.html)…', 'export', 'Ctrl+F5'], '-', ['Close Project', 'close']]],
  ['&Edit', [['Undo', 'undo', 'Ctrl+Z'], ['Redo', 'redo', 'Ctrl+Y'], '-', ['Cut', 'cut', 'Ctrl+X'], ['Copy', 'copy', 'Ctrl+C'], ['Paste', 'paste', 'Ctrl+V'], ['Delete', 'delete', 'Del'], '-', ['Find…', 'find', 'Ctrl+F'], ['Go to Line…', 'gotoLine', 'Ctrl+L']]],
  ['&View', [['Code', 'viewCode', 'F7'], ['Object', 'viewObj', 'Shift+F7'], '-', ['Immediate Window', 'toggleImm', 'Ctrl+G'], ['Project Explorer', 'toggleRight', 'Ctrl+R'], ['Toolbox', 'toggleTools']]],
  ['&Project', [['Add Form', 'addForm'], ['Add MDI Form', 'addMDI'], ['Add Module', 'addModule'], ['Add Class Module', 'addClass'], ['Add File…', 'addFile', 'Ctrl+D'], ['Add Database File… (.mdb, .accdb, .db)', 'addDb'], ['Import Spreadsheet… (.csv, .tsv)', 'importSheet'], '-', ['Remove Selected Item', 'removeItem'], '-', ['Project Properties…', 'projProps']]],
  ['F&ormat', [['Align to Grid', 'alignGrid'], ['Center Horizontally', 'centerH'], ['Center Vertically', 'centerV'], '-', ['Bring to Front', 'front', 'Ctrl+J'], ['Send to Back', 'back', 'Ctrl+Shift+J']]],
  ['&Run', [['Start', 'run', 'F5'], ['End', 'stop'], ['Restart', 'restart', 'Shift+F5']]],
  ['&Tools', [['Search Commands…', 'palette', 'Ctrl+K'], '-', ['Options…', 'options']]],
  ['&Help', [['What NeoBasic Supports', 'help'], ['About NeoBasic', 'about']]],
];
function buildMenus() {
  const bar = $('#menubar');
  for (const [cap, items] of MENUS) {
    const t = h('span', { html: mnemonicHtml(cap) });
    t.addEventListener('mousedown', ev => { ev.preventDefault(); const r = t.getBoundingClientRect(); openIdeMenu(items, r.left, r.bottom, t); });
    t.addEventListener('mouseenter', () => { if ($('.vb-popup.idem')) { const r = t.getBoundingClientRect(); openIdeMenu(items, r.left, r.bottom, t); } });
    bar.appendChild(t);
  }
}
function openIdeMenu(items, x, y, anchor) {
  closeIdeMenu();
  const pop = h('div', { class: 'vb-popup idem nb-root' });
  for (const it of items) {
    if (it === '-') { pop.appendChild(h('div', { class: 'vb-msep' })); continue; }
    const [lab, id, sc] = it;
    const dis = isCmdDisabled(id);
    const row = h('div', { class: 'vb-mi' + (dis ? ' dis' : ''), html: `<span class="ck"></span><span>${esc(lab)}</span><span class="sc">${sc || ''}</span>` });
    row.addEventListener('mouseup', () => { if (dis) return; closeIdeMenu(); cmd(id); });
    pop.appendChild(row);
  }
  document.body.appendChild(pop);
  pop.style.left = x + 'px'; pop.style.top = y + 'px';
  if (anchor) anchor.classList.add('open'); IDE.menuAnchor = anchor;
  setTimeout(() => { IDE.menuCloser = ev => { if (!ev.target.closest('.vb-popup.idem') && !ev.target.closest('#menubar')) closeIdeMenu(); }; window.addEventListener('mousedown', IDE.menuCloser, true); }, 0);
}
function closeIdeMenu() { $$('.vb-popup.idem').forEach(p => p.remove()); if (IDE.menuAnchor) IDE.menuAnchor.classList.remove('open'); if (IDE.menuCloser) window.removeEventListener('mousedown', IDE.menuCloser, true); IDE.menuCloser = null; }
function isCmdDisabled(id) {
  const running = IDE.running, noProj = !IDE.project;
  if (id === 'stop') return !running;
  if (id === 'break') return true;
  if (id === 'redo' || id === 'undo' || id === 'showProps') return running || noProj;
  if (['run', 'restart', 'export'].includes(id)) return id === 'restart' ? !running : (running || noProj);
  if (id === 'palette') return false;
  if (['new', 'openFolder', 'openFiles', 'demo', 'about', 'help', 'options', 'toggleImm', 'toggleRight', 'toggleTools'].includes(id)) return running && !['about', 'help', 'toggleImm'].includes(id);
  return running || noProj;
}
function buildToolbar() {
  // barra no estilo do VB 5: só ícones, separadores finos, fundo redondo ao passar o mouse
  const tb = $('#toolbar');
  const B = (icon, title, id, cls) => { const b = h('button', { title, html: TB_ICONS[icon], 'data-cmd': id, class: 'tbi' + (cls ? ' ' + cls : '') }); b.onclick = () => cmd(id); return b; };
  const S = () => h('span', { class: 'sep' });
  tb.append(
    B('addProject', 'Add Project (New Project)', 'new'), B('addForm', 'Add Form', 'addForm'), B('addModule', 'Add Module', 'addModule'), B('menuEd', 'Menu Editor (Ctrl+E)', 'menuEditor'), S(),
    B('open', 'Open Project (Ctrl+O)', 'openFolder'), B('save', 'Save Project (Ctrl+S)', 'save'), S(),
    B('cut', 'Cut (Ctrl+X)', 'cut'), B('copy', 'Copy (Ctrl+C)', 'copy'), B('paste', 'Paste (Ctrl+V)', 'paste'), B('search', 'Find (Ctrl+F)', 'find'), S(),
    B('undo', 'Undo (Ctrl+Z)', 'undo'), B('redo', 'Redo (Ctrl+Y)', 'redo'), S(),
    B('start', 'Start (F5)', 'run', 'go'), B('brk', 'Break (not available yet)', 'break'), B('end', 'End', 'stop', 'halt'), S(),
    B('explorer', 'Project Explorer (Ctrl+R)', 'toggleRight'), B('props', 'Properties Window (F4)', 'showProps'), B('imm', 'Immediate Window (Ctrl+G)', 'toggleImm'), B('toolbox', 'Toolbox', 'toggleTools'), S(),
    h('span', { class: 'tbinfo', title: 'Position (Left, Top)', html: TB_ICONS.pos + '<b id="tbpos">0, 0</b>' }),
    h('span', { class: 'tbinfo', title: 'Size (Width x Height)', html: TB_ICONS.size + '<b id="tbsize">0 x 0</b>' }));
}
function refreshToolbar() {
  $$('#toolbar button[data-cmd]').forEach(b => { b.disabled = isCmdDisabled(b.dataset.cmd); });
  const r = $('#bRun'), s = $('#bStop'); if (r) r.disabled = isCmdDisabled('run'); if (s) s.disabled = isCmdDisabled('stop');
  const chip = $('#projchip'); if (chip) chip.classList.toggle('dirty', !!(IDE.project && IDE.project.dirty));
}
function buildToolbox() {
  const box = $('#toolbox .tools'); box.innerHTML = '';
  const add = (type, title) => { const art = TOOL_ART[type] || TOOL_ART.unknown; const t = h('div', { class: 'tool' + ((IDE.tool || 'pointer') === type ? ' on' : ''), title, html: `<span class="tart">${art.svg}</span>` }); t.onclick = () => { IDE.tool = type === 'pointer' ? null : type; buildToolbox(); }; t.ondblclick = () => { if (type !== 'pointer') { addControlDefault(type); IDE.tool = null; buildToolbox(); } }; box.appendChild(t); };
  add('pointer', 'Pointer');
  for (const t of TOOL_ORDER) add(t, ctlDef(t).tool);
}

// ---------- Comandos ----------
async function cmd(id) {
  if (isCmdDisabled(id) && !['run'].includes(id)) { if (isCmdDisabled(id)) return; }
  switch (id) {
    case 'new': if (!(await confirmDiscard())) return; IDE.dirHandle = null; setProject(newProject()); openDesigner(IDE.project.modules[0]); break;
    case 'openFolder': if (!(await confirmDiscard())) return; await pickFolder(); break;
    case 'openFiles': if (!(await confirmDiscard())) return; pickFiles('.vbp,.frm,.frx,.bas,.cls', async files => { await openProjectFromList(files.map(f => ({ path: f.name, file: f })), null); }); break;
    case 'demo': if (!(await confirmDiscard())) return; IDE.dirHandle = null; setProject(demoProject()); openDesigner(IDE.project.modules[0]); break;
    case 'save': await saveProject(false); break;
    case 'saveAs': await saveProject(true); break;
    case 'zip': downloadZip(); break;
    case 'export': exportApp(); break;
    case 'close': if (!(await confirmDiscard())) return; closeAllDocs(); IDE.project = null; IDE.dirHandle = null; localStorage.removeItem('neobasic.autosave'); refreshAll(); break;
    case 'undo': doUndo(); break;
    case 'redo': doRedo(); break;
    case 'showProps': { $('#right').style.display = ''; const g = $('#pgrid'); if (g) g.focus(); break; }
    case 'menuEditor': { const d = IDE.activeDoc; const m = d && d.mod && d.mod.kind === 'form' ? d.mod : (IDE.sel && IDE.sel.mod && IDE.sel.mod.kind === 'form' ? IDE.sel.mod : null); if (m) { if (!d || d.kind !== 'design' || d.mod !== m) openDesigner(m); menuEditorDialog(m); } else IDE.ui.msgBox('Open a form first to edit its menus.', 64, APP_NAME); break; }
    case 'cut': if (inDesigner()) { copySel(); deleteSel(); } else document.execCommand('cut'); break;
    case 'copy': if (inDesigner()) copySel(); else document.execCommand('copy'); break;
    case 'paste': if (inDesigner()) pasteSel(); else navigator.clipboard && navigator.clipboard.readText().then(t => document.execCommand('insertText', false, t)).catch(() => { }); break;
    case 'delete': if (inDesigner()) deleteSel(); break;
    case 'find': openFind(); break;
    case 'gotoLine': gotoLinePrompt(); break;
    case 'viewCode': viewCode(); break;
    case 'viewObj': viewObject(); break;
    case 'toggleImm': { const e = $('#immediate'); e.style.display = e.style.display === 'none' ? '' : 'none'; if (e.style.display !== 'none') $('#immin').focus(); break; }
    case 'toggleRight': { const e = $('#right'); e.style.display = e.style.display === 'none' ? '' : 'none'; break; }
    case 'toggleTools': { const e = $('#toolbox'); e.style.display = e.style.display === 'none' ? '' : 'none'; break; }
    case 'addForm': addModule('form'); break;
    case 'addMDI': if (IDE.project.modules.some(m => m.kind === 'form' && m.frm.isMDI)) { IDE.ui.msgBox('The project already has an MDI form.', 48, APP_NAME); break; } addModule('mdi'); break;
    case 'addModule': addModule('std'); break;
    case 'addClass': addModule('class'); break;
    case 'importSheet': importSpreadsheet(); break;
    case 'addFile': pickFiles('.frm,.frx,.bas,.cls', addFilesToProject); break;
    case 'addDb': pickFiles('.mdb,.accdb,.db,.sqlite,.sqlite3', async files => {
      const P = IDE.project; if (!P) return; P.dbFiles = P.dbFiles || [];
      for (const f of files) { const bytes = new Uint8Array(await f.arrayBuffer()); P.dbFiles = P.dbFiles.filter(x => x.name.toLowerCase() !== f.name.toLowerCase()); P.dbFiles.push({ name: f.name, path: f.name, bytes, inFolder: false }); if (IDE.host.dbCache) IDE.host.dbCache.delete(f.name.toLowerCase().replace(/\.[^.]*$/, '')); }
      markDirty(); refreshExplorer(); refreshDataPanel(); setStatus(`Database added: ${files.map(f => f.name).join(', ')}`);
    }); break;
    case 'removeItem': removeSelectedModule(); break;
    case 'projProps': projectPropsDialog(); break;
    case 'alignGrid': formatSel('grid'); break;
    case 'centerH': formatSel('ch'); break;
    case 'centerV': formatSel('cv'); break;
    case 'front': formatSel('front'); break;
    case 'back': formatSel('back'); break;
    case 'run': if (!IDE.running) startRun(); break;
    case 'stop': stopRun(); break;
    case 'restart': stopRun(); setTimeout(startRun, 50); break;
    case 'options': optionsDialog(); break;
    case 'palette': openPalette(); break;
    case 'help': helpDialog(); break;
    case 'about': IDE.ui.msgBox(`${APP_NAME} ${APP_VERSION}\n\nA free, open-source development environment for Visual Basic 5/6-style projects.\nRuns on Windows and Linux with the same look.\n\nContains no Microsoft code: it reads and writes the same file formats (.vbp, .frm, .frx, .bas, .cls).`, 64, 'About ' + APP_NAME); break;
  }
  refreshToolbar();
}
async function confirmDiscard() {
  if (!IDE.project || !IDE.project.dirty) return true;
  // projeto que já tem pasta: salva sozinho, sem perguntar
  if (IDE.dirHandle && !IDE.running) { try { await saveProject(false); if (!IDE.project.dirty) return true; } catch (e) { } }
  const r = await IDE.ui.msgBox(`Save changes to the project "${IDE.project.name}"?`, 3 + 48, APP_NAME);
  if (r === 2) return false;
  if (r === 6) await saveProject(false);
  return true;
}
function globalKeys(e) {
  const k = e.key, c = e.ctrlKey || e.metaKey;
  if (IDE.running) {
    // Ctrl+Break (como no VB) encerra o programa que está rodando
    if ((c && (k === 'Pause' || k === 'Cancel')) || k === 'Cancel') { e.preventDefault(); stopRun(); return; }
    if (k === 'F5') { e.preventDefault(); if (e.shiftKey) cmd('restart'); }
    return;
  }
  if (k === 'F5' && !e.shiftKey) { e.preventDefault(); if (c) cmd('export'); else cmd('run'); return; }
  if (k === 'F7') { e.preventDefault(); if (e.shiftKey) viewObject(); else viewCode(); return; }
  if (k === 'F4') { e.preventDefault(); const r = $('#right'); r.style.display = ''; $('#pgrid').focus(); return; }
  if (c && (k.toLowerCase() === 'k' || (e.shiftKey && k.toLowerCase() === 'p'))) { e.preventDefault(); openPalette(); return; }
  const inText = e.target.closest && (e.target.closest('input, textarea, select, [contenteditable]'));
  if (c && k.toLowerCase() === 's') { e.preventDefault(); cmd('save'); return; }
  if (c && k.toLowerCase() === 'o') { e.preventDefault(); cmd('openFolder'); return; }
  if (c && k.toLowerCase() === 'n') { e.preventDefault(); cmd('new'); return; }
  if (c && k.toLowerCase() === 'g') { e.preventDefault(); cmd('toggleImm'); return; }
  if (c && k.toLowerCase() === 'r') { e.preventDefault(); cmd('toggleRight'); return; }
  if (c && k.toLowerCase() === 'd') { e.preventDefault(); cmd('addFile'); return; }
  if (c && k.toLowerCase() === 'f') { e.preventDefault(); cmd('find'); return; }
  if (c && k.toLowerCase() === 'e') { e.preventDefault(); cmd('menuEditor'); return; }
  if (c && k.toLowerCase() === 'l' && activeCodeDoc()) { e.preventDefault(); cmd('gotoLine'); return; }
  if (inText) return;
  if (inDesigner()) {
    if (k === 'Delete') { e.preventDefault(); deleteSel(); }
    else if (c && k.toLowerCase() === 'z' && e.shiftKey) { e.preventDefault(); doRedo(); }
    else if (c && k.toLowerCase() === 'y') { e.preventDefault(); doRedo(); }
    else if (c && k.toLowerCase() === 'z') { e.preventDefault(); doUndo(); }
    else if (c && k.toLowerCase() === 'c') { e.preventDefault(); copySel(); }
    else if (c && k.toLowerCase() === 'x') { e.preventDefault(); copySel(); deleteSel(); }
    else if (c && k.toLowerCase() === 'v') { e.preventDefault(); pasteSel(); }
    else if (c && k.toLowerCase() === 'j') { e.preventDefault(); formatSel(e.shiftKey ? 'back' : 'front'); }

    else if (k.startsWith('Arrow')) { e.preventDefault(); nudgeSel(k, e.shiftKey, c); }
    else if (k === 'Enter') { e.preventDefault(); viewCode(); }
    else if (k === 'Escape') { const s = IDE.sel; if (s && s.node && s.node.parent) selectNode(s.mod, s.node.parent); }
  }
}

// ---------- Projeto na interface ----------
// bancos de dados do projeto: o mesmo nome com .db (alterado pelo NeoBasic) tem preferência sobre o .mdb original
function findDbFile(path) {
  const P = IDE.project; if (!P || !P.dbFiles) return null;
  const base = String(path || '').replace(/\//g, '\\').split('\\').pop().toLowerCase(); const stem = base.replace(/\.[^.]*$/, '');
  const same = P.dbFiles.filter(f => f.name.toLowerCase().replace(/\.[^.]*$/, '') === stem);
  return same.find(f => /\.(db|sqlite3?)$/i.test(f.name)) || same.find(f => f.name.toLowerCase() === base) || same[0] || null;
}
function dbFilesToSave(all) {
  // devolve [{path, data}] dos bancos: alterados viram <nome>.db; com all=true inclui também os originais
  const P = IDE.project; const out = []; if (!P) return out;
  const cache = IDE.host && IDE.host.dbCache;
  const done = new Set();
  if (cache) for (const [stem, e] of cache) {
    if (!e.dirty && !all) continue;
    if (!e.dirty) continue;
    const name = e.name.replace(/\.[^.]*$/, '') + '.db';
    out.push({ path: name, data: e.db.export(), stem, entry: e }); done.add(stem);
  }
  if (all) for (const f of P.dbFiles || []) { const stem = f.name.toLowerCase().replace(/\.[^.]*$/, ''); if (done.has(stem)) continue; if (/\.(db|sqlite3?)$/i.test(f.name) || !(P.dbFiles || []).some(g => g !== f && g.name.toLowerCase().replace(/\.[^.]*$/, '') === stem && /\.(db|sqlite3?)$/i.test(g.name))) out.push({ path: f.name, data: f.bytes }); }
  return out;
}
function afterDbSaved(list) {
  const P = IDE.project; if (!P) return;
  for (const d of list) {
    if (!d.entry) continue;
    d.entry.dirty = false;
    const ex = (P.dbFiles || []).find(f => f.name.toLowerCase() === d.path.toLowerCase());
    if (ex) ex.bytes = d.data; else (P.dbFiles || (P.dbFiles = [])).push({ name: d.path, path: d.path, bytes: d.data, inFolder: true });
  }
  P.dbDirty = false;
}
function setProject(p) {
  closeAllDocs();
  if (IDE.host && IDE.host.dbCache) IDE.host.dbCache.clear();
  if (p && !p.dbFiles) p.dbFiles = [];
  IDE.project = p; IDE.sel = null; IDE.undo = new Map(); IDE.redo = new Map();
  setTimeout(() => refreshDataPanel(), 0);
  if (p) IDE.sel = { mod: p.modules[0], node: p.modules[0].kind === 'form' ? p.modules[0].frm.root : null };
  refreshAll();
  if (p) { const first = p.modules.find(m => m.name.toLowerCase() === String(p.startup).toLowerCase()) || p.modules.find(m => m.kind === 'form') || p.modules[0]; if (first.kind === 'form') openDesigner(first); else openCode(first); }
  autosave();
}
function refreshAll() { refreshExplorer(); renderProps(); updateTitle(); refreshToolbar(); $('#welcome').style.display = IDE.project ? 'none' : ''; }
function updateTitle() {
  const P = IDE.project;
  const t = P ? `${P.name} - ${APP_NAME}${IDE.running ? ' [run]' : ' [design]'}${P.dirty ? ' *' : ''}` : APP_NAME;
  $('#ttext').textContent = t; document.title = t; $('#pjname').textContent = P ? P.name + (IDE.running ? ' [run]' : '') : 'No project'; refreshToolbar();
}
function setStatus(s) { $('#status').textContent = s; }
function log(s) { setStatus(s); }
// Debug.Print junta o texto e atualiza a janela no máximo uma vez por quadro (evita travar com Print dentro de laços)
let immBuf = '', immPending = false;
function imm(s) {
  immBuf += s; if (immBuf.length > 200000) immBuf = immBuf.slice(-100000);
  if (immPending) return; immPending = true;
  const flush = () => { immPending = false; const o = $('#immout'); let t = o.textContent + immBuf; immBuf = ''; if (t.length > 200000) t = t.slice(-100000); o.textContent = t; o.scrollTop = o.scrollHeight; };
  if (typeof requestAnimationFrame !== 'undefined' && !document.hidden) requestAnimationFrame(flush); else setTimeout(flush, 50);
}

// ---------- Explorador ----------
function refreshExplorer() {
  const tree = $('#tree'); tree.innerHTML = '';
  const P = IDE.project; if (!P) return;
  const root = h('div', { class: 'node', html: `<span class="ic">${TB_ICONS.project}</span><b>${esc(P.name)}</b><span class="fn">${esc(P.fileName || P.name + '.vbp')}</span>` });
  root.ondblclick = () => projectPropsDialog();
  tree.appendChild(root);
  const groups = [['form', 'Forms', 'form'], ['std', 'Modules', 'module'], ['class', 'Class Modules', 'cls']];
  for (const [kind, label, icon] of groups) {
    const mods = P.modules.filter(m => m.kind === kind); if (!mods.length) continue;
    const kids = h('div', { class: 'kids' });
    kids.appendChild(h('div', { class: 'node grp', html: `<span class="ic">${TB_ICONS.folder}</span>${label} <span class="fn">${mods.length}</span>` }));
    const sub = h('div', { class: 'kids' });
    for (const m of mods.sort((a, b) => a.name.localeCompare(b.name))) {
      const isStart = P.startup && P.startup.toLowerCase() === m.name.toLowerCase();
      const n = h('div', { class: 'node' + (IDE.sel && IDE.sel.mod === m ? ' sel' : ''), title: m.fileName, html: `<span class="ic">${TB_ICONS[icon]}</span><span>${esc(m.name)}</span>${isStart ? '<span class="star" title="Startup object">★</span>' : ''}${m.dirty ? '<span class="star" title="Modified">●</span>' : ''}` });
      n.onclick = () => { selectModule(m); };
      n.ondblclick = () => { if (m.kind === 'form') openDesigner(m); else openCode(m); };
      sub.appendChild(n);
    }
    kids.appendChild(sub); tree.appendChild(kids);
  }
  if (P.dbFiles && P.dbFiles.length) {
    const kids = h('div', { class: 'kids' });
    kids.appendChild(h('div', { class: 'node grp', html: `<span class="ic">${TB_ICONS.db}</span>Databases <span class="fn">${P.dbFiles.length}</span>` }));
    const sub = h('div', { class: 'kids' });
    for (const f of P.dbFiles) sub.appendChild(h('div', { class: 'node', title: `${f.name} — ${(f.bytes.length / 1024).toFixed(0)} KB`, html: `<span class="ic">${TB_ICONS.db}</span><span>${esc(f.name)}</span>` }));
    kids.appendChild(sub); tree.appendChild(kids);
  }
}
function selectModule(m) { IDE.sel = { mod: m, node: m.kind === 'form' ? m.frm.root : null }; refreshExplorer(); renderProps(); updateSelection(); }
async function addModule(kind) {
  syncEditors();
  let m;
  if (kind === 'form' || kind === 'mdi') { const nm = uniqueModuleName(kind === 'mdi' ? 'MDIForm' : 'Form'); m = makeModule('form', nm, { frm: newFormFrm(nm, kind === 'mdi') }); }
  else if (kind === 'std') { const nm = uniqueModuleName('Module'); m = makeModule('std', nm, { code: '', attributes: [] }); }
  else { const nm = uniqueModuleName('Class'); m = makeModule('class', nm, { code: '', attributes: [], header: [] }); }
  IDE.project.modules.push(m); markDirty(); refreshExplorer();
  if (m.kind === 'form') openDesigner(m); else openCode(m);
}
async function addFilesToProject(files) {
  const map = await readFileEntries(files.map(f => ({ path: f.name, file: f })));
  try {
    const { proj } = loadProjectFromMap(map, null);
    for (const m of proj.modules) { if (findModule(m.name)) { await IDE.ui.msgBox(`A module named ${m.name} already exists in the project.`, 48, APP_NAME); continue; } m.dirty = true; IDE.project.modules.push(m); }
    markDirty(); refreshExplorer();
  } catch (e) { IDE.ui.msgBox(e.message, 16, APP_NAME); }
}
async function removeSelectedModule() {
  const m = IDE.sel && IDE.sel.mod; if (!m) return;
  const r = await IDE.ui.msgBox(`Remove ${m.name} from the project?\n(The file on disk is not deleted.)`, 4 + 32, APP_NAME);
  if (r !== 6) return;
  for (const d of IDE.docs.filter(d => d.mod === m)) closeDoc(d);
  IDE.project.modules = IDE.project.modules.filter(x => x !== m);
  if (IDE.project.startup.toLowerCase() === m.name.toLowerCase()) IDE.project.startup = (IDE.project.modules.find(x => x.kind === 'form') || {}).name || 'Sub Main';
  IDE.sel = IDE.project.modules[0] ? { mod: IDE.project.modules[0], node: IDE.project.modules[0].kind === 'form' ? IDE.project.modules[0].frm.root : null } : null;
  markDirty(); refreshAll();
}

// ---------- Documentos (abas) ----------
function openDoc(mod, kind) {
  let d = IDE.docs.find(x => x.mod === mod && x.kind === kind);
  if (!d) {
    d = { mod, kind, el: h('div', { class: 'doc ' + (kind === 'design' ? 'design' : 'code') }) };
    $('#docs').appendChild(d.el); IDE.docs.push(d);
    if (kind === 'design') buildDesigner(d); else buildCodeEditor(d);
  }
  activateDoc(d); return d;
}
function activateDoc(d) {
  if (IDE.activeDoc && IDE.activeDoc.kind === 'code') syncEditor(IDE.activeDoc);
  IDE.activeDoc = d;
  for (const x of IDE.docs) x.el.classList.toggle('on', x === d);
  renderTabs();
  if (d.kind === 'design') { renderDesigner(d); if (!IDE.sel || IDE.sel.mod !== d.mod) selectNode(d.mod, d.mod.frm.root); else updateSelection(); }
  else { refreshCodeCombos(d); d.ta.focus(); if (!IDE.sel || IDE.sel.mod !== d.mod) { IDE.sel = { mod: d.mod, node: d.mod.kind === 'form' ? d.mod.frm.root : null }; refreshExplorer(); renderProps(); } }
}
function renderTabs() {
  const tabs = $('#tabs'); tabs.innerHTML = '';
  for (const d of IDE.docs) {
    const t = h('div', { class: 'tab' + (d === IDE.activeDoc ? ' on' : ''), title: d.mod.fileName }, h('span', { class: 'tico', html: d.kind === 'design' ? TB_ICONS.form : TB_ICONS.code }), h('span', { class: 't' }, `${d.mod.name}${d.kind === 'design' ? '' : '.' + ({ form: 'frm', std: 'bas', class: 'cls' }[d.mod.kind])}`), h('span', { class: 'c', html: '✕' }));
    t.onmousedown = (ev) => { if (ev.target.classList.contains('c')) return; activateDoc(d); };
    t.querySelector('.c').onclick = () => closeDoc(d);
    tabs.appendChild(t);
  }
}
function closeDoc(d) { if (d.kind === 'code') syncEditor(d); d.el.remove(); IDE.docs = IDE.docs.filter(x => x !== d); if (IDE.activeDoc === d) { IDE.activeDoc = null; const n = IDE.docs[IDE.docs.length - 1]; if (n) activateDoc(n); } renderTabs(); }
function closeAllDocs() { syncEditors(); for (const d of IDE.docs) d.el.remove(); IDE.docs = []; IDE.activeDoc = null; renderTabs(); }
function openDesigner(m) { return openDoc(m, 'design'); }
function openCode(m) { return openDoc(m, 'code'); }
function viewCode() { const s = IDE.sel; if (!s || !s.mod) return; const d = openCode(s.mod); if (s.mod.kind === 'form' && s.node && s.node !== s.mod.frm.root && IDE.activeDoc === d) { /* fica na seção atual */ } }
function viewObject() { const s = IDE.sel; if (s && s.mod && s.mod.kind === 'form') openDesigner(s.mod); }
function inDesigner() { return IDE.activeDoc && IDE.activeDoc.kind === 'design' && !IDE.running; }
function activeCodeDoc() { return IDE.activeDoc && IDE.activeDoc.kind === 'code' ? IDE.activeDoc : null; }

// ---------- Designer ----------
function nodePath(m, node) { const idx = []; let n = node; while (n && n.parent) { idx.unshift(n.parent.children.indexOf(n)); n = n.parent; } return idx.join('.'); }
function nodeByPath(m, path) { let n = m.frm.root; if (!path) return n; for (const i of path.split('.')) n = n.children[Number(i)]; return n; }
function buildDesigner(d) {
  d.el.innerHTML = '';
  d.surf = h('div', { class: 'dsurf nb-root' }); d.el.appendChild(d.surf);
  d.el.addEventListener('mousedown', ev => designerMouseDown(d, ev));
  d.el.addEventListener('dblclick', ev => designerDblClick(d, ev));
  d.el.addEventListener('scroll', () => updateSelection());
}
function renderDesigner(d) {
  const m = d.mod, root = m.frm.root;
  const P = nodeProps(root, frxLookupFor(m));
  d.surf.innerHTML = '';
  const w = h('div', { class: 'vb-window design skin-' + NB_SKIN + (P.borderstyle === 0 ? ' bs0' : '') + ((P.borderstyle === 2 || P.borderstyle === 5) ? ' sizable' : '') });
  const showTitle = P.borderstyle !== 0;
  w.innerHTML = `${showTitle ? `<div class="vb-title"><span class="vb-ticon" style="${P.icon && P.icon.url ? `background-image:url(${P.icon.url})` : ''}"></span><span class="vb-tcap"></span><span class="vb-tbtns">${P.controlbox !== false ? `${P.minbutton !== false ? '<b class="tb-min"></b>' : ''}${P.maxbutton !== false ? '<b class="tb-max"></b>' : ''}<b class="tb-close"></b>` : ''}</span></div>` : ''}<div class="vb-menubar"></div><div class="vb-client dclient"></div>`;
  if (showTitle) w.querySelector('.vb-tcap').textContent = P.caption || '';
  const mb = w.querySelector('.vb-menubar');
  const menus = root.children.filter(c => /\.menu$/i.test(c.type));
  if (menus.length) { for (const mn of menus) { const mp = nodeProps(mn); if (mp.visible === false) continue; mb.appendChild(h('span', { class: 'vb-mtop', html: mnemonicHtml(mp.caption || '') })); } } else mb.style.display = 'none';
  mb.onclick = (ev) => { ev.stopPropagation(); menuEditorDialog(m); };
  const client = w.querySelector('.vb-client');
  const cw = (P.clientwidth || 4680) / 15, ch = (P.clientheight || 3195) / 15;
  client.style.width = cw + 'px'; client.style.height = ch + 'px';
  client.style.backgroundColor = vbColorCss(m.frm.isMDI ? (P.backcolor ?? -2147483636) : P.backcolor);
  if (P.picture && P.picture.url) client.style.backgroundImage = `url(${P.picture.url}), radial-gradient(#000 0.6px, transparent 0.8px)`;
  client.classList.toggle('nogrid', !IDE.opts.grid);
  applyFont(client, P.font);
  client.node = root;
  d.surf.appendChild(w);
  d.win = w; d.client = client;
  const lookup = frxLookupFor(m);
  const renderInto = (node, cont) => {
    for (const ch2 of node.children) {
      if (/\.menu$/i.test(ch2.type)) continue;
      const cp = nodeProps(ch2, lookup);
      const el = createCtlElement(ch2.type, cp, { design: true, scale: 1 / 15 });
      el.node = ch2;
      if (ctlDef(ch2.type).unknown) el.title = ch2.type;
      cont.appendChild(el);
      if (ch2.children.length) renderInto(ch2, el);
    }
  };
  renderInto(root, client);
  // alças do formulário
  d.selLayer = h('div', { class: 'dsel-layer' }); d.surf.appendChild(d.selLayer);
  $('#ssize').textContent = `${Math.round(P.clientwidth || 4680)} x ${Math.round(P.clientheight || 3195)}`;
  updateSelection();
}
function rerenderActive() { if (IDE.activeDoc && IDE.activeDoc.kind === 'design') renderDesigner(IDE.activeDoc); }
function elForNode(d, node) { if (!d.client) return null; if (node === d.mod.frm.root) return d.client; let found = null; d.client.querySelectorAll('.vbc').forEach(e => { if (e.node === node) found = e; }); return found; }
function updateSelection() {
  const d = IDE.activeDoc; if (!d || d.kind !== 'design' || !d.selLayer) return;
  d.selLayer.innerHTML = '';
  const s = IDE.sel; if (!s || s.mod !== d.mod || !s.node) return;
  const el = elForNode(d, s.node); if (!el) return;
  const sr = d.surf.getBoundingClientRect(); const r = el.getBoundingClientRect();
  const L = r.left - sr.left, T = r.top - sr.top, W = r.width, H = r.height;
  const isForm = s.node === d.mod.frm.root;
  const isLine = s.node.type === 'VB.Line';
  const many = selNodes();
  if (many.length > 1) {
    for (const n of many) { const e2 = elForNode(d, n); if (!e2) continue; const r2 = e2.getBoundingClientRect(); d.selLayer.appendChild(h('div', { class: 'dsel multi' + (n === s.node ? ' prim' : ''), style: `left:${r2.left - sr.left}px;top:${r2.top - sr.top}px;width:${r2.width}px;height:${r2.height}px` })); }
    const tp0 = $('#tbpos'), tz0 = $('#tbsize'); if (tp0) tp0.textContent = `${many.length} selected`; if (tz0) tz0.textContent = '';
    return;
  }
  if (!isForm) d.selLayer.appendChild(h('div', { class: 'dsel', style: `left:${L}px;top:${T}px;width:${W}px;height:${H}px` }));
  let handles;
  if (isForm) handles = [['e', L + W, T + H / 2], ['s', L + W / 2, T + H], ['se', L + W, T + H]];
  else if (isLine) { const P = nodeProps(s.node); const cr = el.parentNode.getBoundingClientRect(); handles = [['p1', cr.left - sr.left + P.x1 / 15, cr.top - sr.top + P.y1 / 15], ['p2', cr.left - sr.left + P.x2 / 15, cr.top - sr.top + P.y2 / 15]]; }
  else handles = [['nw', L, T], ['n', L + W / 2, T], ['ne', L + W, T], ['e', L + W, T + H / 2], ['se', L + W, T + H], ['s', L + W / 2, T + H], ['sw', L, T + H], ['w', L, T + H / 2]];
  if (ctlDef(s.node.type).fixedSize) handles = [];
  for (const [k, x, y] of handles) {
    const hd = h('div', { class: 'dh' + (isForm ? ' form' : ''), style: `left:${x - 3}px;top:${y - 3}px;cursor:${{ n: 'ns', s: 'ns', e: 'ew', w: 'ew', nw: 'nwse', se: 'nwse', ne: 'nesw', sw: 'nesw', p1: 'move', p2: 'move' }[k]}-resize` });
    hd.dataset.h = k; d.selLayer.appendChild(hd);
  }
  const P = nodeProps(s.node);
  const tp = $('#tbpos'), tz = $('#tbsize');
  if (tp) tp.textContent = isLine ? `${Math.round(P.x1)}, ${Math.round(P.y1)}` : `${Math.round(P.left || 0)}, ${Math.round(P.top || 0)}`;
  if (tz) tz.textContent = isLine ? `${Math.round(Math.abs(P.x2 - P.x1))} x ${Math.round(Math.abs(P.y2 - P.y1))}` : isForm ? `${Math.round((P.clientwidth || 4680) + 120)} x ${Math.round((P.clientheight || 3195) + 405)}` : `${Math.round(P.width)} x ${Math.round(P.height)}`;
  $('#spos').textContent = isForm ? `${s.node.name}` : isLine ? `${P.x1}, ${P.y1} - ${P.x2}, ${P.y2}` : `${Math.round(P.left)}, ${Math.round(P.top)}`;
  $('#ssize').textContent = isForm ? `${Math.round(P.clientwidth)} x ${Math.round(P.clientheight)}` : isLine ? '' : `${Math.round(P.width)} x ${Math.round(P.height)}`;
}
// seleção múltipla: IDE.multi guarda os controles selecionados (Shift/Ctrl+clique ou arrastar um retângulo)
function selNodes() { const s = IDE.sel; if (!s || !s.node) return []; if (IDE.multi && IDE.multi.mod === s.mod && IDE.multi.nodes.length > 1) return IDE.multi.nodes; return [s.node]; }
function selectNode(m, node, keepMulti) {
  if (!keepMulti) IDE.multi = null;
  IDE.sel = { mod: m, node };
  refreshExplorer(); renderProps(); updateSelection();
}
function pushUndo(m, keepRedo) { const st = IDE.undo.get(m.id) || []; st.push({ root: m.frm.root.clone(), code: m.frm.code }); if (st.length > 60) st.shift(); IDE.undo.set(m.id, st); if (!keepRedo && IDE.redo) IDE.redo.delete(m.id); }
function doRedo() {
  const d = IDE.activeDoc; if (!d) return;
  if (d.kind === 'code') { document.execCommand('redo'); return; }
  const st = IDE.redo && IDE.redo.get(d.mod.id); if (!st || !st.length) { setStatus('Nothing to redo.'); return; }
  pushUndo(d.mod, true);
  const s = st.pop(); d.mod.frm.root = s.root; d.mod.frm.code = s.code; d.mod.dirty = true; markDirty();
  renderDesigner(d); selectNode(d.mod, d.mod.frm.root);
  for (const cd of IDE.docs.filter(x => x.mod === d.mod && x.kind === 'code')) loadEditorText(cd);
}
function doUndo() {
  const d = IDE.activeDoc; if (!d) return;
  if (d.kind === 'code') { document.execCommand('undo'); return; }
  const st = IDE.undo.get(d.mod.id); if (!st || !st.length) { setStatus('Nothing to undo.'); return; }
  if (!IDE.redo) IDE.redo = new Map(); const rs = IDE.redo.get(d.mod.id) || []; rs.push({ root: d.mod.frm.root.clone(), code: d.mod.frm.code }); IDE.redo.set(d.mod.id, rs);
  const s = st.pop(); d.mod.frm.root = s.root; d.mod.frm.code = s.code; d.mod.dirty = true; markDirty();
  renderDesigner(d); selectNode(d.mod, d.mod.frm.root);
  for (const cd of IDE.docs.filter(x => x.mod === d.mod && x.kind === 'code')) loadEditorText(cd);
}
function isContainerType(t) { return t === 'VB.Frame' || t === 'VB.PictureBox'; }
function containerAt(d, cx, cy, exclude) {
  // contêiner mais profundo sob o ponto (em coordenadas de cliente da janela)
  let best = { el: d.client, node: d.mod.frm.root };
  const walk = (el) => {
    for (const c of el.children) {
      if (!c.classList || !c.classList.contains('vbc') || c === exclude) continue;
      if (!isContainerType(c.node.type)) continue;
      const r = c.getBoundingClientRect();
      if (cx >= r.left && cx <= r.right && cy >= r.top && cy <= r.bottom) { best = { el: c, node: c.node }; walk(c); }
    }
  };
  walk(d.client);
  return best;
}
const snap = (v) => IDE.opts.grid ? Math.round(v / 120) * 120 : Math.round(v);
function uniqueCtlName(m, base) {
  const names = new Set(allNodes(m).map(n => n.name.toLowerCase())); names.add(m.name.toLowerCase());
  let i = 1; while (names.has((base + i).toLowerCase())) i++; return base + i;
}
function nextTabIndex(m) { let mx = -1; for (const n of allNodes(m)) { const t = n.get('TabIndex'); if (typeof t === 'number' && t > mx) mx = t; } return mx + 1; }
function createNode(m, type, parentNode, L, T, W, H) {
  const name = uniqueCtlName(m, ctlBaseName(type));
  const n = new CtlNode(type, name); n.parent = parentNode;
  const def = ctlDef(type);
  if (['VB.Label', 'VB.CommandButton', 'VB.CheckBox', 'VB.OptionButton', 'VB.Frame', 'VB.Data'].includes(type)) n.setRaw('Caption', quote(name));
  if (type === 'VB.TextBox' || type === 'VB.ComboBox') n.setRaw('Text', quote(name));
  if (type === 'VB.Line') { n.setRaw('X1', String(Math.round(L))); n.setRaw('X2', String(Math.round(L + W))); n.setRaw('Y1', String(Math.round(T))); n.setRaw('Y2', String(Math.round(T + H))); }
  else {
    if (!def.fixedSize) n.setRaw('Height', String(Math.round(H)));
    n.setRaw('Left', String(Math.round(L)));
    if (!['VB.Label', 'VB.Frame', 'VB.Image', 'VB.Shape', 'VB.Timer'].includes(type) && !def.unknown) n.setRaw('TabIndex', String(nextTabIndex(m)));
    n.setRaw('Top', String(Math.round(T)));
    if (!def.fixedSize) n.setRaw('Width', String(Math.round(W)));
  }
  if (type === 'VB.HScrollBar' || type === 'VB.VScrollBar') { /* padrões */ }
  parentNode.children.push(n);
  return n;
}
function addControlDefault(type) {
  const d = IDE.activeDoc; if (!d || d.kind !== 'design') return;
  pushUndo(d.mod);
  const def = ctlDef(type); const P = nodeProps(d.mod.frm.root);
  const W = def.w || 1215, H = def.h || 495;
  const n = type === 'VB.Line' ? createNode(d.mod, type, d.mod.frm.root, snap(P.clientwidth / 2 - 600), snap(P.clientheight / 2), 1200, 0) : createNode(d.mod, type, d.mod.frm.root, snap((P.clientwidth - W) / 2), snap((P.clientheight - H) / 2), W, H);
  d.mod.dirty = true; markDirty(); renderDesigner(d); selectNode(d.mod, n);
}
function designerDblClick(d, ev) {
  if (IDE.running) return;
  const el = ev.target.closest('.vbc') || ev.target.closest('.vb-client');
  if (!el) return;
  const node = el.node || d.mod.frm.root;
  jumpToEvent(d.mod, node);
}
function designerMouseDown(d, ev) {
  if (IDE.running || ev.button !== 0) return;
  const m = d.mod, root = m.frm.root;
  const hd = ev.target.closest('.dh');
  if (hd) return startResize(d, ev, hd.dataset.h);
  const ctlEl = ev.target.closest('.vbc');
  const inClient = ev.target.closest('.vb-client');
  if (!inClient && !ctlEl) { if (ev.target.closest('.vb-window')) selectNode(m, root); return; }
  ev.preventDefault();
  if (IDE.tool) return startDraw(d, ev, IDE.tool);
  if (ctlEl) {
    const node = ctlEl.node; const cur = selNodes();
    if (ev.shiftKey || ev.ctrlKey) {
      // Shift/Ctrl + clique: junta ou tira o controle da seleção
      let list = cur.filter(n => n !== root && n.parent === node.parent);
      if (list.includes(node)) { list = list.filter(n => n !== node); if (!list.length) { selectNode(m, root); return; } IDE.multi = { mod: m, nodes: list }; selectNode(m, list[list.length - 1], true); setStatus(`${list.length} controls selected`); return; }
      list.push(node); IDE.multi = { mod: m, nodes: list }; selectNode(m, node, true); if (list.length > 1) setStatus(`${list.length} controls selected — drag one of them to move all`);
      return startMove(d, ev, ctlEl);
    }
    if (cur.length > 1 && cur.includes(node)) { IDE.sel = { mod: m, node }; return startMove(d, ev, ctlEl); }
    selectNode(m, node); return startMove(d, ev, ctlEl);
  }
  return startMarquee(d, ev);
}
// arrastar no fundo do formulário: retângulo que seleciona vários controles
function startMarquee(d, ev) {
  const m = d.mod, root = m.frm.root; const cr = d.client.getBoundingClientRect(); const sr = d.surf.getBoundingClientRect();
  const x0 = ev.clientX, y0 = ev.clientY; let x1 = x0, y1 = y0, on = false;
  const rb = h('div', { class: 'rubber' });
  const mv = e => { x1 = e.clientX; y1 = e.clientY; if (!on && Math.abs(x1 - x0) + Math.abs(y1 - y0) < 5) return; if (!on) { on = true; d.surf.appendChild(rb); } Object.assign(rb.style, { left: (Math.min(x0, x1) - sr.left) + 'px', top: (Math.min(y0, y1) - sr.top) + 'px', width: Math.abs(x1 - x0) + 'px', height: Math.abs(y1 - y0) + 'px' }); };
  const up = e => {
    window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', up); rb.remove();
    if (!on) { selectNode(m, root); return; }
    const L = (Math.min(x0, x1) - cr.left) * 15, T = (Math.min(y0, y1) - cr.top) * 15, R = (Math.max(x0, x1) - cr.left) * 15, B = (Math.max(y0, y1) - cr.top) * 15;
    const hit = root.children.filter(n => { if (/menu$/i.test(n.type)) return false; const q = nodeProps(n); const nl = n.type === 'VB.Line' ? Math.min(q.x1, q.x2) : q.left, nt = n.type === 'VB.Line' ? Math.min(q.y1, q.y2) : q.top; const nr = n.type === 'VB.Line' ? Math.max(q.x1, q.x2) : q.left + (q.width || 420), nb = n.type === 'VB.Line' ? Math.max(q.y1, q.y2) : q.top + (q.height || 420); return nl < R && nr > L && nt < B && nb > T; });
    if (!hit.length) { selectNode(m, root); return; }
    IDE.multi = hit.length > 1 ? { mod: m, nodes: hit } : null; selectNode(m, hit[hit.length - 1], true);
    setStatus(hit.length > 1 ? `${hit.length} controls selected — drag one of them to move all` : hit[0].name);
  };
  window.addEventListener('mousemove', mv); window.addEventListener('mouseup', up);
}
function startDraw(d, ev, type) {
  const m = d.mod; const cont = containerAt(d, ev.clientX, ev.clientY);
  const cr = cont.el.getBoundingClientRect();
  const x0 = ev.clientX - cr.left, y0 = ev.clientY - cr.top;
  const sr = d.surf.getBoundingClientRect();
  const rb = h('div', { class: 'rubber' }); d.surf.appendChild(rb);
  const isLine = type === 'VB.Line';
  let x1 = x0, y1 = y0;
  const draw = () => { const L = Math.min(x0, x1), T = Math.min(y0, y1); Object.assign(rb.style, { left: (cr.left - sr.left + L) + 'px', top: (cr.top - sr.top + T) + 'px', width: Math.abs(x1 - x0) + 'px', height: Math.abs(y1 - y0) + 'px' }); if (isLine) { rb.style.borderStyle = 'none'; rb.style.background = `linear-gradient(${(x1 - x0) * (y1 - y0) >= 0 ? 'to top right' : 'to bottom right'}, transparent calc(50% - .5px), #000 50%, transparent calc(50% + .5px))`; } };
  draw();
  const mv = e => { x1 = e.clientX - cr.left; y1 = e.clientY - cr.top; draw(); };
  const up = e => {
    window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', up); rb.remove();
    pushUndo(m);
    const def = ctlDef(type);
    let L = Math.min(x0, x1) * 15, T = Math.min(y0, y1) * 15, W = Math.abs(x1 - x0) * 15, H = Math.abs(y1 - y0) * 15;
    let n;
    if (isLine) { const a = [snap(x0 * 15), snap(y0 * 15)], b = [snap(x1 * 15), snap(y1 * 15)]; if (a[0] === b[0] && a[1] === b[1]) b[0] += 1200; n = createNode(m, type, cont.node, a[0], a[1], b[0] - a[0], b[1] - a[1]); }
    else {
      if (W < 60 && H < 60) { W = def.w || 1215; H = def.h || 495; }
      L = snap(L); T = snap(T); W = Math.max(30, snap(W) || W); H = Math.max(30, snap(H) || H);
      if (type === 'VB.ComboBox') H = 315;
      n = createNode(m, type, cont.node, L, T, W, H);
    }
    IDE.tool = null; buildToolbox();
    m.dirty = true; markDirty(); renderDesigner(d); selectNode(m, n);
  };
  window.addEventListener('mousemove', mv); window.addEventListener('mouseup', up);
}
function startMove(d, ev, el) {
  const m = d.mod, node = el.node; const sx = ev.clientX, sy = ev.clientY;
  const isLine = node.type === 'VB.Line';
  const P0 = nodeProps(node);
  const group = selNodes().filter(n => n !== node && n.parent === node.parent).map(n => ({ n, P: nodeProps(n), el: elForNode(d, n) }));
  let moved = false, undoPushed = false;
  const tip = h('div', { class: 'dtip' });
  const mv = e => {
    const dx = (e.clientX - sx) * 15, dy = (e.clientY - sy) * 15;
    if (!moved && Math.abs(dx) < 45 && Math.abs(dy) < 45) return;
    if (!undoPushed) { pushUndo(m); undoPushed = true; d.surf.appendChild(tip); }
    moved = true;
    if (isLine) { const ddx = snap(dx), ddy = snap(dy); node.setRaw('X1', String(Math.round(P0.x1 + ddx))); node.setRaw('X2', String(Math.round(P0.x2 + ddx))); node.setRaw('Y1', String(Math.round(P0.y1 + ddy))); node.setRaw('Y2', String(Math.round(P0.y2 + ddy))); }
    else { node.setRaw('Left', String(Math.round(snap(P0.left + dx)))); node.setRaw('Top', String(Math.round(snap(P0.top + dy)))); }
    // os outros selecionados andam a mesma distância
    { const ddx = isLine ? snap(dx) : snap(P0.left + dx) - P0.left, ddy = isLine ? snap(dy) : snap(P0.top + dy) - P0.top;
      for (const g of group) { if (g.n.type === 'VB.Line') { g.n.setRaw('X1', String(Math.round(g.P.x1 + ddx))); g.n.setRaw('X2', String(Math.round(g.P.x2 + ddx))); g.n.setRaw('Y1', String(Math.round(g.P.y1 + ddy))); g.n.setRaw('Y2', String(Math.round(g.P.y2 + ddy))); } else { g.n.setRaw('Left', String(Math.round(g.P.left + ddx))); g.n.setRaw('Top', String(Math.round(g.P.top + ddy))); } if (g.el) updateCtlElement(g.el, g.n.type, nodeProps(g.n, frxLookupFor(m)), { design: true, scale: 1 / 15 }); } }
    const P = nodeProps(node, frxLookupFor(m)); updateCtlElement(el, node.type, P, { design: true, scale: 1 / 15 });
    updateSelection();
    const sr = d.surf.getBoundingClientRect(); tip.textContent = isLine ? `${P.x1}, ${P.y1}` : `${P.left}, ${P.top}`; tip.style.left = (e.clientX - sr.left + 12) + 'px'; tip.style.top = (e.clientY - sr.top + 14) + 'px';
  };
  const up = () => { window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', up); tip.remove(); if (moved) { m.dirty = true; markDirty(); renderProps(); } };
  window.addEventListener('mousemove', mv); window.addEventListener('mouseup', up);
}
function startResize(d, ev, k) {
  ev.preventDefault(); ev.stopPropagation();
  const m = d.mod, node = IDE.sel.node; const isForm = node === m.frm.root;
  const P0 = nodeProps(node); const sx = ev.clientX, sy = ev.clientY;
  pushUndo(m);
  const tip = h('div', { class: 'dtip' }); d.surf.appendChild(tip);
  const mv = e => {
    const dx = (e.clientX - sx) * 15, dy = (e.clientY - sy) * 15;
    if (isForm) {
      let cw = P0.clientwidth, ch = P0.clientheight;
      if (k.includes('e')) cw = Math.max(600, snap(P0.clientwidth + dx)); if (k.includes('s')) ch = Math.max(300, snap(P0.clientheight + dy));
      setFormClientSize(node, cw, ch);
      d.client.style.width = cw / 15 + 'px'; d.client.style.height = ch / 15 + 'px';
      tip.textContent = `${cw} x ${ch}`;
    } else if (node.type === 'VB.Line') {
      const ddx = snap(dx), ddy = snap(dy);
      if (k === 'p1') { node.setRaw('X1', String(Math.round(P0.x1 + ddx))); node.setRaw('Y1', String(Math.round(P0.y1 + ddy))); } else { node.setRaw('X2', String(Math.round(P0.x2 + ddx))); node.setRaw('Y2', String(Math.round(P0.y2 + ddy))); }
      const el = elForNode(d, node); updateCtlElement(el, node.type, nodeProps(node), { design: true, scale: 1 / 15 });
    } else {
      let L = P0.left, T = P0.top, W = P0.width, H = P0.height;
      if (k.includes('e')) W = snap(P0.width + dx); if (k.includes('s')) H = snap(P0.height + dy);
      if (k.includes('w')) { L = snap(P0.left + dx); W = P0.width + (P0.left - L); } if (k.includes('n')) { T = snap(P0.top + dy); H = P0.height + (P0.top - T); }
      W = Math.max(30, W); H = Math.max(30, H);
      node.setRaw('Left', String(Math.round(L))); node.setRaw('Top', String(Math.round(T))); node.setRaw('Width', String(Math.round(W))); node.setRaw('Height', String(Math.round(H)));
      const el = elForNode(d, node); updateCtlElement(el, node.type, nodeProps(node, frxLookupFor(m)), { design: true, scale: 1 / 15 });
      tip.textContent = `${Math.round(W)} x ${Math.round(H)}`;
    }
    updateSelection();
    const sr = d.surf.getBoundingClientRect(); tip.style.left = (e.clientX - sr.left + 12) + 'px'; tip.style.top = (e.clientY - sr.top + 14) + 'px';
  };
  const up = () => { window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', up); tip.remove(); m.dirty = true; markDirty(); renderDesigner(d); renderProps(); };
  window.addEventListener('mousemove', mv); window.addEventListener('mouseup', up);
}
function setFormClientSize(node, cw, ch) {
  const P = nodeProps(node);
  node.setRaw('ClientWidth', String(Math.round(cw))); node.setRaw('ClientHeight', String(Math.round(ch)));
  if (Number(P.scalemode) === 1 || P.scalemode === undefined) { if (node.findProp('ScaleWidth')) node.setRaw('ScaleWidth', String(Math.round(cw))); if (node.findProp('ScaleHeight')) node.setRaw('ScaleHeight', String(Math.round(ch))); }
  else if (Number(P.scalemode) === 3) { if (node.findProp('ScaleWidth')) node.setRaw('ScaleWidth', String(Math.round(cw / 15))); if (node.findProp('ScaleHeight')) node.setRaw('ScaleHeight', String(Math.round(ch / 15))); }
  if (node.findProp('Width')) node.setRaw('Width', String(Math.round(cw + 120)));
  if (node.findProp('Height')) node.setRaw('Height', String(Math.round(ch + 405 + (node.children.some(c => /menu$/i.test(c.type)) ? 300 : 0))));
}
function deleteSel() {
  const s = IDE.sel; if (!s || !s.node || !s.node.parent) return;
  pushUndo(s.mod);
  const all = selNodes(); const p = s.node.parent; p.children = p.children.filter(c => !all.includes(c)); IDE.multi = null;
  s.mod.dirty = true; markDirty(); renderDesigner(IDE.activeDoc); selectNode(s.mod, p);
}
function copySel() { const s = IDE.sel; if (!s || !s.node || !s.node.parent) return; IDE.clip = s.node.clone(); setStatus(`${s.node.name} copied.`); }
function pasteSel() {
  const d = IDE.activeDoc; if (!d || d.kind !== 'design' || !IDE.clip) return;
  const m = d.mod; pushUndo(m);
  const target = (IDE.sel && IDE.sel.mod === m && IDE.sel.node && isContainerType(IDE.sel.node.type)) ? IDE.sel.node : m.frm.root;
  const n = IDE.clip.clone();
  const rename = (x) => { x.name = uniqueCtlName(m, ctlBaseName(x.type)); x.remove('Index'); if (x.findProp('TabIndex')) x.setRaw('TabIndex', String(nextTabIndex(m))); x.children.forEach(rename); };
  n.parent = target; target.children.push(n); rename(n);
  if (n.type === 'VB.Line') { for (const k of ['X1', 'X2', 'Y1', 'Y2']) n.setRaw(k, String(Number(n.get(k, 0)) + 120)); }
  else { n.setRaw('Left', String(Number(n.get('Left', 0)) + 120)); n.setRaw('Top', String(Number(n.get('Top', 0)) + 120)); }
  m.dirty = true; markDirty(); renderDesigner(d); selectNode(m, n);
}
function nudgeSel(k, shift, ctrl) {
  const s = IDE.sel; if (!s || !s.node || !s.node.parent) return;
  const step = ctrl ? 15 : (IDE.opts.grid ? 120 : 15);
  const dx = k === 'ArrowLeft' ? -step : k === 'ArrowRight' ? step : 0, dy = k === 'ArrowUp' ? -step : k === 'ArrowDown' ? step : 0;
  pushUndo(s.mod);
  for (const n of selNodes()) {
  if (n.type === 'VB.Line') { for (const [kk, dd] of [['X1', dx], ['X2', dx], ['Y1', dy], ['Y2', dy]]) n.setRaw(kk, String(Number(n.get(kk, 0)) + dd)); }
  else if (shift) { n.setRaw('Width', String(Math.max(30, Number(n.get('Width', 0)) + dx))); n.setRaw('Height', String(Math.max(30, Number(n.get('Height', 0)) + dy))); }
  else { n.setRaw('Left', String(Number(n.get('Left', 0)) + dx)); n.setRaw('Top', String(Number(n.get('Top', 0)) + dy)); }
  }
  s.mod.dirty = true; markDirty(); renderDesigner(IDE.activeDoc); renderProps();
}
function formatSel(op) {
  const s = IDE.sel; if (!s || !s.node || !s.node.parent) return;
  const n = s.node; pushUndo(s.mod);
  const parent = n.parent; const PP = nodeProps(parent); const P = nodeProps(n);
  const pw = parent === s.mod.frm.root ? PP.clientwidth : PP.width, ph = parent === s.mod.frm.root ? PP.clientheight : PP.height;
  if (op === 'grid') { n.setRaw('Left', String(Math.round(P.left / 120) * 120)); n.setRaw('Top', String(Math.round(P.top / 120) * 120)); }
  if (op === 'ch') n.setRaw('Left', String(Math.round((pw - P.width) / 2)));
  if (op === 'cv') n.setRaw('Top', String(Math.round((ph - P.height) / 2)));
  if (op === 'front') { parent.children = parent.children.filter(c => c !== n); parent.children.push(n); }
  if (op === 'back') { parent.children = parent.children.filter(c => c !== n); parent.children.unshift(n); }
  s.mod.dirty = true; markDirty(); renderDesigner(IDE.activeDoc); renderProps();
}

// ---------- Propriedades ----------
const PROP_DESC = {
  name: 'Returns the name used in code to identify an object.', caption: 'Text displayed in an object\'s title bar or on the control. Use & for an access key.', text: 'Returns/sets the text contained in the control.',
  backcolor: 'Returns/sets the background color.', forecolor: 'Returns/sets the color of text and graphics.', font: 'Returns a Font object (name, size and style).', left: 'Distance between the left edge of the object and its container (twips).', top: 'Distance between the top edge of the object and its container (twips).',
  width: 'Returns/sets the width (twips).', height: 'Returns/sets the height (twips).', visible: 'Determines whether the object is visible at run time.', enabled: 'Determines whether the object responds to user events.', index: 'Identifies the control in a control array.',
  tabindex: 'Returns/sets the tab order of the object.', tabstop: 'Indicates whether the user can use Tab to give focus to the object.', tooltiptext: 'Returns/sets the text shown when the mouse rests over the control.', tag: 'Stores any extra data needed by your program.',
  interval: 'Number of milliseconds between Timer events (0 disables).', multiline: 'Returns/sets whether the control can accept multiple lines of text.', passwordchar: 'Character displayed instead of the typed text (passwords).', locked: 'Determines whether the control can be edited.',
  borderstyle: 'Returns/sets the border style.', startupposition: 'Returns/sets the position of the form when it first appears.', default: 'The button clicked when the user presses Enter.', cancel: 'The button clicked when the user presses Esc.', value: 'Returns/sets the value of the control.',
  picture: 'Returns/sets the graphic displayed (BMP, ICO, GIF, JPG, PNG).', icon: 'Returns/sets the icon of the window.', list: 'The items in the list (one per line).', sorted: 'Indicates whether the items are sorted alphabetically.', style: 'Returns/sets the appearance and behavior of the control.',
  scalemode: 'Returns/sets the units of measurement for coordinates.', windowstate: 'Returns/sets the visual state of the window.', autosize: 'Determines whether the control resizes to fit its contents.', wordwrap: 'Determines whether the text wraps to multiple lines.', alignment: 'Returns/sets the alignment of the text.',
  keypreview: 'Determines whether form keyboard events occur before control events.', controlbox: 'Indicates whether the title bar buttons are displayed.', clientwidth: 'Width of the client area (twips).', clientheight: 'Height of the client area (twips).',
};
const PROP_CAT = { 'Appearance': ['appearance', 'backcolor', 'backstyle', 'borderstyle', 'caption', 'forecolor', 'text', 'passwordchar', 'fillcolor', 'fillstyle', 'bordercolor', 'borderwidth', 'shape', 'style', 'alignment'], 'Behavior': ['enabled', 'visible', 'tabindex', 'tabstop', 'locked', 'multiline', 'maxlength', 'scrollbars', 'interval', 'autosize', 'wordwrap', 'default', 'cancel', 'sorted', 'multiselect', 'keypreview', 'controlbox', 'minbutton', 'maxbutton', 'autoredraw', 'value', 'min', 'max', 'smallchange', 'largechange', 'stretch', 'moveable', 'showintaskbar', 'mdichild'], 'Font': ['font'], 'Position': ['left', 'top', 'width', 'height', 'x1', 'y1', 'x2', 'y2', 'startupposition', 'windowstate', 'clientwidth', 'clientheight'], 'Scale': ['scalemode', 'scalewidth', 'scaleheight', 'scaleleft', 'scaletop'], 'Picture': ['picture', 'icon', 'downpicture', 'disabledpicture'], 'Misc': [] };
function propListFor(node) {
  const def = ctlDef(node.type);
  let list = def.props.map(p => { const [n, en] = p.split(':'); return { name: n, key: n.toLowerCase(), enumKey: en }; });
  if (def.unknown) list = node.props.map(p => ({ name: p.key, key: p.key.toLowerCase() }));
  // propriedades presentes no arquivo mas fora da lista
  for (const p of node.props) if (!list.some(x => x.key === p.key.toLowerCase())) list.push({ name: p.key, key: p.key.toLowerCase(), extra: true });
  const seen = new Set(); list = list.filter(x => { if (seen.has(x.key)) return false; seen.add(x.key); return true; });
  list.sort((a, b) => a.key === 'name' ? -1 : b.key === 'name' ? 1 : a.name.localeCompare(b.name));
  return list;
}
function renderProps() {
  const sel = $('#propsel'), grid = $('#pgrid'); sel.innerHTML = ''; grid.innerHTML = ''; $('#pdesc').innerHTML = '';
  const s = IDE.sel; if (!s || !s.mod) { $('#ppname').textContent = ''; return; }
  const m = s.mod;
  if (m.kind !== 'form') {
    $('#ppname').textContent = m.name;
    sel.appendChild(h('option', {}, `${m.name} ${m.kind === 'std' ? 'Module' : 'Class'}`));
    const t = h('table'); const tr = h('tr', { class: 'sel' }, h('td', {}, '(Name)'), h('td', { class: 'v' }));
    const inp = h('input', { value: m.name }); inp.onchange = () => renameModule(m, inp.value); tr.lastChild.appendChild(inp); t.appendChild(tr);
    if (m.kind === 'class') { const tr2 = h('tr', {}, h('td', {}, 'Instancing'), h('td', { class: 'v' }, h('div', { class: 'pv' }, '5 - MultiUse'))); t.appendChild(tr2); }
    grid.appendChild(t); $('#pdesc').innerHTML = '<b>(Name)</b>Returns the name used in code to identify the module.';
    return;
  }
  const node = s.node || m.frm.root;
  $('#ppname').textContent = node.name;
  const add = (n, label, path) => { const o = h('option', { value: m.id + '|' + path }, label); if (n === node) o.selected = true; sel.appendChild(o); };
  add(m.frm.root, `${m.name} ${m.frm.isMDI ? 'MDIForm' : 'Form'}`, '');
  const nodes = allNodes(m).slice().sort((a, b) => a.name.localeCompare(b.name) || (a.get('Index', 0) - b.get('Index', 0)));
  for (const n of nodes) { const idx = n.get('Index'); add(n, `${n.name}${idx !== undefined ? '(' + idx + ')' : ''} ${n.type.replace(/^VB\./, '')}`, nodePath(m, n)); }
  const P = nodeProps(node, frxLookupFor(m));
  let list = propListFor(node);
  if (IDE.propFilter) list = list.filter(pr => pr.name.toLowerCase().includes(IDE.propFilter) || (PROP_DESC[pr.key] || '').toLowerCase().includes(IDE.propFilter));
  const t = h('table');
  const rowFor = (pr) => {
    const kind = PROP_TYPES[pr.key] || (pr.extra ? 'raw' : 'text');
    const tr = h('tr', {}, h('td', { title: pr.name }, pr.key === 'name' ? '(Name)' : pr.name), h('td', { class: 'v' }));
    tr.onmousedown = () => { $$('tr.sel', grid).forEach(x => x.classList.remove('sel')); tr.classList.add('sel'); $('#pdesc').innerHTML = `<b>${esc(pr.key === 'name' ? '(Name)' : pr.name)}</b>${esc(PROP_DESC[pr.key] || '')}`; };
    tr.lastChild.appendChild(propEditor(m, node, pr, kind, P));
    return tr;
  };
  if (IDE.propTab === 'c') {
    const used = new Set();
    for (const [cat, keys] of Object.entries(PROP_CAT)) {
      const items = list.filter(pr => cat === 'Misc' ? !used.has(pr.key) : keys.includes(pr.key)); items.forEach(i => used.add(i.key));
      if (!items.length) continue;
      t.appendChild(h('tr', { class: 'cat' }, h('td', { colspan: '2' }, cat)));
      items.forEach(pr => t.appendChild(rowFor(pr)));
    }
  } else list.forEach(pr => t.appendChild(rowFor(pr)));
  grid.appendChild(t);
}
function enumFor(node, pr) {
  if (pr.enumKey && ENUMS[pr.enumKey]) return ENUMS[pr.enumKey];
  const k = pr.key;
  if (k === 'drawstyle') return ENUMS.borderstyle_shape.map(([v, l]) => [v, l]);
  if (k === 'checkvalue') return ENUMS.checkvalue;
  if (ENUMS[k]) return ENUMS[k];
  if (k === 'borderstyle') return node.type === 'VB.Form' ? ENUMS.borderstyle_form : ENUMS.borderstyle;
  return null;
}
function propEditor(m, node, pr, kind, P) {
  const key = pr.key; const isRoot = node === m.frm.root;
  let cur = P[key];
  const commit = (fn) => { pushUndo(m); fn(); m.dirty = true; markDirty(); rerenderActive(); renderProps(); };
  if (key === 'name') {
    const inp = h('input', { value: node.name });
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') inp.blur(); if (e.key === 'Escape') { inp.value = node.name; inp.blur(); } });
    inp.addEventListener('change', () => { const v = inp.value.trim(); if (!/^[A-Za-z][A-Za-z0-9_]*$/.test(v)) { IDE.ui.msgBox('Invalid property value.', 48, APP_NAME); inp.value = node.name; return; } if (isRoot) renameModule(m, v); else renameControl(m, node, v); });
    return inp;
  }
  if (key === 'index' && !isRoot) {
    const inp = h('input', { value: cur === null || cur === undefined ? '' : cur });
    inp.onchange = () => commit(() => { const v = inp.value.trim(); if (v === '') node.remove('Index'); else node.setRaw('Index', String(Math.round(Number(v) || 0))); });
    return inp;
  }
  const en = kind === 'enum' ? enumFor(node, pr) : null;
  if (kind === 'bool' || (pr.extra && (node.getRaw(pr.name) === '-1' || node.getRaw(pr.name) === '0') && /'?(True|False)/.test((node.findProp(pr.name) || {}).comment || ''))) {
    const s = h('select'); s.append(h('option', { value: '1' }, 'True'), h('option', { value: '0' }, 'False'));
    s.value = toBoolish(cur) ? '1' : '0';
    s.onchange = () => commit(() => node.set(pr.name, s.value === '1', 'bool'));
    return s;
  }
  if (en) {
    const s = h('select'); for (const [v, l] of en) s.appendChild(h('option', { value: v }, l));
    s.value = String(Number(cur) || 0);
    s.onchange = () => commit(() => { const v = Number(s.value); const lab = (en.find(x => x[0] === v) || [, ''])[1].replace(/^\d+ - /, ''); node.setRaw(pr.name, String(v), lab); });
    return s;
  }
  if (kind === 'color') {
    const wrap = h('div', { class: 'pv', html: `<span class="sw" style="background:${vbColorCss(cur) || '#fff'}"></span><span>${cur === undefined ? '' : colorRaw(Number(cur))}</span>` });
    const b = h('button', { class: 'dots' }, '▾'); wrap.appendChild(b);
    b.onclick = (e) => { e.stopPropagation(); colorPicker(b, cur, v => commit(() => node.set(pr.name, v, 'color'))); };
    return wrap;
  }
  if (kind === 'font') {
    const f = P.font;
    const wrap = h('div', { class: 'pv' }, `${f.name}, ${f.size}${f.bold ? ', Bold' : ''}${f.italic ? ', Italic' : ''}`);
    const b = h('button', { class: 'dots' }, '…'); wrap.appendChild(b);
    b.onclick = async (e) => { e.stopPropagation(); const nf = await fontDialog(f); if (nf) commit(() => { node.blocks = node.blocks.filter(x => x.name.toLowerCase() !== 'font'); const blk = fontToBlock(nf); blk.at = 0; node.blocks.push(blk); }); };
    return wrap;
  }
  if (kind === 'picture') {
    const has = cur && cur.url;
    const wrap = h('div', { class: 'pv' }, has ? '(Bitmap)' : '(None)');
    const b = h('button', { class: 'dots' }, '…'); wrap.appendChild(b);
    b.onclick = async (e) => {
      e.stopPropagation();
      if (has) { const r = await IDE.ui.msgBox('Replace the picture? (No = remove the picture)', 3 + 32, pr.name); if (r === 2) return; if (r === 7) { commit(() => { node._pending = node._pending || {}; node._pending[key] = null; node.remove(pr.name); }); return; } }
      pickFiles('image/*,.bmp,.ico,.gif,.jpg,.jpeg,.png', async files => { const f = files[0]; if (!f) return; const bytes = new Uint8Array(await f.arrayBuffer()); const mime = imageMime(bytes) || f.type || 'image/png'; commit(() => { node._pending = node._pending || {}; node._pending[key] = { url: bytesToDataURL(bytes, mime), bytes }; node.setRaw(pr.name, '"(new).frx":0000'); }); });
    };
    return wrap;
  }
  if (key === 'list' || key === 'itemdata') {
    const items = (P[key] || []);
    const wrap = h('div', { class: 'pv' }, items.length ? `(${items.length} items)` : '(List)');
    const b = h('button', { class: 'dots' }, '▾'); wrap.appendChild(b);
    b.onclick = async (e) => { e.stopPropagation(); const v = await textDialog(pr.name, 'One item per line:', items.join('\n')); if (v === null) return; commit(() => { const arr = v.split(/\r?\n/).filter((x, i, a) => !(i === a.length - 1 && x === '')); node._pending = node._pending || {}; node._pending[key] = key === 'itemdata' ? arr.map(x => Number(x) || 0) : arr; if (arr.length) node.setRaw(pr.name, '"(new).frx":0000'); else { node.remove(pr.name); node._pending[key] = undefined; delete node._pending[key]; } }); };
    return wrap;
  }
  // texto / número / bruto
  let shown = cur;
  if (pr.extra) shown = node.getRaw(pr.name);
  else if (cur && typeof cur === 'object') shown = '(…)';
  else if (cur === undefined || cur === null) shown = '';
  const multilineText = (key === 'text' || key === 'caption') && typeof cur === 'string' && /\n/.test(cur);
  const inp = h('input', { value: multilineText ? cur.replace(/\r?\n/g, '¶') : String(shown) });
  inp.addEventListener('keydown', e => { if (e.key === 'Enter') inp.blur(); if (e.key === 'Escape') { inp.value = String(shown); inp.blur(); } });
  if ((key === 'text' && node.type === 'VB.TextBox') || key === 'caption') {
    const wrap = h('div', { style: 'position:relative;height:17px' }); wrap.appendChild(inp); inp.style.paddingRight = '20px';
    const b = h('button', { class: 'dots' }, '…'); wrap.appendChild(b);
    b.onclick = async e => { e.stopPropagation(); const v = await textDialog(pr.name, 'Text (may have several lines):', String(cur ?? '')); if (v === null) return; commit(() => setTextProp(node, pr.name, v.replace(/\r?\n/g, '\r\n'))); };
    inp.onchange = () => commit(() => setTextProp(node, pr.name, inp.value.replace(/¶/g, '\r\n')));
    return wrap;
  }
  inp.onchange = () => commit(() => {
    const v = inp.value;
    if (pr.extra) { node.setRaw(pr.name, v); return; }
    if (kind === 'num') { const n = Number(String(v).replace(',', '.')); if (isNaN(n)) { IDE.ui.msgBox('Invalid property value.', 48, APP_NAME); return; } node.setRaw(pr.name, String(n)); if (isRoot && (key === 'clientwidth' || key === 'clientheight')) setFormClientSize(node, key === 'clientwidth' ? n : P.clientwidth, key === 'clientheight' ? n : P.clientheight); return; }
    if (kind === 'char') { node.setRaw(pr.name, quote(v.slice(0, 1))); return; }
    if (key === 'caption' && isRoot) { node.setRaw('Caption', quote(v)); return; }
    node.setRaw(pr.name, quote(v));
  });
  return inp;
}
function setTextProp(node, name, v) {
  if (/[\r\n]/.test(v) || v.length > 2000) { node._pending = node._pending || {}; node._pending[name.toLowerCase()] = v; node.setRaw(name, '"(new).frx":0000'); }
  else { if (node._pending) delete node._pending[name.toLowerCase()]; node.setRaw(name, quote(v)); }
}
function toBoolish(v) { return v === true || (typeof v === 'number' && v !== 0) || v === '-1'; }
function renameControl(m, node, nv) {
  const old = node.name; if (old === nv) return;
  const clash = allNodes(m).find(n => n !== node && n.name.toLowerCase() === nv.toLowerCase());
  if (clash && clash.type !== node.type) { IDE.ui.msgBox(`A control named ${nv} already exists.`, 48, APP_NAME); renderProps(); return; }
  pushUndo(m);
  if (clash && node.get('Index') === undefined) { node.setRaw('Index', '1'); if (clash.get('Index') === undefined) clash.setRaw('Index', '0'); }
  // renomeia todos os elementos da matriz
  for (const n of allNodes(m)) if (n.name.toLowerCase() === old.toLowerCase() && (n === node || node.get('Index') !== undefined)) n.name = nv;
  // renomeia procedimentos de evento no código
  const re = new RegExp(`(\\bSub\\s+)${old}_(\\w+)\\s*\\(`, 'gi');
  m.frm.code = m.frm.code.replace(re, (all, a, ev) => `${a}${nv}_${ev}(`);
  for (const cd of IDE.docs.filter(x => x.mod === m && x.kind === 'code')) loadEditorText(cd);
  m.dirty = true; markDirty(); rerenderActive(); renderProps();
}
function renameModule(m, nv) {
  nv = nv.trim(); if (!/^[A-Za-z][A-Za-z0-9_]*$/.test(nv)) { IDE.ui.msgBox('Invalid name.', 48, APP_NAME); renderProps(); return; }
  const other = findModule(nv); if (other && other !== m) { IDE.ui.msgBox(`A module named ${nv} already exists.`, 48, APP_NAME); renderProps(); return; }
  const old = m.name;
  if (IDE.project.startup.toLowerCase() === old.toLowerCase()) IDE.project.startup = nv;
  m.name = nv;
  if (m.kind === 'form') { m.frm.name = nv; m.frm.root.name = nv; }
  if (m.dirty === false && /^(Form|Module|Class)\d+\.(frm|bas|cls)$/i.test(m.fileName) || m.fileName.toLowerCase().startsWith(old.toLowerCase() + '.')) m.fileName = m.fileName.replace(new RegExp('^' + old, 'i'), nv);
  m.dirty = true; markDirty(); refreshAll(); renderTabs(); rerenderActive();
}

// ---------- Editor de código ----------
const KEYWORDS = ['AddressOf', 'And', 'Any', 'As', 'Boolean', 'ByRef', 'Byte', 'ByVal', 'Call', 'Case', 'Close', 'Const', 'Currency', 'Date', 'Debug', 'Declare', 'DefBool', 'DefInt', 'DefLng', 'DefStr', 'Dim', 'Do', 'Double', 'Each', 'Else', 'ElseIf', 'Empty', 'End', 'Enum', 'Eqv', 'Erase', 'Error', 'Event', 'Exit', 'False', 'For', 'Friend', 'Function', 'Get', 'Global', 'GoSub', 'GoTo', 'If', 'Imp', 'Implements', 'In', 'Input', 'Integer', 'Is', 'Let', 'Lib', 'Like', 'Line', 'Load', 'Lock', 'Long', 'Loop', 'LSet', 'Me', 'Mod', 'New', 'Next', 'Not', 'Nothing', 'Null', 'Object', 'On', 'Open', 'Option', 'Optional', 'Or', 'Output', 'ParamArray', 'Preserve', 'Print', 'Private', 'Property', 'Public', 'Put', 'RaiseEvent', 'Random', 'ReDim', 'Rem', 'Resume', 'Return', 'RSet', 'Select', 'Set', 'Single', 'Static', 'Step', 'Stop', 'String', 'Sub', 'Then', 'To', 'True', 'Type', 'TypeOf', 'Unload', 'Until', 'Variant', 'Wend', 'While', 'With', 'WithEvents', 'Write', 'Xor', 'Explicit', 'Compare', 'Base', 'Binary', 'Text', 'Append', 'Access', 'Shared'];
const KW_MAP = Object.fromEntries(KEYWORDS.map(k => [k.toLowerCase(), k]));
const FN_CASE = ['MsgBox', 'InputBox', 'Len', 'Left', 'Right', 'Mid', 'UCase', 'LCase', 'Trim', 'LTrim', 'RTrim', 'InStr', 'InStrRev', 'Replace', 'Split', 'Join', 'Val', 'Str', 'CStr', 'CInt', 'CLng', 'CDbl', 'CSng', 'CBool', 'CDate', 'CCur', 'Format', 'Now', 'Time', 'Timer', 'Year', 'Month', 'Day', 'Hour', 'Minute', 'Second', 'DateAdd', 'DateDiff', 'IIf', 'IsNumeric', 'IsEmpty', 'IsNull', 'IsArray', 'UBound', 'LBound', 'Array', 'Chr', 'Asc', 'Space', 'Abs', 'Int', 'Fix', 'Sqr', 'Rnd', 'Randomize', 'RGB', 'QBColor', 'DoEvents', 'Err', 'TypeName', 'StrComp', 'StrReverse', 'Hex', 'Oct', 'LoadPicture', 'Round', 'Sgn', 'Sin', 'Cos', 'Tan', 'Atn', 'Exp', 'Log', 'Choose', 'Switch', 'FreeFile', 'EOF', 'LOF', 'Dir', 'Kill', 'App', 'Screen', 'Clipboard', 'Printer', 'vbCrLf', 'vbNewLine', 'vbTab', 'vbYesNo', 'vbYes', 'vbNo', 'vbOKOnly', 'vbOKCancel', 'vbCritical', 'vbQuestion', 'vbExclamation', 'vbInformation', 'vbRed', 'vbGreen', 'vbBlue', 'vbBlack', 'vbWhite', 'vbYellow', 'vbModal', 'vbKeyReturn', 'vbKeyEscape', 'vbCancel', 'vbOK'];
const ID_CASE = Object.assign({}, KW_MAP, Object.fromEntries(FN_CASE.map(k => [k.toLowerCase(), k])));
const EVENT_SIG = {
  click: '', dblclick: '', change: '', gotfocus: '', lostfocus: '', timer: '', load: '', resize: '', activate: '', deactivate: '', initialize: '', terminate: '', paint: '', scroll: '', dropdown: '', pathchange: '', patternchange: '', reposition: '',
  mousedown: 'Button As Integer, Shift As Integer, X As Single, Y As Single', mouseup: 'Button As Integer, Shift As Integer, X As Single, Y As Single', mousemove: 'Button As Integer, Shift As Integer, X As Single, Y As Single',
  keydown: 'KeyCode As Integer, Shift As Integer', keyup: 'KeyCode As Integer, Shift As Integer', keypress: 'KeyAscii As Integer', unload: 'Cancel As Integer', queryunload: 'Cancel As Integer, UnloadMode As Integer',
  itemcheck: 'Item As Integer', validate: 'Cancel As Boolean', error: 'DataErr As Integer, Response As Integer',
};
function buildCodeEditor(d) {
  d.el.innerHTML = `<div class="cbar"><select class="cobj"></select><select class="cproc"></select></div><div class="cedit"><div class="gutter"></div><div class="cwrap"><pre class="hl"></pre><textarea spellcheck="false" autocapitalize="off" autocomplete="off" wrap="off"></textarea></div></div>`;
  d.ta = $('textarea', d.el); d.hl = $('pre', d.el); d.gut = $('.gutter', d.el); d.cobj = $('.cobj', d.el); d.cproc = $('.cproc', d.el);
  loadEditorText(d);
  const ta = d.ta;
  ta.addEventListener('input', () => { d.dirtyText = true; renderHL(d); d.mod.dirty = true; markDirty(); });
  ta.addEventListener('scroll', () => { d.hl.scrollTop = ta.scrollTop; d.hl.scrollLeft = ta.scrollLeft; d.gut.scrollTop = ta.scrollTop; });
  ta.addEventListener('keydown', e => codeKey(d, e));
  ta.addEventListener('keyup', () => { updateCaretInfo(d); });
  ta.addEventListener('click', () => { updateCaretInfo(d); });
  ta.addEventListener('blur', () => { syncEditor(d); });
  d.cobj.onchange = () => fillProcCombo(d);
  d.cproc.onchange = () => { const v = d.cproc.value; if (!v) return; gotoProc(d, d.cobj.value, v); };
}
function loadEditorText(d) { d.ta.value = (getCode(d.mod) || '').replace(/\r\n/g, '\n'); d.dirtyText = false; renderHL(d); }
function syncEditor(d) { if (d && d.kind === 'code' && d.ta && d.dirtyText) { const v = d.ta.value.replace(/\n/g, '\r\n'); if (m_code_changed(d.mod, v)) setCode(d.mod, v); d.dirtyText = false; } }
function m_code_changed(m, v) { return (getCode(m) || '') !== v; }
function syncEditors() { for (const d of IDE.docs) if (d.kind === 'code') syncEditor(d); }
function highlightLine(line) {
  let out = ''; let i = 0; const n = line.length;
  while (i < n) {
    const c = line[i];
    if (c === "'") { out += `<span class="c">${esc(line.slice(i))}</span>`; break; }
    if (c === '"') { let j = i + 1; while (j < n && !(line[j] === '"' && line[j + 1] !== '"')) { if (line[j] === '"') j++; j++; } out += `<span class="s">${esc(line.slice(i, j + 1))}</span>`; i = j + 1; continue; }
    if (/[A-Za-z_]/.test(c)) {
      let j = i; while (j < n && /[\w$]/.test(line[j])) j++;
      const w = line.slice(i, j); const lw = w.toLowerCase();
      if (lw === 'rem' && /^\s*$/.test(line.slice(0, i))) { out += `<span class="c">${esc(line.slice(i))}</span>`; break; }
      const afterDot = /\.\s*$/.test(line.slice(0, i));
      out += KW_MAP[lw] && !afterDot ? `<span class="k">${w}</span>` : esc(w); i = j; continue;
    }
    out += esc(c); i++;
  }
  return out;
}
function renderHL(d) {
  const lines = d.ta.value.split('\n');
  d.hl.innerHTML = lines.map((l, i) => (d.errLine === i + 1 ? `<span class="errline">${highlightLine(l) || ' '}</span>` : highlightLine(l))).join('\n') + '\n ';
  if (d.lastLineCount !== lines.length) { d.gut.innerHTML = lines.map((_, i) => `<div${d.errLine === i + 1 ? ' class="err"' : ''}>${i + 1}</div>`).join('') + '<div>&nbsp;</div><div>&nbsp;</div>'; d.lastLineCount = lines.length; }
  else if (d.errLineShown !== d.errLine) { d.gut.innerHTML = lines.map((_, i) => `<div${d.errLine === i + 1 ? ' class="err"' : ''}>${i + 1}</div>`).join('') + '<div>&nbsp;</div><div>&nbsp;</div>'; }
  d.errLineShown = d.errLine;
  d.hl.scrollTop = d.ta.scrollTop; d.gut.scrollTop = d.ta.scrollTop;
}
function fixCase(line) {
  // ajusta maiúsculas/minúsculas de palavras-chave fora de strings e comentários (como o VB faz)
  let out = '', i = 0; const n = line.length;
  while (i < n) {
    const c = line[i];
    if (c === "'") { out += line.slice(i); break; }
    if (c === '"') { let j = i + 1; while (j < n && !(line[j] === '"' && line[j + 1] !== '"')) { if (line[j] === '"') j++; j++; } out += line.slice(i, j + 1); i = j + 1; continue; }
    if (/[A-Za-z_]/.test(c) && (i === 0 || !/[\w.]/.test(line[i - 1]))) {
      let j = i; while (j < n && /\w/.test(line[j])) j++;
      const w = line.slice(i, j); const fixed = ID_CASE[w.toLowerCase()];
      out += fixed || w; i = j; continue;
    }
    out += c; i++;
  }
  return out;
}
function codeKey(d, e) {
  const ta = d.ta;
  if (e.key === 'Tab') {
    e.preventDefault();
    const s = ta.selectionStart, en = ta.selectionEnd; const v = ta.value;
    if (s !== en && v.slice(s, en).includes('\n')) {
      const ls = v.lastIndexOf('\n', s - 1) + 1; const block = v.slice(ls, en);
      const nb = e.shiftKey ? block.replace(/^( {1,4}|\t)/gm, '') : block.replace(/^/gm, '    ');
      ta.setRangeText(nb, ls, en, 'select');
    } else if (e.shiftKey) { const ls = v.lastIndexOf('\n', s - 1) + 1; const m = /^( {1,4})/.exec(v.slice(ls)); if (m) ta.setRangeText('', ls, ls + m[1].length, 'end'); }
    else ta.setRangeText('    ', s, en, 'end');
    ta.dispatchEvent(new Event('input')); return;
  }
  if (e.key === 'Enter' && !e.ctrlKey) {
    e.preventDefault();
    const v = ta.value, s = ta.selectionStart;
    const ls = v.lastIndexOf('\n', s - 1) + 1; let le = v.indexOf('\n', s); if (le < 0) le = v.length;
    let line = v.slice(ls, le);
    const before = v.slice(ls, s);
    if (IDE.opts.autoCase) { const fixed = fixCase(line); if (fixed !== line) { ta.setRangeText(fixed, ls, le, 'preserve'); line = fixed; } }
    const indent = /^\s*/.exec(before)[0];
    let ins = '\n' + indent;
    // auto End Sub/Function/Property
    const mm = /^\s*(?:(?:Public|Private|Friend|Static)\s+)*(Sub|Function|Property\s+(?:Get|Let|Set))\s+(\w+)/i.exec(line);
    const cur = ta.selectionStart;
    if (mm && cur >= ls + line.trimEnd().length) {
      const kind = /^property/i.test(mm[1]) ? 'Property' : (mm[1][0].toUpperCase() + mm[1].slice(1).toLowerCase());
      const rest = v.slice(le);
      const nextProc = /^\s*\n\s*(End\s+(Sub|Function|Property))/i.test(rest);
      const hasEnd = new RegExp(`^[^]*?\\n\\s*End\\s+${kind}\\b`, 'i').test(rest) && !/\n\s*(?:(?:Public|Private|Friend|Static)\s+)*(Sub|Function|Property)\s+\w+[^]*?\n\s*End\s+(Sub|Function|Property)/i.test(rest.split(new RegExp(`\\n\\s*End\\s+${kind}\\b`, 'i'))[0]);
      if (!hasEnd) { ta.setRangeText(ins + '    ' + '\n' + indent + 'End ' + kind, ta.selectionStart, ta.selectionEnd, 'end'); ta.selectionStart = ta.selectionEnd = ls + line.length + 1 + indent.length + 4; ta.dispatchEvent(new Event('input')); return; }
    }
    if (/^\s*(If\b.*\bThen\s*$|For\b|Do\b|While\b|Select\s+Case\b|Case\b|Else\b|ElseIf\b|With\b|Private\s+Sub|Public\s+Sub|Sub\b|Function\b|Private\s+Function|Public\s+Function|Type\b|Enum\b)/i.test(line) && !/^\s*End\b/i.test(line) && !/\bEnd\s+If\s*$/i.test(line)) ins += '    ';
    ta.setRangeText(ins, ta.selectionStart, ta.selectionEnd, 'end');
    ta.dispatchEvent(new Event('input'));
    return;
  }
  if (e.key === 'F3' || (e.key === 'Escape' && d.find)) { if (e.key === 'Escape') { d.find.remove(); d.find = null; } else findNext(d); e.preventDefault(); }
}
function updateCaretInfo(d) {
  const v = d.ta.value, s = d.ta.selectionStart; const line = v.slice(0, s).split('\n').length; const col = s - v.lastIndexOf('\n', s - 1);
  $('#spos').textContent = `Ln ${line}, Col ${col}`;
  // sincroniza combos com o procedimento atual
  const procs = listProcs(v);
  const p = procs.filter(x => x.line <= line).pop();
  if (p && p.endLine >= line) {
    const us = p.name.indexOf('_'); const obj = us > 0 ? p.name.slice(0, us) : null;
    if (obj && d.mod.kind === 'form' && (obj.toLowerCase() === 'form' || obj.toLowerCase() === 'mdiform' || allNodes(d.mod).some(n => n.name.toLowerCase() === obj.toLowerCase()))) { setSel(d.cobj, obj.toLowerCase() === 'form' || obj.toLowerCase() === 'mdiform' ? obj : allNodes(d.mod).find(n => n.name.toLowerCase() === obj.toLowerCase()).name); fillProcCombo(d, p.name.slice(us + 1)); }
    else { setSel(d.cobj, '(General)'); fillProcCombo(d, p.name); }
  } else if (d.cobj.value !== '(General)') { setSel(d.cobj, '(General)'); fillProcCombo(d, '(Declarations)'); }
}
function setSel(sel, v) { for (const o of sel.options) if (o.value.toLowerCase() === String(v).toLowerCase()) { sel.value = o.value; return; } }
function listProcs(text) {
  const out = []; const lines = text.split('\n'); let cur = null;
  lines.forEach((l, i) => {
    const m = /^\s*(?:(?:Public|Private|Friend|Static|Global)\s+)*(Sub|Function|Property\s+(?:Get|Let|Set))\s+(\w+)/i.exec(l);
    if (m && !cur) { cur = { name: m[2], kind: m[1], line: i + 1, endLine: lines.length }; out.push(cur); }
    else if (cur && /^\s*End\s+(Sub|Function|Property)\b/i.test(l)) { cur.endLine = i + 1; cur = null; }
  });
  return out;
}
function refreshCodeCombos(d) {
  const m = d.mod; const sel = d.cobj; sel.innerHTML = '';
  sel.appendChild(h('option', { value: '(General)' }, '(General)'));
  if (m.kind === 'form') {
    sel.appendChild(h('option', { value: m.frm.isMDI ? 'MDIForm' : 'Form' }, m.frm.isMDI ? 'MDIForm' : 'Form'));
    const names = [...new Map(allNodes(m).map(n => [n.name.toLowerCase(), n])).values()].sort((a, b) => a.name.localeCompare(b.name));
    for (const n of names) sel.appendChild(h('option', { value: n.name }, n.name));
  } else if (m.kind === 'class') sel.appendChild(h('option', { value: 'Class' }, 'Class'));
  fillProcCombo(d);
  updateCaretInfo(d);
}
function fillProcCombo(d, selName) {
  const m = d.mod, obj = d.cobj.value; const pc = d.cproc; pc.innerHTML = '';
  const text = d.ta.value; const procs = listProcs(text);
  if (obj === '(General)') {
    pc.appendChild(h('option', { value: '(Declarations)' }, '(Declarations)'));
    const names = new Set(allNodes(m).map(n => n.name.toLowerCase()).concat(['form', 'mdiform', 'class']));
    for (const p of procs) { const us = p.name.indexOf('_'); if (us > 0 && names.has(p.name.slice(0, us).toLowerCase()) && m.kind !== 'std') continue; pc.appendChild(h('option', { value: p.name }, p.name)); }
  } else {
    let events;
    if (obj === 'Form' || obj === 'MDIForm') events = ctlDef(m.frm.isMDI ? 'VB.MDIForm' : 'VB.Form').events;
    else if (obj === 'Class') events = ['Initialize', 'Terminate'];
    else { const n = allNodes(m).find(x => x.name === obj); events = n ? ctlDef(n.type).events : []; if (!events.length) events = ['Click']; }
    for (const ev of events) {
      const has = procs.some(p => p.name.toLowerCase() === (obj + '_' + ev).toLowerCase());
      const o = h('option', { value: ev }, ev); if (has) o.style.fontWeight = 'bold'; pc.appendChild(o);
    }
  }
  if (selName) setSel(pc, selName);
}
function gotoProc(d, obj, proc) {
  if (obj === '(General)') { if (proc === '(Declarations)') { selectLine(d, 1); return; } const p = listProcs(d.ta.value).find(x => x.name === proc); if (p) selectLine(d, p.line + 1, true); return; }
  const m = d.mod;
  const isArr = obj !== 'Form' && obj !== 'MDIForm' && obj !== 'Class' && allNodes(m).some(n => n.name === obj && n.get('Index') !== undefined);
  const name = obj + '_' + proc;
  const p = listProcs(d.ta.value).find(x => x.name.toLowerCase() === name.toLowerCase());
  if (p) { selectLine(d, p.line + 1, true); return; }
  const sig = EVENT_SIG[proc.toLowerCase()] ?? '';
  const params = (isArr ? 'Index As Integer' + (sig ? ', ' : '') : '') + sig;
  let v = d.ta.value.replace(/\s*$/, '');
  const stub = `Private Sub ${name}(${params})\n    \nEnd Sub`;
  v = v + (v ? '\n\n' : '') + stub + '\n';
  d.ta.value = v; d.dirtyText = true; syncEditor(d); renderHL(d);
  const ln = v.split('\n').length - 2;
  selectLine(d, ln, true);
  fillProcCombo(d, proc);
}
function selectLine(d, line, caretEnd) {
  const lines = d.ta.value.split('\n'); line = Math.max(1, Math.min(lines.length, line));
  let pos = 0; for (let i = 0; i < line - 1; i++) pos += lines[i].length + 1;
  d.ta.focus(); d.ta.setSelectionRange(caretEnd ? pos + lines[line - 1].length : pos, pos + lines[line - 1].length);
  const lh = 18; const top = (line - 1) * lh; const ta = d.ta;
  if (top < ta.scrollTop || top > ta.scrollTop + ta.clientHeight - 2 * lh) ta.scrollTop = Math.max(0, top - ta.clientHeight / 3);
  renderHL(d); updateCaretInfo(d);
}
function jumpToEvent(m, node) {
  const d = openCode(m);
  const isRoot = node === m.frm.root;
  const obj = isRoot ? (m.frm.isMDI ? 'MDIForm' : 'Form') : node.name;
  const def = ctlDef(isRoot ? m.frm.root.type : node.type);
  const procs = listProcs(d.ta.value);
  const existing = def.events.find(ev => procs.some(p => p.name.toLowerCase() === (obj + '_' + ev).toLowerCase()));
  const ev = def.defEvent && procs.some(p => p.name.toLowerCase() === (obj + '_' + def.defEvent).toLowerCase()) ? def.defEvent : (existing || def.defEvent || def.events[0] || 'Click');
  setSel(d.cobj, obj); fillProcCombo(d, ev); gotoProc(d, obj, ev);
}
function openFind() {
  const d = activeCodeDoc(); if (!d) { setStatus('Open a code window to search.'); return; }
  if (d.find) { d.find.querySelector('input').select(); return; }
  const bar = h('div', { class: 'findbar' }); bar.innerHTML = `<input placeholder="Find"><input placeholder="Replace with" style="width:110px"><button class="nb-btn" style="min-width:0">Find Next</button><button class="nb-btn" style="min-width:0">Replace All</button><span class="x" style="cursor:default;padding:0 4px">✕</span>`;
  $('.cwrap', d.el).appendChild(bar); d.find = bar;
  const [fi, ri] = bar.querySelectorAll('input'); const [bn, br] = bar.querySelectorAll('button');
  const sel = d.ta.value.slice(d.ta.selectionStart, d.ta.selectionEnd); if (sel && !sel.includes('\n')) fi.value = sel;
  fi.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); findNext(d); } if (e.key === 'Escape') { bar.remove(); d.find = null; d.ta.focus(); } });
  bn.onclick = () => findNext(d);
  br.onclick = () => { const f = fi.value; if (!f) return; const re = new RegExp(f.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'); const n = (d.ta.value.match(re) || []).length; d.ta.value = d.ta.value.replace(re, ri.value); d.dirtyText = true; syncEditor(d); renderHL(d); setStatus(`${n} replacement(s).`); };
  bar.querySelector('.x').onclick = () => { bar.remove(); d.find = null; d.ta.focus(); };
  fi.focus(); fi.select();
}
function findNext(d) {
  if (!d.find) return; const f = d.find.querySelector('input').value; if (!f) return;
  const v = d.ta.value.toLowerCase(); let i = v.indexOf(f.toLowerCase(), d.ta.selectionEnd); if (i < 0) i = v.indexOf(f.toLowerCase());
  if (i < 0) { setStatus('The specified text was not found.'); return; }
  d.ta.focus(); d.ta.setSelectionRange(i, i + f.length); const line = v.slice(0, i).split('\n').length; const top = (line - 1) * 18; if (top < d.ta.scrollTop || top > d.ta.scrollTop + d.ta.clientHeight - 36) d.ta.scrollTop = Math.max(0, top - d.ta.clientHeight / 3);
}
async function gotoLinePrompt() { const d = activeCodeDoc(); if (!d) return; const v = await IDE.ui.inputBox('Line number:', 'Go to Line', ''); const n = parseInt(v, 10); if (n > 0) selectLine(d, n); }
function showErrorAt(modName, line) {
  const m = findModule(modName); if (!m) return;
  const d = openCode(m);
  d.errLine = line; renderHL(d); d.lastLineCount = -1; renderHL(d);
  selectLine(d, line);
  const clear = () => { d.errLine = null; d.lastLineCount = -1; renderHL(d); d.ta.removeEventListener('input', clear); };
  d.ta.addEventListener('input', clear);
}

// ---------- Execução ----------
function runtimeProjectFromIDE() {
  syncEditors();
  const P = IDE.project;
  const mods = P.modules.map(m => {
    if (m.kind !== 'form') return { kind: m.kind, name: m.name, code: m.code, defaultMember: m.defaultMember || (m.kind === 'class' ? (/Attribute\s+(\w+)\.VB_UserMemId\s*=\s*0\b/i.exec(m.code || '') || [])[1] : null) };
    // usa uma cópia com imagens/listas pendentes resolvidas
    const lookup = frxLookupFor(m);
    return { kind: 'form', name: m.name, frm: m.frm, frxLookup: lookup };
  });
  return buildRuntimeProject({ name: P.name, title: P.title, startup: P.startup, modules: mods.map(x => Object.assign({}, x, { defaultMember: x.defaultMember ? String(x.defaultMember).toLowerCase() : null })) });
}
async function startRun() {
  if (IDE.running || !IDE.project) return;
  closeIdeMenu();
  const proj = runtimeProjectFromIDE();
  setLocale(IDE.opts.locale);
  const rt = new VBRuntime(IDE.host);
  IDE.host.appName = IDE.project.title || IDE.project.name;
  IDE.host.appPath = 'C:\\NeoBasic\\' + IDE.project.name;
  try { rt.load(proj); }
  catch (e) { if (e instanceof VBError) { await IDE.ui.msgBox(`Compile error:\n\n${e.description}\n\nModule: ${e.module}, line ${e.line}`, 16, APP_NAME); showErrorAt(e.module, e.line); } else { await IDE.ui.msgBox('Error: ' + e.message, 16, APP_NAME); console.error(e); } return; }
  IDE.rt = rt; IDE.running = true; document.body.classList.add('running');
  IDE.host.clear(); IDE.stage.classList.add('on');
  updateTitle(); refreshToolbar(); setStatus('Running…');
  imm('');
  rt.run();
}
function stopRun() { if (!IDE.running) return; const rt = IDE.rt; rt.end(); }
function onRunEnd() {
  if (!IDE.running) return;
  IDE.running = false; IDE.rt = null; document.body.classList.remove('running');
  IDE.host.clear(); IDE.stage.classList.remove('on');
  updateTitle(); refreshToolbar(); setStatus('Ready');
  rerenderActive();
}
async function onRunError(e) {
  if (e && e.isCompile) { IDE.host.clear(); IDE.stage.classList.remove('on'); }
  const what = e.isCompile ? 'Compile error' : `Run-time error '${e.number}'`;
  const where = e.module ? `\n\nModule: ${e.module}${e.proc ? ' — ' + e.proc : ''}, line ${e.line}` : '';
  if (e.internal) console.error(e.internal);
  const host = IDE.ui;
  // diálogo com Encerrar / Depurar
  const r = await host.dialog(IDE.project ? (IDE.project.title || IDE.project.name) : APP_NAME, (c, done) => {
    c.innerHTML = `<div class="msg"><span class="vb-micon i16"></span><div class="txt"></div></div><div class="btns"><button class="def">End</button><button>Debug</button></div>`;
    c.querySelector('.txt').textContent = `${what}:\n\n${e.description || e.message}${where}`;
    const [b1, b2] = c.querySelectorAll('button'); b1.onclick = () => done('end'); b2.onclick = () => done('debug');
    return b2;
  });
  if (r === 'debug' && e.module) setTimeout(() => showErrorAt(e.module, e.line), 50);
}
async function immediateExec(text) {
  text = text.trim(); if (!text) return;
  imm(text + '\n');
  let src = text;
  if (/^(\?|print\s)/i.test(src)) src = 'Debug.Print ' + src.replace(/^(\?|print\s)/i, '');
  const rt = IDE.rt || new VBRuntime(IDE.host);
  try {
    const stmts = parseStatements(src);
    let mi = null;
    if (IDE.rt) { const af = IDE.host.activeForm(); mi = (af && af.mi) || rt.stdModules[0]; }
    if (!mi) mi = new ModuleInstance(rt, 'Immediate', 'std', { procs: {}, decls: [], consts: [], types: {}, enums: {} }, null);
    if (!rt.immFrame || rt.immFrame.mi !== mi) rt.immFrame = rt.newFrame(mi, null);
    const frame = rt.immFrame; frame.top = null;
    await rt.execList(stmts, frame, 0);
  } catch (e) { imm(`' Error: ${e.description || e.message}\n`); }
}

// ---------- Diálogos da IDE ----------
function ideDialog(title, build) { return IDE.ui.dialog(title, (c, done) => { c.parentNode.classList.add('ide-dlg'); return build(c, done); }); }
function chooseDialog(title, prompt, items) {
  return ideDialog(title, (c, done) => {
    c.innerHTML = `<div style="margin-bottom:6px"></div><div class="list"></div><div class="btns"><button class="nb-btn">OK</button><button class="nb-btn">Cancel</button></div>`;
    c.firstChild.textContent = prompt; const list = c.querySelector('.list'); let cur = items[0] && items[0].value;
    items.forEach((it, i) => { const r = h('div', { class: i === 0 ? 'sel' : '' }, it.label); r.onclick = () => { $$('div', list).forEach(x => x.classList.remove('sel')); r.classList.add('sel'); cur = it.value; }; r.ondblclick = () => done(it.value); list.appendChild(r); });
    const [ok, ca] = c.querySelectorAll('button'); ok.onclick = () => done(cur); ca.onclick = () => done(null);
    c.parentNode._cancelValue = null; return ok;
  });
}
function textDialog(title, prompt, value) {
  return ideDialog(title, (c, done) => {
    c.innerHTML = `<div style="margin-bottom:6px"></div><textarea spellcheck="false"></textarea><div class="btns"><button class="nb-btn">OK</button><button class="nb-btn">Cancel</button></div>`;
    c.firstChild.textContent = prompt; const ta = c.querySelector('textarea'); ta.value = value || '';
    const [ok, ca] = c.querySelectorAll('button'); ok.onclick = () => done(ta.value); ca.onclick = () => done(null);
    c.parentNode._cancelValue = null; return ta;
  });
}
function fontDialog(f) {
  const fonts = ['MS Sans Serif', 'Arial', 'Tahoma', 'Verdana', 'Times New Roman', 'Courier New', 'Comic Sans MS', 'Georgia', 'Trebuchet MS', 'Impact', 'System', 'Segoe UI', 'Lucida Console'];
  return ideDialog('Font', (c, done) => {
    c.innerHTML = `<div class="row"><label>Font:</label><input type="text" list="nbfonts" class="fn" style="width:170px"><datalist id="nbfonts">${fonts.map(x => `<option value="${x}">`).join('')}</datalist></div>
      <div class="row"><label>Size:</label><input type="number" class="fs" step="0.75" min="4" max="96" style="width:70px"></div>
      <div class="row"><label>Font style:</label><label style="width:auto"><input type="checkbox" class="fb"> Bold</label><label style="width:auto"><input type="checkbox" class="fi"> Italic</label><label style="width:auto"><input type="checkbox" class="fu"> Underline</label><label style="width:auto"><input type="checkbox" class="fx"> Strikeout</label></div>
      <div class="sample" style="height:46px;border:1px solid #808080;background:#fff;display:flex;align-items:center;justify-content:center;margin:6px 0">AaBbYyZz</div>
      <div class="btns"><button class="nb-btn">OK</button><button class="nb-btn">Cancel</button></div>`;
    const fn = $('.fn', c), fs = $('.fs', c), fb = $('.fb', c), fi = $('.fi', c), fu = $('.fu', c), fx = $('.fx', c), smp = $('.sample', c);
    fn.value = f.name; fs.value = f.size; fb.checked = !!f.bold; fi.checked = !!f.italic; fu.checked = !!f.underline; fx.checked = !!f.strikethrough;
    const val = () => ({ name: fn.value || 'MS Sans Serif', size: Number(fs.value) || 8.25, bold: fb.checked, italic: fi.checked, underline: fu.checked, strikethrough: fx.checked, charset: f.charset || 0 });
    const upd = () => applyFont(smp, val()); [fn, fs, fb, fi, fu, fx].forEach(x => x.addEventListener('input', upd)); upd();
    const [ok, ca] = c.querySelectorAll('.btns button'); ok.onclick = () => done(val()); ca.onclick = () => done(null);
    c.parentNode._cancelValue = null; return fn;
  });
}
function colorPicker(anchor, cur, cb) {
  // seletor de cores moderno: paleta com tons, código #RRGGBB e cores do sistema recolhidas
  closeIdeMenu();
  const pop = h('div', { class: 'vb-popup idem nb-root nbcp' });
  const hues = [['#1f2937', '#4b5563', '#9ca3af', '#d1d5db', '#ffffff'], ['#1e3a8a', '#1d4ed8', '#2f6fed', '#60a5fa', '#dbeafe'], ['#0c4a6e', '#0369a1', '#0ea5e9', '#7dd3fc', '#e0f2fe'], ['#134e4a', '#0f766e', '#14b8a6', '#5eead4', '#ccfbf1'], ['#14532d', '#15803d', '#22c55e', '#86efac', '#dcfce7'], ['#713f12', '#a16207', '#eab308', '#fde047', '#fef9c3'], ['#7c2d12', '#c2410c', '#f97316', '#fdba74', '#ffedd5'], ['#7f1d1d', '#b91c1c', '#ef4444', '#fca5a5', '#fee2e2'], ['#831843', '#be185d', '#ec4899', '#f9a8d4', '#fce7f3'], ['#4c1d95', '#6d28d9', '#8b5cf6', '#c4b5fd', '#ede9fe']];
  const curCss = (cur != null && cur >= 0) ? vbColorCss(cur) : '';
  pop.innerHTML = `<div class="cp-title">Colors</div><div class="cp-grid"></div>
    <div class="cp-row"><span class="cp-prev"></span><input class="cp-hex" spellcheck="false" maxlength="7" placeholder="#2F6FED"><button class="cp-ok">Apply</button></div>
    <div class="cp-sys-t">System colors <span>▸</span></div><div class="cp-sys"></div>`;
  const pick = v => { closeIdeMenu(); cb(v); };
  const grid = $('.cp-grid', pop);
  for (let row = 0; row < 5; row++) for (const hue of hues) { const c = hue[row]; const sw = h('span', { class: 'cp-sw' + (curCss && curCss.toLowerCase() === c ? ' on' : ''), style: `background:${c}`, title: c.toUpperCase() }); sw.onmousedown = e => { e.preventDefault(); pick(cssToVbColor(c)); }; grid.appendChild(sw); }
  const hex = $('.cp-hex', pop), prev = $('.cp-prev', pop);
  hex.value = curCss ? curCss.toUpperCase() : '';
  const norm = () => { let v = hex.value.trim(); if (!v.startsWith('#')) v = '#' + v; return /^#[0-9a-f]{6}$/i.test(v) ? v : (/^#[0-9a-f]{3}$/i.test(v) ? '#' + v.slice(1).split('').map(x => x + x).join('') : null); };
  const upd = () => { const v = norm(); prev.style.background = v || 'transparent'; };
  hex.oninput = upd; upd();
  const apply = () => { const v = norm(); if (v) pick(cssToVbColor(v)); else hex.focus(); };
  $('.cp-ok', pop).onclick = apply; hex.onkeydown = e => { if (e.key === 'Enter') apply(); if (e.key === 'Escape') closeIdeMenu(); };
  const sys = $('.cp-sys', pop);
  SYSCOLOR_NAMES.forEach((n, i) => { const v = (0x80000000 | i) >> 0; const r = h('div', { html: `<span style="background:${SYSCOLORS[i]}"></span>${n}` }); r.onmousedown = e => { e.preventDefault(); pick(v); }; sys.appendChild(r); });
  $('.cp-sys-t', pop).onclick = () => { pop.classList.toggle('sys-on'); place(); };
  document.body.appendChild(pop);
  const place = () => { const r = anchor.getBoundingClientRect(); const pr = pop.getBoundingClientRect(); pop.style.left = Math.max(4, Math.min(r.right - pr.width, window.innerWidth - pr.width - 4)) + 'px'; pop.style.top = Math.max(4, Math.min(r.bottom + 4, window.innerHeight - pr.height - 4)) + 'px'; };
  place();
  setTimeout(() => { IDE.menuCloser = ev => { if (!ev.target.closest('.vb-popup.idem')) closeIdeMenu(); }; window.addEventListener('mousedown', IDE.menuCloser, true); }, 0);
}
function projectPropsDialog() {
  const P = IDE.project; if (!P) return;
  return ideDialog('Project Properties', (c, done) => {
    const startOpts = ['Sub Main', ...P.modules.filter(m => m.kind === 'form').map(m => m.name)];
    c.innerHTML = `<div class="row"><label>Project Name:</label><input type="text" class="pn" style="width:180px"></div><div class="row"><label>Application Title:</label><input type="text" class="pt" style="width:180px"></div><div class="row"><label>Startup Object:</label><select class="ps" style="width:186px">${startOpts.map(o => `<option>${esc(o)}</option>`).join('')}</select></div><div class="btns"><button class="nb-btn">OK</button><button class="nb-btn">Cancel</button></div>`;
    const pn = $('.pn', c), pt = $('.pt', c), ps = $('.ps', c); pn.value = P.name; pt.value = P.title || ''; setSel(ps, P.startup || 'Sub Main');
    const [ok, ca] = c.querySelectorAll('.btns button');
    ok.onclick = () => { const nm = pn.value.trim(); if (!/^[A-Za-z][\w]*$/.test(nm)) { IDE.ui.msgBox('Invalid project name.', 48, APP_NAME); return; } if (P.fileName && P.fileName.toLowerCase() === (P.name + '.vbp').toLowerCase()) P.fileName = nm + '.vbp'; P.name = nm; P.title = pt.value; P.startup = ps.value; markDirty(); refreshAll(); done(true); };
    ca.onclick = () => done(false); return pn;
  });
}
function optionsDialog() {
  return ideDialog('Options', (c, done) => {
    c.innerHTML = `<div class="row"><label>IDE theme</label><select class="ot"><option value="dark">Dark</option><option value="light">Light</option></select></div>
      <div class="row"><label>App style</label><select class="os"><option value="modern">Modern (2026)</option><option value="classic">Classic 2000</option></select></div>
      <div class="row"><label>Show grid</label><input type="checkbox" class="og"></div>
      <div class="row"><label>Auto case</label><input type="checkbox" class="oc"><span style="color:var(--muted)">fix keyword case when leaving a line, like VB</span></div>
      <div class="row"><label>Locale</label><select class="ol"><option value="pt-BR">Portuguese (Brazil) — 1.234,56</option><option value="en-US">English (United States) — 1,234.56</option></select></div>
      <div style="color:var(--muted);max-width:420px;line-height:1.5">App style applies to the designer, to running programs and to generated apps. Locale controls how CStr, CDbl, Format and dates handle numbers, separators and month names, like the Windows regional settings.</div>
      <div class="btns"><button class="nb-btn">OK</button><button class="nb-btn">Cancel</button></div>`;
    $('.ot', c).value = IDE.opts.theme || 'dark'; $('.os', c).value = IDE.opts.skin || 'modern';
    $('.og', c).checked = IDE.opts.grid; $('.oc', c).checked = IDE.opts.autoCase; $('.ol', c).value = IDE.opts.locale;
    const [ok, ca] = c.querySelectorAll('.btns button');
    ok.onclick = () => { IDE.opts.theme = $('.ot', c).value; IDE.opts.skin = $('.os', c).value; IDE.opts.grid = $('.og', c).checked; IDE.opts.autoCase = $('.oc', c).checked; IDE.opts.locale = $('.ol', c).value; try { localStorage.setItem('neobasic.opts', JSON.stringify(IDE.opts)); } catch (e) { } applyTheme(); updateSkinLabel(); rerenderActive(); done(true); };
    ca.onclick = () => done(false); return ok;
  });
}
function helpDialog() {
  const txt = `NeoBasic opens and runs Visual Basic 5/6 projects (.vbp, .frm, .frx, .bas, .cls).

Language: Dim/ReDim/Preserve, Const, Type, Enum, Sub/Function/Property Get/Let/Set, classes (New, Set, Class_Initialize), If/ElseIf, Select Case, For/Next, For Each, Do/Loop, While/Wend, With, GoTo, On Error GoTo/Resume Next/Resume, Exit, End, arrays, ByRef/ByVal, Optional, ParamArray, #If/#Const, Collection, Scripting.Dictionary.

Functions: strings (Left, Mid, InStr, Replace, Split, Format...), math, dates (Now, DateAdd, DateDiff...), conversions (CInt, CStr, Val...), MsgBox, InputBox, RGB, IIf, DoEvents, text files (Open/Print #/Input #/Line Input/EOF) on a virtual disk, GetSetting/SaveSetting.

Controls: Form, MDIForm, CommandButton, Label, TextBox, CheckBox, OptionButton, Frame, ListBox, ComboBox, PictureBox (Print, Line, Circle, PSet, Cls), Image, Timer, Shape, Line, scroll bars, menus, control arrays (Load/Unload), CommonDialog (open/save).

Not yet: Windows API calls (Declare), third-party ActiveX controls (shown as placeholders), databases (Data control/DAO/ADO), binary files (Get/Put) and Crystal Reports-style reports (next phase).

Shortcuts: F5 Start, F7 Code, Shift+F7 Object, Ctrl+S Save, Ctrl+G Immediate window, Ctrl+K Command search, Del deletes a control, arrows move, Shift+arrows resize.`;
  return IDE.ui.msgBox(txt, 64, 'What NeoBasic supports');
}
function menuEditorDialog(m) {
  const root = m.frm.root;
  const flat = []; const walk = (n, lvl) => { for (const c of n.children) if (/\.menu$/i.test(c.type)) { flat.push({ node: c, lvl }); walk(c, lvl + 1); } }; walk(root, 0);
  const text = flat.map(x => '....'.repeat(x.lvl) + (nodeProps(x.node).caption || '') + ' | ' + x.node.name + (x.node.get('Index') !== undefined ? '(' + x.node.get('Index') + ')' : '') + (nodeProps(x.node).shortcut ? ' | ' + nodeProps(x.node).shortcut : '')).join('\n');
  return ideDialog('Menu Editor', (c, done) => {
    c.innerHTML = `<div style="max-width:420px;margin-bottom:6px">One line per item: <b>Caption | Name</b>. Start a line with <b>....</b> for each submenu level and use <b>-</b> as the caption for a separator. Example:<br><code>&amp;File | mnuFile<br>....&amp;Open | mnuOpen<br>....- | mnuSep1<br>....E&amp;xit | mnuExit</code></div><textarea spellcheck="false" style="width:420px;height:200px"></textarea><div class="btns"><button class="nb-btn">OK</button><button class="nb-btn">Cancel</button></div>`;
    const ta = $('textarea', c); ta.value = text;
    const [ok, ca] = c.querySelectorAll('.btns button');
    ok.onclick = () => {
      pushUndo(m);
      const old = new Map(flat.map(x => [x.node.name.toLowerCase() + '|' + (x.node.get('Index') ?? ''), x.node]));
      root.children = root.children.filter(ch => !/\.menu$/i.test(ch.type));
      const stack = [root];
      for (const raw of ta.value.split('\n')) {
        if (!raw.trim()) continue;
        const lvl = (/^(\.{4})*/.exec(raw)[0].length) / 4; const line = raw.slice(lvl * 4);
        const [cap, nmRaw, sc] = line.split('|').map(s => s.trim());
        const im = /^(\w+)(?:\((\d+)\))?$/.exec(nmRaw || ''); if (!im) continue;
        const key = im[1].toLowerCase() + '|' + (im[2] ?? '');
        const prev = old.get(key);
        const n = prev ? Object.assign(prev, { children: [] }) : new CtlNode('VB.Menu', im[1]);
        n.name = im[1]; n.setRaw('Caption', quote(cap || '')); if (im[2] !== undefined) n.setRaw('Index', im[2]); else n.remove('Index');
        if (sc) n.setRaw('Shortcut', sc); else n.remove('Shortcut');
        const parent = stack[Math.min(lvl, stack.length - 1)]; n.parent = parent; parent.children.push(n);
        stack.length = Math.min(lvl, stack.length - 1) + 1; stack.push(n);
      }
      m.dirty = true; markDirty(); rerenderActive(); renderProps(); done(true);
    };
    ca.onclick = () => done(false); return ta;
  });
}

// ---------- Exportar aplicativo ----------
// Make App: escolhe os formatos (.html, .exe para Windows, .sh para Linux)
function exportApp() {
  if (!IDE.project) return;
  const saved = (() => { try { return JSON.parse(localStorage.getItem('neobasic.makeapp') || 'null'); } catch (e) { return null; } })() || { html: true, exe: true, sh: true };
  return ideDialog('Make App', (c, done) => {
    c.innerHTML = `<div style="margin-bottom:10px">Choose what to create for <b>${esc(IDE.project.name)}</b>:</div>
      <label class="row" style="gap:8px"><input type="checkbox" class="fh"> <b>.html</b> &nbsp;<span style="color:var(--muted)">runs in any browser</span></label>
      <label class="row" style="gap:8px"><input type="checkbox" class="fe"> <b>.exe</b> &nbsp;<span style="color:var(--muted)">Windows — opens in its own window</span></label>
      <label class="row" style="gap:8px"><input type="checkbox" class="fs"> <b>.sh</b> &nbsp;<span style="color:var(--muted)">Linux (Mint, Neo Kurumin…) — opens in its own window</span></label>
      <div style="color:var(--muted);margin-top:8px;max-width:420px">.exe and .sh open the .html in an app window (Chrome, Brave, Vivaldi, Chromium, Opera or Edge — chosen in navegador.txt). Files are saved in the project folder, inside <b>Executables\\${esc(IDE.project.name)}</b>.</div>
      <div class="btns"><button class="nb-btn">Create</button><button class="nb-btn">Cancel</button></div>`;
    const fh = $('.fh', c), fe = $('.fe', c), fs = $('.fs', c); fh.checked = saved.html; fe.checked = saved.exe; fs.checked = saved.sh;
    const sync = () => { if (fe.checked || fs.checked) { fh.checked = true; fh.disabled = true; } else fh.disabled = false; }; fe.onchange = fs.onchange = sync; sync();
    const [ok, ca] = c.querySelectorAll('.btns button');
    ok.onclick = () => { const o = { html: fh.checked, exe: fe.checked, sh: fs.checked }; if (!o.html && !o.exe && !o.sh) return; try { localStorage.setItem('neobasic.makeapp', JSON.stringify(o)); } catch (e) { } done(true); setTimeout(() => makeAppFiles(o), 0); };
    ca.onclick = () => done(false); return ok;
  });
}
async function makeAppFiles(o) {
  const P = IDE.project; const name = (P.name || 'App').replace(/[^\w\- ]+/g, '_');
  const html = buildAppHtml();
  // grava em <pasta do projeto>\Executables\<Nome>\ (se o projeto ainda não tem pasta, pergunta onde salvar)
  if (!IDE.dirHandle && window.showDirectoryPicker) { await saveProject(false); }
  if (IDE.dirHandle) {
    try {
      if (IDE.dirHandle.requestPermission) { const pm = await IDE.dirHandle.requestPermission({ mode: 'readwrite' }); if (pm !== 'granted') throw new Error('Write permission denied'); }
      const ex = await IDE.dirHandle.getDirectoryHandle('Executables', { create: true });
      const out = await ex.getDirectoryHandle(name, { create: true });
      const [exeB64, shB64] = (IDE.launchersSrc || '|').split('|');
      const enc = new TextEncoder(); const list = [[name + '.html', enc.encode(html)]];
      if (o.exe && exeB64) list.push([name + '.exe', b64ToU8(exeB64.trim())]);
      if (o.sh && shB64) list.push([name + '.sh', b64ToU8(shB64.trim())]);
      if (o.exe || o.sh) list.push(['navegador.txt', enc.encode('chrome\r\n')], ['LEIA-ME.txt', enc.encode(appReadme(P, name, o))]);
      // o Windows/navegador pode bloquear a criação de .exe; nesse caso os outros arquivos continuam e explicamos a alternativa
      const made = []; let exeBlocked = false;
      for (const [fn, data] of list) {
        try { const fh = await out.getFileHandle(fn, { create: true }); const w = await fh.createWritable(); await w.write(data); await w.close(); made.push(fn); }
        catch (e) { if (/\.exe$/i.test(fn)) { exeBlocked = true; try { await out.removeEntry(fn); } catch (e2) { } } else throw e; }
      }
      setStatus(`App created in the project folder: Executables\\${name}\\ (${made.join(', ')})`);
      await IDE.ui.msgBox(`App created in the project folder:\n\nExecutables\\${name}\\\n\n` + made.map(x => '  ' + x).join('\n')
        + (exeBlocked ? `\n\nWindows blocked creating ${name}.exe (it does that with any new .exe made by a browser). To open ${name} in its own window on Windows, do one of these:\n  • Drag ${name}.html onto NeoBasic.exe once: it opens the program and adds "${name}" to the Start menu.\n  • Or copy NeoBasic.exe into this folder and rename the copy to ${name}.exe.` : '')
        + (o.sh ? '\n\nLinux: the first time, right-click ' + name + '.sh > Properties > Permissions > "Allow executing file as program".' : ''), exeBlocked ? 48 : 64, APP_NAME);
      return;
    } catch (e) { await IDE.ui.msgBox('Could not write to the project folder: ' + e.message + '\n\nThe app will be downloaded instead.', 48, APP_NAME); }
  }
  if (!o.exe && !o.sh) { downloadBlob(new Blob([html], { type: 'text/html' }), name + '.html'); setStatus(`App ${name}.html created. Open it in any browser (Windows or Linux).`); return; }
  const [exeB64, shB64] = (IDE.launchersSrc || '|').split('|');
  const enc = new TextEncoder(); const files = [{ name: `${name}/${name}.html`, data: enc.encode(html) }];
  if (o.exe && exeB64) files.push({ name: `${name}/${name}.exe`, data: b64ToU8(exeB64.trim()) });
  if (o.sh && shB64) files.push({ name: `${name}/${name}.sh`, data: b64ToU8(shB64.trim()), mode: 0o100755 });
  files.push({ name: `${name}/navegador.txt`, data: enc.encode('chrome\r\n') });
  files.push({ name: `${name}/LEIA-ME.txt`, data: enc.encode(appReadme(P, name, o)) });
  downloadBlob(new Blob([makeZip(files)], { type: 'application/zip' }), name + '.zip');
  setStatus(`App ${name}.zip created (${[o.html && '.html', o.exe && '.exe', o.sh && '.sh'].filter(Boolean).join(', ')}).`);
}
function appReadme(P, name, o) {
  return `${P.title || name} - feito com NeoBasic\r\n\r\n` + (o.exe ? `Windows: dois cliques em ${name}.exe\r\n  (se não houver ${name}.exe: arraste ${name}.html para cima do NeoBasic.exe; ele abre o programa e cria o atalho "${name}" no Menu Iniciar.\r\n   Ou copie o NeoBasic.exe para esta pasta e renomeie a cópia para ${name}.exe)\r\n` : '') + (o.sh ? `Linux: dois cliques em ${name}.sh (na primeira vez: clique direito > Propriedades > Permissões > "Permitir executar o arquivo como programa")\r\n` : '') + `\r\nO programa abre em janela própria usando um navegador Chromium.\r\nPara escolher qual, escreva no navegador.txt: chrome, brave, vivaldi, chromium, opera ou edge.\r\nDeixe todos os arquivos juntos na mesma pasta.\r\n`;
}
function buildAppHtml() {
  const dbs = dbFilesToSave(true);
  const files = projectFiles().concat(dbs.map(d => ({ path: d.path, data: d.data })));
  const P = IDE.project;
  const data = { name: P.name, title: P.title || P.name, startup: P.startup, locale: IDE.opts.locale, skin: NB_SKIN, files: files.map(f => ({ path: f.path, b64: u8ToB64(f.data) })) };
  const core = IDE.coreSrc;
  // o motor de banco de dados só vai junto quando o programa usa banco
  const usesDb = dbs.length || IDE.project.modules.some(m => /\b(OpenDatabase|DBEngine|Recordset)\b/i.test(getCode(m) || '') || (m.kind === 'form' && /VB\.Data\b/.test(serializeFrm(m.frm))));
  const dblib = usesDb ? `<script id="nb-dblib">${IDE.dbLibSrc.replace(/<\/script/gi, '<\\/script')}<\/script><script>${IDE.sqlWasmSrc}<\/script>` : '';
  const css = (document.getElementById('nb-fonts') || { textContent: '' }).textContent + '\n' + document.getElementById('nb-runcss').textContent;
  const html = `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(data.title)}</title>
<style id="nb-runcss">${css}</style>
<style>html,body{margin:0;height:100%;overflow:hidden}#stage{position:fixed;inset:0;background:radial-gradient(1200px 600px at 30% 20%,#1f2a44 0%,#12151c 55%,#0c0e12 100%)}#ended{position:fixed;inset:0;display:none;align-items:center;justify-content:center;color:#fff;font:bold 16px Tahoma,sans-serif;flex-direction:column;gap:12px}</style>
</head><body class="nb-root"><div id="stage" class="nb-root"></div><div id="ended"><div>The program has ended.</div><button class="nb-btn" onclick="location.reload()">Run again</button></div>
${dblib}
<script id="nb-core">${core.replace(/<\/script/gi, '<\\/script')}<\/script>
<script>
const NB_APP = ${JSON.stringify(data).replace(/</g, '\\u003c')};
(function () {
  const b64 = b => { const s = atob(b); const u = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i); return u; };
  const map = new Map(); for (const f of NB_APP.files) map.set(f.path.replace(/\\\\/g, '/').toLowerCase(), { path: f.path.replace(/\\\\/g, '/'), bytes: b64(f.b64) });
  const find = p => { p = p.replace(/\\\\/g, '/').toLowerCase(); if (map.has(p)) return map.get(p); const n = p.split('/').pop(); for (const [k, v] of map) if (k.split('/').pop() === n) return v; return null; };
  const vbpE = [...map.values()].find(v => /\\.vbp$/i.test(v.path)); const vbp = parseVbp(decodeText(vbpE.bytes));
  const mods = [];
  for (const f of vbp.forms) { const e = find(f); const frm = parseFrm(decodeText(e.bytes), e.path); const frx = {}; frm.root.walk(n => { for (const p of n.props) { const m = /^\\$?"([^"]+\\.frx)":/i.exec(p.raw); if (m) { const x = find(m[1]); if (x) frx[m[1].toLowerCase()] = x.bytes; } } }); mods.push({ kind: 'form', name: frm.name, frm, frxLookup: n => frx[String(n).toLowerCase()] || null }); }
  for (const f of vbp.modules) { const e = find(f.file); const b = parseBas(decodeText(e.bytes)); mods.push({ kind: 'std', name: b.name, code: b.code }); }
  for (const f of vbp.classes) { const e = find(f.file); const c = parseCls(decodeText(e.bytes)); mods.push({ kind: 'class', name: c.name, code: c.code, defaultMember: c.defaultMember }); }
  setLocale(NB_APP.locale); setSkin(NB_APP.skin || 'classic');
  document.title = NB_APP.title;
  const stage = document.getElementById('stage');
  const host = new RunHost(stage, { onEnd: () => { stage.style.display = 'none'; document.getElementById('ended').style.display = 'flex'; }, beep: true });
  host.appName = NB_APP.title; host.appPath = 'C:\\\\NeoBasic\\\\' + NB_APP.name;
  host.getDbFile = p => { const base = String(p).replace(/\\//g, '\\\\').split('\\\\').pop().toLowerCase(); const stem = base.replace(/\\.[^.]*$/, ''); const all = [...map.values()].filter(v => /\\.(mdb|accdb|db|sqlite3?)$/i.test(v.path) && v.path.split('/').pop().toLowerCase().replace(/\\.[^.]*$/, '') === stem); const f = all.find(v => /\\.(db|sqlite3?)$/i.test(v.path)) || all[0]; return f ? { name: f.path.split('/').pop(), bytes: f.bytes } : null; };
  const rt = new VBRuntime(host);
  try { rt.load(buildRuntimeProject({ name: NB_APP.name, title: NB_APP.title, startup: NB_APP.startup, modules: mods })); rt.run(); }
  catch (e) { host.msgBox('Error: ' + (e.description || e.message) + (e.line ? ' (line ' + e.line + ' of ' + e.module + ')' : ''), 16, NB_APP.title); }
})();
<\/script></body></html>`;
  return html;
}

// ---------- Projeto de exemplo ----------
function demoProject() {
  const frmText = `VERSION 5.00
Begin VB.Form frmDemo
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Hello, NeoBasic!"
   ClientHeight    =   4095
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5760
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   4095
   ScaleWidth      =   5760
   StartUpPosition =   2  'CenterScreen
   Begin VB.Timer tmrRelogio
      Interval        =   1000
      Left            =   5160
      Top             =   3480
   End
   Begin VB.Frame fraConta
      Caption         =   "Quick calculator"
      Height          =   1455
      Left            =   120
      TabIndex        =   7
      Top             =   1080
      Width           =   5535
      Begin VB.CommandButton cmdOp
         Caption         =   "x"
         Height          =   375
         Index           =   2
         Left            =   4560
         TabIndex        =   4
         Top             =   840
         Width           =   735
      End
      Begin VB.CommandButton cmdOp
         Caption         =   "-"
         Height          =   375
         Index           =   1
         Left            =   3720
         TabIndex        =   3
         Top             =   840
         Width           =   735
      End
      Begin VB.CommandButton cmdOp
         Caption         =   "+"
         Height          =   375
         Index           =   0
         Left            =   2880
         TabIndex        =   2
         Top             =   840
         Width           =   735
      End
      Begin VB.TextBox txtB
         Height          =   285
         Left            =   1560
         TabIndex        =   1
         Text            =   "5"
         Top             =   360
         Width           =   1215
      End
      Begin VB.TextBox txtA
         Height          =   285
         Left            =   240
         TabIndex        =   0
         Text            =   "10"
         Top             =   360
         Width           =   1215
      End
      Begin VB.Label lblResultado
         Caption         =   "Result:"
         Height          =   255
         Left            =   240
         Top             =   900
         Width           =   2535
      End
   End
   Begin VB.ListBox lstHist
      Height          =   1035
      Left            =   120
      TabIndex        =   8
      Top             =   2880
      Width           =   3975
   End
   Begin VB.CommandButton cmdOla
      Caption         =   "&Say hello"
      Default         =   -1  'True
      Height          =   495
      Left            =   4200
      TabIndex        =   6
      Top             =   2880
      Width           =   1455
   End
   Begin VB.TextBox txtNome
      Height          =   285
      Left            =   1440
      TabIndex        =   5
      Top             =   600
      Width           =   2655
   End
   Begin VB.Label lblHora
      Alignment       =   1  'Right Justify
      Caption         =   "00:00:00"
      Height          =   255
      Left            =   4200
      Top             =   120
      Width           =   1455
   End
   Begin VB.Label lblTitulo
      Caption         =   "Welcome to NeoBasic"
      BeginProperty Font
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00800000&
      Height          =   375
      Left            =   120
      Top             =   120
      Width           =   3975
   End
   Begin VB.Label lblNome
      Caption         =   "Your name:"
      Height          =   255
      Left            =   120
      Top             =   630
      Width           =   1215
   End
   Begin VB.Label lblHist
      Caption         =   "History:"
      Height          =   255
      Left            =   120
      Top             =   2640
      Width           =   1215
   End
End
Attribute VB_Name = "frmDemo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Load()
    lblHora.Caption = Format(Now, "hh:mm:ss")
    lstHist.AddItem "Program started on " & Format(Date, "Short Date")
End Sub

Private Sub cmdOla_Click()
    If Trim(txtNome.Text) = "" Then
        MsgBox "Please type your name first.", vbExclamation, "Attention"
        txtNome.SetFocus
    Else
        MsgBox "Hello, " & txtNome.Text & "! BASIC is alive.", vbInformation
        lstHist.AddItem "Said hello to " & txtNome.Text
    End If
End Sub

Private Sub cmdOp_Click(Index As Integer)
    Dim a As Double, b As Double, r As Double
    If Not IsNumeric(txtA.Text) Or Not IsNumeric(txtB.Text) Then
        MsgBox "Please type two numbers.", vbCritical
        Exit Sub
    End If
    a = CDbl(txtA.Text): b = CDbl(txtB.Text)
    Select Case Index
        Case 0: r = a + b
        Case 1: r = a - b
        Case 2: r = a * b
    End Select
    lblResultado.Caption = "Result: " & Format(r, "#,##0.00")
    lstHist.AddItem txtA.Text & " " & cmdOp(Index).Caption & " " & txtB.Text & " = " & r
    lstHist.ListIndex = lstHist.ListCount - 1
End Sub

Private Sub tmrRelogio_Timer()
    lblHora.Caption = Format(Now, "hh:mm:ss")
End Sub
`;
  const frm = parseFrm(frmText, 'frmDemo.frm');
  const m = makeModule('form', 'frmDemo', { frm, fileName: 'frmDemo.frm' });
  return { name: 'Sample', title: 'NeoBasic Sample', startup: 'frmDemo', modules: [m], vbp: null, fileName: 'Sample.vbp', extra: [], dirty: true };
}

// ---------- Arrastar e soltar ----------
function setupDrop() {
  const note = $('#dropnote'); let cnt = 0;
  window.addEventListener('dragenter', e => { if (IDE.running) return; if ([...e.dataTransfer.types].includes('Files')) { cnt++; note.classList.add('on'); } });
  window.addEventListener('dragleave', () => { cnt = Math.max(0, cnt - 1); if (!cnt) note.classList.remove('on'); });
  window.addEventListener('dragover', e => { if ([...e.dataTransfer.types].includes('Files')) e.preventDefault(); });
  window.addEventListener('drop', async e => {
    e.preventDefault(); cnt = 0; note.classList.remove('on'); if (IDE.running) return;
    const list = [];
    const items = [...e.dataTransfer.items].map(i => i.webkitGetAsEntry && i.webkitGetAsEntry()).filter(Boolean);
    const readEntry = (en, pre) => new Promise(res => {
      if (list.length >= MAX_PROJECT_FILES || pre.split('/').length > 5) return res();
      if (en.isFile) en.file(f => { if (/\.(vbp|frm|frx|bas|cls|mdb|accdb|db|sqlite|sqlite3)$/i.test(f.name)) list.push({ path: pre + f.name, file: f }); res(); }, () => res());
      else if (en.isDirectory) { const r = en.createReader(); const all = []; const rd = () => r.readEntries(async ents => { if (!ents.length) { for (const x of all) await readEntry(x, pre + en.name + '/'); res(); } else { all.push(...ents); rd(); } }, () => res()); rd(); }
      else res();
    });
    if (items.length) for (const en of items) await readEntry(en, '');
    else for (const f of e.dataTransfer.files) list.push({ path: f.name, file: f });
    if (!list.length) return;
    if (!(await confirmDiscard())) return;
    IDE.dirHandle = null;
    await openProjectFromList(list, null);
  });
}

// ---------- Início ----------
function boot() {
  try {
    const o = JSON.parse(localStorage.getItem('neobasic.opts') || 'null');
    if (o) Object.assign(IDE.opts, o);
    if (!localStorage.getItem('neobasic.ui043')) {
      IDE.opts.theme = 'light';
      localStorage.setItem('neobasic.opts', JSON.stringify(IDE.opts));
      localStorage.setItem('neobasic.ui043', '1');
    }
    // 0.6: datas e números no formato brasileiro (a interface continua em inglês); muda em Tools > Options > Locale
    if (!localStorage.getItem('neobasic.loc060')) { IDE.opts.locale = 'pt-BR'; localStorage.setItem('neobasic.opts', JSON.stringify(IDE.opts)); localStorage.setItem('neobasic.loc060', '1'); }
  } catch (e) { }
  IDE.coreSrc = (document.getElementById('nb-core') || {}).textContent || '';
  IDE.launchersSrc = (document.getElementById('nb-launchers') || {}).textContent || '';
  IDE.dbLibSrc = (document.getElementById('nb-dblib') || {}).textContent || ''; IDE.sqlWasmSrc = (document.getElementById('nb-sqlwasm') || {}).textContent || '';
  IDE.appMode = new URLSearchParams(location.search).has('app');
  buildShell(); renderWelcome();
  let restored = false;
  try { const s = localStorage.getItem('neobasic.autosave'); if (s) { const p = restoreSnapshot(JSON.parse(s)); setProject(p); restored = true; setStatus('Previous project restored from autosave.'); } } catch (e) { console.warn('autosave', e); }
  if (!restored) refreshAll();
  refreshToolbar();
}
window.addEventListener('DOMContentLoaded', boot);
