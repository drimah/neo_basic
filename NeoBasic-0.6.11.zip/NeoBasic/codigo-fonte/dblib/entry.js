import MDBReader from 'mdb-reader';
import initSqlJs from 'sql.js/dist/sql-wasm.js';
import { Buffer } from 'buffer';
globalThis.NB_DBLIB = { MDBReader, initSqlJs, Buffer };
