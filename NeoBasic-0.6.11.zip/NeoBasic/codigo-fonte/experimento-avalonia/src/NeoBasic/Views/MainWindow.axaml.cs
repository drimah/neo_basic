using System.Collections.ObjectModel;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Avalonia.Media;
using Avalonia.VisualTree;

namespace NeoBasic.Views;

public partial class MainWindow : Window
{
    public ObservableCollection<ToolboxItem> ToolboxItems { get; } = new()
    {
        new("Pointer", "↖"), new("PictureBox", "▧"),
        new("Label", "A"), new("TextBox", "▭"),
        new("Frame", "▱"), new("CommandButton", "▰"),
        new("CheckBox", "☑"), new("OptionButton", "◉"),
        new("ListBox", "☷"), new("ComboBox", "▤"),
        new("HScrollBar", "━"), new("VScrollBar", "┃"),
        new("Timer", "◴"), new("Calendar", "▦"),
        new("DriveListBox", "▱"), new("FileListBox", "▯"),
        new("Shape", "◇"), new("Line", "／"),
        new("Image", "▧"), new("Data", "‹›")
    };

    public MainWindow()
    {
        InitializeComponent();
        DataContext = this;
    }

    private void InitializeComponent() => AvaloniaXamlLoader.Load(this);

    private void Tool_Click(object? sender, RoutedEventArgs e)
    {
        if (sender is Button button)
        {
            foreach (var child in FindControls<Button>(this).Where(b => b.Classes.Contains("tool")))
                child.Background = Brushes.Transparent;
            button.Background = new SolidColorBrush(Color.Parse("#D9E9FF"));
        }
    }

    private static IEnumerable<T> FindControls<T>(Control root) where T : Control
    {
        if (root is T match) yield return match;
        foreach (var child in root.GetVisualChildren())
        {
            if (child is Control control)
                foreach (var nested in FindControls<T>(control))
                    yield return nested;
        }
    }

    private void Minimize_Click(object? sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
    private void Maximize_Click(object? sender, RoutedEventArgs e) =>
        WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
    private void Close_Click(object? sender, RoutedEventArgs e) => Close();
}
