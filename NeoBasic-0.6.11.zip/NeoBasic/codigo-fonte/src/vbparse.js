// ===== New Basic — lexer & parser (subset compatível com VB6) =====
'use strict';

class VBSyntaxError extends Error {
  constructor(msg, line) { super(msg); this.line = line; this.isSyntax = true; }
}

// ---------- Lexer ----------
function preprocess(src) {
  const lines = src.split('\n');
  const consts = { win32: true, win16: false, win64: false, vba6: true, vba7: false, mac: false, neobasic: true };
  const stack = []; // {active, taken}
  const evalCond = (e) => {
    let x = e.replace(/\bThen\b/i, '').trim();
    x = x.replace(/[A-Za-z_]\w*/g, w => { const lw = w.toLowerCase(); if (lw === 'and') return '&&'; if (lw === 'or') return '||'; if (lw === 'not') return '!'; if (lw === 'true') return 'true'; if (lw === 'false') return 'false'; return (lw in consts) ? JSON.stringify(consts[lw]) : 'false'; });
    x = x.replace(/<>/g, '!=').replace(/([^<>!=])=([^=])/g, '$1==$2');
    try { return !!Function('return (' + x + ')')(); } catch (er) { return false; }
  };
  const active = () => stack.every(s => s.active);
  for (let i = 0; i < lines.length; i++) {
    const t = lines[i].trim();
    let m;
    if ((m = /^#if\s+(.*)$/i.exec(t))) { const par = active(); const c = par && evalCond(m[1]); stack.push({ active: c, taken: c, par }); lines[i] = ''; continue; }
    if ((m = /^#elseif\s+(.*)$/i.exec(t))) { const s = stack[stack.length - 1]; if (s) { const c = s.par && !s.taken && evalCond(m[1]); s.active = c; s.taken = s.taken || c; } lines[i] = ''; continue; }
    if (/^#else\b/i.test(t)) { const s = stack[stack.length - 1]; if (s) { s.active = s.par && !s.taken; s.taken = true; } lines[i] = ''; continue; }
    if (/^#end\s*if\b/i.test(t)) { stack.pop(); lines[i] = ''; continue; }
    if ((m = /^#const\s+(\w+)\s*=\s*(.*)$/i.exec(t))) { if (active()) consts[m[1].toLowerCase()] = evalCond(m[2]) || (/^-?\d+$/.test(m[2].trim()) ? Number(m[2]) : false); lines[i] = ''; continue; }
    if (!active()) lines[i] = '';
  }
  return lines.join('\n');
}

function lex(src) {
  if (/^\s*#(if|const)\b/im.test(src)) src = preprocess(src);
  const toks = [];
  let i = 0, line = 1;
  const n = src.length;
  let spaced = false;
  const push = (t, v, extra) => { const o = { t, v, line, sp: spaced }; spaced = false; if (t === 'id') o.k = v.toLowerCase(); if (extra) Object.assign(o, extra); toks.push(o); };
  const prevSig = () => toks.length ? toks[toks.length - 1] : null;
  const atStmtStart = () => { const p = prevSig(); return !p || p.t === 'nl' || (p.t === 'op' && p.v === ':'); };
  while (i < n) {
    const c = src[i];
    if (c === '\r') { i++; continue; }
    if (c === '\n') { push('nl', '\n'); line++; i++; continue; }
    if (c === ' ' || c === '\t') { i++; spaced = true; continue; }
    // continuação de linha " _"
    if (c === '_' && (i + 1 >= n || /[ \t\r\n]/.test(src[i + 1]))) {
      let j = i + 1; while (j < n && (src[j] === ' ' || src[j] === '\t' || src[j] === '\r')) j++;
      if (j >= n || src[j] === '\n') { i = j + 1; line++; continue; }
    }
    if (c === "'") { while (i < n && src[i] !== '\n') i++; continue; }
    if (c === '"') {
      let s = ''; i++;
      while (i < n) {
        if (src[i] === '"') { if (src[i + 1] === '"') { s += '"'; i += 2; continue; } i++; break; }
        if (src[i] === '\n') break;
        s += src[i++];
      }
      push('str', s); continue;
    }
    if (c === '#') {
      const p = prevSig();
      const m = /^#([0-9\/\-:. ]+(?:[AaPp][Mm])?)#/.exec(src.slice(i, i + 40));
      if (m && !(p && (p.t === 'id' || p.t === 'num' || (p.t === 'op' && p.v === ')')))) { push('date', m[1].trim()); i += m[0].length; continue; }
      push('op', '#'); i++; continue;
    }
    if (c === '&' && /[hHoO]/.test(src[i + 1] || '')) {
      const hex = /[hH]/.test(src[i + 1]);
      let j = i + 2, s = '';
      while (j < n && (hex ? /[0-9a-fA-F]/ : /[0-7]/).test(src[j])) s += src[j++];
      if (s.length) {
        let suffixLong = false;
        if (src[j] === '&') { j++; suffixLong = true; }
        else if (src[j] === '%') j++;
        let v = parseInt(s, hex ? 16 : 8);
        // literais &H de 16 bits sem & são Integer com sinal
        if (!suffixLong && v <= 0xFFFF && s.length <= 4 && v > 0x7FFF) v -= 0x10000;
        else if (v > 0x7FFFFFFF) v -= 0x100000000;
        push('num', v); i = j; continue;
      }
    }
    if (/[0-9]/.test(c) || (c === '.' && /[0-9]/.test(src[i + 1] || ''))) {
      const m = /^(\d*\.?\d+(?:[eE][+\-]?\d+)?|\d+\.)/.exec(src.slice(i));
      let j = i + m[0].length;
      if (/[%&!#@]/.test(src[j] || '') && !/[A-Za-z0-9_]/.test(src[j + 1] || '')) {
        if (!(src[j] === '&' && /[A-Za-z0-9_"]/.test(src[j + 1] || ''))) j++;
      }
      push('num', parseFloat(m[0])); i = j; continue;
    }
    if (/[A-Za-z_À-ɏ]/.test(c)) {
      let j = i; while (j < n && /[A-Za-z0-9_À-ɏ]/.test(src[j])) j++;
      let word = src.slice(i, j);
      if (/[$%@]/.test(src[j] || '')) j++;
      else if (src[j] === '!' && !/[A-Za-z_\[]/.test(src[j + 1] || '')) j++;
      else if (src[j] === '#' && !/[A-Za-z0-9_"]/.test(src[j + 1] || '')) j++;
      else if (src[j] === '&' && /^[ \t]*([=),:+\-*\/<>\\\r\n]|$)/.test(src.slice(j + 1, j + 4)) && !/[hHoO]/.test(src[j + 1] || '')) j++;
      const lw = word.toLowerCase();
      if (lw === 'rem' && atStmtStart()) { while (j < n && src[j] !== '\n') j++; i = j; continue; }
      push('id', word); i = j; continue;
    }
    if (c === '[') { let j = i + 1; while (j < n && src[j] !== ']' && src[j] !== '\n') j++; push('id', src.slice(i + 1, j)); i = j + 1; continue; }
    const two = src.substr(i, 2);
    if (two === '<=' || two === '>=' || two === '<>' || two === ':=' || two === '=<' || two === '=>') {
      const map = { '=<': '<=', '=>': '>=' }; push('op', map[two] || two); i += 2; continue;
    }
    if ('=<>+-*/\\^&(),.:;!'.includes(c)) { push('op', c); i++; continue; }
    // caractere desconhecido: ignora
    i++;
  }
  push('nl', '\n'); push('eof', null);
  return toks;
}

// ---------- Parser ----------
const KW_STMT_END = new Set(['end', 'else', 'elseif', 'next', 'loop', 'wend', 'case']);

class Parser {
  constructor(src, modName) { this.toks = lex(src); this.p = 0; this.mod = modName || ''; }
  get cur() { return this.toks[this.p]; }
  la(k) { return this.toks[this.p + k] || this.toks[this.toks.length - 1]; }
  err(msg, t) { throw new VBSyntaxError(msg, (t || this.cur).line); }
  isKw(w, t) { t = t || this.cur; return t.t === 'id' && t.k === w; }
  isOp(o, t) { t = t || this.cur; return t.t === 'op' && t.v === o; }
  eatKw(w) { if (this.isKw(w)) { this.p++; return true; } return false; }
  eatOp(o) { if (this.isOp(o)) { this.p++; return true; } return false; }
  expectKw(w) { if (!this.eatKw(w)) this.err(`Expected: ${w}`); }
  expectOp(o) { if (!this.eatOp(o)) this.err(`Expected: ${o}`); }
  ident() { const t = this.cur; if (t.t !== 'id') this.err('Expected: identifier'); this.p++; return t.v; }
  atEOS() { const t = this.cur; return t.t === 'nl' || t.t === 'eof' || (t.t === 'op' && t.v === ':') || (t.t === 'id' && t.k === 'else' && this.inSingleIf); }
  skipEOS() { while (this.cur.t === 'nl' || this.isOp(':')) this.p++; }
  skipLine() { while (this.cur.t !== 'nl' && this.cur.t !== 'eof') this.p++; }

  // ===== Módulo =====
  parseModule() {
    const mod = { decls: [], procs: {}, types: {}, enums: {}, consts: [], declares: {}, optionExplicit: false, events: [] };
    let pendingVis = null;
    for (;;) {
      this.skipEOS();
      const t = this.cur;
      if (t.t === 'eof') break;
      if (t.t !== 'id') { this.err('Invalid outside procedure'); }
      const k = t.k;
      if (k === 'attribute' || k === 'implements' || k === 'deftype' || /^def(int|lng|str|bool|sng|dbl|var|obj|cur|date|byte)$/.test(k)) { this.skipLine(); continue; }
      if (k === 'option') { this.p++; if (this.eatKw('explicit')) mod.optionExplicit = true; else if (this.eatKw('compare')) mod.compareText = this.isKw('text'); else if (this.eatKw('base')) mod.optionBase = this.cur.v; this.skipLine(); continue; }
      let vis = 'public';
      if (k === 'private' || k === 'public' || k === 'global' || k === 'friend' || k === 'static') {
        vis = (k === 'private') ? 'private' : 'public';
        const nk = this.la(1);
        if (nk.t === 'id' && ['sub', 'function', 'property', 'type', 'enum', 'declare', 'const', 'event', 'static', 'friend'].includes(nk.k)) { this.p++; if (this.isKw('static') || this.isKw('friend')) this.p++; }
        else { // Private x As Integer
          this.p++; const d = this.parseDimList(vis, false); mod.decls.push(...d); continue;
        }
      }
      if (this.isKw('dim')) { this.p++; mod.decls.push(...this.parseDimList('private', false)); continue; }
      if (this.isKw('const')) { this.p++; mod.consts.push(...this.parseConstList(vis)); continue; }
      if (this.isKw('sub') || this.isKw('function') || this.isKw('property')) { const pr = this.parseProc(vis); this.addProc(mod, pr); continue; }
      if (this.isKw('type')) { this.p++; const name = this.ident(); const fields = []; this.skipEOS();
        while (!this.isKw('end')) { const fn = this.ident(); let dims = null; if (this.isOp('(')) dims = this.parseDims(); let type = 'variant', typeLen = 0; if (this.eatKw('as')) { type = this.parseTypeName(); if (this.eatOp('*')) { typeLen = this.cur.v; this.p++; } } fields.push({ name: fn, type, dims }); this.skipEOS(); }
        this.expectKw('end'); this.expectKw('type'); mod.types[name.toLowerCase()] = { name, fields }; continue; }
      if (this.isKw('enum')) { this.p++; const name = this.ident(); const items = []; this.skipEOS(); let val = 0;
        while (!this.isKw('end')) { const nm = this.ident(); let expr = null; if (this.eatOp('=')) expr = this.parseExpr(); items.push({ name: nm, expr }); this.skipEOS(); }
        this.expectKw('end'); this.expectKw('enum'); mod.enums[name.toLowerCase()] = { name, items }; continue; }
      if (this.isKw('declare')) { this.p++; this.eatKw('ptrsafe'); const kind = this.ident(); const name = this.ident(); this.skipLine(); mod.declares[name.toLowerCase()] = { name, kind }; continue; }
      if (this.isKw('event')) { this.skipLine(); continue; }
      this.err(`Invalid outside procedure: ${t.v}`);
    }
    return mod;
  }
  addProc(mod, pr) {
    const key = pr.name.toLowerCase();
    if (pr.kind === 'propget' || pr.kind === 'proplet' || pr.kind === 'propset') {
      const slot = mod.procs[key] && mod.procs[key].isProperty ? mod.procs[key] : (mod.procs[key] = { isProperty: true, name: pr.name, vis: pr.vis });
      slot[pr.kind] = pr;
    } else mod.procs[key] = pr;
  }
  parseTypeName() {
    this.eatKw('new');
    let name = this.ident();
    while (this.eatOp('.')) name = this.ident(); // VB.Form, Scripting.Dictionary
    return name.toLowerCase();
  }
  parseDims() { // ( [lb To] ub, ... )  ou ()
    this.expectOp('(');
    const dims = [];
    if (this.eatOp(')')) return dims;
    do {
      let a = this.parseExpr(), b = null;
      if (this.eatKw('to')) b = this.parseExpr();
      dims.push(b ? { lb: a, ub: b } : { lb: null, ub: a });
    } while (this.eatOp(','));
    this.expectOp(')');
    return dims;
  }
  parseDimList(vis, isStatic) {
    const out = [];
    do {
      this.eatKw('withevents');
      const line = this.cur.line;
      const name = this.ident();
      let dims = null; if (this.isOp('(')) dims = this.parseDims();
      let type = 'variant', isNew = false;
      if (this.eatKw('as')) { if (this.eatKw('new')) isNew = true; type = this.parseTypeName(); if (this.eatOp('*')) this.p++; }
      out.push({ k: 'dim', name, dims, type, isNew, vis, isStatic, line });
    } while (this.eatOp(','));
    return out;
  }
  parseConstList(vis) {
    const out = [];
    do { const name = this.ident(); if (this.eatKw('as')) this.parseTypeName(); this.expectOp('='); out.push({ name, expr: this.parseExpr(), vis }); } while (this.eatOp(','));
    return out;
  }
  parseProc(vis) {
    const startTok = this.cur;
    let kind;
    if (this.eatKw('sub')) kind = 'sub';
    else if (this.eatKw('function')) kind = 'function';
    else { this.expectKw('property'); if (this.eatKw('get')) kind = 'propget'; else if (this.eatKw('let')) kind = 'proplet'; else if (this.eatKw('set')) kind = 'propset'; else this.err('Expected: Get, Let, or Set'); }
    const name = this.ident();
    const params = [];
    if (this.eatOp('(')) {
      if (!this.isOp(')')) do {
        const pa = { name: '', byVal: false, optional: false, paramArray: false, type: 'variant', def: null, isArray: false };
        for (;;) {
          if (this.eatKw('optional')) pa.optional = true;
          else if (this.eatKw('byval')) pa.byVal = true;
          else if (this.eatKw('byref')) pa.byVal = false;
          else if (this.eatKw('paramarray')) pa.paramArray = true;
          else break;
        }
        pa.name = this.ident();
        if (this.eatOp('(')) { this.expectOp(')'); pa.isArray = true; }
        if (this.eatKw('as')) pa.type = this.parseTypeName();
        if (this.eatOp('=')) pa.def = this.parseExpr();
        params.push(pa);
      } while (this.eatOp(','));
      this.expectOp(')');
    }
    let retType = 'variant';
    if (this.eatKw('as')) { retType = this.parseTypeName(); if (this.eatOp('(')) this.expectOp(')'); }
    const endWord = kind === 'sub' ? 'sub' : kind === 'function' ? 'function' : 'property';
    const body = this.parseBlock(() => this.isKw('end') && this.isKw(endWord, this.la(1)));
    this.expectKw('end'); this.p++;
    return { kind, name, params, retType, body, vis, line: startTok.line, mod: this.mod };
  }

  // ===== Blocos =====
  parseBlock(stop) {
    const stmts = [];
    for (;;) {
      // rótulos: identificador seguido de ':' no início da linha
      while (this.cur.t === 'nl' || this.isOp(':')) this.p++;
      if (this.cur.t === 'eof') { if (stop) this.err('Block not closed (missing End?)'); break; }
      if (stop && stop()) break;
      const t = this.cur;
      const prev = this.toks[this.p - 1];
      if (t.t === 'id' && this.isOp(':', this.la(1)) && (!prev || prev.t === 'nl') && !KW_STMT_END.has(t.k)) {
        stmts.push({ k: 'label', name: t.k, line: t.line }); this.p += 2; continue;
      }
      if (t.t === 'num' && (!prev || prev.t === 'nl')) { stmts.push({ k: 'label', name: String(t.v), line: t.line }); this.p++; continue; }
      const s = this.parseStatement();
      if (s) stmts.push(s);
      if (!this.atEOS() && !(this.inSingleIf && this.isKw('else'))) this.err(`Expected: end of statement (found '${this.cur.v}')`);
    }
    return stmts;
  }

  parseStatement() {
    const t = this.cur, line = t.line;
    if (t.t === 'op' && t.v === '.') { return this.parseExprStatement(line); } // dentro de With
    if (t.t !== 'id') return this.parseExprStatement(line);
    const k = t.k;
    switch (k) {
      case 'dim': this.p++; return { k: 'dims', list: this.parseDimList('local', false), line };
      case 'static': this.p++; return { k: 'dims', list: this.parseDimList('local', true), line };
      case 'private': case 'public': this.p++; return { k: 'dims', list: this.parseDimList('local', false), line };
      case 'const': this.p++; return { k: 'consts', list: this.parseConstList('local'), line };
      case 'redim': {
        this.p++; const preserve = this.eatKw('preserve'); const list = [];
        do { const name = this.ident().toLowerCase(); const dims = this.parseDims(); let type = null, isNew = false; if (this.eatKw('as')) { if (this.eatKw('new')) isNew = true; type = this.parseTypeName(); } list.push({ name, dims, type, isNew }); } while (this.eatOp(','));
        return { k: 'redim', preserve, list, line };
      }
      case 'erase': { this.p++; const names = []; do names.push(this.ident()); while (this.eatOp(',')); return { k: 'erase', names, line }; }
      case 'if': return this.parseIf();
      case 'for': return this.parseFor();
      case 'do': return this.parseDo();
      case 'while': { this.p++; const cond = this.parseExpr(); const body = this.parseBlock(() => this.isKw('wend')); this.expectKw('wend'); return { k: 'while', cond, body, line }; }
      case 'select': return this.parseSelect();
      case 'with': { this.p++; const obj = this.parseExpr(); const body = this.parseBlock(() => this.isKw('end') && this.isKw('with', this.la(1))); this.p += 2; return { k: 'with', obj, body, line }; }
      case 'exit': { this.p++; const w = this.ident().toLowerCase(); return { k: 'exit', what: w, line }; }
      case 'end': {
        const nk = this.la(1);
        if (nk.t === 'id' && ['if', 'sub', 'function', 'property', 'select', 'with', 'type', 'enum'].includes(nk.k)) this.err(`End ${nk.v} without block ${nk.v}`);
        this.p++; return { k: 'end', line };
      }
      case 'stop': this.p++; return { k: 'stop', line };
      case 'goto': { this.p++; const l = this.cur; this.p++; return { k: 'goto', label: String(l.t === 'id' ? l.k : l.v), line }; }
      case 'gosub': { this.p++; const l = this.cur; this.p++; return { k: 'gosub', label: String(l.t === 'id' ? l.k : l.v), line }; }
      case 'return': this.p++; return { k: 'return', line };
      case 'on': {
        this.p++;
        this.eatKw('local');
        if (this.eatKw('error')) {
          if (this.eatKw('resume')) { this.expectKw('next'); return { k: 'onerror', mode: 'next', line }; }
          this.expectKw('goto'); const l = this.cur; this.p++;
          if (l.t === 'num' && l.v === 0) return { k: 'onerror', mode: 'off', line };
          if (l.t === 'op' && l.v === '-') { this.p++; return { k: 'onerror', mode: 'off', line }; }
          return { k: 'onerror', mode: 'goto', label: String(l.t === 'id' ? l.k : l.v), line };
        }
        this.err('Computed On ... GoTo is not supported');
      }
      case 'resume': {
        this.p++;
        if (this.eatKw('next')) return { k: 'resume', mode: 'next', line };
        if (this.atEOS()) return { k: 'resume', mode: 'retry', line };
        const l = this.cur; this.p++; if (l.t === 'num' && l.v === 0) return { k: 'resume', mode: 'retry', line };
        return { k: 'resume', mode: 'label', label: String(l.t === 'id' ? l.k : l.v), line };
      }
      case 'call': { this.p++; const e = this.parsePostfix(false); return { k: 'call', expr: e, line }; }
      case 'set': { this.p++; const target = this.parsePostfix(true); this.expectOp('='); const value = this.parseExpr(); return { k: 'assign', target, value, isSet: true, line }; }
      case 'let': { this.p++; const target = this.parsePostfix(true); this.expectOp('='); const value = this.parseExpr(); return { k: 'assign', target, value, line }; }
      case 'randomize': { this.p++; const seed = this.atEOS() ? null : this.parseExpr(); return { k: 'randomize', seed, line }; }
      case 'option': case 'attribute': this.skipLine(); return null;
      case 'open': case 'close': case 'input': case 'line': case 'get': case 'put': case 'write': case 'seek': case 'lock': case 'unlock': case 'kill': case 'mkdir': case 'rmdir': case 'chdir': case 'name': case 'print': case 'circle': case 'pset': case 'mid':
        { const sp = this.tryParseSpecial(null, line); if (sp) return sp; break; }
    }
    return this.parseExprStatement(line);
  }

  // Instruções com sintaxe especial: Print, Line, Circle, PSet, Open/Close/Input#/Print#
  tryParseSpecial(objExpr, line) {
    const k = this.cur.k;
    if (k === 'print') {
      this.p++;
      if (!objExpr && this.isOp('#')) { this.p++; const fnum = this.parseExpr(); this.expectOp(','); return { k: 'fileprint', fnum, items: this.parsePrintList(), line }; }
      return { k: 'print', obj: objExpr, items: this.parsePrintList(), line };
    }
    if (k === 'line' && !objExpr && this.isKw('input', this.la(1))) {
      this.p += 2; this.expectOp('#'); const fnum = this.parseExpr(); this.expectOp(','); const target = this.parsePostfix(true); return { k: 'lineinput', fnum, target, line };
    }
    if (k === 'line' && (this.isOp('(', this.la(1)) || this.isOp('-', this.la(1)) || (this.la(1).t === 'id' && this.la(1).k === 'step'))) {
      this.p++;
      let p1 = null, step1 = false;
      if (this.eatKw('step')) step1 = true;
      if (this.isOp('(')) { p1 = this.parsePoint(); }
      this.expectOp('-'); let step2 = false; if (this.eatKw('step')) step2 = true;
      const p2 = this.parsePoint();
      let color = null, box = null;
      if (this.eatOp(',')) { if (!this.isOp(',') && !this.atEOS()) color = this.parseExpr(); if (this.eatOp(',')) { box = this.ident().toLowerCase(); } }
      return { k: 'gline', obj: objExpr, p1, p2, step1, step2, color, box, line };
    }
    if (k === 'circle' && (this.isOp('(', this.la(1)) || this.isKw('step', this.la(1)))) {
      this.p++; this.eatKw('step'); const c = this.parsePoint(); this.expectOp(','); const r = this.parseExpr(); let color = null;
      const extra = [];
      if (this.eatOp(',')) { if (!this.isOp(',') && !this.atEOS()) color = this.parseExpr(); while (this.eatOp(',')) { extra.push(this.isOp(',') || this.atEOS() ? null : this.parseExpr()); } }
      return { k: 'circle', obj: objExpr, c, r, color, extra, line };
    }
    if (k === 'pset' && (this.isOp('(', this.la(1)) || this.isKw('step', this.la(1)))) {
      this.p++; this.eatKw('step'); const c = this.parsePoint(); let color = null; if (this.eatOp(',')) color = this.parseExpr();
      return { k: 'pset', obj: objExpr, c, color, line };
    }
    if (objExpr) return null;
    if (k === 'open') {
      this.p++; const path = this.parseExpr(); let mode = 'random';
      if (this.eatKw('for')) mode = this.ident().toLowerCase();
      while (!this.isKw('as') && !this.atEOS()) this.p++; // Access/Lock
      this.expectKw('as'); this.eatOp('#'); const fnum = this.parseExpr();
      if (this.eatKw('len')) { this.expectOp('='); this.parseExpr(); }
      return { k: 'fopen', path, mode, fnum, line };
    }
    if (k === 'close') { this.p++; const nums = []; while (!this.atEOS()) { this.eatOp('#'); nums.push(this.parseExpr()); if (!this.eatOp(',')) break; } return { k: 'fclose', nums, line }; }
    if (k === 'input' && this.isOp('#', this.la(1))) { this.p += 2; const fnum = this.parseExpr(); const targets = []; while (this.eatOp(',')) targets.push(this.parsePostfix(true)); return { k: 'finput', fnum, targets, line }; }
    if (k === 'write' && this.isOp('#', this.la(1))) { this.p += 2; const fnum = this.parseExpr(); const items = []; while (this.eatOp(',')) { if (this.atEOS()) break; items.push(this.parseExpr()); } return { k: 'fwrite', fnum, items, line }; }
    if ((k === 'get' || k === 'put' || k === 'seek') && this.isOp('#', this.la(1))) {
      this.p += 2; const fnum = this.parseExpr(); const rest = [];
      while (this.eatOp(',')) { if (this.isOp(',')) { rest.push(null); continue; } rest.push(this.parseExpr()); }
      return { k: 'fbin', op: k, fnum, rest, line };
    }
    if (k === 'name' && this.la(1).t !== 'op') { const save = this.p; this.p++; try { const from = this.parseExpr(); if (this.eatKw('as')) { const to = this.parseExpr(); return { k: 'fname', from, to, line }; } } catch (er) { } this.p = save; return null; }
    if (k === 'kill') { this.p++; return { k: 'kill', path: this.parseExpr(), line }; }
    if (k === 'mid' && this.isOp('(', this.la(1))) {
      // Mid(s, start[, len]) = valor
      const save = this.p; this.p++;
      const e = this.parsePostfix(true, { k: 'id', name: 'mid', line });
      if (this.eatOp('=')) { const value = this.parseExpr(); return { k: 'midassign', args: e.args, value, line }; }
      this.p = save; return null;
    }
    return null;
  }
  parsePoint() { this.expectOp('('); const x = this.parseExpr(); this.expectOp(','); const y = this.parseExpr(); this.expectOp(')'); return { x, y }; }
  parsePrintList() {
    const items = [];
    while (!this.atEOS()) {
      if (this.eatOp(';')) { items.push({ sep: ';' }); continue; }
      if (this.eatOp(',')) { items.push({ sep: ',' }); continue; }
      if (this.isKw('spc') || this.isKw('tab')) {
        const fn = this.cur.k; this.p++;
        let arg = null; if (this.eatOp('(')) { if (!this.isOp(')')) arg = this.parseExpr(); this.expectOp(')'); }
        items.push({ fn, arg }); continue;
      }
      items.push({ expr: this.parseExpr() });
    }
    return items;
  }

  parseExprStatement(line) {
    this._lastParen = null;
    let target = this.parsePostfix(true);
    // "Foo (a) * 2, b"  -> chamada sem parênteses cujo 1º argumento começa com '('
    if (target.k === 'call' && this._lastParen && this._lastParen.node === target && !this.atEOS() && !this.isOp('=') && !this.isOp(',') && (this.cur.t === 'op' || (this.cur.t === 'id' && ['mod', 'and', 'or', 'xor', 'like', 'is', 'eqv', 'imp'].includes(this.cur.k)))) {
      this.p = this._lastParen.pos;
      const args = this.parseArgList(true);
      return { k: 'call', expr: { k: 'call', fn: this._lastParen.base, args, line, noParens: true }, line };
    }
    // método especial em objeto: Me.Print, Picture1.Line, Debug.Print
    if (target.k === 'mem' && this.lastSpecial) {
      // nunca acontece; tratado em parsePostfix
    }
    if (target.special) return target.special;
    if (this.eatOp('=')) { const value = this.parseExpr(); return { k: 'assign', target, value, line }; }
    if (this.atEOS()) return { k: 'call', expr: target, line, bare: true };
    if (target.k === 'call' && this.isOp(',')) { // Foo (a), b
      this.p++; const rest = this.parseArgList(true);
      return { k: 'call', expr: { k: 'call', fn: target.fn, args: target.args.concat(rest), line, noParens: true }, line };
    }
    // chamada sem parênteses: Foo a, b
    const args = this.parseArgList(true);
    let callee = target, extraArgs = args;
    return { k: 'call', expr: { k: 'call', fn: callee, args: extraArgs, line, noParens: true }, line };
  }

  parseArgList(noParens) {
    const args = [];
    const end = () => noParens ? this.atEOS() : this.isOp(')');
    if (end()) return args;
    for (;;) {
      if (this.isOp(',')) { args.push(null); this.p++; if (end()) { args.push(null); break; } continue; }
      let name = null;
      if (this.cur.t === 'id' && this.isOp(':=', this.la(1))) { name = this.cur.k; this.p += 2; }
      let byValParen = false;
      const e = this.parseExpr();
      args.push({ e, name });
      if (!this.eatOp(',')) break;
      if (end()) { args.push(null); break; }
    }
    return args;
  }

  // ===== If =====
  parseIf() {
    const line = this.cur.line; this.p++;
    const cond = this.parseExpr();
    this.expectKw('then');
    if (this.cur.t !== 'nl' && !(this.cur.t === 'op' && this.cur.v === "'")) {
      // If de uma linha
      const saved = this.inSingleIf; this.inSingleIf = true;
      const then = this.parseInline();
      let els = null;
      if (this.eatKw('else')) els = this.parseInline();
      this.inSingleIf = saved;
      return { k: 'if', arms: [{ cond, body: then }], els, line };
    }
    const arms = []; let els = null;
    let body = this.parseBlock(() => this.isKw('elseif') || this.isKw('else') || (this.isKw('end') && this.isKw('if', this.la(1))) || this.isKw('endif'));
    arms.push({ cond, body });
    for (;;) {
      if (this.eatKw('elseif')) { const c = this.parseExpr(); this.expectKw('then'); const b = this.parseBlock(() => this.isKw('elseif') || this.isKw('else') || (this.isKw('end') && this.isKw('if', this.la(1))) || this.isKw('endif')); arms.push({ cond: c, body: b }); continue; }
      if (this.eatKw('else')) { els = this.parseBlock(() => (this.isKw('end') && this.isKw('if', this.la(1))) || this.isKw('endif')); continue; }
      break;
    }
    if (this.eatKw('endif')) {} else { this.expectKw('end'); this.expectKw('if'); }
    return { k: 'if', arms, els, line };
  }
  parseInline() {
    const stmts = [];
    for (;;) {
      if (this.cur.t === 'nl' || this.cur.t === 'eof' || this.isKw('else')) break;
      if (this.isOp(':')) { this.p++; continue; }
      // "If x Then 100" -> GoTo 100
      if (this.cur.t === 'num') { stmts.push({ k: 'goto', label: String(this.cur.v), line: this.cur.line }); this.p++; continue; }
      const s = this.parseStatement(); if (s) stmts.push(s);
    }
    return stmts;
  }

  // ===== For =====
  parseFor() {
    const line = this.cur.line; this.p++;
    if (this.eatKw('each')) {
      const v = this.parsePostfix(true); this.expectKw('in'); const coll = this.parseExpr();
      const body = this.parseBlock(() => this.isKw('next'));
      this.closeNext();
      return { k: 'foreach', v, coll, body, line };
    }
    const v = this.parsePostfix(true);
    this.expectOp('='); const from = this.parseExpr(); this.expectKw('to'); const to = this.parseExpr();
    let step = null; if (this.eatKw('step')) step = this.parseExpr();
    const body = this.parseBlock(() => this.isKw('next') || this.pendingNext > 0);
    this.closeNext();
    return { k: 'for', v, from, to, step, body, line };
  }
  closeNext() {
    // "Next i, j" fecha vários For
    if (this.pendingNext > 0) { this.pendingNext--; return; }
    this.expectKw('next');
    if (this.cur.t === 'id' && !this.atEOS()) {
      this.p++;
      while (this.eatOp(',')) { this.ident(); this.pendingNext = (this.pendingNext || 0) + 1; }
    }
  }

  // ===== Do =====
  parseDo() {
    const line = this.cur.line; this.p++;
    let pre = null;
    if (this.isKw('while') || this.isKw('until')) { const w = this.cur.k; this.p++; pre = { until: w === 'until', cond: this.parseExpr() }; }
    const body = this.parseBlock(() => this.isKw('loop'));
    this.expectKw('loop');
    let post = null;
    if (this.isKw('while') || this.isKw('until')) { const w = this.cur.k; this.p++; post = { until: w === 'until', cond: this.parseExpr() }; }
    return { k: 'do', pre, post, body, line };
  }

  // ===== Select Case =====
  parseSelect() {
    const line = this.cur.line; this.p++; this.expectKw('case');
    const subj = this.parseExpr();
    const cases = []; let els = null;
    this.skipEOS();
    while (this.isKw('case')) {
      this.p++;
      if (this.eatKw('else')) { els = this.parseBlock(() => this.isKw('case') || (this.isKw('end') && this.isKw('select', this.la(1)))); continue; }
      const tests = [];
      do {
        if (this.eatKw('is')) { const op = this.cur.v; this.p++; tests.push({ op, e: this.parseExpr() }); }
        else { const a = this.parseExpr(); if (this.eatKw('to')) tests.push({ range: [a, this.parseExpr()] }); else tests.push({ op: '=', e: a }); }
      } while (this.eatOp(','));
      const body = this.parseBlock(() => this.isKw('case') || (this.isKw('end') && this.isKw('select', this.la(1))));
      cases.push({ tests, body });
    }
    this.expectKw('end'); this.expectKw('select');
    return { k: 'select', subj, cases, els, line };
  }

  // ===== Expressões =====
  parseExpr() { return this.parseImp(); }
  bin(next, ops) {
    let l = next();
    for (;;) {
      const t = this.cur; let op = null;
      if (t.t === 'op' && ops.includes(t.v)) op = t.v;
      else if (t.t === 'id' && ops.includes(t.k)) op = t.k;
      if (!op) return l;
      this.p++;
      const r = next();
      l = { k: 'bin', op, l, r, line: t.line };
    }
  }
  parseImp() { return this.bin(() => this.parseEqv(), ['imp']); }
  parseEqv() { return this.bin(() => this.parseXor(), ['eqv']); }
  parseXor() { return this.bin(() => this.parseOr(), ['xor']); }
  parseOr() { return this.bin(() => this.parseAnd(), ['or', 'orelse']); }
  parseAnd() { return this.bin(() => this.parseNot(), ['and', 'andalso']); }
  parseNot() { if (this.isKw('not')) { const line = this.cur.line; this.p++; return { k: 'un', op: 'not', e: this.parseNot(), line }; } return this.parseCmp(); }
  parseCmp() {
    let l = this.parseConcat();
    for (;;) {
      const t = this.cur;
      if (t.t === 'op' && ['=', '<>', '<', '>', '<=', '>='].includes(t.v)) { this.p++; l = { k: 'bin', op: t.v, l, r: this.parseConcat(), line: t.line }; continue; }
      if (t.t === 'id' && (t.k === 'like' || t.k === 'is')) { this.p++; l = { k: 'bin', op: t.k, l, r: this.parseConcat(), line: t.line }; continue; }
      return l;
    }
  }
  parseConcat() { return this.bin(() => this.parseAdd(), ['&']); }
  parseAdd() { return this.bin(() => this.parseMod(), ['+', '-']); }
  parseMod() { return this.bin(() => this.parseIDiv(), ['mod']); }
  parseIDiv() { return this.bin(() => this.parseMul(), ['\\']); }
  parseMul() { return this.bin(() => this.parseNeg(), ['*', '/']); }
  parseNeg() {
    if (this.isOp('-')) { const line = this.cur.line; this.p++; return { k: 'un', op: '-', e: this.parseNeg(), line }; }
    if (this.isOp('+')) { this.p++; return this.parseNeg(); }
    return this.parsePow();
  }
  parsePow() {
    let l = this.parsePrimaryPostfix();
    while (this.isOp('^')) { const line = this.cur.line; this.p++; let r; if (this.isOp('-')) { this.p++; r = { k: 'un', op: '-', e: this.parsePrimaryPostfix(), line }; } else r = this.parsePrimaryPostfix(); l = { k: 'bin', op: '^', l, r, line }; }
    return l;
  }
  parsePrimaryPostfix() { return this.parsePostfix(false); }

  // postfix: primário seguido de .membro, (args), !chave
  parsePostfix(isStmt, preset) {
    const t = this.cur, line = t.line;
    let e = preset || null;
    if (!e) {
      if (t.t === 'num') { this.p++; e = { k: 'lit', v: t.v }; }
      else if (t.t === 'str') { this.p++; e = { k: 'lit', v: t.v }; }
      else if (t.t === 'date') { this.p++; e = { k: 'datelit', v: t.v }; }
      else if (t.t === 'op' && t.v === '(') { this.p++; const inner = this.parseExpr(); this.expectOp(')'); e = { k: 'paren', e: inner }; }
      else if (t.t === 'op' && (t.v === '.' || t.v === '!')) { e = { k: 'withref', line }; }
      else if (t.t === 'id') {
        const k = t.k;
        if (k === 'new') { this.p++; const cls = this.parseTypeName(); return { k: 'new', cls, line }; }
        if (k === 'true') { this.p++; e = { k: 'lit', v: true }; }
        else if (k === 'false') { this.p++; e = { k: 'lit', v: false }; }
        else if (k === 'nothing') { this.p++; e = { k: 'lit', v: null }; }
        else if (k === 'empty') { this.p++; e = { k: 'lit', v: undefined }; }
        else if (k === 'null') { this.p++; e = { k: 'nulllit' }; }
        else if (k === 'me') { this.p++; e = { k: 'me', line }; }
        else if (k === 'typeof') { this.p++; const obj = this.parsePostfix(false); this.expectKw('is'); const cls = this.parseTypeName(); return { k: 'typeof', obj, cls, line }; }
        else if (k === 'addressof') { this.p++; const nm = this.ident(); return { k: 'lit', v: 0 }; }
        else { this.p++; e = { k: 'id', name: k, raw: t.v, line }; }
      }
      else this.err(`Expected: expression (found '${t.v === '\n' ? 'end of line' : t.v}')`);
    }
    for (;;) {
      if (this.isOp('.') && this.cur.sp && e.k !== 'withref') break;
      if (this.isOp('.') || (this.isOp('!') && this.la(1).t === 'id')) {
        const bang = this.cur.v === '!';
        this.p++;
        const nt = this.cur; if (nt.t !== 'id') this.err('Expected: member name after "."');
        // Debug.Print / Me.Print / Picture1.Line etc.
        if (isStmt && !bang && ['print', 'line', 'circle', 'pset'].includes(nt.k)) {
          const sp = this.tryParseSpecial(e.k === 'withref' ? { k: 'withref', line } : e, line);
          if (sp) { return { special: sp }; }
        }
        this.p++;
        e = { k: 'mem', obj: e.k === 'withref' ? null : e, name: nt.k, raw: nt.v, bang, line: nt.line };
        continue;
      }
      if (this.isOp('(') && e.k !== 'lit' && e.k !== 'paren') {
        // "Foo (x)" como instrução: se após ) vier ',' é lista sem parênteses: Foo (a), b
        const parenPos = this.p, base = e;
        this.p++;
        const args = this.parseArgList(false);
        this.expectOp(')');
        e = { k: 'call', fn: e, args, line };
        this._lastParen = { pos: parenPos, base, node: e };
        continue;
      }
      break;
    }
    if (e.k === 'withref') this.err('Invalid or unqualified reference');
    return e;
  }
}

function parseModuleSource(src, name) { return new Parser(src, name).parseModule(); }
function parseExpression(src) { const p = new Parser(src); const e = p.parseExpr(); return e; }
function parseStatements(src) { const p = new Parser(src); return p.parseBlock(null); }

if (typeof module !== 'undefined') module.exports = { lex, Parser, parseModuleSource, parseExpression, parseStatements, VBSyntaxError };
