// ===== NeoBasic — leitura e gravação de arquivos VB5/VB6 (.vbp .frm .frx .bas .cls) =====
'use strict';

// ---------- Codificação Windows-1252 ----------
const W1252_HI = [0x20AC, 0x81, 0x201A, 0x0192, 0x201E, 0x2026, 0x2020, 0x2021, 0x02C6, 0x2030, 0x0160, 0x2039, 0x0152, 0x8D, 0x017D, 0x8F, 0x90, 0x2018, 0x2019, 0x201C, 0x201D, 0x2022, 0x2013, 0x2014, 0x02DC, 0x2122, 0x0161, 0x203A, 0x0153, 0x9D, 0x017E, 0x0178];
function decode1252(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i++) { const b = bytes[i]; s += String.fromCharCode(b >= 0x80 && b < 0xA0 ? W1252_HI[b - 0x80] : b); }
  return s;
}
function encode1252(str) {
  const out = new Uint8Array(str.length);
  for (let i = 0; i < str.length; i++) {
    const c = str.charCodeAt(i);
    if (c < 0x80 || (c >= 0xA0 && c < 0x100)) out[i] = c;
    else { const j = W1252_HI.indexOf(c); out[i] = j >= 0 ? 0x80 + j : 0x3F; }
  }
  return out;
}
function decodeText(bytes) {
  // UTF-8 com BOM ou válido → UTF-8; senão Windows-1252
  if (bytes[0] === 0xEF && bytes[1] === 0xBB && bytes[2] === 0xBF) return new TextDecoder('utf-8').decode(bytes.subarray(3));
  return decode1252(bytes);
}

// ---------- Valores de propriedades ----------
function parsePropValue(rest) {
  // devolve { raw, comment }
  let s = rest.trim();
  let raw = s, comment = '', sep = '';
  if (s.startsWith('"') || s.startsWith('$"')) {
    let i = s.startsWith('$') ? 2 : 1;
    while (i < s.length) { if (s[i] === '"') { if (s[i + 1] === '"') { i += 2; continue; } i++; break; } i++; }
    // frx: "Form1.frx":0000
    const m = /^:[0-9A-Fa-f]+/.exec(s.slice(i)); if (m) i += m[0].length;
    raw = s.slice(0, i); const tail = s.slice(i); const tt = tail.trim(); if (tt.startsWith("'")) { comment = tt.slice(1); sep = tail.slice(0, tail.indexOf("'")); }
  } else {
    const j = s.indexOf("'");
    if (j >= 0) { raw = s.slice(0, j).trim(); comment = s.slice(j + 1); sep = s.slice(raw.length, j); }
  }
  return { raw, comment, sep };
}
function unquote(raw) { return raw.slice(1, -1).replace(/""/g, '"'); }
function quote(s) { return '"' + String(s).replace(/"/g, '""') + '"'; }
function rawToValue(raw) {
  if (raw === undefined || raw === null) return undefined;
  const fm = /^\$?"([^"]*)":([0-9A-Fa-f]+)$/.exec(raw);
  if (fm) return { frx: fm[1], offset: parseInt(fm[2], 16), isString: raw.startsWith('$') };
  if (raw.startsWith('"')) return unquote(raw);
  const hm = /^&H([0-9A-Fa-f]+)&?$/.exec(raw); if (hm) { let v = parseInt(hm[1], 16); if (v > 0x7FFFFFFF) v -= 0x100000000; return v; }
  if (/^[+\-]?\d+(\.\d+)?([eE][+\-]?\d+)?$/.test(raw)) return Number(raw);
  return raw;
}
function colorRaw(v) { const u = v >>> 0; return '&H' + u.toString(16).toUpperCase().padStart(8, '0') + '&'; }

// ---------- FRX ----------
function frxRead(frxBytes, offset, kind) {
  if (!frxBytes || offset >= frxBytes.length) return null;
  const dv = new DataView(frxBytes.buffer, frxBytes.byteOffset, frxBytes.byteLength);
  if (kind === 'list') {
    const n = dv.getUint16(offset, true); const items = []; let p = offset + 2;
    for (let i = 0; i < n && p + 2 <= frxBytes.length; i++) { const l = dv.getUint16(p, true); p += 2; items.push(decode1252(frxBytes.subarray(p, p + l))); p += l; }
    return items;
  }
  if (kind === 'itemdata') {
    const n = dv.getUint16(offset, true); const items = []; let p = offset + 2;
    for (let i = 0; i < n; i++) { items.push(dv.getInt32(p, true)); p += 4; }
    return items;
  }
  if (kind === 'image') {
    // [DWORD total][ "lt\0\0" ][DWORD tamanho][dados]
    if (offset + 12 <= frxBytes.length && frxBytes[offset + 4] === 0x6C && frxBytes[offset + 5] === 0x74) {
      const size = dv.getUint32(offset + 8, true);
      return frxBytes.subarray(offset + 12, offset + 12 + size);
    }
    const size = dv.getUint32(offset, true);
    if (size > 0 && offset + 4 + size <= frxBytes.length) return frxBytes.subarray(offset + 4, offset + 4 + size);
    return null;
  }
  // texto
  const b0 = frxBytes[offset];
  if (kind === 'string4') { const l = dv.getUint32(offset, true); if (offset + 4 + l <= frxBytes.length) return decode1252(frxBytes.subarray(offset + 4, offset + 4 + l)); }
  if (b0 === 0xFF) { const l = dv.getUint16(offset + 1, true); return decode1252(frxBytes.subarray(offset + 3, offset + 3 + l)); }
  return decode1252(frxBytes.subarray(offset + 1, offset + 1 + b0));
}
function imageMime(bytes) {
  if (!bytes || bytes.length < 4) return null;
  if (bytes[0] === 0x42 && bytes[1] === 0x4D) return 'image/bmp';
  if (bytes[0] === 0 && bytes[1] === 0 && (bytes[2] === 1 || bytes[2] === 2) && bytes[3] === 0) return bytes[2] === 1 ? 'image/x-icon' : 'image/x-icon';
  if (bytes[0] === 0x47 && bytes[1] === 0x49 && bytes[2] === 0x46) return 'image/gif';
  if (bytes[0] === 0xFF && bytes[1] === 0xD8) return 'image/jpeg';
  if (bytes[0] === 0x89 && bytes[1] === 0x50) return 'image/png';
  return null; // WMF/EMF e outros não são exibíveis no navegador
}
function bytesToDataURL(bytes, mime) {
  let bin = ''; for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  const b64 = typeof btoa !== 'undefined' ? btoa(bin) : Buffer.from(bin, 'binary').toString('base64');
  return 'data:' + mime + ';base64,' + b64;
}

// ---------- Nó de controle ----------
class CtlNode {
  constructor(type, name) { this.type = type; this.name = name; this.props = []; this.blocks = []; this.children = []; this.parent = null; }
  get shortType() { return this.type.replace(/^VB\./i, ''); }
  findProp(key) { const k = key.toLowerCase(); return this.props.find(p => p.key.toLowerCase() === k); }
  getRaw(key) { const p = this.findProp(key); return p ? p.raw : undefined; }
  get(key, def) { const p = this.findProp(key); if (!p) return def; const v = rawToValue(p.raw); return v === undefined ? def : v; }
  setRaw(key, raw, comment) {
    let p = this.findProp(key);
    if (!p) { p = { key, raw, comment: comment || '' }; this.props.push(p); }
    else { p.raw = raw; p.comment = comment !== undefined ? comment : ''; p.sep = ''; }
  }
  set(key, value, kind) {
    if (value === undefined || value === null) return this.remove(key);
    if (kind === 'color') return this.setRaw(key, colorRaw(value));
    if (kind === 'bool') return this.setRaw(key, value ? '-1' : '0', value ? 'True' : 'False');
    if (typeof value === 'boolean') return this.setRaw(key, value ? '-1' : '0', value ? 'True' : 'False');
    if (typeof value === 'number') return this.setRaw(key, String(value));
    this.setRaw(key, quote(value));
  }
  remove(key) { const k = key.toLowerCase(); this.props = this.props.filter(p => p.key.toLowerCase() !== k); }
  block(name) { const k = name.toLowerCase(); return this.blocks.find(b => b.name.toLowerCase() === k); }
  get index() { const v = this.get('Index'); return v === undefined ? null : v; }
  walk(fn) { fn(this); for (const c of this.children) c.walk(fn); }
  clone() {
    const n = new CtlNode(this.type, this.name);
    n.props = this.props.map(p => Object.assign({}, p));
    n.blocks = this.blocks.map(cloneBlock);
    n.children = this.children.map(c => { const cc = c.clone(); cc.parent = n; return cc; });
    return n;
  }
}
function cloneBlock(b) { return { name: b.name, guid: b.guid, at: b.at, props: b.props.map(p => Object.assign({}, p)), blocks: (b.blocks || []).map(cloneBlock) }; }

// ---------- .FRM ----------
function parseFrm(text, fileName) {
  const lines = text.replace(/\r\n?/g, '\n').split('\n');
  const form = { fileName, header: [], root: null, attributes: [], code: '', isMDI: false, version: '5.00' };
  let i = 0;
  // cabeçalho: VERSION e Object = ...
  while (i < lines.length && !/^\s*Begin\s/i.test(lines[i])) {
    const l = lines[i];
    const vm = /^VERSION\s+([\d.]+)/i.exec(l); if (vm) form.version = vm[1];
    if (l.trim()) form.header.push(l);
    i++;
  }
  const parseBlockProps = (startIdx, block) => {
    // BeginProperty ... EndProperty
    let j = startIdx;
    while (j < lines.length) {
      const t = lines[j].trim();
      if (/^EndProperty\b/i.test(t)) return j + 1;
      const bm = /^BeginProperty\s+(\S+)\s*(\{[^}]*\})?/i.exec(t);
      if (bm) { const sub = { name: bm[1], guid: bm[2] || '', props: [], blocks: [] }; block.blocks.push(sub); j = parseBlockProps(j + 1, sub); continue; }
      const pm = /^([A-Za-z_][\w().]*)(\s*=\s*)(.*)$/.exec(t);
      if (pm) { const { raw, comment, sep } = parsePropValue(pm[3]); block.props.push({ key: pm[1], raw, comment, sep, eq: pm[2] }); }
      j++;
    }
    return j;
  };
  const parseCtl = (startIdx, parent) => {
    const m = /^\s*Begin\s+(\S+)\s+(\S+)/i.exec(lines[startIdx]);
    const node = new CtlNode(m[1], m[2]); node.parent = parent;
    let j = startIdx + 1;
    while (j < lines.length) {
      const t = lines[j].trim();
      if (/^End$/i.test(t)) return { node, next: j + 1 };
      if (/^Begin\s/i.test(t)) { const r = parseCtl(j, node); node.children.push(r.node); j = r.next; continue; }
      const bm = /^BeginProperty\s+(\S+)\s*(\{[^}]*\})?/i.exec(t);
      if (bm) { const blk = { name: bm[1], guid: bm[2] || '', props: [], blocks: [], at: node.props.length }; node.blocks.push(blk); j = parseBlockProps(j + 1, blk); continue; }
      const pm = /^([A-Za-z_][\w().]*)(\s*=\s*)(.*)$/.exec(t);
      if (pm) { const { raw, comment, sep } = parsePropValue(pm[3]); node.props.push({ key: pm[1], raw, comment, sep, eq: pm[2] }); }
      j++;
    }
    return { node, next: j };
  };
  if (i < lines.length) { const r = parseCtl(i, null); form.root = r.node; i = r.next; }
  else { form.root = new CtlNode('VB.Form', (fileName || 'Form1').replace(/\..*$/, '')); }
  form.isMDI = /mdiform/i.test(form.root.type);
  // atributos
  while (i < lines.length && /^Attribute\s/i.test(lines[i])) form.attributes.push(lines[i++]);
  form.code = lines.slice(i).join('\r\n').replace(/\s+$/, '') + '\r\n';
  const nm = form.attributes.map(a => /^Attribute\s+VB_Name\s*=\s*"([^"]*)"/i.exec(a)).find(Boolean);
  form.name = nm ? nm[1] : form.root.name;
  return form;
}
function fmtProp(indent, key, raw, comment, sep, eq) {
  if (eq && key.length + eq.length > 16) return indent + key + eq + raw + (comment ? (sep || '  ') + "'" + comment : '');
  const k = key.padEnd(16);
  if (!sep) sep = raw === '0' && /^False$/i.test(comment || '') ? '   ' : '  ';
  return indent + k + '=   ' + raw + (comment ? sep + "'" + comment : '');
}
function serializeBlock(b, indent, out) {
  out.push(indent + 'BeginProperty ' + b.name + ' ' + (b.guid || ''));
  for (const p of b.props) out.push(fmtProp(indent + '   ', p.key, p.raw, p.comment, p.sep, p.eq));
  for (const s of b.blocks || []) serializeBlock(s, indent + '   ', out);
  out.push(indent + 'EndProperty');
}
function serializeCtl(node, indent, out) {
  out.push(indent + 'Begin ' + node.type + ' ' + node.name + ' ');
  const inner = indent + '   ';
  // ordem do VB: propriedades e blocos intercalados - mantemos props, com Font após Caption/ClientXXX
  const fontIdx = node._blockAfter;
  const placed = new Set();
  node.props.forEach((p, i) => {
    for (const b of node.blocks) if (!placed.has(b) && b.at === i) { serializeBlock(b, inner, out); placed.add(b); }
    out.push(fmtProp(inner, p.key, p.raw, p.comment, p.sep, p.eq));
  });
  for (const b of node.blocks) if (!placed.has(b)) serializeBlock(b, inner, out);
  for (const c of node.children) serializeCtl(c, inner, out);
  out.push(indent + 'End');
}
function serializeFrm(form) {
  const out = [];
  const hdr = form.header.length ? form.header : ['VERSION 5.00'];
  for (const h of hdr) out.push(h);
  serializeCtl(form.root, '', out);
  let attrs = form.attributes.length ? form.attributes.slice() : defaultFormAttributes(form.name);
  attrs = attrs.map(a => /^Attribute\s+VB_Name\b/i.test(a) ? `Attribute VB_Name = "${form.name}"` : a);
  out.push(...attrs);
  let code = (form.code || '').replace(/\r?\n/g, '\r\n');
  return out.join('\r\n') + '\r\n' + code.replace(/(\r\n)*$/, '') + (code.trim() ? '\r\n' : '');
}
function defaultFormAttributes(name) { return [`Attribute VB_Name = "${name}"`, 'Attribute VB_GlobalNameSpace = False', 'Attribute VB_Creatable = False', 'Attribute VB_PredeclaredId = True', 'Attribute VB_Exposed = False']; }

// ---------- .BAS ----------
function parseBas(text, fileName) {
  const lines = text.replace(/\r\n?/g, '\n').split('\n');
  const attrs = []; let i = 0;
  while (i < lines.length && /^Attribute\s/i.test(lines[i])) attrs.push(lines[i++]);
  const nm = attrs.map(a => /^Attribute\s+VB_Name\s*=\s*"([^"]*)"/i.exec(a)).find(Boolean);
  return { fileName, name: nm ? nm[1] : (fileName || 'Module1').replace(/\..*$/, ''), attributes: attrs, code: lines.slice(i).join('\r\n') };
}
function serializeBas(m) {
  const attrs = m.attributes && m.attributes.length ? m.attributes.map(a => /^Attribute\s+VB_Name\b/i.test(a) ? `Attribute VB_Name = "${m.name}"` : a) : [`Attribute VB_Name = "${m.name}"`];
  return attrs.join('\r\n') + '\r\n' + (m.code || '').replace(/\r?\n/g, '\r\n').replace(/(\r\n)*$/, '') + '\r\n';
}

// ---------- .CLS ----------
function parseCls(text, fileName) {
  const lines = text.replace(/\r\n?/g, '\n').split('\n');
  const header = []; let i = 0;
  if (/^VERSION/i.test(lines[0] || '')) {
    while (i < lines.length && !/^END\s*$/i.test(lines[i].trim())) header.push(lines[i++]);
    if (i < lines.length) header.push(lines[i++]);
  }
  const attrs = [];
  while (i < lines.length && /^Attribute\s/i.test(lines[i])) attrs.push(lines[i++]);
  const nm = attrs.map(a => /^Attribute\s+VB_Name\s*=\s*"([^"]*)"/i.exec(a)).find(Boolean);
  const code = lines.slice(i).join('\r\n');
  const dm = /Attribute\s+(\w+)\.VB_UserMemId\s*=\s*0\b/i.exec(code);
  return { fileName, name: nm ? nm[1] : (fileName || 'Class1').replace(/\..*$/, ''), header, attributes: attrs, code, defaultMember: dm ? dm[1].toLowerCase() : null };
}
function serializeCls(m) {
  const header = m.header && m.header.length ? m.header : ['VERSION 1.0 CLASS', 'BEGIN', "  MultiUse = -1  'True", 'END'];
  const attrs = m.attributes && m.attributes.length ? m.attributes.map(a => /^Attribute\s+VB_Name\b/i.test(a) ? `Attribute VB_Name = "${m.name}"` : a)
    : [`Attribute VB_Name = "${m.name}"`, 'Attribute VB_GlobalNameSpace = False', 'Attribute VB_Creatable = True', 'Attribute VB_PredeclaredId = False', 'Attribute VB_Exposed = False'];
  return header.join('\r\n') + '\r\n' + attrs.join('\r\n') + '\r\n' + (m.code || '').replace(/\r?\n/g, '\r\n').replace(/(\r\n)*$/, '') + '\r\n';
}

// ---------- .VBP ----------
function parseVbp(text, fileName) {
  const lines = text.replace(/\r\n?/g, '\n').split('\n');
  const p = { fileName, lines: [], forms: [], modules: [], classes: [], others: [], startup: '', name: 'Projeto1', title: '', type: 'Exe' };
  for (const l of lines) {
    if (!l.trim()) continue;
    const m = /^([^=]+)=(.*)$/.exec(l);
    if (!m) { p.lines.push(l); continue; }
    const key = m[1].trim(), val = m[2].trim(), lk = key.toLowerCase();
    if (lk === 'form') { p.forms.push(val.replace(/^"|"$/g, '')); continue; }
    if (lk === 'module' || lk === 'class') { const [nm, file] = val.split(';').map(s => s.trim()); (lk === 'module' ? p.modules : p.classes).push({ name: nm, file: file || nm }); continue; }
    if (lk === 'usercontrol' || lk === 'userdocument' || lk === 'propertypage' || lk === 'designer' || lk === 'relateddoc' || lk === 'resfile32') { p.others.push({ key, val }); p.lines.push(l); continue; }
    if (lk === 'startup') p.startup = val.replace(/^"|"$/g, '');
    if (lk === 'name') p.name = val.replace(/^"|"$/g, '');
    if (lk === 'title') p.title = val.replace(/^"|"$/g, '');
    if (lk === 'type') p.type = val;
    p.lines.push(l);
  }
  return p;
}
function serializeVbp(p) {
  const out = [];
  const keep = (p.lines || []).filter(l => !/^(Startup|Name|Title)\s*=/i.test(l));
  const typeLine = keep.findIndex(l => /^Type\s*=/i.test(l));
  if (typeLine < 0) out.push('Type=Exe'); else out.push(keep.splice(typeLine, 1)[0]);
  // referências e objetos primeiro (como o VB)
  const refs = keep.filter(l => /^(Reference|Object)\s*=/i.test(l));
  out.push(...refs);
  for (const f of p.forms) out.push('Form=' + f);
  for (const m of p.modules) out.push(`Module=${m.name}; ${m.file}`);
  for (const c of p.classes) out.push(`Class=${c.name}; ${c.file}`);
  out.push(`Startup="${p.startup || ''}"`);
  out.push(`Name="${p.name || 'Projeto1'}"`);
  if (p.title) out.push(`Title="${p.title}"`);
  out.push(...keep.filter(l => !/^(Reference|Object)\s*=/i.test(l)));
  return out.join('\r\n') + '\r\n';
}

// ---------- ZIP (armazenado, sem compressão) ----------
const CRC_TABLE = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(b) { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC_TABLE[(c ^ b[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
function makeZip(files) { // files: [{name, data: Uint8Array}]
  const parts = [], central = []; let off = 0;
  const enc = new TextEncoder();
  for (const f of files) {
    const nameB = enc.encode(f.name); const crc = crc32(f.data);
    const lh = new Uint8Array(30 + nameB.length); const dv = new DataView(lh.buffer);
    dv.setUint32(0, 0x04034b50, true); dv.setUint16(4, 20, true); dv.setUint16(6, 0x0800, true); dv.setUint16(8, 0, true);
    dv.setUint16(10, 0, true); dv.setUint16(12, 0x21, true); dv.setUint32(14, crc, true); dv.setUint32(18, f.data.length, true); dv.setUint32(22, f.data.length, true);
    dv.setUint16(26, nameB.length, true); lh.set(nameB, 30);
    parts.push(lh, f.data);
    const ch = new Uint8Array(46 + nameB.length); const cv = new DataView(ch.buffer);
    cv.setUint32(0, 0x02014b50, true); cv.setUint16(4, 20, true); cv.setUint16(6, 20, true); cv.setUint16(8, 0x0800, true); cv.setUint16(10, 0, true);
    cv.setUint16(14, 0x21, true); cv.setUint32(16, crc, true); cv.setUint32(20, f.data.length, true); cv.setUint32(24, f.data.length, true);
    cv.setUint16(28, nameB.length, true); cv.setUint32(42, off, true); ch.set(nameB, 46);
    central.push(ch); off += lh.length + f.data.length;
  }
  const csize = central.reduce((a, b) => a + b.length, 0);
  const end = new Uint8Array(22); const ev = new DataView(end.buffer);
  ev.setUint32(0, 0x06054b50, true); ev.setUint16(8, files.length, true); ev.setUint16(10, files.length, true); ev.setUint32(12, csize, true); ev.setUint32(16, off, true);
  const all = [...parts, ...central, end]; const total = all.reduce((a, b) => a + b.length, 0);
  const out = new Uint8Array(total); let p = 0; for (const a of all) { out.set(a, p); p += a.length; }
  return out;
}

if (typeof module !== 'undefined') module.exports = { decode1252, encode1252, decodeText, parseFrm, serializeFrm, parseBas, serializeBas, parseCls, serializeCls, parseVbp, serializeVbp, CtlNode, rawToValue, quote, colorRaw, frxRead, imageMime, bytesToDataURL, makeZip, defaultFormAttributes };
