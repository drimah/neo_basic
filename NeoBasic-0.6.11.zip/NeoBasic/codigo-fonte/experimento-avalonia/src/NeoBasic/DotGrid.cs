using Avalonia;
using Avalonia.Controls;
using Avalonia.Media;

namespace NeoBasic;

public sealed class DotGrid : Control
{
    public override void Render(DrawingContext context)
    {
        base.Render(context);
        var bg = Background ?? new SolidColorBrush(Color.Parse("#DCE7F7"));
        context.FillRectangle(bg, new Rect(Bounds.Size));
        var dot = new SolidColorBrush(Color.Parse("#AFC3E1"));
        const double spacing = 16;
        for (double y = 8; y < Bounds.Height; y += spacing)
        for (double x = 8; x < Bounds.Width; x += spacing)
            context.DrawEllipse(dot, null, new Point(x, y), 0.8, 0.8);
    }

    public IBrush? Background { get; set; }
}
