// ===== NeoBasic — banco de dados no estilo DAO (VB5) sobre SQLite =====
// OpenDatabase / Database / Recordset / Field / TableDef, com leitura de .mdb/.accdb (Access) e .db (SQLite).
'use strict';
if (typeof module !== 'undefined' && typeof VBObject === 'undefined') Object.assign(globalThis, require('./vbrun.js'));

const DAO_CONST = {
  dbopentable: 1, dbopendynaset: 2, dbopensnapshot: 4, dbopenforwardonly: 8, dbopendynamic: 16,
  dbappendonly: 8, dbseechanges: 512, dbdenywrite: 1, dbdenyread: 2, dbreadonly: 4, dbforwardonly: 256, dbconsistent: 32, dbinconsistent: 16,
  dbfailonerror: 128, dbsqlpassthrough: 64,
  dbeditnone: 0, dbeditinprogress: 1, dbeditadd: 2,
  dbboolean: 1, dbbyte: 2, dbinteger: 3, dblong: 4, dbcurrency: 5, dbsingle: 6, dbdouble: 7, dbdate: 8, dbbinary: 9, dbtext: 10, dblongbinary: 11, dbmemo: 12, dbguid: 15,
  dbautoincrfield: 16, dbfixedfield: 1, dbvariablefield: 2, dbupdatablefield: 32,
  dbsystemobject: -2147483646, dbattachedtable: 1073741824,
  vbdataactionmovefirst: 1, vbdataactionmoveprevious: 2, vbdataactionmovenext: 3, vbdataactionmovelast: 4, vbdataactionaddnew: 5, vbdataactionupdate: 6, vbdataactiondelete: 7, vbdataactionfind: 8, vbdataactionbookmark: 9, vbdataactionclose: 10, vbdataactionunload: 11, vbdataactioncancel: 0,
};

// ---------- motor SQLite (carregado uma vez) ----------
let NB_SQL = null;
async function nbSqlEngine() {
  if (NB_SQL) return NB_SQL;
  const lib = globalThis.NB_DBLIB;
  if (lib && lib.initSqlJs) {
    const b64 = globalThis.NB_SQLWASM_B64 || '';
    const bin = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
    NB_SQL = await lib.initSqlJs({ wasmBinary: bin });
  } else if (typeof require !== 'undefined') {
    NB_SQL = await require(process.env.NB_SQLJS || 'sql.js')();
  } else throw vbErr(3001, 'The database engine is not available in this build.');
  return NB_SQL;
}

const dbBase = p => String(p || '').replace(/\//g, '\\').split('\\').pop().toLowerCase();
const dbStem = p => dbBase(p).replace(/\.[^.]*$/, '');

// tipos do Access -> tipo DAO
const MDB_TYPE = { boolean: 1, byte: 2, integer: 3, long: 4, currency: 5, float: 6, double: 7, datetime: 8, binary: 9, text: 10, ole: 11, memo: 12, repid: 15, numeric: 7, complex: 4, bigint: 4, datetimeextended: 8 };
const SQL_TYPE = t => ({ 1: 'INTEGER', 2: 'INTEGER', 3: 'INTEGER', 4: 'INTEGER', 5: 'REAL', 6: 'REAL', 7: 'REAL', 8: 'TEXT', 9: 'BLOB', 10: 'TEXT', 11: 'BLOB', 12: 'TEXT', 15: 'TEXT' }[t] || 'TEXT');
const qi = s => '[' + String(s).replace(/]/g, ']]') + ']';

// converte um arquivo do Access (.mdb/.accdb) para um banco SQLite em memória
function mdbToSqlite(SQL, bytes) {
  const lib = globalThis.NB_DBLIB; let MDBReader, Buf;
  if (lib && lib.MDBReader) { MDBReader = lib.MDBReader; Buf = lib.Buffer; }
  else { MDBReader = require(process.env.NB_MDBREADER || 'mdb-reader').default; Buf = Buffer; }
  const r = new MDBReader(Buf.from(bytes));
  const db = new SQL.Database();
  db.run('CREATE TABLE _nb_cols (tbl TEXT, col TEXT, type INTEGER, size INTEGER, pos INTEGER, auto INTEGER)');
  db.run('BEGIN');
  for (const tn of r.getTableNames()) {
    const t = r.getTable(tn); const cols = t.getColumns();
    const defs = cols.map(c => { const dt = MDB_TYPE[c.type] || 10; return qi(c.name) + ' ' + SQL_TYPE(dt) + (SQL_TYPE(dt) === 'TEXT' && dt !== 8 ? ' COLLATE NOCASE' : '') + (c.autoLong ? ' UNIQUE' : ''); /* Access compara texto sem diferenciar maiúsculas */ });
    db.run(`CREATE TABLE ${qi(tn)} (${defs.join(', ')})`);
    cols.forEach((c, i) => db.run('INSERT INTO _nb_cols VALUES (?,?,?,?,?,?)', [tn, c.name, MDB_TYPE[c.type] || 10, c.size || 0, i, c.autoLong ? 1 : 0]));
    const st = db.prepare(`INSERT INTO ${qi(tn)} VALUES (${cols.map(() => '?').join(',')})`);
    for (const row of t.getData()) {
      st.run(cols.map(c => { const v = row[c.name]; if (v == null) return null; if (v instanceof Date) return isoDate(v); if (typeof v === 'boolean') return v ? -1 : 0; if (typeof v === 'bigint') return Number(v); if (v && v.buffer && typeof v !== 'string') return new Uint8Array(v); return v; }));
    }
    st.free();
  }
  db.run('COMMIT');
  return db;
}
function pad(n, w) { return String(n).padStart(w || 2, '0'); }
function isoDate(d) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`; }

// funções do VB/Access usadas dentro do SQL
function registerSqlFunctions(db) {
  const s = v => v == null ? null : String(v);
  const f = (name, fn) => { try { db.create_function(name, fn); } catch (e) { } };
  f('ucase', a => s(a) && s(a).toUpperCase()); f('lcase', a => s(a) && s(a).toLowerCase());
  f('len', a => a == null ? null : s(a).length);
  f('left', (a, n) => a == null ? null : s(a).slice(0, n)); f('right', (a, n) => a == null ? null : (n > 0 ? s(a).slice(-n) : ''));
  f('mid', (a, st, n) => a == null ? null : (n == null ? s(a).slice(st - 1) : s(a).substr(st - 1, n)));
  f('trim', a => s(a) && s(a).trim()); f('ltrim', a => s(a) && s(a).replace(/^\s+/, '')); f('rtrim', a => s(a) && s(a).replace(/\s+$/, ''));
  f('instr', (a, b) => a == null || b == null ? null : s(a).indexOf(s(b)) + 1);
  f('val', a => parseFloat(s(a)) || 0); f('str', a => a == null ? null : String(a));
  f('iif', (c, a, b) => (c && c !== '0') ? a : b); f('nz', (a, b) => a == null ? (b == null ? 0 : b) : a);
  const dp = a => { if (a == null) return null; const d = new Date(String(a).replace(' ', 'T')); return isNaN(d) ? null : d; };
  f('year', a => { const d = dp(a); return d && d.getFullYear(); }); f('month', a => { const d = dp(a); return d && d.getMonth() + 1; }); f('day', a => { const d = dp(a); return d && d.getDate(); });
  f('now', () => isoDate(new Date())); f('date', () => isoDate(new Date()).slice(0, 10) + ' 00:00:00');
}

// Jet SQL -> SQLite
function jetToSqlite(sql) {
  let out = '', i = 0; const n = sql.length; let top = null;
  while (i < n) {
    const c = sql[i];
    if (c === "'" || c === '"') { // strings: "texto" do Jet vira 'texto'
      let j = i + 1, buf = '';
      while (j < n) { if (sql[j] === c) { if (sql[j + 1] === c) { buf += c; j += 2; continue; } break; } buf += sql[j]; j++; }
      out += "'" + buf.replace(/'/g, "''") + "'"; i = j + 1; continue;
    }
    if (c === '[') { const j = sql.indexOf(']', i); out += sql.slice(i, j < 0 ? n : j + 1); i = j < 0 ? n : j + 1; continue; }
    if (c === '#') { const j = sql.indexOf('#', i + 1); if (j > i) { const d = new Date(sql.slice(i + 1, j)); if (!isNaN(d)) { out += "'" + isoDate(d) + "'"; i = j + 1; continue; } } }
    if (c === '&') { out += '||'; i++; continue; }
    const m = /^[A-Za-z_]\w*/.exec(sql.slice(i));
    if (m) {
      const w = m[0], lw = w.toLowerCase();
      if (lw === 'true') out += '-1'; else if (lw === 'false') out += '0';
      else if (lw === 'top' && /select\s*(distinct\s*)?$/i.test(out)) { const mm = /^\s*(\d+)/.exec(sql.slice(i + w.length)); if (mm) { top = mm[1]; i += w.length + mm[0].length; continue; } out += w; }
      else if (lw === 'like') { out += 'LIKE'; i += w.length; const mm = /^\s*(['"])((?:\1\1|(?!\1).)*)\1/.exec(sql.slice(i)); if (mm) { out += " '" + mm[2].replace(new RegExp(mm[1] + mm[1], 'g'), mm[1]).replace(/'/g, "''").replace(/\*/g, '%').replace(/\?/g, '_') + "'"; i += mm[0].length; } continue; }
      else if (lw === 'mod') out += '%';
      else out += w;
      i += w.length; continue;
    }
    out += c; i++;
  }
  out = out.replace(/;\s*$/, '');
  if (top) out += ' LIMIT ' + top;
  return out;
}

// ---------- objetos DAO ----------
class DAOField extends VBObject {
  constructor(rs, idx) { super(); this.rs = rs; this.idx = idx; }
  get typeName() { return 'Field'; }
  get defaultProp() { return 'value'; }
  get col() { return this.rs.cols[this.idx]; }
  async getMember(n) {
    switch (n) {
      case 'value': return this.rs.fieldValue(this.idx);
      case 'name': case 'sourcefield': return this.col.name;
      case 'type': return this.col.type;
      case 'size': return this.col.size || (this.col.type === 10 ? 50 : 0);
      case 'sourcetable': return this.rs.table || '';
      case 'ordinalposition': return this.idx;
      case 'attributes': return this.col.auto ? 17 : 34;
      case 'required': case 'allowzerolength': return false;
      case 'defaultvalue': return '';
    }
    throw vbErr(438);
  }
  async setMember(n, v) { if (n === 'value') return this.rs.setFieldValue(this.idx, v); throw vbErr(438); }
}

class DAOFields extends VBObject {
  constructor(rs) { super(); this.rs = rs; }
  get typeName() { return 'Fields'; }
  async getMember(n) { if (n === 'count') return this.rs.cols.length; throw vbErr(438); }
  bangGet(n) { return new DAOField(this.rs, this.rs.colIndex(n)); }
  async callMethod(n, a) { if (n === '' || n === 'item') return new DAOField(this.rs, this.rs.colIndex(a[0])); if (n === 'count') return this.rs.cols.length; throw vbErr(438); }
  enumerate() { return this.rs.cols.map((c, i) => new DAOField(this.rs, i)); }
}

class DAORecordset extends VBObject {
  constructor(db, source, type) {
    super(); this.db = db; this.source = source; this.type = type || 2; this.pos = -1; this.rows = []; this.cols = []; this.editMode = 0; this.buf = null; this.noMatch = true; this.closed = false; this.onChange = null;
  }
  get typeName() { return 'Recordset'; }
  get defaultProp() { return null; }
  // monta o SELECT (com rowid quando dá para atualizar)
  build() {
    const src = String(this.source).trim();
    const sqlite = this.db.sqlite;
    this.table = null; let sql;
    const tbl = this.db.findTable(src.replace(/^\[|\]$/g, ''));
    if (tbl) { this.table = tbl; sql = `SELECT rowid AS __rid, * FROM ${qi(tbl)}`; }
    else {
      sql = jetToSqlite(src);
      const m = /^\s*select\s+(distinct\s+)?([\s\S]+?)\s+from\s+(\[[^\]]+\]|[A-Za-z_]\w*)(\s+(where|order\s+by)\s[\s\S]*)?$/i.exec(sql);
      if (m && !m[1] && !/\b(join|group\s+by|union)\b/i.test(sql)) { const t = this.db.findTable(m[3].replace(/^\[|\]$/g, '')); if (t) { this.table = t; sql = sql.replace(/^\s*select\s+/i, 'SELECT rowid AS __rid, '); } }
    }
    if (this.type === 4 || this.type === 8) { /* snapshot: só leitura */ }
    return sql;
  }
  load() {
    this.sql = this.build();
    let res;
    try { res = this.db.sqlite.exec(this.sql); } catch (e) { throw vbErr(3001, 'SQL error: ' + e.message + '\n' + this.source); }
    const r = res[0] || { columns: [], values: [] };
    if (!res[0]) { // sem linhas: descobre as colunas
      try { const st = this.db.sqlite.prepare(this.sql); r.columns = st.getColumnNames(); st.free(); } catch (e) { }
    }
    const ridIx = r.columns.indexOf('__rid');
    this.ridIx = ridIx;
    this.cols = r.columns.map((name, i) => ({ name, i })).filter(c => c.i !== ridIx).map(c => Object.assign({ name: c.name, src: c.i }, this.db.colInfo(this.table, c.name)));
    this.rows = r.values;
    this.updatable = !!this.table && ridIx >= 0 && this.type !== 4 && this.type !== 8 && !this.db.readOnly;
    this.pos = this.rows.length ? 0 : -1; this.bofFlag = !this.rows.length; this.eofFlag = !this.rows.length;
    return this;
  }
  get eof() { return this.eofFlag || !this.rows.length; }
  get bof() { return this.bofFlag || !this.rows.length; }
  colIndex(k) {
    if (typeof k === 'number' || (typeof k === 'string' && /^\d+$/.test(k) && false)) { const i = Math.round(k); if (i < 0 || i >= this.cols.length) throw vbErr(3265); return i; }
    const lk = toStr(k).toLowerCase(); const i = this.cols.findIndex(c => c.name.toLowerCase() === lk);
    if (i < 0) throw vbErr(3265, `Item not found in this collection: ${toStr(k)}`); return i;
  }
  cur() { if (this.closed) throw vbErr(3420); if (this.deletedHere) throw vbErr(3167, 'Record is deleted.'); if (this.editMode === 2) return null; if (this.pos < 0 || this.eofFlag || this.bofFlag || this.pos >= this.rows.length) throw vbErr(3021, 'No current record.'); return this.rows[this.pos]; }
  toVB(c, v) {
    if (v === null || v === undefined) return VBNull;
    if (c.type === 8 && typeof v === 'string') { const d = new Date(v.replace(' ', 'T')); return isNaN(d) ? v : new VBDate(d); }
    if (c.type === 1) return !!v && v !== '0';
    if (v instanceof Uint8Array) return Array.from(v).map(b => String.fromCharCode(b)).join('');
    return v;
  }
  toSQL(c, v) {
    if (v === VBNull || v === undefined || v === VBMissing) return null;
    if (v instanceof VBDate) return isoDate(v.d);
    if (typeof v === 'boolean') return v ? -1 : 0;
    if (c && (c.type === 3 || c.type === 4 || c.type === 2) && (typeof v === 'string')) { const t = v.trim(); if (t === '') return null; const nn = Number(t.replace(',', '.')); return isNaN(nn) ? v : Math.round(nn); }
    if (c && (c.type === 5 || c.type === 6 || c.type === 7) && typeof v === 'string') { const t = v.trim(); if (t === '') return null; const nn = Number(t.replace(',', '.')); return isNaN(nn) ? v : nn; }
    if (c && c.type === 8 && typeof v === 'string') { const d = parseDate(v); return d instanceof VBDate ? isoDate(d.d) : v; }
    return v;
  }
  fieldValue(i) {
    const c = this.cols[i];
    if (this.editMode && this.buf && this.buf.has(i)) return this.buf.get(i);
    if (this.editMode === 2) return VBNull;
    return this.toVB(c, this.cur()[c.src]);
  }
  setFieldValue(i, v) {
    if (!this.editMode) throw vbErr(3020, 'Update or CancelUpdate without AddNew or Edit.');
    if (!this.buf) this.buf = new Map();
    this.buf.set(i, v);
  }
  changed() { if (this.onChange) this.onChange(); }
  move(to) {
    if (this.closed) throw vbErr(3420);
    this.deletedHere = false;
    if (this.beforeMove && !this._inMove) { this._inMove = true; try { this.beforeMove(); } finally { this._inMove = false; } }
    const n = this.rows.length;
    if (to < 0) { this.pos = -1; this.bofFlag = true; this.eofFlag = n === 0; }
    else if (to >= n) { this.pos = n; this.eofFlag = true; this.bofFlag = n === 0; }
    else { this.pos = to; this.bofFlag = false; this.eofFlag = false; }
    this.changed();
  }
  ensureUpdatable() { if (!this.updatable) throw vbErr(3027, this.db.readOnly ? 'Cannot update. Database or object is read-only.' : "Cannot update. This recordset is read-only (use a table or a simple SELECT from one table)."); }
  doUpdate() {
    if (!this.editMode) throw vbErr(3020, 'Update or CancelUpdate without AddNew or Edit.');
    const sq = this.db.sqlite; const buf = this.buf || new Map();
    if (this.editMode === 2) {
      const names = [], vals = [];
      for (const [i, v] of buf) { names.push(qi(this.cols[i].name)); vals.push(this.toSQL(this.cols[i], v)); }
      for (const c of this.cols) if (c.auto && !names.includes(qi(c.name))) { const mx = sq.exec(`SELECT IFNULL(MAX(${qi(c.name)}),0)+1 FROM ${qi(this.table)}`)[0].values[0][0]; names.push(qi(c.name)); vals.push(mx); }
      try { sq.run(names.length ? `INSERT INTO ${qi(this.table)} (${names.join(',')}) VALUES (${vals.map(() => '?').join(',')})` : `INSERT INTO ${qi(this.table)} DEFAULT VALUES`, vals); } catch (e) { throw vbErr(3022, 'Could not add the record: ' + e.message); }
      const rid = sq.exec('SELECT last_insert_rowid()')[0].values[0][0];
      const row = sq.exec(`SELECT rowid AS __rid, * FROM ${qi(this.table)} WHERE rowid = ${rid}`)[0];
      const full = this.cols.map(c => row.values[0][row.columns.indexOf(c.name)]);
      const newRow = []; newRow[this.ridIx] = rid; this.cols.forEach((c, k) => { newRow[c.src] = full[k]; });
      this.rows.push(newRow); this.lastModified = this.rows.length - 1;
    } else {
      const row = this.cur(); const rid = row[this.ridIx];
      if (buf.size) {
        const sets = [], vals = [];
        for (const [i, v] of buf) { sets.push(qi(this.cols[i].name) + ' = ?'); vals.push(this.toSQL(this.cols[i], v)); }
        try { sq.run(`UPDATE ${qi(this.table)} SET ${sets.join(', ')} WHERE rowid = ?`, [...vals, rid]); } catch (e) { throw vbErr(3022, 'Could not update the record: ' + e.message); }
        for (const [i, v] of buf) row[this.cols[i].src] = this.toSQL(this.cols[i], v);
      }
      this.lastModified = this.pos;
    }
    this.editMode = 0; this.buf = null; this.db.dirty = true; this.db.touch();
  }
  async getMember(n, rt) {
    switch (n) {
      case 'eof': return this.eof;
      case 'bof': return this.bof;
      case 'recordcount': return this.rows.length;
      case 'absoluteposition': return this.eof || this.bof ? -1 : this.pos;
      case 'percentposition': return this.rows.length ? (this.pos + 1) * 100 / this.rows.length : 0;
      case 'fields': return new DAOFields(this);
      case 'nomatch': return this.noMatch;
      case 'editmode': return this.editMode;
      case 'updatable': return this.updatable;
      case 'name': return this.table || this.source;
      case 'type': return this.type;
      case 'bookmark': this.cur(); return 'bm' + this.cur()[this.ridIx >= 0 ? this.ridIx : 0] + ':' + this.pos;
      case 'lastmodified': return this.lastModified != null ? 'bm0:' + this.lastModified : '';
      case 'bookmarkable': return true;
      case 'sort': return this.sort || ''; case 'filter': return this.filter || '';
      case 'index': return this.index || '';
      case 'movefirst': case 'movenext': case 'moveprevious': case 'movelast': case 'addnew': case 'edit': case 'update': case 'delete': case 'close': case 'requery': case 'cancelupdate':
        return this.callMethod(n, [], rt);
    }
    // rs!Campo
    return this.fieldValue(this.colIndex(n));
  }
  // rs!Campo sempre é um campo (mesmo que se chame Name, Type, Index...)
  bangGet(n) { return this.fieldValue(this.colIndex(n)); }
  bangSet(n, v) { return this.setFieldValue(this.colIndex(n), v); }
  async setMember(n, v, rt, idx) {
    if (n === 'bookmark') { const m = /:(\d+)$/.exec(toStr(v)); if (!m) throw vbErr(3159); this.move(+m[1]); return; }
    if (n === 'absoluteposition') { this.move(Math.round(toNum(v))); return; }
    if (n === 'sort') { this.sort = toStr(v); return; }
    if (n === 'filter') { this.filter = toStr(v); return; }
    if (n === 'index') { this.index = toStr(v); return; }
    if ((n === '' || n === 'fields') && idx) return this.setFieldValue(this.colIndex(idx[0]), v);
    // rs!Campo = valor
    return this.setFieldValue(this.colIndex(n), v);
  }
  async callMethod(n, a, rt) {
    switch (n) {
      case '': case 'fields': if (!a.length) return new DAOFields(this); return new DAOField(this, this.colIndex(a[0]));
      case 'movefirst': if (this.editMode) this.editMode = 0; this.move(0); return;
      case 'movelast': if (this.editMode) this.editMode = 0; this.move(this.rows.length - 1); return;
      case 'movenext': if (this.deletedHere) { this.deletedHere = false; this.move(this.pos); return; } if (this.eof) throw vbErr(3021, 'No current record.'); this.move(this.pos + 1); return;
      case 'moveprevious': if (this.deletedHere) { this.deletedHere = false; this.move(this.pos - 1); return; } if (this.bof) throw vbErr(3021, 'No current record.'); this.move(this.pos - 1); return;
      case 'move': this.move(this.pos + Math.round(toNum(a[0]))); return;
      case 'addnew': this.ensureUpdatable(); this.editMode = 2; this.buf = new Map(); this.changed(); return;
      case 'edit': this.ensureUpdatable(); this.cur(); this.editMode = 1; this.buf = new Map(); return;
      case 'update': { const wasAdd = this.editMode === 2; this.doUpdate(); if (wasAdd) { /* VB: depois do AddNew o registro atual continua o mesmo */ } this.changed(); return; }
      case 'cancelupdate': this.editMode = 0; this.buf = null; this.changed(); return;
      case 'delete': {
        this.ensureUpdatable(); const row = this.cur();
        this.db.sqlite.run(`DELETE FROM ${qi(this.table)} WHERE rowid = ?`, [row[this.ridIx]]);
        this.rows.splice(this.pos, 1); this.db.dirty = true; this.db.touch();
        // como no VB: o registro apagado continua "atual" até mover (MoveNext vai para o seguinte)
        this.deletedHere = true; return;
      }
      case 'close': this.closed = true; return;
      case 'requery': this.load(); this.changed(); return;
      case 'findfirst': case 'findlast': case 'findnext': case 'findprevious': return this.find(n, toStr(a[0]));
      case 'seek': return this.seek(a);
      case 'clone': { const c = new DAORecordset(this.db, this.source, this.type); c.load(); return c; }
      case 'openrecordset': { const c = new DAORecordset(this.db, this.sql, this.type); return c.load(); }
      case 'getrows': { const k = daoMiss(a[0]) ? this.rows.length : Math.round(toNum(a[0])); const take = this.rows.slice(this.pos, this.pos + k); const arr = new VBArray([[0, this.cols.length - 1], [0, Math.max(0, take.length - 1)]], 'variant', rt); take.forEach((row, j) => this.cols.forEach((c, i) => { arr.set([i, j], this.toVB(c, row[c.src])); })); this.move(this.pos + take.length); return arr; }
    }
    if (!a.length) return this.getMember(n, rt);
    throw vbErr(438);
  }
  find(kind, crit) {
    if (!this.rows.length) { this.noMatch = true; return; }
    let set;
    const where = jetToSqlite(crit);
    if (this.table && this.ridIx >= 0) {
      let res; try { res = this.db.sqlite.exec(`SELECT rowid FROM ${qi(this.table)} WHERE ${where}`); } catch (e) { throw vbErr(3077, 'Syntax error in expression: ' + crit); }
      set = new Set(res[0] ? res[0].values.map(v => v[0]) : []);
    } else {
      let res; try { res = this.db.sqlite.exec(`SELECT * FROM (${this.sql}) WHERE ${where}`); } catch (e) { throw vbErr(3077, 'Syntax error in expression: ' + crit); }
      const keys = new Set((res[0] ? res[0].values : []).map(v => JSON.stringify(v)));
      set = { has: (row) => keys.has(JSON.stringify(row)) }; this._rowMatch = true;
    }
    const match = i => { const row = this.rows[i]; return this._rowMatch ? set.has(row) : set.has(row[this.ridIx]); };
    const n = this.rows.length; let found = -1;
    if (kind === 'findfirst') { for (let i = 0; i < n; i++) if (match(i)) { found = i; break; } }
    else if (kind === 'findlast') { for (let i = n - 1; i >= 0; i--) if (match(i)) { found = i; break; } }
    else if (kind === 'findnext') { for (let i = Math.max(0, this.pos + 1); i < n; i++) if (match(i)) { found = i; break; } }
    else { for (let i = Math.min(n - 1, this.pos - 1); i >= 0; i--) if (match(i)) { found = i; break; } }
    this._rowMatch = false;
    this.noMatch = found < 0;
    if (!this.noMatch) this.move(found);
  }
  seek(a) {
    // Seek "=", valor  -> procura pela primeira coluna do índice (ou a primeira coluna)
    const op = toStr(a[0]); const val = a[1];
    const col = this.index ? this.cols.findIndex(c => c.name.toLowerCase() === this.index.toLowerCase()) : 0;
    const ci = col < 0 ? 0 : col; const c = this.cols[ci];
    const cmp = (x) => { const v = this.toVB(c, x[c.src]); return cmpValues(v === VBNull ? '' : v, val, true); };
    const okOp = { '=': d => d === 0, '>=': d => d >= 0, '>': d => d > 0, '<=': d => d <= 0, '<': d => d < 0 }[op] || (d => d === 0);
    const i = this.rows.findIndex(r => okOp(cmp(r)));
    this.noMatch = i < 0; if (i >= 0) this.move(i);
  }
  enumerate() { return new DAOFields(this).enumerate(); }
}

class DAOTableDef extends VBObject {
  constructor(db, name) { super(); this.db = db; this.name = name; }
  get typeName() { return 'TableDef'; }
  async getMember(n) {
    switch (n) {
      case 'name': return this.name;
      case 'recordcount': return this.db.sqlite.exec(`SELECT COUNT(*) FROM ${qi(this.name)}`)[0].values[0][0];
      case 'attributes': return 0;
      case 'fields': { const rs = new DAORecordset(this.db, this.name, 4); rs.load(); return new DAOFields(rs); }
      case 'sourcetablename': return ''; case 'connect': return '';
      case 'updatable': return !this.db.readOnly;
    }
    throw vbErr(438);
  }
  async callMethod(n, a, rt) { if (n === 'openrecordset') { const rs = new DAORecordset(this.db, this.name, daoMiss(a[0]) ? 1 : toNum(a[0])); return rs.load(); } return this.getMember(n); }
}
class DAOList extends VBObject {
  constructor(tn, items) { super(); this.tn = tn; this.items = items; }
  get typeName() { return this.tn; }
  async getMember(n) { if (n === 'count') return this.items.length; if (n === 'refresh') return; throw vbErr(438); }
  async callMethod(n, a) {
    if (n === 'refresh') return;
    if (n === '' || n === 'item') { const k = a[0]; if (typeof k === 'number') { const it = this.items[Math.round(k)]; if (!it) throw vbErr(3265); return it; } const lk = toStr(k).toLowerCase(); const it = this.items.find(x => x.name.toLowerCase() === lk); if (!it) throw vbErr(3265, `Item not found in this collection: ${toStr(k)}`); return it; }
    return this.getMember(n);
  }
  enumerate() { return this.items.slice(); }
}

class DAODatabase extends VBObject {
  constructor(entry, name, readOnly) { super(); this.entry = entry; this.sqlite = entry.db; this.name = name; this.readOnly = !!readOnly; this.recordsAffected = 0; }
  get typeName() { return 'Database'; }
  get dirty() { return this.entry.dirty; } set dirty(v) { this.entry.dirty = v; }
  touch() { if (this.entry.onChange) this.entry.onChange(this.entry); }
  tables() { return this.sqlite.exec("SELECT name FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE '\\_nb\\_%' ESCAPE '\\' AND name NOT LIKE 'sqlite\\_%' ESCAPE '\\' ORDER BY name")[0]?.values.map(v => v[0]) || []; }
  findTable(name) { const ln = String(name).toLowerCase(); return this.tables().find(t => t.toLowerCase() === ln) || null; }
  colInfo(table, col) {
    if (!this.entry.colMeta) {
      this.entry.colMeta = new Map();
      try { const r = this.sqlite.exec('SELECT tbl, col, type, size, auto FROM _nb_cols')[0]; if (r) for (const [t, c, ty, sz, au] of r.values) this.entry.colMeta.set((t + '\u0000' + c).toLowerCase(), { type: ty, size: sz, auto: !!au }); } catch (e) { }
    }
    const m = table && this.entry.colMeta.get((table + '\u0000' + col).toLowerCase());
    if (m) return m;
    // banco SQLite comum: deduz pelo tipo declarado
    if (table) { try { const info = this.sqlite.exec(`PRAGMA table_info(${qi(table)})`)[0]; const row = info && info.values.find(v => String(v[1]).toLowerCase() === String(col).toLowerCase()); if (row) { const t = String(row[2]).toUpperCase(); return { type: /INT/.test(t) ? 4 : /REAL|FLOA|DOUB|NUM|DEC/.test(t) ? 7 : /DATE|TIME/.test(t) ? 8 : /BLOB/.test(t) ? 11 : /BOOL/.test(t) ? 1 : 10, size: 0, auto: !!row[5] && /INT/.test(t) }; } } catch (e) { } }
    return { type: 10, size: 0, auto: false };
  }
  async getMember(n) {
    switch (n) {
      case 'name': return this.name;
      case 'tabledefs': return new DAOList('TableDefs', this.tables().map(t => new DAOTableDef(this, t)));
      case 'querydefs': return new DAOList('QueryDefs', []);
      case 'recordsaffected': return this.recordsAffected;
      case 'updatable': return !this.readOnly;
      case 'version': return '3.0';
      case 'connect': return '';
      case 'close': return;
    }
    throw vbErr(438);
  }
  async callMethod(n, a, rt) {
    switch (n) {
      case 'openrecordset': { const rs = new DAORecordset(this, toStr(a[0]), daoMiss(a[1]) ? 2 : Math.round(toNum(a[1]))); return rs.load(); }
      case 'execute': {
        if (this.readOnly) throw vbErr(3027, 'Cannot update. Database or object is read-only.');
        const sql = jetToSqlite(toStr(a[0]));
        try { this.sqlite.run(sql); } catch (e) { throw vbErr(3001, 'SQL error: ' + e.message); }
        this.recordsAffected = this.sqlite.getRowsModified(); this.dirty = true; this.touch(); return;
      }
      case 'close': return;
      case 'createquerydef': { const sql = toStr(a[1] || ''); const db = this; return new SimpleObject('QueryDef', { sql, name: toStr(a[0] || '') }, { openrecordset: (b) => new DAORecordset(db, sql, daoMiss(b[0]) ? 2 : toNum(b[0])).load(), execute: () => db.callMethod('execute', [sql]) }); }
    }
    if (!a.length) return this.getMember(n, rt);
    throw vbErr(438);
  }
}
const daoMiss = v => v === undefined || v === VBMissing;

// abre (ou reaproveita) um banco pelo nome do arquivo
async function daoOpenDatabase(rt, path, readOnly) {
  const host = rt.host || {};
  const cache = host.dbCache || (host.dbCache = new Map());
  const key = dbStem(path);
  let entry = cache.get(key);
  if (!entry) {
    const f = host.getDbFile ? await host.getDbFile(path) : null;
    if (!f) {
      const e = vbErr(3024, `Couldn't find file '${path}'.` + (host.dbHint || '')); throw e;
    }
    const SQL = await nbSqlEngine();
    const ext = (f.name.split('.').pop() || '').toLowerCase();
    let db;
    if (ext === 'mdb' || ext === 'accdb') { try { db = mdbToSqlite(SQL, f.bytes); } catch (e) { throw vbErr(3343, `Unrecognized database format '${path}': ${e.message}`); } }
    else { try { db = new SQL.Database(f.bytes); db.exec('SELECT name FROM sqlite_master LIMIT 1'); } catch (e) { throw vbErr(3343, `Unrecognized database format '${path}'.`); } }
    registerSqlFunctions(db);
    entry = { name: f.name, stem: key, db, dirty: false, onChange: host.onDbChange || null, fromAccess: ext === 'mdb' || ext === 'accdb' };
    cache.set(key, entry);
  }
  return new DAODatabase(entry, path, readOnly);
}

// DBEngine / Workspaces(0)
function makeDBEngine(rt) {
  const ws = new SimpleObject('Workspace', { name: '#Default Workspace#', username: 'admin' }, {
    opendatabase: (a) => daoOpenDatabase(rt, toStr(a[0]), !daoMiss(a[2]) && toBool(a[2])),
    begintrans: () => { }, committrans: () => { }, rollback: () => { }, close: () => { },
  });
  const wss = new DAOList('Workspaces', [ws]); ws.name = '#Default Workspace#';
  return new SimpleObject('DBEngine', { version: '3.0', inipath: '', defaulttype: 2, workspaces: wss }, {
    workspaces: (a) => a.length ? wss.callMethod('', a) : wss,
    opendatabase: (a) => daoOpenDatabase(rt, toStr(a[0]), !daoMiss(a[2]) && toBool(a[2])),
    idle: () => { }, compactdatabase: () => { }, repairdatabase: () => { },
  });
}

// ---------- controle Data (VB.Data) e controles ligados (DataSource / DataField) ----------
const NB_DONE = { done: true };
const RS_TYPE = { 0: 1, 1: 2, 2: 4 }; // RecordsetType do controle -> tipo DAO
function nbBound(ctl) {
  const nm = ctl.vbName.toLowerCase();
  return ctl.form.allControls.filter(c => c !== ctl && c.P.datafield && String(c.P.datasource || '').toLowerCase() === nm);
}
function nbShowValue(c, v) {
  const s = (v === VBNull || v === undefined || v === null) ? '' : toStr(v);
  const P = c.P;
  switch (c.type) {
    case 'VB.CheckBox': P.value = (v === VBNull || !v) ? 0 : 1; break;
    case 'VB.Label': P.caption = s; break;
    case 'VB.ComboBox': case 'VB.ListBox': P.text = s; if (c.input) c.input.value = s; break;
    default: { const sv = c.type === 'VB.TextBox' && P.mask && !P.multiline ? nbMaskFormat(P.mask, s) : s; P.text = sv; if (c.input) c.input.value = sv; c.refresh(); return sv; }
  }
  c.refresh();
  return c.type === 'VB.CheckBox' ? P.value : s;
}
function nbReadValue(c) {
  if (c.type === 'VB.CheckBox') return c.P.value ? 1 : 0;
  if (c.type === 'VB.Label') return c.P.caption;
  return c.input ? c.input.value : (c.P.text || '');
}
function nbUpdateControls(ctl) {
  const rs = ctl.dataRs; const shown = ctl.dataShown = new Map(); ctl.navRedo = null;
  for (const c of nbBound(ctl)) {
    let v = '';
    if (rs && !rs.closed && (rs.editMode === 2 || (!rs.eof && !rs.bof))) { try { v = rs.fieldValue(rs.colIndex(c.P.datafield)); } catch (e) { v = ''; } }
    shown.set(c, nbShowValue(c, v));
  }
  if (typeof nbNavSyncAll === 'function') nbNavSyncAll(ctl);
}
// grava o que o usuário digitou nos controles ligados antes de sair do registro
function nbSaveBound(ctl) {
  const rs = ctl.dataRs; if (!rs || rs.closed || !rs.updatable) return;
  const shown = ctl.dataShown || new Map(); const changes = [];
  for (const c of nbBound(ctl)) { if (c.type === 'VB.Label') continue; const now = nbReadValue(c); if (shown.has(c) && String(now) !== String(shown.get(c))) changes.push([c, now]); }
  if (!changes.length && rs.editMode !== 2) return;
  if (rs.editMode !== 2) { if (rs.eof || rs.bof) return; rs.editMode = 1; rs.buf = new Map(); }
  for (const [c, now] of changes) { try { const i = rs.colIndex(c.P.datafield); rs.buf.set(i, c.type === 'VB.CheckBox' ? (now ? -1 : 0) : now); } catch (e) { } }
  try { rs.doUpdate(); } catch (e) { if (ctl.form.rt) ctl.form.rt.handleTopError(e); }
}
async function nbDataRefresh(ctl, rt) {
  const P = ctl.P;
  if (!P.databasename || !P.recordsource) { ctl.dataRs = null; nbUpdateControls(ctl); return; }
  const db = await daoOpenDatabase(rt, P.databasename, !!P.readonly);
  const rs = new DAORecordset(db, P.recordsource, RS_TYPE[P.recordsettype] || 2); rs.load();
  ctl.dataDb = db; ctl.dataRs = rs;
  rs.beforeMove = () => nbSaveBound(ctl);
  rs.onChange = () => { nbUpdateControls(ctl); if (rt.fireEvent) rt.fireEvent(ctl.form, ctl.lname, 'reposition', [], ctl.index); };
  nbUpdateControls(ctl);
  if (rt.fireEvent) await rt.fireEvent(ctl.form, ctl.lname, 'reposition', [], ctl.index);
}
async function nbInitFormData(form, rt) {
  for (const c of form.allControls || []) {
    if (c.dataRs) continue;
    if (c.type !== 'VB.Data' && !(c.type === 'NB.NavigationBar' && !String(c.P.datasource || '').trim() && c.P.recordsource)) continue;
    try { await nbDataRefresh(c, rt); } catch (e) { if (rt.fireEvent && rt.hasEvent && rt.hasEvent(form, c.lname, 'error')) { await rt.fireEvent(form, c.lname, 'error', [e.number || 0, 0], c.index); } else throw e; }
  }
  for (const c of form.allControls || []) if (c.type === 'NB.NavigationBar') { const src = nbNavSrc(c); if (src) nbNavSyncAll(src); else nbNavRender(c); }
}
function nbDataNav(ctl, where) {
  const rs = ctl.dataRs; if (!rs) return;
  const P = ctl.P; const rt = ctl.form.rt;
  try {
    if (where === 'first') rs.move(0);
    else if (where === 'last') rs.move(rs.rows.length - 1);
    else if (where === 'next') { if (rs.pos >= rs.rows.length - 1) { if (P.eofaction === 2 && rs.updatable) { nbSaveBound(ctl); rs.editMode = 2; rs.buf = new Map(); rs.changed(); } else if (P.eofaction === 1) rs.move(rs.rows.length); else rs.move(rs.rows.length - 1); } else rs.move(rs.pos + 1); }
    else if (where === 'prev') { if (rs.pos <= 0) { if (P.bofaction === 1) rs.move(-1); else rs.move(0); } else rs.move(rs.pos - 1); }
  } catch (e) { if (rt) rt.handleTopError(e); }
}
async function nbDataGet(ctl, n, rt) {
  if (n === 'recordset') { if (!ctl.dataRs) throw vbErr(91); return ctl.dataRs; }
  if (n === 'database') { if (!ctl.dataDb) throw vbErr(91); return ctl.dataDb; }
  if (n === 'editmode') return ctl.dataRs ? ctl.dataRs.editMode : 0;
  if (n === 'refresh' || n === 'updaterecord' || n === 'updatecontrols') { await nbDataCall(ctl, n, [], rt || ctl.form.rt); return null; }
  return undefined;
}
async function nbDataCall(ctl, n, a, rt) {
  switch (n) {
    case 'refresh': await nbDataRefresh(ctl, rt); return NB_DONE;
    case 'updaterecord': nbSaveBound(ctl); return NB_DONE;
    case 'updatecontrols': nbUpdateControls(ctl); return NB_DONE;
  }
  return undefined;
}

// ---------- Barra de navegação de registros (NB.NavigationBar) ----------
// Funciona sozinha (DatabaseName + RecordSource, os campos usam DataSource = a barra)
// ou comandando um controle Data do form (propriedade DataSource = nome do Data).
// ícones de linha iguais aos da barra do NeoBasic
const NAV_ICON = {
  new: '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M12 11v6M9 14h6"/>',
  copy: '<rect x="8" y="8" width="12" height="13" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h2"/>',
  paste: '<path d="M9 4H6.5A1.5 1.5 0 0 0 5 5.5v14A1.5 1.5 0 0 0 6.5 21h11a1.5 1.5 0 0 0 1.5-1.5v-14A1.5 1.5 0 0 0 17.5 4H15"/><rect x="9" y="2.5" width="6" height="3.5" rx="1"/><path d="M9 11h6M9 14.5h6M9 18h3.5"/>',
  undo: '<path d="M9 14L4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/>',
  redo: '<path d="M15 14l5-5-5-5"/><path d="M20 9H9.5a5.5 5.5 0 0 0 0 11H13"/>',
  save: '<path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7"/><path d="M7 3v4a1 1 0 0 0 1 1h7"/>',
  edit: '<path d="M4 20h4L19 9a2.1 2.1 0 0 0-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
  del: '<path d="M4 7h16M9.5 7V4.5h5V7M6.5 7l1 13h9l1-13M10 11v5.5M14 11v5.5"/>',
  cancel: '<circle cx="12" cy="12" r="8.5"/><path d="M9 9l6 6M15 9l-6 6"/>',
  first: '<path d="M6 5v14M17 6l-6 6 6 6"/>', prev: '<path d="M15 6l-6 6 6 6"/>', next: '<path d="M9 6l6 6-6 6"/>', last: '<path d="M18 5v14M7 6l6 6-6 6"/>',
};
// ordem padrão: Novo, Copiar, Colar, Desfazer, Refazer, Salvar, Alterar, Excluir, Primeiro, Anterior, Próximo, Último
const NAV_ORDER_DEFAULT = 'new,copy,paste,|,undo,redo,|,save,edit,del,cancel,|,first,prev,rec,next,last';
const NAV_ITEMS = ['new', 'copy', 'paste', 'undo', 'redo', 'save', 'edit', 'del', 'cancel', 'first', 'prev', 'rec', 'next', 'last'];
const NAV_SHOWPROP = { new: 'shownew', copy: 'showcopy', paste: 'showpaste', undo: 'showundo', redo: 'showredo', save: 'showsave', edit: 'showedit', del: 'showdelete', cancel: 'showcancel', first: 'showfirst', prev: 'showprevious', rec: 'showrecordnumber', next: 'shownext', last: 'showlast' };
function navOrderList(P) {
  const raw = String((P && P.buttonorder) || '').trim() || NAV_ORDER_DEFAULT;
  const out = []; const seen = new Set();
  for (let t of raw.split(/[,;\s]+/)) { t = t.toLowerCase(); if (t === '|' || t === 'sep' || t === '-') { out.push('|'); continue; } if (NAV_ITEMS.includes(t) && !seen.has(t)) { seen.add(t); out.push(t); } }
  for (const t of NAV_ITEMS) if (!seen.has(t)) out.push(t); // botões novos que ainda não estão na lista vão para o fim
  return out;
}
function navText() {
  const pt = typeof LOCALE === 'undefined' || LOCALE !== 'en-US';
  return pt ? { new: 'Novo', copy: 'Copiar', paste: 'Colar', undo: 'Desfazer', redo: 'Refazer', save: 'Salvar', edit: 'Alterar', del: 'Excluir', cancel: 'Cancelar', first: 'Primeiro', prev: 'Anterior', next: 'Próximo', last: 'Último', rec: 'Nº do registro',
      tip: { new: 'Novo registro', copy: 'Copiar os dados deste registro', paste: 'Colar os dados copiados', undo: 'Desfazer o que foi digitado', redo: 'Refazer', save: 'Salvar', edit: 'Alterar este registro', del: 'Excluir este registro', cancel: 'Cancelar a alteração', first: 'Primeiro registro', prev: 'Registro anterior', next: 'Próximo registro', last: 'Último registro' },
      of: 'de', ask: 'Excluir este registro?', noSrc: 'A barra de navegação não está ligada a uma tabela.\n\nEscolha DatabaseName e RecordSource (ou o DataSource com o nome de um controle Data).', ro: 'Esta tabela é só de leitura.' }
    : { new: 'New', copy: 'Copy', paste: 'Paste', undo: 'Undo', redo: 'Redo', save: 'Save', edit: 'Edit', del: 'Delete', cancel: 'Cancel', first: 'First', prev: 'Previous', next: 'Next', last: 'Last', rec: 'Record number',
      tip: { new: 'New record', copy: 'Copy the data of this record', paste: 'Paste the copied data', undo: 'Undo what was typed', redo: 'Redo', save: 'Save', edit: 'Edit this record', del: 'Delete this record', cancel: 'Cancel the changes', first: 'First record', prev: 'Previous record', next: 'Next record', last: 'Last record' },
      of: 'of', ask: 'Delete this record?', noSrc: 'The navigation bar is not connected to a table.\n\nSet DatabaseName and RecordSource (or DataSource with the name of a Data control).', ro: 'This table is read-only.' };
}
const NAV_CLIP = new Map(); // dados copiados, por tabela
function nbNavHtml(P, ctx) {
  const T = navText(); const st = P._navstate || { mode: 'browse', pos: 0, count: 0 };
  const design = ctx && ctx.design; const style = Number(P.buttonstyle) || 0;
  const browse = st.mode === 'browse', editing = !browse || P.lockfields === false;
  const dis = (a) => {
    if (design) return false;
    switch (a) {
      case 'first': case 'prev': return !browse || st.count === 0 || st.pos <= 0;
      case 'next': case 'last': return !browse || st.count === 0 || st.pos >= st.count - 1;
      case 'new': return !browse || !st.upd;
      case 'edit': case 'del': return !browse || !st.upd || !st.hasCur;
      case 'copy': return !(st.hasCur || !browse);
      case 'paste': return !st.clip || !st.upd || (browse ? false : false);
      case 'undo': return !editing || !st.undo;
      case 'redo': return !editing || !st.redo;
      case 'save': case 'cancel': return browse && P.lockfields !== false;
    }
    return false;
  };
  const B = (a) => `<b data-a="${a}" class="nv nv-${a}${dis(a) ? ' dis' : ''}" title="${T.tip[a] || T[a]}">${style !== 2 ? `<svg viewBox="0 0 24 24">${NAV_ICON[a]}</svg>` : ''}${style !== 0 ? `<span>${T[a]}</span>` : ''}</b>`;
  let h = ''; let pendingSep = false;
  for (const t of navOrderList(P)) {
    if (t === '|') { if (h) pendingSep = true; continue; }
    if (P[NAV_SHOWPROP[t]] === false) continue;
    if (pendingSep) { h += '<span class="nv-sep"></span>'; pendingSep = false; }
    if (t === 'rec') {
      const cur = design ? '1' : st.mode === 'new' ? '*' : st.count ? String(st.pos + 1) : '0';
      h += `<span class="nv-rec" title="${T.rec}"><input class="nv-recin" value="${cur}" ${design || !browse ? 'readonly tabindex="-1"' : ''} spellcheck="false"><span class="nv-of">${T.of} ${design ? 'n' : st.count}</span></span>`;
    } else h += B(t);
  }
  return h;
}
function nbNavSrc(nav) {
  const ds = String(nav.P.datasource || '').trim();
  if (!ds) return nav;
  return nav.form.allControls.find(x => x !== nav && x.vbName.toLowerCase() === ds.toLowerCase() && (x.type === 'VB.Data' || x.type === 'NB.NavigationBar')) || null;
}
function nbNavsOf(src) { return (src.form.allControls || []).filter(c => c.type === 'NB.NavigationBar' && nbNavSrc(c) === src); }
function nbNavRender(nav) {
  const src = nbNavSrc(nav); const rs = src && src.dataRs;
  if (src && rs) {
    // se o registro mudou por fora (setas do Data, código), sai do modo de edição
    if (src.navMode === 'new' && rs.editMode !== 2) src.navMode = 'browse';
    if (src.navMode === 'edit' && rs.pos !== src.navEditPos) src.navMode = 'browse';
  }
  const mode = (src && src.navMode) || 'browse';
  nav.P._navstate = { mode, pos: rs ? rs.pos : -1, count: rs ? rs.rows.length : 0, upd: !!(rs && rs.updatable), hasCur: !!(rs && !rs.closed && rs.editMode !== 2 && !rs.eof && !rs.bof && !rs.deletedHere), clip: !!(src && NAV_CLIP.has(navClipKey(src))), undo: !!(src && nbNavChanged(src)), redo: !!(src && src.navRedo) };
  const inp = nav.el && nav.el.querySelector('.nv-recin');
  if (inp && document.activeElement === inp) return;
  nav.refresh();
}
function navClipKey(src) { return String(src.P.recordsource || '').toLowerCase(); }
// algum campo foi mudado desde que o registro apareceu?
function nbNavChanged(src) { const shown = src.dataShown; if (!shown) return false; for (const c of nbBound(src)) { if (c.type === 'VB.Label' || !shown.has(c)) continue; if (String(nbReadValue(c)) !== String(shown.get(c))) return true; } return false; }
function nbNavSnapshot(src) { const m = new Map(); for (const c of nbBound(src)) if (c.type !== 'VB.Label') m.set(c, nbReadValue(c)); return m; }
function nbNavPut(c, v) { const P = c.P; if (c.type === 'VB.CheckBox') { P.value = v && v !== '0' ? 1 : 0; c.refresh(); return; } const s2 = v === undefined || v === null ? '' : String(v); if (c.type === 'VB.Label') P.caption = s2; else { P.text = s2; if (c.input) c.input.value = s2; } c.refresh(); }
function nbNavLock(src) {
  const navs = nbNavsOf(src);
  const lock = navs.some(n => n.P.lockfields !== false) && (src.navMode || 'browse') === 'browse';
  for (const c of nbBound(src)) {
    if (c.type === 'VB.Label') continue;
    if (!!c.P._navlock !== lock) { c.P._navlock = lock; c.refresh(); }
    // ao digitar, a barra liga Desfazer/Refazer
    if (!c._navHooked && c.el) { c._navHooked = true; const upd = () => { for (const n of nbNavsOf(src)) nbNavRender(n); }; c.el.addEventListener('input', upd); c.el.addEventListener('click', () => setTimeout(upd, 0)); }
  }
}
function nbNavSyncAll(src) { if (!src || !src.form || !src.form.allControls) return; const navs = nbNavsOf(src); if (!navs.length) return; for (const n of navs) nbNavRender(n); nbNavLock(src); }
function nbNavFocusFirst(src) {
  const list = nbBound(src).filter(c => c.type !== 'VB.Label' && c.P.visible !== false && c.P.enabled !== false).sort((a, b) => (a.P.tabindex ?? 0) - (b.P.tabindex ?? 0));
  const c = list[0]; if (c) { const t = c.input || c.el; setTimeout(() => { try { t.focus(); if (t.select) t.select(); } catch (e) { } }, 0); }
}
function nbNavSave(src, mode) {
  const rs = src.dataRs; const shown = src.dataShown || new Map(); const buf = new Map();
  for (const c of nbBound(src)) {
    if (c.type === 'VB.Label') continue;
    const now = nbReadValue(c);
    if (mode === 'new' ? String(now) !== '' : String(now) !== String(shown.get(c))) { try { buf.set(rs.colIndex(c.P.datafield), c.type === 'VB.CheckBox' ? (now ? -1 : 0) : now); } catch (e) { } }
  }
  if (!buf.size) return mode === 'new' ? 'empty' : undefined;
  rs.editMode = mode === 'new' ? 2 : 1; rs.buf = buf;
  try { rs.doUpdate(); }
  catch (e) { if (mode === 'new') { rs.editMode = 2; rs.buf = new Map(); } else { rs.editMode = 0; rs.buf = null; } throw e; }
}
async function nbNavAction(nav, a) {
  const rt = nav.form.rt; const T = navText();
  const src = nbNavSrc(nav); const rs = src && src.dataRs;
  if (!src || !rs) { await nav.form.host.msgBox(T.noSrc, 48, nav.form.rt && nav.form.rt.title || ''); return; }
  const mode = src.navMode || 'browse';
  try {
    switch (a) {
      case 'first': if (mode === 'browse' && rs.rows.length) rs.move(0); break;
      case 'prev': if (mode === 'browse' && rs.pos > 0) rs.move(rs.pos - 1); break;
      case 'next': if (mode === 'browse' && rs.pos < rs.rows.length - 1) rs.move(rs.pos + 1); break;
      case 'last': if (mode === 'browse' && rs.rows.length) rs.move(rs.rows.length - 1); break;
      case 'copy': {
        const clip = new Map(); for (const c of nbBound(src)) if (c.type !== 'VB.Label' && c.P.datafield) clip.set(String(c.P.datafield).toLowerCase(), nbReadValue(c));
        NAV_CLIP.set(navClipKey(src), clip); break;
      }
      case 'paste': {
        const clip = NAV_CLIP.get(navClipKey(src)); if (!clip || !rs.updatable) break;
        if (mode === 'browse' && nav.P.lockfields !== false) { src.navBackPos = rs.pos; src.navMode = 'new'; rs.editMode = 2; rs.buf = new Map(); rs.changed(); }
        src.navRedo = null;
        for (const c of nbBound(src)) { if (c.type === 'VB.Label' || !c.P.datafield) continue; const k = String(c.P.datafield).toLowerCase(); if (clip.has(k)) nbNavPut(c, clip.get(k)); }
        nbNavFocusFirst(src); break;
      }
      case 'undo': {
        const shown = src.dataShown || new Map(); if (!nbNavChanged(src)) break;
        src.navRedo = nbNavSnapshot(src);
        for (const c of nbBound(src)) if (c.type !== 'VB.Label' && shown.has(c)) nbNavPut(c, shown.get(c));
        break;
      }
      case 'redo': {
        const r = src.navRedo; if (!r) break; src.navRedo = null;
        for (const [c, v] of r) nbNavPut(c, v);
        break;
      }
      case 'new':
        if (mode !== 'browse') break;
        if (!rs.updatable) { await nav.form.host.msgBox(T.ro, 48, ''); break; }
        if (nav.P.lockfields === false) nbSaveBound(src);
        src.navBackPos = rs.pos; src.navMode = 'new'; rs.editMode = 2; rs.buf = new Map(); rs.changed();
        nbNavFocusFirst(src); break;
      case 'edit':
        if (mode !== 'browse' || !rs.updatable || rs.eof || rs.bof || rs.deletedHere) break;
        src.navMode = 'edit'; src.navEditPos = rs.pos; nbNavSyncAll(src); nbNavFocusFirst(src); break;
      case 'save':
        if (mode === 'browse') { nbSaveBound(src); nbUpdateControls(src); break; }
        if (nbNavSave(src, mode) === 'empty') { await nbNavAction(nav, 'cancel'); return; }
        src.navMode = 'browse';
        if (mode === 'new') { nbUpdateControls(src); rs.move(rs.rows.length - 1); } else { nbUpdateControls(src); rs.changed(); }
        break;
      case 'cancel':
        if (mode === 'new') { rs.editMode = 0; rs.buf = null; src.navMode = 'browse'; const back = src.navBackPos; if (typeof back === 'number' && back >= 0 && back < rs.rows.length) { rs.pos = back; rs.bofFlag = false; rs.eofFlag = false; } rs.changed(); }
        else if (mode === 'edit') { src.navMode = 'browse'; nbUpdateControls(src); }
        else nbUpdateControls(src);
        break;
      case 'del': {
        if (mode !== 'browse' || !rs.updatable || rs.eof || rs.bof || rs.deletedHere) break;
        if (nav.P.confirmdelete !== false && (await nav.form.host.msgBox(T.ask, 4 + 32 + 256, '')) !== 6) break;
        const p = rs.pos; await rs.callMethod('delete', [], rt);
        rs.deletedHere = false; nbUpdateControls(src);
        if (rs.rows.length) rs.move(Math.min(p, rs.rows.length - 1)); else { rs.move(-1); }
        break;
      }
    }
  } catch (e) { if (rt) rt.handleTopError(e); }
  nbNavSyncAll(src);
}
function nbNavGoto(nav, v) {
  const src = nbNavSrc(nav); const rs = src && src.dataRs; if (!rs) return;
  const n = Math.round(Number(String(v).trim()));
  if ((src.navMode || 'browse') === 'browse' && isFinite(n) && n >= 1 && n <= rs.rows.length) { try { rs.move(n - 1); } catch (e) { if (nav.form.rt) nav.form.rt.handleTopError(e); } }
  const inp = nav.el.querySelector('.nv-recin'); if (inp) inp.blur();
  nbNavRender(nav);
}
async function nbNavGet(nav, n, rt) {
  const src = nbNavSrc(nav);
  if (n === 'mode') return { browse: 0, edit: 1, new: 2 }[(src && src.navMode) || 'browse'];
  if (n === 'recordset' || n === 'database' || n === 'editmode') { if (!src) throw vbErr(91); return nbDataGet(src, n, rt); }
  const acts = { movefirst: 'first', moveprevious: 'prev', movenext: 'next', movelast: 'last', addnew: 'new', edit: 'edit', delete: 'del', save: 'save', update: 'save', cancel: 'cancel', cancelupdate: 'cancel' };
  if (acts[n]) { await nbNavAction(nav, acts[n]); return null; }
  if (n === 'refresh') { await nbNavCall(nav, 'refresh', [], rt); return null; }
  return undefined;
}
async function nbNavCall(nav, n, a, rt) {
  const acts = { movefirst: 'first', moveprevious: 'prev', movenext: 'next', movelast: 'last', addnew: 'new', edit: 'edit', delete: 'del', save: 'save', update: 'save', cancel: 'cancel', cancelupdate: 'cancel' };
  if (acts[n]) { await nbNavAction(nav, acts[n]); return NB_DONE; }
  if (n === 'refresh') { const src = nbNavSrc(nav); if (src === nav) await nbDataRefresh(nav, rt); else if (src) await nbDataCall(src, 'refresh', [], rt); if (src) { src.navMode = 'browse'; nbNavSyncAll(src); } return NB_DONE; }
  return undefined;
}

if (typeof module !== 'undefined') module.exports = { DAO_CONST, daoOpenDatabase, makeDBEngine, jetToSqlite, mdbToSqlite, nbSqlEngine, DAORecordset, DAODatabase, dbStem, dbBase };
