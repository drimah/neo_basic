import re, pathlib
src = pathlib.Path(__file__).parent / 'src'
core_files = ['vbparse.js', 'vbrun.js', 'vbdata.js', 'vbexec.js', 'vbfiles.js', 'vbui.js', 'vbforms.js', 'runhost.js']
def strip(js):
    # remove exports de node
    js = re.sub(r"^if \(typeof module !== 'undefined'\)[^\n]*(\n[^\n]*\}\);)?\n?", '', js, flags=re.M)
    return js
core = '\n'.join(f'// ---- {f} ----\n' + (src/f).read_text() for f in core_files)
# o bloco require do vbexec
runcss = (src/'runtime.css').read_text()
import base64 as _b64
_fd = pathlib.Path(__file__).parent / 'fonts'
def _ff(fam, file, weight, style='normal'):
    data = _b64.b64encode((_fd/file).read_bytes()).decode()
    return f"@font-face{{font-family:'{fam}';src:url(data:font/woff2;base64,{data}) format('woff2');font-weight:{weight};font-style:{style};font-display:block}}"
fonts = '\n'.join([_ff('NB Inter','inter-latin-400-normal.woff2',400), _ff('NB Inter','inter-latin-500-normal.woff2',500), _ff('NB Inter','inter-latin-600-normal.woff2',600), _ff('NB Inter','inter-latin-700-normal.woff2',700), _ff('NB Inter','inter-latin-400-italic.woff2',400,'italic'), _ff('NB Mono','jetbrains-mono-latin-400-normal.woff2',400), _ff('NB Mono','jetbrains-mono-latin-600-normal.woff2',600)])
idecss = (src/'ide.css').read_text()
ide = (src/'ide.js').read_text()
dblib = (pathlib.Path(__file__).parent / 'dblib' / 'dblib.js').read_text().replace('</script', '<\\/script')
sqlwasm = _b64.b64encode((pathlib.Path(__file__).parent / 'dblib' / 'sql-wasm.wasm').read_bytes()).decode()
ICON = __import__('base64').b64encode((pathlib.Path(__file__).parent / 'launcher' / 'icon256.png').read_bytes()).decode()
html = f'''<!DOCTYPE html>
<html lang="en" translate="no">
<head>
<meta charset="utf-8">
<meta name="google" content="notranslate">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>NeoBasic</title>
<link rel="icon" type="image/png" href="data:image/png;base64,{ICON}">
<style id="nb-fonts">
{fonts}
</style>
<style id="nb-runcss">
{runcss}
</style>
<style>
{idecss}
</style>
</head>
<body>
<script id="nb-dblib">
{dblib}
</script>
<script id="nb-sqlwasm">window.NB_SQLWASM_B64="{sqlwasm}";</script>
<script id="nb-core">
{core}
</script>
<script>
{ide}
</script>
</body>
</html>
'''
out = pathlib.Path(__file__).parent / 'dist'
out.mkdir(exist_ok=True)
(out/'NeoBasic.html').write_text(html)
print('ok', len(html))
