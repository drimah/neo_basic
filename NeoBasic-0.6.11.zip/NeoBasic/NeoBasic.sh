#!/bin/sh
# NeoBasic para Linux (Mint, Ubuntu, etc.) — abre o NeoBasic em janela própria,
# igual à do Windows, usando um navegador Chromium (Chrome, Chromium, Brave ou Edge).
# Na primeira vez cria o atalho no menu de aplicativos.

DIR="$(cd "$(dirname "$0")" && pwd)"
# abre o .html com o mesmo nome deste arquivo (NeoBasic.sh -> NeoBasic.html, Agenda.sh -> Agenda.html)
APP="$(basename "$0" .sh)"
HTML="$DIR/$APP.html"
ICON="$DIR/icone/neobasic.png"; [ -f "$DIR/$APP.png" ] && ICON="$DIR/$APP.png"
if [ "$APP" = "NeoBasic" ]; then PERFIL="${XDG_DATA_HOME:-$HOME/.local/share}/neobasic/perfil"; else PERFIL="${XDG_DATA_HOME:-$HOME/.local/share}/neobasic/apps/$APP"; fi
SLUG="$(printf '%s' "$APP" | tr 'A-Z ' 'a-z-')"

aviso() {
  if command -v zenity >/dev/null 2>&1; then zenity --error --title="NeoBasic" --width=420 --text="$1" 2>/dev/null
  elif command -v notify-send >/dev/null 2>&1; then notify-send "NeoBasic" "$1"
  else echo "NeoBasic: $1" >&2; fi
}

[ -f "$HTML" ] || { aviso "Não encontrei o $APP.html. Deixe o $APP.sh na mesma pasta dele."; exit 1; }

# atalho no menu (uma vez, ou se a pasta mudou)
APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
DESK="$APPS/$SLUG.desktop"
if [ -z "$NEOBASIC_DRYRUN" ] && ! grep -qF "Exec=\"$DIR/$APP.sh\"" "$DESK" 2>/dev/null; then
  mkdir -p "$APPS"
  cat > "$DESK" <<EOF
[Desktop Entry]
Type=Application
Name=$APP
Comment=$APP
Exec="$DIR/$APP.sh"
Icon=$ICON
Terminal=false
Categories=Development;IDE;
StartupWMClass=$APP
EOF
  chmod +x "$DESK" 2>/dev/null
  command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APPS" >/dev/null 2>&1
fi

# endereço file:// (com acentos e espaços codificados)
if command -v python3 >/dev/null 2>&1; then
  URL="file://$(python3 -c 'import sys,urllib.parse;print(urllib.parse.quote(sys.argv[1]))' "$HTML")?app=1"
else
  URL="file://$(printf '%s' "$HTML" | sed 's/ /%20/g')?app=1"
fi

ARGS="--app=$URL --user-data-dir=$PERFIL --class=$APP --start-maximized --no-first-run --no-default-browser-check --disable-features=Translate --lang=pt-BR --hide-crash-restore-bubble $NEOBASIC_EXTRA"

# navegador.txt (ao lado deste arquivo): chrome, brave, vivaldi, chromium, opera, edge ou o caminho de um navegador
LISTA="google-chrome google-chrome-stable brave-browser brave vivaldi vivaldi-stable chromium chromium-browser opera microsoft-edge microsoft-edge-stable"
if [ -f "$DIR/navegador.txt" ]; then
  ESC="$(head -n 1 "$DIR/navegador.txt" | tr -d '\r"' | sed 's/^[ \t]*//;s/[ \t]*$//')"
  case "$(printf '%s' "$ESC" | tr 'A-Z' 'a-z')" in
    chrome) LISTA="google-chrome google-chrome-stable $LISTA" ;;
    brave) LISTA="brave-browser brave $LISTA" ;;
    vivaldi) LISTA="vivaldi vivaldi-stable $LISTA" ;;
    chromium) LISTA="chromium chromium-browser $LISTA" ;;
    opera) LISTA="opera $LISTA" ;;
    edge) LISTA="microsoft-edge microsoft-edge-stable $LISTA" ;;
    "") ;;
    *) [ -x "$ESC" ] && LISTA="$ESC $LISTA" ;;
  esac
fi
mkdir -p "$PERFIL"
for B in $LISTA; do
  if command -v "$B" >/dev/null 2>&1; then
    [ -n "$NEOBASIC_DRYRUN" ] && { echo "$B $ARGS"; exit 0; }
    # shellcheck disable=SC2086
    exec "$B" $ARGS
  fi
done
for F in com.google.Chrome org.chromium.Chromium com.brave.Browser com.microsoft.Edge; do
  if command -v flatpak >/dev/null 2>&1 && flatpak info "$F" >/dev/null 2>&1; then
    [ -n "$NEOBASIC_DRYRUN" ] && { echo "flatpak run $F $ARGS"; exit 0; }
    # shellcheck disable=SC2086
    exec flatpak run --filesystem=home "$F" $ARGS
  fi
done

aviso "O NeoBasic precisa de um navegador Chromium (Chromium, Chrome ou Brave) para abrir em janela própria.

No Linux Mint, instale com:
    sudo apt install chromium

Por enquanto vou abrir no navegador padrão."
exec xdg-open "$HTML"
