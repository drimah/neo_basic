# NeoBasic 0.4.4 — Native Avalonia migration

## Architecture decision
The new desktop UI is built with Avalonia 12, C#, XAML and .NET 10. It does not embed a browser, WebView, HTML page or browser-based application window. Avalonia draws the interface directly.

## Included in this migration foundation
- Native desktop application entry point and window.
- Light blue/white Visual Basic-inspired shell.
- Menu and toolbar rows.
- Compact two-column Toolbox with circular hover/selection feedback.
- Dotted form-design surface and a sample internal form window.
- Project Explorer, Properties panel and Immediate pane.
- Capsule treatment reserved for action buttons; toolbar buttons are transparent until hover.
- Original JavaScript source and HTML build are preserved under `legacy-js/` for reference and controlled porting.

## Not yet ported
The existing BASIC parser, interpreter/runtime, project/file handling, form serialization, control property editing, and code editor are still implemented in the preserved JavaScript source. They have not been silently replaced with mock C# implementations. The new Avalonia shell is the first migration milestone; feature parity requires porting and testing those subsystems.

## Build requirements
- .NET 10 SDK
- NuGet package restore access

Windows: run `build-windows.bat`.
Linux: run `./build-linux.sh`.

## Current environment verification
The authoring environment did not contain the `dotnet` SDK. Source files and project structure were created, but a successful C# compilation could not be claimed here. Run the build script on a machine with .NET 10 installed.
