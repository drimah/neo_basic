// ===== New Basic — interpretador =====
'use strict';

const ERR_MSG = {
  3: 'Return without GoSub', 5: 'Invalid procedure call or argument', 6: 'Overflow', 7: 'Out of memory',
  9: 'Subscript out of range', 10: 'This array is fixed or temporarily locked', 11: 'Division by zero',
  13: 'Type mismatch', 20: 'Resume without error', 28: 'Out of stack space', 35: 'Sub or Function not defined',
  52: 'Bad file name or number', 53: 'File not found', 54: 'Bad file mode', 55: 'File already open',
  62: 'Input past end of file', 67: 'Too many files', 91: 'Object variable or With block variable not set', 92: 'For loop not initialized',
  94: 'Invalid use of Null', 340: 'Control array element does not exist', 343: 'Object not an array', 360: 'Object already loaded', 361: "Can't load or unload this object",
  380: 'Invalid property value', 381: 'Invalid property array index', 382: "Property can't be set at run time", 383: 'Property is read-only', 424: 'Object required', 429: "ActiveX component can't create object",
  438: "Object doesn't support this property or method", 440: 'Automation error', 448: 'Named argument not found', 449: 'Argument not optional',
  450: 'Wrong number of arguments or invalid property assignment', 451: 'Property let procedure not defined and property get procedure did not return an object',
  457: 'This key is already associated with an element of this collection', 458: 'Variable uses an Automation type not supported in Visual Basic',
  730: 'Control not found', 32755: 'Cancel was selected.', 32811: 'Element not found',
  1001: 'Variable not defined', 1002: 'Feature not supported by NeoBasic',
};
class VBError extends Error {
  constructor(num, desc, line, module) { super(desc || ERR_MSG[num] || 'Application-defined or object-defined error'); this.number = num; this.description = this.message; this.line = line; this.module = module; this.source = ''; }
}
const vbErr = (n, d) => new VBError(n, d);
class EndSignal { }
const VBNull = Object.freeze({ isNull: true, toString() { return 'Null'; } });
const VBMissing = Object.freeze({ isMissing: true });

// ---------- Datas ----------
const DAY_MS = 86400000;
const EPOCH = new Date(1899, 11, 30).getTime();
class VBDate {
  constructor(d) { this.d = d instanceof Date ? d : new Date(d); }
  get serial() { const d = this.d; const base = new Date(d.getFullYear(), d.getMonth(), d.getDate()); const days = Math.round((base - EPOCH) / DAY_MS); const frac = (d - base) / DAY_MS; return days + (days < 0 ? -frac : frac); }
  static fromSerial(s) { const days = Math.trunc(s); const frac = Math.abs(s - days); const base = new Date(EPOCH); base.setDate(base.getDate() + days); return new VBDate(new Date(base.getTime() + Math.round(frac * DAY_MS))); }
}

// ---------- Matrizes ----------
class VBArray {
  constructor(dims, type, rt) { this.type = type || 'variant'; this.dims = dims || []; this.dynamic = false; this.data = []; this.rt = rt; this.alloc(); }
  get size() { return this.dims.reduce((a, [lb, ub]) => a * Math.max(0, ub - lb + 1), this.dims.length ? 1 : 0); }
  alloc() { const n = this.size; this.data = new Array(n); for (let i = 0; i < n; i++) this.data[i] = defaultValue(this.type, this.rt); }
  flat(idx) {
    if (idx.length !== this.dims.length) throw vbErr(9);
    let off = 0;
    for (let k = 0; k < idx.length; k++) {
      const [lb, ub] = this.dims[k]; const i = idx[k];
      if (i < lb || i > ub) throw vbErr(9);
      off = off * (ub - lb + 1) + (i - lb);
    }
    return off;
  }
  get(idx) { return this.data[this.flat(idx)]; }
  set(idx, v) { this.data[this.flat(idx)] = v; }
  clone() { const a = Object.create(VBArray.prototype); a.type = this.type; a.dims = this.dims.map(d => d.slice()); a.dynamic = this.dynamic; a.rt = this.rt; a.data = this.data.map(cloneValue); return a; }
  redim(dims, preserve) {
    if (!preserve) { this.dims = dims; this.alloc(); return; }
    const old = this; const oldDims = this.dims, oldData = this.data;
    this.dims = dims; this.alloc();
    if (!oldDims.length) return;
    // preserva: só a última dimensão pode mudar (copiamos o que couber)
    const iter = (k, idx) => {
      if (k === dims.length) { try { const v = oldData[flatOf(oldDims, idx)]; if (v !== undefined) this.data[this.flat(idx)] = v; } catch (e) { } return; }
      const [lb, ub] = dims[k]; const [olb, oub] = oldDims[k] || [0, -1];
      for (let i = Math.max(lb, olb); i <= Math.min(ub, oub); i++) { idx[k] = i; iter(k + 1, idx); }
    };
    if (oldDims.length === dims.length) iter(0, []);
  }
}
function flatOf(dims, idx) { let off = 0; for (let k = 0; k < idx.length; k++) { const [lb, ub] = dims[k]; if (idx[k] < lb || idx[k] > ub) throw vbErr(9); off = off * (ub - lb + 1) + (idx[k] - lb); } return off; }

// ---------- Tipos definidos pelo usuário ----------
class VBRecord {
  constructor(typeDef, rt) { this.typeDef = typeDef; this.fields = new Map(); if (typeDef) for (const f of typeDef.fields) this.fields.set(f.name.toLowerCase(), f.dims ? rt.makeArray(f.dims, f.type, null) : defaultValue(f.type, rt)); }
  clone() { const r = Object.create(VBRecord.prototype); r.typeDef = this.typeDef; r.fields = new Map(); for (const [k, v] of this.fields) r.fields.set(k, cloneValue(v)); return r; }
}
function cloneValue(v) { return (v instanceof VBArray || v instanceof VBRecord) ? v.clone() : v; }

// ---------- Objetos ----------
class VBObject {
  get typeName() { return 'Object'; }
  get defaultProp() { return null; }
  async getMember(name, rt) { throw vbErr(438); }
  async setMember(name, v, rt, idx) { throw vbErr(438); }
  async callMember(name, args, frame, rt) {
    const vals = await rt.argValues(args, frame);
    return this.callMethod(name, vals, rt);
  }
  async callMethod(name, vals, rt) {
    if (!vals.length) return this.getMember(name, rt);
    throw vbErr(438);
  }
  enumerate() { throw vbErr(451, 'Object is not a collection'); }
}

class VBCollection extends VBObject {
  constructor() { super(); this.items = []; this.keys = []; }
  get typeName() { return 'Collection'; }
  findIndex(k) {
    if (typeof k === 'string') { const lk = k.toLowerCase(); const i = this.keys.indexOf(lk); if (i < 0) throw vbErr(5); return i; }
    const i = Math.round(toNum(k)) - 1; if (i < 0 || i >= this.items.length) throw vbErr(9); return i;
  }
  async getMember(name) { if (name === 'count') return this.items.length; throw vbErr(438); }
  async callMethod(name, a, rt) {
    switch (name) {
      case 'add': {
        const [item, key, before, after] = a;
        const k = (key === undefined || key === VBMissing) ? null : toStr(key).toLowerCase();
        if (k !== null && this.keys.includes(k)) throw vbErr(457);
        let pos = this.items.length;
        if (before !== undefined && before !== VBMissing) pos = this.findIndex(before);
        else if (after !== undefined && after !== VBMissing) pos = this.findIndex(after) + 1;
        this.items.splice(pos, 0, item); this.keys.splice(pos, 0, k); return;
      }
      case 'remove': { const i = this.findIndex(a[0]); this.items.splice(i, 1); this.keys.splice(i, 1); return; }
      case 'item': case '': return this.items[this.findIndex(a[0])];
      case 'count': return this.items.length;
      case 'clear': this.items = []; this.keys = []; return;
    }
    throw vbErr(438);
  }
  enumerate() { return this.items.slice(); }
}

class VBDictionary extends VBObject {
  constructor() { super(); this.map = new Map(); this.compareMode = 0; }
  get typeName() { return 'Dictionary'; }
  kk(k) { if (k instanceof VBObject) return k; const s = (typeof k === 'number') ? 'n:' + k : 's:' + toStr(k); return this.compareMode ? s.toLowerCase() : s; }
  async getMember(name) {
    if (name === 'count') return this.map.size;
    if (name === 'comparemode') return this.compareMode;
    if (name === 'keys') return arrFrom([...this.map.values()].map(e => e.k));
    if (name === 'items') return arrFrom([...this.map.values()].map(e => e.v));
    if (name === 'removeall') { this.map.clear(); return; }
    throw vbErr(438);
  }
  async setMember(name, v, rt, idx) {
    if (name === 'comparemode') { this.compareMode = toNum(v); return; }
    if ((name === 'item' || name === '') && idx) { const key = idx[0]; this.map.set(this.kk(key), { k: key, v }); return; }
    throw vbErr(438);
  }
  async callMethod(name, a, rt) {
    switch (name) {
      case 'add': { const kk = this.kk(a[0]); if (this.map.has(kk)) throw vbErr(457); this.map.set(kk, { k: a[0], v: a[1] }); return; }
      case 'exists': return this.map.has(this.kk(a[0]));
      case 'item': case '': { const e = this.map.get(this.kk(a[0])); if (!e) { this.map.set(this.kk(a[0]), { k: a[0], v: undefined }); return undefined; } return e.v; }
      case 'remove': if (!this.map.delete(this.kk(a[0]))) throw vbErr(32811); return;
      case 'removeall': this.map.clear(); return;
      case 'keys': return arrFrom([...this.map.values()].map(e => e.k));
      case 'items': return arrFrom([...this.map.values()].map(e => e.v));
      case 'count': return this.map.size;
    }
    throw vbErr(438);
  }
  enumerate() { return [...this.map.values()].map(e => e.k); }
}
function arrFrom(list) { const a = new VBArray([[0, list.length - 1]], 'variant', null); a.data = list.slice(); return a; }

class ErrObject extends VBObject {
  constructor() { super(); this.clear(); }
  get typeName() { return 'ErrObject'; }
  get defaultProp() { return 'number'; }
  clear() { this.number = 0; this.description = ''; this.source = ''; this.line = 0; }
  async getMember(n) { if (n === 'number') return this.number; if (n === 'description') return this.description; if (n === 'source') return this.source; if (n === 'erl') return this.line; if (n === 'lastdllerror') return 0; if (n === 'clear') { this.clear(); return; } throw vbErr(438); }
  async setMember(n, v) { if (n === 'number') this.number = toNum(v); else if (n === 'description') this.description = toStr(v); else if (n === 'source') this.source = toStr(v); else throw vbErr(438); }
  async callMethod(n, a) {
    if (n === 'clear') { this.clear(); return; }
    if (n === 'raise') {
      const num = toNum(a[0]);
      const e = new VBError(num, a[2] !== undefined && a[2] !== VBMissing ? toStr(a[2]) : undefined);
      e.source = a[1] !== undefined && a[1] !== VBMissing ? toStr(a[1]) : ''; throw e;
    }
    return this.getMember(n);
  }
}

class SimpleObject extends VBObject {
  constructor(name, props, methods, def) { super(); this.tn = name; this.props = props || {}; this.methods = methods || {}; this.def = def || null; }
  get typeName() { return this.tn; }
  get defaultProp() { return this.def; }
  async getMember(n, rt) { if (n in this.props) { const p = this.props[n]; return typeof p === 'function' ? p(rt) : p; } if (n in this.methods) return this.methods[n]([], rt); throw vbErr(438); }
  async setMember(n, v) { if (n in this.props && typeof this.props[n] !== 'function') { this.props[n] = v; return; } throw vbErr(438); }
  async callMethod(n, a, rt) { if (n in this.methods) return this.methods[n](a, rt); return this.getMember(n, rt); }
}

// ---------- Conversões ----------
let DEC_SEP = ',';     // configurável (pt-BR por padrão)
let THOUS_SEP = '.';
function setLocale(loc) { LOCALE = loc === 'en-US' ? 'en-US' : 'pt-BR'; if (LOCALE === 'en-US') { DEC_SEP = '.'; THOUS_SEP = ','; MONTHS = MONTHS_EN; WDAYS = WDAYS_EN; } else { DEC_SEP = ','; THOUS_SEP = '.'; MONTHS = MONTHS_PT; WDAYS = WDAYS_PT; } }
function curSym() { return LOCALE === 'en-US' ? '$' : 'R$ '; }
function shortDate(d) { return LOCALE === 'en-US' ? `${d.getMonth() + 1}/${d.getDate()}/${d.getFullYear()}` : `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}/${d.getFullYear()}`; }

function isObj(v) { return v instanceof VBObject; }
function strToNum(s, strict) {
  let t = s.trim();
  if (t === '') { if (strict) throw vbErr(13); return 0; }
  const hm = /^&H([0-9a-f]+)&?$/i.exec(t); if (hm) return parseInt(hm[1], 16);
  const om = /^&O([0-7]+)&?$/i.exec(t); if (om) return parseInt(om[1], 8);
  let neg = false;
  if (/^\(.*\)$/.test(t)) { neg = true; t = t.slice(1, -1); }
  t = t.replace(/^R\$\s*/i, '').replace(/^\$\s*/, '');
  if (THOUS_SEP) t = t.split(THOUS_SEP).join(THOUS_SEP === '.' && !/\.\d{3}(\D|$)/.test(t) ? '.' : '');
  if (DEC_SEP === ',') t = t.replace(',', '.');
  if (t.endsWith('%')) { t = t.slice(0, -1); const v = Number(t); if (!isNaN(v)) return (neg ? -v : v) / 100; }
  if (/^[+\-]?(\d+\.?\d*|\.\d+)([eEdD][+\-]?\d+)?$/.test(t)) { const v = Number(t.replace(/[dD]/, 'e')); return neg ? -v : v; }
  if (/^(true|verdadeiro)$/i.test(t)) return -1; if (/^(false|falso)$/i.test(t)) return 0;
  throw vbErr(13);
}
function toNum(v) {
  if (typeof v === 'number') return v;
  if (typeof v === 'boolean') return v ? -1 : 0;
  if (v === undefined) return 0;
  if (typeof v === 'string') return strToNum(v, true);
  if (v instanceof VBDate) return v.serial;
  if (v === VBNull) throw vbErr(94);
  if (v === null) throw vbErr(91);
  if (v instanceof VBObject && v.defaultProp && v._sync) return toNum(v._sync(v.defaultProp));
  throw vbErr(13);
}
function isNumericStr(s) { try { strToNum(String(s), true); return true; } catch (e) { return false; } }
function numToStr(n, sep) {
  if (!isFinite(n)) return n > 0 ? '1,#INF' : (n < 0 ? '-1,#INF' : '-1,#IND');
  let s;
  if (Number.isInteger(n) && Math.abs(n) < 1e15) s = String(n);
  else {
    s = String(Number(n.toPrecision(15)));
    if (/e/.test(s)) { const [m, e] = s.split('e'); const ei = parseInt(e, 10); s = m.toUpperCase() + 'E' + (ei < 0 ? '-' : '+') + String(Math.abs(ei)).padStart(2, '0'); }
    else if (s.startsWith('0.')) s = s.slice(1); else if (s.startsWith('-0.')) s = '-' + s.slice(2);
  }
  return s.replace('.', sep === undefined ? DEC_SEP : sep);
}
function toStr(v) {
  if (typeof v === 'string') return v;
  if (typeof v === 'number') return numToStr(v);
  if (typeof v === 'boolean') return v ? 'True' : 'False';
  if (v === undefined || v === VBMissing) return '';
  if (v instanceof VBDate) return fmtDateDefault(v);
  if (v === VBNull) throw vbErr(94);
  if (v === null) throw vbErr(91);
  if (v instanceof VBObject && v.defaultProp && v._sync) return toStr(v._sync(v.defaultProp));
  throw vbErr(13);
}
function toBool(v) {
  if (typeof v === 'boolean') return v;
  if (typeof v === 'number') return v !== 0;
  if (v === undefined) return false;
  if (v === VBNull) return false;
  if (typeof v === 'string') { const t = v.trim().toLowerCase(); if (t === 'true' || t === 'verdadeiro') return true; if (t === 'false' || t === 'falso') return false; return strToNum(v, true) !== 0; }
  return toNum(v) !== 0;
}
function vbRound(x) { if (!isFinite(x)) return x; const f = Math.floor(x); const d = x - f; if (Math.abs(d - 0.5) < 1e-12) return (f % 2 === 0) ? f : f + 1; return Math.round(x); }
function toLong(v, min, max) { const n = vbRound(toNum(v)); if (n < min || n > max) throw vbErr(6); return n; }
function pad2(n) { return String(n).padStart(2, '0'); }
function fmtDateDefault(dt) {
  const d = dt.d, s = dt.serial;
  const datePart = shortDate(d);
  const timePart = `${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
  const hasTime = d.getHours() || d.getMinutes() || d.getSeconds();
  if (Math.trunc(s) === 0 && hasTime) return timePart;
  return hasTime ? datePart + ' ' + timePart : datePart;
}
function parseDate(str, us) {
  if (str instanceof VBDate) return str;
  if (typeof str === 'number') return VBDate.fromSerial(str);
  const s = String(str).trim();
  let m = /^(\d{1,4})[\/\-.](\d{1,2})[\/\-.](\d{1,4})(?:\s+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?\s*([ap]m)?)?$/i.exec(s);
  if (m) {
    let a = +m[1], b = +m[2], c = +m[3], y, mo, d;
    if (m[1].length === 4) { y = a; mo = b; d = c; }
    else if (DEC_SEP === ',' && !us) { d = a; mo = b; y = c; } else { mo = a; d = b; y = c; }
    if (y < 100) y += y < 30 ? 2000 : 1900;
    let h = m[4] ? +m[4] : 0; const mi = m[5] ? +m[5] : 0, se = m[6] ? +m[6] : 0;
    if (m[7]) { if (/pm/i.test(m[7]) && h < 12) h += 12; if (/am/i.test(m[7]) && h === 12) h = 0; }
    const dt = new Date(y, mo - 1, d, h, mi, se);
    if (dt.getMonth() !== mo - 1) throw vbErr(13);
    return new VBDate(dt);
  }
  m = /^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?\s*([ap]m)?$/i.exec(s);
  if (m) { let h = +m[1]; if (m[4]) { if (/pm/i.test(m[4]) && h < 12) h += 12; if (/am/i.test(m[4]) && h === 12) h = 0; } const dt = new Date(EPOCH); dt.setHours(h, +m[2], m[3] ? +m[3] : 0); return new VBDate(dt); }
  throw vbErr(13);
}

function defaultValue(type, rt) {
  switch (type) {
    case 'integer': case 'long': case 'byte': case 'single': case 'double': case 'currency': case 'decimal': case 'longlong': return 0;
    case 'string': return '';
    case 'boolean': return false;
    case 'date': return VBDate.fromSerial(0);
    case 'variant': case undefined: case null: return undefined;
    case 'object': return null;
  }
  if (rt) { const td = rt.findType(type); if (td) return new VBRecord(td, rt); }
  return null; // classes / objetos
}
function coerce(v, type, rt) {
  if (v === VBMissing && type !== 'variant') throw vbErr(449);
  switch (type) {
    case 'integer': return toLong(v, -32768, 32767);
    case 'long': return toLong(v, -2147483648, 2147483647);
    case 'longlong': return toLong(v, -9.2e18, 9.2e18);
    case 'byte': return toLong(v, 0, 255);
    case 'single': case 'double': case 'decimal': return toNum(v);
    case 'currency': return Math.round(toNum(v) * 10000) / 10000;
    case 'string': return toStr(v);
    case 'boolean': return toBool(v);
    case 'date': return (v instanceof VBDate) ? v : (typeof v === 'string' ? parseDate(v) : VBDate.fromSerial(toNum(v)));
    case 'variant': case undefined: case null: return cloneValue(v);
    case 'object': if (v !== null && !(v instanceof VBObject)) throw vbErr(13); return v;
  }
  if (v instanceof VBRecord) return v.clone();
  if (v instanceof VBArray) return v.clone();
  return v;
}

function typeNameOf(v) {
  if (v === undefined) return 'Empty';
  if (v === VBNull) return 'Null';
  if (v === null) return 'Nothing';
  if (typeof v === 'string') return 'String';
  if (typeof v === 'boolean') return 'Boolean';
  if (typeof v === 'number') return Number.isInteger(v) ? (Math.abs(v) <= 32767 ? 'Integer' : 'Long') : 'Double';
  if (v instanceof VBDate) return 'Date';
  if (v instanceof VBArray) return 'Variant()';
  if (v instanceof VBRecord) return v.typeDef ? v.typeDef.name : 'UDT';
  if (v instanceof VBObject) return v.typeName;
  return 'Unknown';
}
function varTypeOf(v) {
  if (v === undefined) return 0; if (v === VBNull) return 1;
  if (typeof v === 'number') return Number.isInteger(v) ? (Math.abs(v) <= 32767 ? 2 : 3) : 5;
  if (typeof v === 'string') return 8; if (typeof v === 'boolean') return 11; if (v instanceof VBDate) return 7;
  if (v instanceof VBArray) return 8192 + 12; if (v === null || v instanceof VBObject) return 9; return 12;
}

// ---------- Operadores ----------
function likeToRegex(p) {
  let r = '^';
  for (let i = 0; i < p.length; i++) {
    const c = p[i];
    if (c === '*') r += '[\\s\\S]*'; else if (c === '?') r += '[\\s\\S]'; else if (c === '#') r += '\\d';
    else if (c === '[') { let j = p.indexOf(']', i); if (j < 0) { r += '\\['; continue; } let cls = p.slice(i + 1, j); if (cls[0] === '!') cls = '^' + cls.slice(1); r += '[' + cls.replace(/\\/g, '\\\\') + ']'; i = j; }
    else r += c.replace(/[.+^${}()|\\\/]/g, '\\$&');
  }
  return new RegExp(r + '$');
}
function cmpValues(a, b, textCompare) {
  if (a === VBNull || b === VBNull) return null;
  if (a === undefined && typeof b === 'string') a = '';
  if (b === undefined && typeof a === 'string') b = '';
  if (typeof a === 'string' && typeof b === 'string') {
    if (textCompare) { a = a.toLowerCase(); b = b.toLowerCase(); }
    return a < b ? -1 : a > b ? 1 : 0;
  }
  if (typeof a === 'string' && !isNumericStr(a)) { b = toStr(b); return a < b ? -1 : a > b ? 1 : 0; }
  if (typeof b === 'string' && !isNumericStr(b)) { a = toStr(a); return a < b ? -1 : a > b ? 1 : 0; }
  const x = toNum(a), y = toNum(b);
  return x < y ? -1 : x > y ? 1 : 0;
}
function binop(op, a, b, textCompare) {
  switch (op) {
    case '&': return (a === VBNull ? '' : toStr(a)) + (b === VBNull ? '' : toStr(b));
    case '+':
      if (a === VBNull || b === VBNull) return VBNull;
      if (typeof a === 'string' && typeof b === 'string') return a + b;
      if (typeof a === 'string' && b === undefined) return a;
      if (typeof b === 'string' && a === undefined) return b;
      if (a instanceof VBDate || b instanceof VBDate) return VBDate.fromSerial(toNum(a) + toNum(b));
      return toNum(a) + toNum(b);
    case '-':
      if (a === VBNull || b === VBNull) return VBNull;
      if (a instanceof VBDate && !(b instanceof VBDate)) return VBDate.fromSerial(toNum(a) - toNum(b));
      return toNum(a) - toNum(b);
    case '*': if (a === VBNull || b === VBNull) return VBNull; return toNum(a) * toNum(b);
    case '/': { if (a === VBNull || b === VBNull) return VBNull; const y = toNum(b); if (y === 0) { if (toNum(a) === 0) throw vbErr(6); throw vbErr(11); } return toNum(a) / y; }
    case '\\': { if (a === VBNull || b === VBNull) return VBNull; const y = vbRound(toNum(b)); if (y === 0) throw vbErr(11); return Math.trunc(vbRound(toNum(a)) / y); }
    case 'mod': { if (a === VBNull || b === VBNull) return VBNull; const y = vbRound(toNum(b)); if (y === 0) throw vbErr(11); const x = vbRound(toNum(a)); return x % y; }
    case '^': return Math.pow(toNum(a), toNum(b));
    case '=': { const c = cmpValues(a, b, textCompare); return c === null ? VBNull : c === 0; }
    case '<>': { const c = cmpValues(a, b, textCompare); return c === null ? VBNull : c !== 0; }
    case '<': { const c = cmpValues(a, b, textCompare); return c === null ? VBNull : c < 0; }
    case '>': { const c = cmpValues(a, b, textCompare); return c === null ? VBNull : c > 0; }
    case '<=': { const c = cmpValues(a, b, textCompare); return c === null ? VBNull : c <= 0; }
    case '>=': { const c = cmpValues(a, b, textCompare); return c === null ? VBNull : c >= 0; }
    case 'and': case 'andalso':
      if (typeof a === 'boolean' && typeof b === 'boolean') return a && b;
      if (a === VBNull || b === VBNull) { if (a === false || b === false) return false; return VBNull; }
      return logicNum(a, b, (x, y) => x & y);
    case 'or': case 'orelse':
      if (typeof a === 'boolean' && typeof b === 'boolean') return a || b;
      if (a === VBNull || b === VBNull) { if (a === true || b === true) return true; return VBNull; }
      return logicNum(a, b, (x, y) => x | y);
    case 'xor': if (typeof a === 'boolean' && typeof b === 'boolean') return a !== b; return logicNum(a, b, (x, y) => x ^ y);
    case 'eqv': if (typeof a === 'boolean' && typeof b === 'boolean') return a === b; return logicNum(a, b, (x, y) => ~(x ^ y));
    case 'imp': if (typeof a === 'boolean' && typeof b === 'boolean') return !a || b; return logicNum(a, b, (x, y) => (~x) | y);
    case 'is': return a === b;
    case 'like': if (a === VBNull || b === VBNull) return VBNull; return likeToRegex(toStr(b)).test(toStr(a));
  }
  throw vbErr(5, 'Operador desconhecido ' + op);
}
function logicNum(a, b, f) {
  const x = toLong(a, -2147483648, 2147483647), y = toLong(b, -2147483648, 2147483647);
  return f(x, y) | 0;
}

// ---------- Format ----------
const MONTHS_PT = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
const WDAYS_PT = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
const MONTHS_EN = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const WDAYS_EN = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
let MONTHS = MONTHS_PT, WDAYS = WDAYS_PT, LOCALE = 'pt-BR';
function groupInt(s, sep) { return s.replace(/\B(?=(\d{3})+(?!\d))/g, sep); }
function fmtFixed(n, dec, group) {
  let s = Math.abs(n).toFixed(dec);
  let [ip, fp] = s.split('.');
  if (group) ip = groupInt(ip, THOUS_SEP);
  return (n < 0 && Number(s) !== 0 ? '-' : '') + ip + (fp ? DEC_SEP + fp : '');
}
function vbFormat(v, fmt) {
  if (v === VBNull) return '';
  if (fmt === undefined || fmt === VBMissing || fmt === '') return v === undefined ? '' : toStr(v);
  const f = String(fmt); const fl = f.toLowerCase();
  // nomeados
  const isDate = v instanceof VBDate;
  if (!isDate && ['general number', 'currency', 'fixed', 'standard', 'percent', 'scientific', 'yes/no', 'true/false', 'on/off'].includes(fl)) {
    const n = toNum(v);
    switch (fl) {
      case 'general number': return numToStr(n);
      case 'currency': return (n < 0 ? '-' : '') + curSym() + fmtFixed(Math.abs(n), 2, true);
      case 'fixed': return fmtFixed(n, 2, false);
      case 'standard': return fmtFixed(n, 2, true);
      case 'percent': return fmtFixed(n * 100, 2, false) + '%';
      case 'scientific': { const s = n.toExponential(2).toUpperCase().replace('.', DEC_SEP); return s.replace(/E([+\-])(\d)$/, 'E$10$2'); }
      case 'yes/no': return n ? (LOCALE === 'en-US' ? 'Yes' : 'Sim') : (LOCALE === 'en-US' ? 'No' : 'Não');
      case 'true/false': return n ? (LOCALE === 'en-US' ? 'True' : 'Verdadeiro') : (LOCALE === 'en-US' ? 'False' : 'Falso');
      case 'on/off': return n ? (LOCALE === 'en-US' ? 'On' : 'Ativado') : (LOCALE === 'en-US' ? 'Off' : 'Desativado');
    }
  }
  if (['general date', 'long date', 'medium date', 'short date', 'long time', 'medium time', 'short time'].includes(fl) || (isDate || /[dmyhns]/i.test(f) && !/[0#]/.test(f) && (typeof v !== 'string' || /\d[\/:\-]\d/.test(v)))) {
    let dt;
    try { dt = isDate ? v : (typeof v === 'number' ? VBDate.fromSerial(v) : parseDate(v)); } catch (e) { return toStr(v); }
    const d = dt.d;
    switch (fl) {
      case 'general date': return fmtDateDefault(dt);
      case 'long date': return LOCALE === 'en-US' ? `${WDAYS[d.getDay()]}, ${MONTHS[d.getMonth()]} ${pad2(d.getDate())}, ${d.getFullYear()}` : `${WDAYS[d.getDay()]}, ${d.getDate()} de ${MONTHS[d.getMonth()]} de ${d.getFullYear()}`;
      case 'medium date': return `${pad2(d.getDate())}-${MONTHS[d.getMonth()].slice(0, 3)}-${String(d.getFullYear()).slice(2)}`;
      case 'short date': return shortDate(d);
      case 'long time': return `${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
      case 'medium time': { const h = d.getHours() % 12 || 12; return `${pad2(h)}:${pad2(d.getMinutes())} ${d.getHours() < 12 ? 'AM' : 'PM'}`; }
      case 'short time': return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
    }
    return fmtDatePattern(d, f);
  }
  if (typeof v === 'string' && !isNumericStr(v)) {
    // formatos de texto: @ & < >
    let s = v;
    if (f.includes('>')) s = s.toUpperCase(); if (f.includes('<')) s = s.toLowerCase();
    const ph = (f.match(/[@&]/g) || []).length;
    if (!ph) return s;
    let out = '', si = 0; const pad = Math.max(0, ph - s.length); let padded = ' '.repeat(pad) + s;
    for (const c of f) { if (c === '@' || c === '&') { out += padded[si++] || ''; } else if (c !== '<' && c !== '>' && c !== '!') out += c; }
    return out;
  }
  // numérico com seções ; (positivo;negativo;zero)
  const n = v === undefined ? 0 : toNum(v);
  const sections = splitSections(f);
  let sec = sections[0], val = n;
  if (n < 0 && sections[1] !== undefined) { sec = sections[1]; val = -n; }
  else if (n === 0 && sections[2] !== undefined) sec = sections[2];
  return fmtNumPattern(val, sec);
}
function splitSections(f) { const out = []; let cur = '', q = false; for (const c of f) { if (c === '"') q = !q; if (c === ';' && !q) { out.push(cur); cur = ''; } else cur += c; } out.push(cur); return out; }
function fmtNumPattern(n, pat) {
  // separa literais
  let pre = '', post = '', core = '';
  const tokens = []; let q = false;
  for (let i = 0; i < pat.length; i++) {
    const c = pat[i];
    if (c === '"') { q = !q; continue; }
    if (q) { tokens.push({ lit: c }); continue; }
    if (c === '\\') { tokens.push({ lit: pat[++i] || '' }); continue; }
    if ('0#.,%eE+-'.includes(c) && !(c === '-' || c === '+') || ((c === '+' || c === '-') && /[eE]/.test(pat[i - 1] || ''))) tokens.push({ d: c }); else tokens.push({ lit: c });
  }
  let first = tokens.findIndex(t => t.d), last = -1; for (let i = tokens.length - 1; i >= 0; i--) if (tokens[i].d) { last = i; break; }
  if (first < 0) return tokens.map(t => t.lit).join('');
  pre = tokens.slice(0, first).map(t => t.lit !== undefined ? t.lit : t.d).join('');
  post = tokens.slice(last + 1).map(t => t.lit !== undefined ? t.lit : t.d).join('');
  core = tokens.slice(first, last + 1).map(t => t.d || t.lit).join('');
  const percent = (pre + core + post).includes('%');
  if (percent) n *= 100;
  const sci = /[eE][+\-]/.exec(core);
  if (sci) {
    const [mant, ex] = [core.slice(0, sci.index), core.slice(sci.index + 2)];
    const dec = (mant.split('.')[1] || '').length;
    let s = n.toExponential(dec); let [m, e] = s.split('e'); const ei = parseInt(e, 10);
    const es = String(Math.abs(ei)).padStart(ex.replace(/#/g, '').length, '0');
    return pre + m.replace('.', DEC_SEP) + core[sci.index] + (ei < 0 ? '-' : (sci[0][1] === '+' ? '+' : '')) + es + post;
  }
  const dot = core.indexOf('.');
  const ipat = dot >= 0 ? core.slice(0, dot) : core;
  const fpat = dot >= 0 ? core.slice(dot + 1) : '';
  const group = ipat.includes(',');
  const fdigits = fpat.replace(/[^0#]/g, '');
  const minF = (fdigits.match(/0/g) || []).length, maxF = fdigits.length;
  let s = Math.abs(n).toFixed(maxF);
  let [ip, fp = ''] = s.split('.');
  while (fp.length > minF && fp.endsWith('0')) fp = fp.slice(0, -1);
  const minI = (ipat.replace(/,/g, '').match(/0/g) || []).length;
  if (ip === '0' && minI === 0) ip = '';
  ip = ip.padStart(minI, '0');
  if (group) ip = groupInt(ip, THOUS_SEP);
  const neg = n < 0 && Number(s) !== 0;
  let out = ip + (dot >= 0 ? DEC_SEP + fp : '');
  return (neg ? '-' : '') + pre + out + post;
}
function fmtDatePattern(d, f) {
  let out = ''; let i = 0; const L = f.length; let lastWasHour = false;
  const peekRun = (ch) => { let j = i; while (j < L && f[j].toLowerCase() === ch) j++; return j - i; };
  while (i < L) {
    const c = f[i], lc = c.toLowerCase();
    if (c === '"') { const j = f.indexOf('"', i + 1); out += f.slice(i + 1, j < 0 ? L : j); i = j < 0 ? L : j + 1; continue; }
    if (c === '\\') { out += f[i + 1] || ''; i += 2; continue; }
    if (/^am\/pm/i.test(f.slice(i))) { out += d.getHours() < 12 ? 'AM' : 'PM'; i += 5; continue; }
    if (/^a\/p/i.test(f.slice(i))) { out += d.getHours() < 12 ? 'a' : 'p'; i += 3; continue; }
    if ('dmyhns'.includes(lc)) {
      const n = peekRun(lc);
      let piece = '';
      switch (lc) {
        case 'd': piece = n === 1 ? String(d.getDate()) : n === 2 ? pad2(d.getDate()) : n === 3 ? WDAYS[d.getDay()].slice(0, 3) : n === 4 ? WDAYS[d.getDay()] : fmtDatePattern(d, n === 5 ? 'dd/mm/yyyy' : 'Long Date'); break;
        case 'm':
          if (lastWasHour && n <= 2) piece = n === 1 ? String(d.getMinutes()) : pad2(d.getMinutes());
          else piece = n === 1 ? String(d.getMonth() + 1) : n === 2 ? pad2(d.getMonth() + 1) : n === 3 ? MONTHS[d.getMonth()].slice(0, 3) : MONTHS[d.getMonth()];
          break;
        case 'y': piece = n <= 2 ? String(d.getFullYear()).slice(2) : String(d.getFullYear()); break;
        case 'h': { const ampm = /am\/pm|a\/p/i.test(f); const h = ampm ? (d.getHours() % 12 || 12) : d.getHours(); piece = n === 1 ? String(h) : pad2(h); break; }
        case 'n': piece = n === 1 ? String(d.getMinutes()) : pad2(d.getMinutes()); break;
        case 's': piece = n === 1 ? String(d.getSeconds()) : pad2(d.getSeconds()); break;
      }
      lastWasHour = lc === 'h' || (lastWasHour && lc !== 'd' && lc !== 'y' && lc !== 's');
      if (lc === 'm' || lc === 's') lastWasHour = false;
      out += piece; i += n; continue;
    }
    out += c; i++;
  }
  return out;
}

if (typeof module !== 'undefined') module.exports = Object.assign(module.exports || {}, {
  VBError, vbErr, EndSignal, VBNull, VBMissing, VBDate, VBArray, VBRecord, VBObject, VBCollection, VBDictionary, ErrObject, SimpleObject,
  toNum, toStr, toBool, coerce, defaultValue, binop, vbFormat, vbRound, typeNameOf, varTypeOf, parseDate, isNumericStr, numToStr, setLocale, ERR_MSG, arrFrom, cloneValue, toLong, cmpValues, EPOCH, fmtFixed, likeToRegex, curSym,
});
