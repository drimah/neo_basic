// NeoBasic.exe — abre o NeoBasic em janela própria (modo aplicativo do Edge/Chrome/Brave),
// sem barra de endereço nem menus do navegador. Cria também o atalho no Menu Iniciar.
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define COBJMACROS
#include <windows.h>
#include <shlobj.h>
#include <shobjidl.h>
#include <objbase.h>
#include <wchar.h>
#include <stdio.h>

static int file_exists(const wchar_t *p) { DWORD a = GetFileAttributesW(p); return a != INVALID_FILE_ATTRIBUTES && !(a & FILE_ATTRIBUTE_DIRECTORY); }

static int app_path_from_registry(const wchar_t *exe, wchar_t *out, DWORD cap) {
    wchar_t key[300];
    swprintf(key, 300, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\%ls", exe);
    HKEY roots[2] = { HKEY_CURRENT_USER, HKEY_LOCAL_MACHINE };
    for (int i = 0; i < 2; i++) {
        DWORD sz = cap * sizeof(wchar_t);
        if (RegGetValueW(roots[i], key, NULL, RRF_RT_REG_SZ, NULL, out, &sz) == ERROR_SUCCESS && file_exists(out)) return 1;
    }
    return 0;
}

// navegadores conhecidos: nome, exe no registro, caminhos comuns
typedef struct { const wchar_t *name; const wchar_t *exe; const wchar_t *paths[3]; } BrowserDef;
static const BrowserDef BROWSERS[] = {
    { L"chrome",   L"chrome.exe",  { L"%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe", L"%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe", L"%LOCALAPPDATA%\\Google\\Chrome\\Application\\chrome.exe" } },
    { L"brave",    L"brave.exe",   { L"%ProgramFiles%\\BraveSoftware\\Brave-Browser\\Application\\brave.exe", L"%ProgramFiles(x86)%\\BraveSoftware\\Brave-Browser\\Application\\brave.exe", L"%LOCALAPPDATA%\\BraveSoftware\\Brave-Browser\\Application\\brave.exe" } },
    { L"vivaldi",  L"vivaldi.exe", { L"%LOCALAPPDATA%\\Vivaldi\\Application\\vivaldi.exe", L"%ProgramFiles%\\Vivaldi\\Application\\vivaldi.exe", NULL } },
    { L"chromium", NULL,           { L"%LOCALAPPDATA%\\Chromium\\Application\\chrome.exe", L"%ProgramFiles%\\Chromium\\Application\\chrome.exe", NULL } },
    { L"opera",    L"opera.exe",   { L"%LOCALAPPDATA%\\Programs\\Opera\\opera.exe", L"%ProgramFiles%\\Opera\\opera.exe", NULL } },
    { L"edge",     L"msedge.exe",  { L"%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe", L"%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe", NULL } },
};
#define NBROWSERS ((int)(sizeof(BROWSERS) / sizeof(BROWSERS[0])))

static int find_one(const BrowserDef *b, wchar_t *out, DWORD cap) {
    if (b->exe && app_path_from_registry(b->exe, out, cap)) return 1;
    for (int i = 0; i < 3 && b->paths[i]; i++) if (ExpandEnvironmentStringsW(b->paths[i], out, cap) && file_exists(out)) return 1;
    return 0;
}

// navegador.txt (ao lado do NeoBasic.exe): chrome, brave, vivaldi, chromium, opera, edge ou o caminho completo de um .exe
static int read_choice(const wchar_t *dir, wchar_t *choice, int cap) {
    wchar_t path[MAX_PATH]; swprintf(path, MAX_PATH, L"%ls\\navegador.txt", dir);
    FILE *f = _wfopen(path, L"rb"); if (!f) return 0;
    char buf[1024] = { 0 }; size_t n = fread(buf, 1, sizeof(buf) - 1, f); fclose(f); buf[n] = 0;
    char *p = buf; if ((unsigned char)p[0] == 0xEF && (unsigned char)p[1] == 0xBB && (unsigned char)p[2] == 0xBF) p += 3;
    while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n' || *p == '"') p++;
    char *e = p; while (*e && *e != '\r' && *e != '\n') e++;
    while (e > p && (e[-1] == ' ' || e[-1] == '\t' || e[-1] == '"')) e--;
    *e = 0; if (!*p) return 0;
    MultiByteToWideChar(CP_UTF8, 0, p, -1, choice, cap);
    return 1;
}

static int find_browser(const wchar_t *dir, wchar_t *out, DWORD cap) {
    wchar_t choice[512];
    if (read_choice(dir, choice, 512)) {
        if (wcschr(choice, L'\\') || wcschr(choice, L'/')) { ExpandEnvironmentStringsW(choice, out, cap); if (file_exists(out)) return 1; }
        for (int i = 0; i < NBROWSERS; i++) if (_wcsicmp(choice, BROWSERS[i].name) == 0 && find_one(&BROWSERS[i], out, cap)) return 1;
    }
    // sem escolha (ou não encontrado): Chrome, Brave, Vivaldi, Chromium, Opera e, por último, Edge
    for (int i = 0; i < NBROWSERS; i++) if (find_one(&BROWSERS[i], out, cap)) return 1;
    return 0;
}

// caminho do Windows -> file:///C:/... (UTF-8 com %XX), aceita acentos como em "MAÍRA"
static void path_to_url(const wchar_t *path, char *url, int cap) {
    char utf8[4096];
    WideCharToMultiByte(CP_UTF8, 0, path, -1, utf8, sizeof(utf8), NULL, NULL);
    int n = snprintf(url, cap, "file:///");
    for (unsigned char *p = (unsigned char *)utf8; *p && n < cap - 4; p++) {
        unsigned char c = *p;
        if (c == '\\') c = '/';
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || strchr("-._~/:", c)) url[n++] = (char)c;
        else n += snprintf(url + n, cap - n, "%%%02X", c);
    }
    url[n] = 0;
}

static void ensure_shortcut(const wchar_t *exePath, const wchar_t *workDir, const wchar_t *appname, const wchar_t *args) {
    wchar_t lnk[MAX_PATH];
    if (FAILED(SHGetFolderPathW(NULL, CSIDL_PROGRAMS, NULL, 0, lnk))) return;
    wcscat(lnk, L"\\"); wcscat(lnk, appname); wcscat(lnk, L".lnk");
    if (file_exists(lnk)) {
        // atualiza se o programa mudou de pasta
        IShellLinkW *sl0 = NULL;
        if (SUCCEEDED(CoCreateInstance(&CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, &IID_IShellLinkW, (void **)&sl0))) {
            IPersistFile *pf0 = NULL; wchar_t cur[MAX_PATH] = L"";
            if (SUCCEEDED(IShellLinkW_QueryInterface(sl0, &IID_IPersistFile, (void **)&pf0))) {
                if (SUCCEEDED(IPersistFile_Load(pf0, lnk, STGM_READ))) IShellLinkW_GetPath(sl0, cur, MAX_PATH, NULL, 0);
                IPersistFile_Release(pf0);
            }
            IShellLinkW_Release(sl0);
            wchar_t curArgs[MAX_PATH * 2] = L"";
            { IShellLinkW *sl1 = NULL; if (SUCCEEDED(CoCreateInstance(&CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, &IID_IShellLinkW, (void **)&sl1))) { IPersistFile *pf1 = NULL; if (SUCCEEDED(IShellLinkW_QueryInterface(sl1, &IID_IPersistFile, (void **)&pf1))) { if (SUCCEEDED(IPersistFile_Load(pf1, lnk, STGM_READ))) IShellLinkW_GetArguments(sl1, curArgs, MAX_PATH * 2); IPersistFile_Release(pf1); } IShellLinkW_Release(sl1); } }
            if (_wcsicmp(cur, exePath) == 0 && _wcsicmp(curArgs, args ? args : L"") == 0) return;
        }
    }
    IShellLinkW *sl = NULL;
    if (FAILED(CoCreateInstance(&CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, &IID_IShellLinkW, (void **)&sl))) return;
    IShellLinkW_SetPath(sl, exePath);
    if (args && *args) IShellLinkW_SetArguments(sl, args);
    IShellLinkW_SetWorkingDirectory(sl, workDir);
    IShellLinkW_SetDescription(sl, appname);
    IShellLinkW_SetIconLocation(sl, exePath, 0);
    IPersistFile *pf = NULL;
    if (SUCCEEDED(IShellLinkW_QueryInterface(sl, &IID_IPersistFile, (void **)&pf))) { IPersistFile_Save(pf, lnk, TRUE); IPersistFile_Release(pf); }
    IShellLinkW_Release(sl);
}

int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE hPrev, PWSTR cmd, int show) {
    (void)hInst; (void)hPrev; (void)cmd; (void)show;
    wchar_t exe[MAX_PATH], dir[MAX_PATH], html[MAX_PATH], browser[MAX_PATH], profile[MAX_PATH];
    GetModuleFileNameW(NULL, exe, MAX_PATH);
    wcscpy(dir, exe);
    wchar_t *slash = wcsrchr(dir, L'\\'); if (slash) *slash = 0;
    // o lançador abre o .html com o mesmo nome dele (NeoBasic.exe -> NeoBasic.html, Agenda.exe -> Agenda.html)
    wchar_t appname[MAX_PATH]; { const wchar_t *bn = wcsrchr(exe, L'\\'); wcscpy(appname, bn ? bn + 1 : exe); wchar_t *dt = wcsrchr(appname, L'.'); if (dt) *dt = 0; }
    swprintf(html, MAX_PATH, L"%ls\\%ls.html", dir, appname);
    // NeoBasic.exe Agenda.html (ou arrastar o .html para cima do NeoBasic.exe): abre esse programa e cria o atalho dele
    wchar_t appdir[MAX_PATH]; wcscpy(appdir, dir); wchar_t lnkArgs[MAX_PATH + 4] = L"";
    { int argc = 0; LPWSTR *argv = CommandLineToArgvW(GetCommandLineW(), &argc);
      if (argv && argc >= 2) {
        wchar_t full[MAX_PATH]; if (GetFullPathNameW(argv[1], MAX_PATH, full, NULL)) {
          const wchar_t *ext = wcsrchr(full, L'.');
          if (ext && (_wcsicmp(ext, L".html") == 0 || _wcsicmp(ext, L".htm") == 0) && file_exists(full)) {
            wcscpy(html, full); wcscpy(appdir, full); wchar_t *sl2 = wcsrchr(appdir, L'\\'); if (sl2) *sl2 = 0;
            const wchar_t *bn = wcsrchr(full, L'\\'); wcscpy(appname, bn ? bn + 1 : full); wchar_t *dt = wcsrchr(appname, L'.'); if (dt) *dt = 0;
            swprintf(lnkArgs, MAX_PATH + 4, L"\"%ls\"", full);
          } } }
      if (argv) LocalFree(argv); }
    if (!file_exists(html)) {
        wchar_t msg[1024]; swprintf(msg, 1024, L"Não encontrei o arquivo %ls.html.\n\nDeixe o %ls.exe na mesma pasta do %ls.html.", appname, appname, appname);
        MessageBoxW(NULL, msg, appname, MB_ICONERROR);
        return 1;
    }
    { wchar_t nav[MAX_PATH]; swprintf(nav, MAX_PATH, L"%ls\\navegador.txt", appdir); if (!file_exists(nav)) wcscpy(appdir, dir); }
    if (!find_browser(appdir, browser, MAX_PATH)) {
        MessageBoxW(NULL, L"O NeoBasic precisa de um navegador Chromium (Chrome, Brave, Vivaldi, Chromium, Opera ou Edge) e nenhum foi encontrado.\n\nInstale um deles e tente de novo.", L"NeoBasic", MB_ICONERROR);
        return 1;
    }
    // perfil próprio: o NeoBasic vira um aplicativo separado do seu navegador
    // um perfil para cada navegador (Chrome e Edge não podem dividir a mesma pasta de perfil)
    { wchar_t base[MAX_PATH], bname[64]; ExpandEnvironmentStringsW(L"%LOCALAPPDATA%\\NeoBasic\\Perfil", base, MAX_PATH);
      const wchar_t *bn = wcsrchr(browser, L'\\'); bn = bn ? bn + 1 : browser; wcsncpy(bname, bn, 63); bname[63] = 0;
      wchar_t *dot = wcsrchr(bname, L'.'); if (dot) *dot = 0;
      if (_wcsicmp(appname, L"NeoBasic") == 0) swprintf(profile, MAX_PATH, L"%ls-%ls", base, bname);
      else { ExpandEnvironmentStringsW(L"%LOCALAPPDATA%\\NeoBasic\\Apps", base, MAX_PATH); swprintf(profile, MAX_PATH, L"%ls\\%ls-%ls", base, appname, bname); } }
    SHCreateDirectoryExW(NULL, profile, NULL);

    CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
    ensure_shortcut(exe, dir, appname, lnkArgs);
    CoUninitialize();

    char url8[8192];
    path_to_url(html, url8, sizeof(url8));
    strcat(url8, "?app=1");
    wchar_t url[8192];
    MultiByteToWideChar(CP_UTF8, 0, url8, -1, url, 8192);

    wchar_t cmdline[16384];
    swprintf(cmdline, 16384,
        L"\"%ls\" --app=\"%ls\" --user-data-dir=\"%ls\" --start-maximized --no-first-run --no-default-browser-check "
        L"--lang=pt-BR --disable-features=Translate,msEdgeSidebarV2,msHubApps,msUndersideButton --disable-sync --hide-crash-restore-bubble",
        browser, url, profile);
    STARTUPINFOW si; PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si); ZeroMemory(&pi, sizeof(pi));
    if (!CreateProcessW(NULL, cmdline, NULL, NULL, FALSE, 0, NULL, dir, &si, &pi)) {
        MessageBoxW(NULL, L"Não foi possível abrir a janela do NeoBasic.", L"NeoBasic", MB_ICONERROR);
        return 1;
    }
    CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
    return 0;
}
