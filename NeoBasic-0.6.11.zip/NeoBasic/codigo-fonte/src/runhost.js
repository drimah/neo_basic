// ===== NeoBasic — hospedeiro de execução (janelas, diálogos, arquivos virtuais) =====
'use strict';

class RunHost {
  constructor(stage, opts) {
    this.stage = stage; this.opts = opts || {}; this.z = (opts && opts.zBase) || 10; this.forms = []; this.cascade = 0; this.downloads = new Set();
    this.appName = 'NeoBasic';
    stage.addEventListener('mousemove', e => { this.lastMouse = { x: e.clientX, y: e.clientY }; }, true);
    this.lastMouse = { x: 100, y: 100 };
    this.appPath = 'C:\\NeoBasic';
  }
  // ----- formulários -----
  createForm(def, rt) { const f = new VBForm(def, rt, this); return f; }
  mdiParent(f) { if (!f.P.mdichild) return null; return f.rt.loadedForms().find(x => x.isMDI) || null; }
  containerFor(f) { const m = this.mdiParent(f); return m ? (m.mdiArea || m.client) : this.stage; }
  stageSize(f) { const c = this.containerFor(f); return { w: c.clientWidth, h: c.clientHeight }; }
  screenW() { return this.stage.clientWidth; } screenH() { return this.stage.clientHeight; }
  async ensureMDI(f) {
    if (!f.P.mdichild) return;
    if (!this.mdiParent(f)) { const def = [...f.rt.forms.values()].find(d => d.data && /mdiform/i.test(d.data.frm.root.type)); if (def) { const m = await f.rt.getForm(def.name.toLowerCase()); if (m && !m.shown) await m.callMethod('show', [], f.rt); } }
  }
  showForm(f, modal, first) {
    const cont = this.containerFor(f);
    if (f.P.mdichild && !this.mdiParent(f)) { this.ensureMDI(f).then(() => { const c2 = this.containerFor(f); if (f.win.parentNode !== c2) c2.appendChild(f.win); this.positionFirst(f, c2); }); }
    if (modal) { f.shade = document.createElement('div'); f.shade.className = 'vb-shade'; f.shade.style.zIndex = ++this.z; this.stage.appendChild(f.shade); f.shade.addEventListener('mousedown', ev => { ev.preventDefault(); this.flash(f); }); }
    if (f.win.parentNode !== cont) cont.appendChild(f.win);
    f.win.style.display = '';
    if (first) this.positionFirst(f, cont);
    if (!this.forms.includes(f)) this.forms.push(f);
    this.bringToFront(f);
    this.formsChanged();
  }
  positionFirst(f, cont) {
    const P = f.P; const sp = Number(P.startupposition) || 0;
    const W = f.outerW(), H = f.outerH();
    if (P.windowstate === 2) { f.layout(); return; }
    if (sp === 1 || sp === 2) { P.left = Math.max(0, (cont.clientWidth - W) / 2) * 15; P.top = Math.max(0, (cont.clientHeight - H) / 2) * 15; }
    else if (sp === 3 || (f.P.mdichild)) { const n = this.cascade++ % 8; P.left = (12 + n * 24) * 15; P.top = (12 + n * 24) * 15; }
    else {
      // manual: posição do .frm; garante que fique visível
      const L = (P.left || 0) / 15, T = (P.top || 0) / 15;
      if (L + 40 > cont.clientWidth || T + 30 > cont.clientHeight || L < 0 || T < 0) { P.left = Math.max(0, Math.min(L, cont.clientWidth - W)) * 15; P.top = Math.max(0, Math.min(T, cont.clientHeight - H)) * 15; }
    }
    f.place();
  }
  flash(f) { f.win.classList.add('inactive'); setTimeout(() => f.win.classList.remove('inactive'), 80); setTimeout(() => f.win.classList.add('inactive'), 160); setTimeout(() => f.win.classList.remove('inactive'), 240); }
  hideForm(f) { f.win.style.display = 'none'; if (f.shade) { f.shade.remove(); f.shade = null; } this.formsChanged(); this.activateTop(); }
  removeForm(f) { if (f.win.parentNode) f.win.remove(); if (f.shade) { f.shade.remove(); f.shade = null; } this.forms = this.forms.filter(x => x !== f); this.formsChanged(); this.activateTop(); }
  activateTop() { const vis = this.forms.filter(x => x.shown && !x.dead); vis.sort((a, b) => (Number(b.win.style.zIndex) || 0) - (Number(a.win.style.zIndex) || 0)); if (vis[0]) this.bringToFront(vis[0], true); }
  bringToFront(f, quiet) {
    const modal = this.forms.filter(x => x.modal && x.shown && !x.dead).pop();
    if (modal && modal !== f && !quiet) { this.flash(modal); f = modal; }
    f.win.style.zIndex = ++this.z;
    if (f.shade) { f.shade.style.zIndex = f.win.style.zIndex - 1 + 0; f.win.style.zIndex = ++this.z; }
    const prev = this.active;
    let act = f;
    if (f.isMDI) { const kids = this.forms.filter(x => x.P.mdichild && x.shown && !x.dead).sort((a, b) => (Number(b.win.style.zIndex) || 0) - (Number(a.win.style.zIndex) || 0)); if (kids[0]) act = kids[0]; }
    for (const x of this.forms) x.win.classList.toggle('inactive', x !== f && x !== act && !(act.P.mdichild && x.isMDI));
    f = act;
    if (prev !== f) { this.active = f; const mdi = this.forms.find(x => x.isMDI && !x.dead); if (mdi && ((prev && prev.P.mdichild) || f.P.mdichild)) mdi.renderMenubar(); if (prev && !prev.dead && prev.rt && !quiet) prev.rt.fireEvent(prev, 'form', 'deactivate', []); if (!quiet && prev && f.everShown) f.rt.fireEvent(f, 'form', 'activate', []); }
  }
  isModalBlocked(f) { const modal = this.forms.filter(x => x.modal && x.shown && !x.dead).pop(); return !!(modal && modal !== f); }
  activeForm() { return this.active || null; }
  formsChanged() { if (this.opts.onFormsChanged) this.opts.onFormsChanged(this.forms); }
  clear() { for (const f of this.forms) if (f.win.parentNode) f.win.remove(); this.forms = []; this.stage.querySelectorAll('.vb-shade,.vb-dlg').forEach(e => e.remove()); this.closePopups(); this.cascade = 0; }

  // ----- menus -----
  closePopups() { document.querySelectorAll('.vb-popup,.vb-combo-pop').forEach(p => p.remove()); if (this._closer) { window.removeEventListener('mousedown', this._closer, true); this._closer = null; } }
  showMenu(items, x, y, form, anchor, level) {
    if (!level) this.closePopups();
    const pop = document.createElement('div'); pop.className = 'vb-popup nb-root skin-' + NB_SKIN; pop.dataset.level = level || 0;
    const vis = items.filter(m => m.P.visible !== false);
    if (!vis.length) return;
    for (const m of vis) {
      if ((m.P.caption || '') === '-') { const s = document.createElement('div'); s.className = 'vb-msep'; pop.appendChild(s); continue; }
      const it = document.createElement('div'); it.className = 'vb-mi' + (m.P.enabled === false ? ' dis' : '') + (m.items.some(s => s.P.visible !== false) ? ' sub' : '');
      it.innerHTML = `<span class="ck">${m.P.checked ? '✓' : ''}</span><span>${mnemonicHtml(m.P.caption || '')}</span><span class="sc">${shortcutText(m.P.shortcut)}</span>`;
      it.addEventListener('mouseenter', async () => {
        document.querySelectorAll('.vb-popup').forEach(p => { if (Number(p.dataset.level) > (level || 0)) p.remove(); });
        if (m.items.length && m.P.enabled !== false) { await m.fire(); const r = it.getBoundingClientRect(); this.showMenu(m.items, r.right - 3, r.top - 3, form, it, (level || 0) + 1); }
      });
      it.addEventListener('mouseup', async (ev) => {
        if (m.P.enabled === false || m.items.length) return;
        this.closePopups(); await m.fire();
      });
      pop.appendChild(it);
    }
    document.body.appendChild(pop);
    const r = pop.getBoundingClientRect();
    pop.style.left = Math.min(x, window.innerWidth - r.width - 2) + 'px'; pop.style.top = Math.min(y, window.innerHeight - r.height - 2) + 'px';
    if (!level) { setTimeout(() => { this._closer = (ev) => { if (!ev.target.closest('.vb-popup')) this.closePopups(); }; window.addEventListener('mousedown', this._closer, true); }, 0); }
  }
  showComboPopup(ctl, cb) {
    this.closePopups();
    const P = ctl.P; if (!P.list || !P.list.length) return;
    const pop = document.createElement('div'); pop.className = 'vb-combo-pop skin-' + NB_SKIN;
    const r = ctl.el.getBoundingClientRect();
    Object.assign(pop.style, { left: r.left + 'px', top: r.bottom + 'px', width: r.width + 'px' });
    applyFont(pop, P.font);
    P.list.forEach((t, i) => { const d = document.createElement('div'); d.textContent = t; if (i === P.listindex) d.className = 'sel'; d.addEventListener('mousedown', ev => { ev.preventDefault(); this.closePopups(); cb(i); }); pop.appendChild(d); });
    document.body.appendChild(pop);
    const pr = pop.getBoundingClientRect(); if (pr.bottom > window.innerHeight) pop.style.top = (r.top - pr.height) + 'px';
    setTimeout(() => { this._closer = (ev) => { if (!ev.target.closest('.vb-combo-pop')) this.closePopups(); }; window.addEventListener('mousedown', this._closer, true); }, 0);
  }

  // ----- diálogos -----
  dialog(title, build) {
    return new Promise(resolve => {
      const shade = document.createElement('div'); shade.className = 'vb-shade'; shade.style.zIndex = ++this.z;
      const w = document.createElement('div'); w.className = 'vb-window vb-dlg nb-root ' + (this.opts.dialogClass || ('skin-' + NB_SKIN)); w.style.zIndex = ++this.z;
      w.innerHTML = `<div class="vb-title"><span class="vb-tcap"></span><span class="vb-tbtns"><b class="tb-close"></b></span></div><div class="vb-client"></div>`;
      w.querySelector('.vb-tcap').textContent = title;
      const host = this.dialogParent();
      if (host === document.body) { shade.style.position = 'fixed'; w.style.position = 'fixed'; }
      host.appendChild(shade); host.appendChild(w);
      const done = (v) => { shade.remove(); w.remove(); resolve(v); };
      const focusEl = build(w.querySelector('.vb-client'), done);
      w.querySelector('.tb-close').addEventListener('click', () => done(w._cancelValue));
      // centraliza
      const r = w.getBoundingClientRect(); const hr = host === document.body ? { width: window.innerWidth, height: window.innerHeight } : host.getBoundingClientRect();
      w.style.left = Math.max(0, (hr.width - r.width) / 2) + 'px'; w.style.top = Math.max(0, (hr.height - r.height) / 2.4) + 'px';
      // arrastar
      const t = w.querySelector('.vb-title');
      t.addEventListener('mousedown', ev => { if (ev.target.closest('.vb-tbtns')) return; ev.preventDefault(); const sx = ev.clientX, sy = ev.clientY, l0 = parseFloat(w.style.left), t0 = parseFloat(w.style.top); const mv = e => { w.style.left = l0 + e.clientX - sx + 'px'; w.style.top = t0 + e.clientY - sy + 'px'; }; const up = () => { window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', up); }; window.addEventListener('mousemove', mv); window.addEventListener('mouseup', up); });
      shade.addEventListener('mousedown', ev => { ev.preventDefault(); this.flashEl(w); });
      setTimeout(() => focusEl && focusEl.focus(), 0);
    });
  }
  dialogParent() { return this.stage.isConnected && this.stage.offsetParent !== null ? this.stage : document.body; }
  flashEl(w) { w.classList.add('inactive'); setTimeout(() => w.classList.remove('inactive'), 90); setTimeout(() => w.classList.add('inactive'), 180); setTimeout(() => w.classList.remove('inactive'), 270); }
  msgBox(prompt, buttons, title) {
    const set = buttons & 7; const icon = buttons & 0x70; const defb = (buttons >> 8) & 3;
    const sets = { 0: [['OK', 1]], 1: [['OK', 1], ['Cancel', 2]], 2: [['&Abort', 3], ['&Retry', 4], ['&Ignore', 5]], 3: [['&Yes', 6], ['&No', 7], ['Cancel', 2]], 4: [['&Yes', 6], ['&No', 7]], 5: [['&Retry', 4], ['Cancel', 2]] };
    const bl = sets[set] || sets[0];
    const cancelVal = set === 0 ? 1 : set === 4 || set === 2 ? null : 2;
    if (this.opts.beforeDialog) this.opts.beforeDialog();
    return this.dialog(title || this.appName, (c, done) => {
      c.parentNode._cancelValue = cancelVal === null ? undefined : cancelVal;
      c.innerHTML = `<div class="msg">${icon ? `<span class="vb-micon i${icon}"></span>` : ''}<div class="txt"></div></div><div class="btns"></div>`;
      c.querySelector('.txt').textContent = prompt;
      const bw = c.querySelector('.btns'); let first = null;
      bl.forEach(([lab, val], i) => { const b = document.createElement('button'); b.innerHTML = mnemonicHtml(lab); if (i === defb) { b.className = 'def'; first = b; } b.addEventListener('click', () => done(val)); bw.appendChild(b); });
      if (!first) first = bw.firstChild;
      c.parentNode.addEventListener('keydown', ev => {
        if (ev.key === 'Escape' && cancelVal !== null) { ev.preventDefault(); done(cancelVal); }
        const k = ev.key.toLowerCase(); const hit = bl.find(([lab]) => { const m = /&(.)/.exec(lab); return m && m[1].toLowerCase() === k; }); if (hit) { ev.preventDefault(); done(hit[1]); }
        if (ev.key === 'ArrowRight' || ev.key === 'ArrowLeft') { const bs = [...bw.children]; const i = bs.indexOf(document.activeElement); const n = bs[(i + (ev.key === 'ArrowRight' ? 1 : bs.length - 1)) % bs.length]; n && n.focus(); }
      });
      if (this.opts.beep && icon) this.beep();
      return first;
    }).then(v => v === undefined ? (cancelVal || 1) : v);
  }
  inputBox(prompt, title, def) {
    if (this.opts.beforeDialog) this.opts.beforeDialog();
    return this.dialog(title || this.appName, (c, done) => {
      c.parentNode._cancelValue = '';
      c.innerHTML = `<div class="ibwrap"><div class="txt" style="white-space:pre-wrap;min-height:46px"></div><div class="btns"><button class="def">OK</button><button>Cancel</button></div></div><input class="ib">`;
      c.querySelector('.txt').textContent = prompt;
      const inp = c.querySelector('input'); inp.value = def || '';
      const [ok, cancel] = c.querySelectorAll('button');
      ok.addEventListener('click', () => done(inp.value)); cancel.addEventListener('click', () => done(''));
      inp.addEventListener('keydown', ev => { if (ev.key === 'Enter') done(inp.value); if (ev.key === 'Escape') done(''); });
      setTimeout(() => inp.select(), 0);
      return inp;
    });
  }
  pickColor(def) {
    return new Promise(res => { const i = document.createElement('input'); i.type = 'color'; i.value = def || '#000000'; let done = false; i.addEventListener('change', () => { done = true; res(i.value); }); i.addEventListener('cancel', () => { if (!done) res(null); }); i.click(); setTimeout(() => { }, 0); });
  }
  pickFileToVFS(filter) {
    return new Promise(res => {
      const i = document.createElement('input'); i.type = 'file';
      const exts = []; const parts = String(filter || '').split('|'); for (let k = 1; k < parts.length; k += 2) for (const p of parts[k].split(';')) { const m = /\*(\.\w+)$/.exec(p.trim()); if (m) exts.push(m[1]); }
      if (exts.length) i.accept = exts.join(',');
      let done = false;
      i.addEventListener('change', async () => {
        done = true; const f = i.files[0]; if (!f) return res(null);
        const buf = new Uint8Array(await f.arrayBuffer());
        let txt; try { txt = new TextDecoder('utf-8', { fatal: true }).decode(buf); } catch (e) { txt = decode1252(buf); }
        const path = 'C:\\NeoBasic\\' + f.name; this.vfsWrite(path.toLowerCase(), txt); res({ path, name: f.name });
      });
      i.addEventListener('cancel', () => { if (!done) res(null); });
      i.click();
    });
  }
  markDownload(path) { this.downloads.add(path.toLowerCase()); }
  // ----- arquivos virtuais (localStorage) -----
  vfsKey(p) { return 'neobasic.vfs:' + p.toLowerCase(); }
  vfsRead(p) { try { const v = localStorage.getItem(this.vfsKey(this.absPath(p))); return v; } catch (e) { return this._mem && this._mem[p]; } }
  vfsWrite(p, s) {
    p = this.absPath(p);
    try { localStorage.setItem(this.vfsKey(p), s); } catch (e) { (this._mem || (this._mem = {}))[p] = s; }
    if (this.downloads.has(p.toLowerCase())) { this.downloads.delete(p.toLowerCase()); downloadBlob(new Blob([encode1252(s)]), p.split('\\').pop()); }
  }
  vfsDelete(p) { try { localStorage.removeItem(this.vfsKey(this.absPath(p))); } catch (e) { } }
  vfsList() { const out = []; try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k.startsWith('neobasic.vfs:')) out.push(k.slice(13)); } } catch (e) { } return out; }
  absPath(p) { p = String(p).replace(/\//g, '\\'); if (!/^[a-z]:\\/i.test(p) && !p.startsWith('\\\\')) p = this.appPath + '\\' + p.replace(/^\.?\\/, ''); return p.toLowerCase(); }
  // ----- registro (GetSetting/SaveSetting) -----
  regKey(a, s, k) { return `neobasic.reg:${a}\\${s}\\${k}`.toLowerCase(); }
  getSetting(a, s, k) { try { return localStorage.getItem(this.regKey(a, s, k)); } catch (e) { return null; } }
  saveSetting(a, s, k, v) { try { localStorage.setItem(this.regKey(a, s, k), v); } catch (e) { } }
  deleteSetting(a, s, k) { try { const pre = `neobasic.reg:${a}\\${s ? s + '\\' + (k || '') : ''}`.toLowerCase(); for (let i = localStorage.length - 1; i >= 0; i--) { const kk = localStorage.key(i); if (kk.startsWith(pre)) localStorage.removeItem(kk); } } catch (e) { } }
  beep() { try { const C = window.AudioContext || window.webkitAudioContext; const ac = this._ac || (this._ac = new C()); const o = ac.createOscillator(), g = ac.createGain(); o.frequency.value = 800; g.gain.value = 0.08; o.connect(g); g.connect(ac.destination); o.start(); o.stop(ac.currentTime + 0.12); } catch (e) { } }
  printerPrint(s) { this.printBuf = (this.printBuf || '') + s; }
  printerEnd() { const t = this.printBuf || ''; this.printBuf = ''; const w = window.open('', '_blank'); if (!w) return; w.document.write('<pre style="font:12pt Arial">' + t.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/\f/g, '<div style="page-break-after:always"></div>') + '</pre>'); w.document.close(); w.print(); }
  debugPrint(s) { if (this.opts.debugPrint) this.opts.debugPrint(s); else console.log(s); }
  onEnd() { this.closePopups(); if (this.opts.onEnd) this.opts.onEnd(); }
  onError(e) { if (this.opts.onError) this.opts.onError(e); else this.msgBox(`Run-time error '${e.number}':\n\n${e.description || e.message}`, 16, this.appName); }
}
function shortcutText(s) { if (!s) return ''; const m = /^([\^+%]*)(.*)$/.exec(String(s)); const key = { INSERT: 'Ins', DEL: 'Del', BKSP: 'Bksp' }[m[2].replace(/[{}]/g, '').toUpperCase()] || m[2].replace(/[{}]/g, ''); return (m[1].includes('+') ? 'Shift+' : '') + (m[1].includes('^') ? 'Ctrl+' : '') + (m[1].includes('%') ? 'Alt+' : '') + key; }
function downloadBlob(blob, name) { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500); }

// Constrói a descrição de projeto para o runtime a partir de arquivos texto
function buildRuntimeProject(proj) {
  // proj: { name, title, startup, modules: [{kind, name, code, frm, frxLookup, defaultMember}] }
  return {
    name: proj.name, title: proj.title, startup: proj.startup,
    modules: proj.modules.map(m => ({ name: m.name, kind: m.kind, source: m.kind === 'form' ? m.frm.code : m.code, formData: m.kind === 'form' ? { frm: m.frm, frxLookup: m.frxLookup } : null, defaultMember: m.defaultMember })),
  };
}
