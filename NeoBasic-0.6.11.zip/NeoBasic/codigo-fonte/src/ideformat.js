// ===== NeoBasic — Editor de menus, pincel de formatação, alinhamento e novo projeto =====

// ---------- Editor de menus (estilo WordPress: itens, subitens e o que cada um faz) ----------
const MENU_SHORTCUTS = (() => {
  const o = [['', '(None)']];
  for (let c = 65; c <= 90; c++) o.push(['^' + String.fromCharCode(c), 'Ctrl+' + String.fromCharCode(c)]);
  for (let i = 1; i <= 12; i++) o.push([`{F${i}}`, `F${i}`]);
  for (let i = 1; i <= 12; i++) o.push([`^{F${i}}`, `Ctrl+F${i}`]);
  for (let i = 1; i <= 12; i++) o.push([`+{F${i}}`, `Shift+F${i}`]);
  for (let i = 1; i <= 12; i++) o.push([`+^{F${i}}`, `Shift+Ctrl+F${i}`]);
  o.push(['^{INSERT}', 'Ctrl+Ins'], ['+{INSERT}', 'Shift+Ins'], ['{DEL}', 'Del'], ['+{DEL}', 'Shift+Del'], ['%{BKSP}', 'Alt+Bksp']);
  return o;
})();
const MENU_ACTIONS = [
  ['none', 'Nothing'],
  ['open', 'Open a form'],
  ['modal', 'Open a form and wait until it closes'],
  ['close', 'Close this form'],
  ['end', 'End the program'],
  ['msg', 'Show a message'],
  ['custom', 'Run my own code (opens the code window)'],
];
// procura "Sub <nome>(" ... "End Sub" no código (linhas com \n)
function findSubLines(lines, procName) {
  const re = new RegExp('^\\s*(?:(?:Public|Private|Friend|Static)\\s+)*Sub\\s+' + procName + '\\s*\\(', 'i');
  const s = lines.findIndex(l => re.test(l)); if (s < 0) return null;
  let e = s + 1; while (e < lines.length && !/^\s*End\s+Sub\b/i.test(lines[e])) e++;
  if (e >= lines.length) return null;
  return { s, e };
}
// reconhece o que o código do Click faz (só os casos simples que o editor sabe escrever)
function detectMenuAction(lines, name, formNames) {
  const r = findSubLines(lines, name + '_Click'); if (!r) return { kind: 'none', exists: false };
  const body = lines.slice(r.s + 1, r.e).map(l => l.trim()).filter(l => l && !l.startsWith("'") && !/^Rem\b/i.test(l));
  if (!body.length) return { kind: 'none', exists: true };
  if (body.length === 1) {
    const l = body[0]; let m;
    if ((m = /^(\w+)\.Show(?:\s+(vbModal|1)\b.*)?$/i.exec(l)) && formNames.some(f => f.toLowerCase() === m[1].toLowerCase())) return { kind: m[2] ? 'modal' : 'open', form: formNames.find(f => f.toLowerCase() === m[1].toLowerCase()), exists: true };
    if (/^Unload\s+Me$/i.test(l)) return { kind: 'close', exists: true };
    if (/^End$/i.test(l)) return { kind: 'end', exists: true };
    if ((m = /^MsgBox\s+"((?:[^"]|"")*)"$/i.exec(l))) return { kind: 'msg', msg: m[1].replace(/""/g, '"'), exists: true };
  }
  return { kind: 'custom', exists: true };
}
function menuActionCode(a) {
  if (a.kind === 'open') return [`    ${a.form}.Show`];
  if (a.kind === 'modal') return [`    ${a.form}.Show vbModal`];
  if (a.kind === 'close') return ['    Unload Me'];
  if (a.kind === 'end') return ['    End'];
  if (a.kind === 'msg') return [`    MsgBox "${String(a.msg || '').replace(/"/g, '""')}"`];
  return ['    '];
}
function menuActionLabel(it) {
  if (isMenuSep(it)) return '';
  if (it.hasKids) return 'opens sub-items';
  const a = it.action;
  if (a.kind === 'open') return a.form ? '→ ' + a.form : '→ (choose a form)';
  if (a.kind === 'modal') return a.form ? '→ ' + a.form + ' (wait)' : '→ (choose a form)';
  if (a.kind === 'close') return 'closes this form';
  if (a.kind === 'end') return 'ends the program';
  if (a.kind === 'msg') return 'shows a message';
  if (a.kind === 'custom') return 'your code';
  return '';
}
const isMenuSep = it => (it.caption || '').trim() === '-';
function menuAutoName(cap, used) {
  const plain = stripMnemonic(cap || '').normalize('NFD').replace(/[̀-ͯ]/g, '');
  let base;
  if (plain.trim() === '-') base = 'mnuSep';
  else { const w = plain.split(/[^A-Za-z0-9]+/).filter(Boolean); base = 'mnu' + w.map(x => x[0].toUpperCase() + x.slice(1)).join(''); if (base === 'mnu') base = 'mnuItem'; }
  base = base.slice(0, 40);
  if (base !== 'mnuSep' && !used.has(base.toLowerCase())) return base;
  let i = 1; while (used.has((base + i).toLowerCase())) i++; return base + i;
}
function menuEditorDialog(m) {
  syncEditors();
  const root = m.frm.root;
  const formNames = IDE.project.modules.filter(x => x.kind === 'form').map(x => x.name);
  const otherForms = formNames.filter(f => f.toLowerCase() !== m.name.toLowerCase());
  const lines0 = (getCode(m) || '').replace(/\r\n/g, '\n').split('\n');
  // lista plana (ordem do menu) com o nível de cada item
  const items = [];
  const walk = (n, lvl) => { for (const c of n.children) if (/\.menu$/i.test(c.type)) {
    const P = nodeProps(c);
    const act = detectMenuAction(lines0, c.name, formNames);
    items.push({ node: c, oldName: c.name, lvl, caption: P.caption || '', name: c.name, index: c.get('Index'), shortcut: c.getRaw('Shortcut') || '', checked: !!P.checked, enabled: P.enabled !== false, visible: P.visible !== false, action: { kind: act.kind, form: act.form || '', msg: act.msg || '' }, orig: JSON.stringify({ kind: act.kind, form: act.form || '', msg: act.msg || '' }), origKind: act.kind, nameTouched: true });
    walk(c, lvl + 1);
  } };
  walk(root, 0);
  const oldList = items.map(it => ({ node: it.node, name: it.name }));
  let cur = items.length ? 0 : -1;
  const ctlNames = new Set(allNodes(m).filter(n => !/\.menu$/i.test(n.type)).map(n => n.name.toLowerCase())); ctlNames.add(m.name.toLowerCase());
  const usedNames = (except) => { const s = new Set(ctlNames); items.forEach(it => { if (it !== except) s.add(it.name.toLowerCase()); }); return s; };
  const blockEnd = i => { let j = i + 1; while (j < items.length && items[j].lvl > items[i].lvl) j++; return j; };
  const fixKids = () => items.forEach((it, i) => { it.hasKids = i + 1 < items.length && items[i + 1].lvl > it.lvl; });
  let customToOpen = null;

  return ideDialog('Menu Editor', (c, done) => {
    c.parentNode.classList.add('me-dlg');
    c.innerHTML = `<div class="me-wrap">
      <div class="me-left">
        <div class="me-tools">
          <button class="nb-btn me-add" title="Add a menu item">+ Item</button>
          <button class="nb-btn me-sub" title="Add a sub-item inside the selected item">+ Sub-item</button>
          <button class="nb-btn me-sep" title="Add a separator line">+ Separator</button>
          <span class="me-gap"></span>
          <button class="me-ib me-up" title="Move up">${MI.up}</button><button class="me-ib me-dn" title="Move down">${MI.down}</button><button class="me-ib me-out" title="Move left (out of the sub-menu)">${MI.left}</button><button class="me-ib me-in" title="Move right (into the item above, as a sub-item)">${MI.right}</button><button class="me-ib me-del" title="Delete the item (and its sub-items)">${MI.del}</button>
        </div>
        <div class="me-list" tabindex="0"></div>
        <div class="me-hint"><b>+ Item</b> adds next to the selected item, <b>+ Sub-item</b> adds inside it. Drag an item to change the order; drag it to the right to make it a sub-item.</div>
      </div>
      <div class="me-right"></div>
    </div>
    <div class="btns"><button class="nb-btn">OK</button><button class="nb-btn">Cancel</button></div>`;
    const list = $('.me-list', c), det = $('.me-right', c);
    const INDENT = 24;

    const renderList = () => {
      fixKids();
      list.innerHTML = '';
      if (!items.length) { list.appendChild(h('div', { class: 'me-empty' }, 'No menu items yet. Click "+ Item" to create the first menu (for example File).')); }
      items.forEach((it, i) => {
        const sep = isMenuSep(it);
        const row = h('div', { class: 'me-row' + (i === cur ? ' on' : '') + (sep ? ' sep' : '') + (it.lvl === 0 ? ' top' : ''), style: `margin-left:${it.lvl * INDENT}px` });
        row.innerHTML = `<span class="grip">${MI.grip}</span><span class="cap"></span><span class="act"></span>`;
        $('.cap', row).innerHTML = sep ? '<span class="sepline"></span>' : (it.caption ? mnemonicHtml(it.caption) : '<i>(no text)</i>');
        $('.act', row).textContent = menuActionLabel(it) + (it.visible ? '' : ' · hidden');
        row.dataset.i = i;
        row.addEventListener('mousedown', ev => startDrag(ev, i));
        list.appendChild(row);
      });
      refreshTools();
    };
    const refreshTools = () => {
      const has = cur >= 0 && cur < items.length;
      $('.me-sub', c).disabled = !has; $('.me-del', c).disabled = !has;
      $('.me-up', c).disabled = !has || prevSibling(cur) < 0; $('.me-dn', c).disabled = !has || nextSibling(cur) < 0;
      $('.me-out', c).disabled = !has || items[cur].lvl === 0; $('.me-in', c).disabled = !has || prevSibling(cur) < 0;
    };
    const prevSibling = i => { const L = items[i].lvl; for (let j = i - 1; j >= 0; j--) { if (items[j].lvl < L) return -1; if (items[j].lvl === L) return j; } return -1; };
    const nextSibling = i => { const L = items[i].lvl; const j = blockEnd(i); return j < items.length && items[j].lvl === L ? j : -1; };

    // ----- painel da direita: detalhes do item escolhido -----
    const renderDetails = () => {
      det.innerHTML = '';
      if (cur < 0 || cur >= items.length) { det.appendChild(h('div', { class: 'me-none' }, 'Choose an item on the left, or create one with "+ Item".')); return; }
      const it = items[cur]; const sep = isMenuSep(it);
      det.innerHTML = `
        <div class="me-f ${sep ? 'hide' : ''}"><label>Text shown</label><input type="text" class="f-cap" spellcheck="false"><small>Put &amp; before a letter to open it with Alt+letter (&amp;File → Alt+F)</small></div>
        <div class="me-f ${sep ? '' : 'hide'}"><label>Separator</label><div class="me-note">A line that separates groups of items.</div></div>
        <div class="me-f fa ${sep ? 'hide' : ''}"><label>When clicked</label><select class="f-act">${MENU_ACTIONS.map(([k, t]) => `<option value="${k}">${esc(t)}</option>`).join('')}</select>
          <div class="me-sub2 f-formrow"><select class="f-form"></select></div>
          <div class="me-sub2 f-msgrow"><input type="text" class="f-msg" placeholder="Message text" spellcheck="false"></div>
          <div class="me-note f-kidsnote">This item has sub-items: clicking it opens them.</div>
          <div class="me-note f-customnote">After OK, the code window opens at <b class="f-subname"></b> so you can write what it does.</div>
        </div>
        <div class="me-f ${sep ? 'hide' : ''}"><label>Shortcut key</label><select class="f-sc">${MENU_SHORTCUTS.map(([k, t]) => `<option value="${esc(k)}">${esc(t)}</option>`).join('')}</select></div>
        <div class="me-f me-checks ${sep ? 'hide' : ''}"><label class="ck"><input type="checkbox" class="f-chk"> Checked ✓</label><label class="ck"><input type="checkbox" class="f-en"> Enabled</label><label class="ck"><input type="checkbox" class="f-vis"> Visible</label></div>
        <div class="me-f me-adv"><label>Name in code</label><div class="me-namerow"><input type="text" class="f-name" spellcheck="false"><span>Index</span><input type="text" class="f-idx" spellcheck="false" placeholder="—" title="Only for menu arrays (Index of a control array). Leave empty."></div></div>`;
      const fc = $('.f-cap', det), fa = $('.f-act', det), ff = $('.f-form', det), fm = $('.f-msg', det), fs = $('.f-sc', det), fk = $('.f-chk', det), fe = $('.f-en', det), fv = $('.f-vis', det), fn = $('.f-name', det), fi = $('.f-idx', det);
      ff.innerHTML = otherForms.length ? otherForms.map(f => `<option>${esc(f)}</option>`).join('') : '<option value="">(the project has no other form)</option>';
      fc.value = it.caption; fa.value = it.action.kind; fm.value = it.action.msg || ''; fs.value = it.shortcut; if (fs.value !== it.shortcut) { fs.appendChild(h('option', { value: it.shortcut }, it.shortcut)); fs.value = it.shortcut; }
      if (it.action.form) ff.value = it.action.form; else if (otherForms.length) ff.value = otherForms[0];
      fk.checked = it.checked; fe.checked = it.enabled; fv.checked = it.visible; fn.value = it.name; fi.value = it.index === undefined || it.index === null ? '' : String(it.index);
      const showAct = () => {
        const k = it.action.kind;
        $('.f-act', det).style.display = it.hasKids ? 'none' : '';
        $('.f-formrow', det).style.display = !it.hasKids && (k === 'open' || k === 'modal') ? '' : 'none';
        $('.f-msgrow', det).style.display = !it.hasKids && k === 'msg' ? '' : 'none';
        $('.f-kidsnote', det).style.display = it.hasKids ? '' : 'none';
        $('.f-customnote', det).style.display = !it.hasKids && k === 'custom' ? '' : 'none';
        $('.f-subname', det).textContent = it.name + '_Click';
      };
      showAct();
      const rowUpd = () => { const row = list.children[cur]; if (!row || !row.classList.contains('me-row')) return; $('.cap', row).innerHTML = isMenuSep(it) ? '<span class="sepline"></span>' : (it.caption ? mnemonicHtml(it.caption) : '<i>(no text)</i>'); $('.act', row).textContent = menuActionLabel(it) + (it.visible ? '' : ' · hidden'); };
      fc.addEventListener('input', () => { it.caption = fc.value; if (!it.nameTouched) { it.name = menuAutoName(it.caption, usedNames(it)); fn.value = it.name; } if (isMenuSep(it) !== $('.f-cap', det).closest('.me-f').classList.contains('hide')) { renderList(); renderDetails(); $('.f-cap', det) && $('.f-cap', det).focus(); return; } rowUpd(); showAct(); });
      fa.addEventListener('change', () => { it.action.kind = fa.value; if ((fa.value === 'open' || fa.value === 'modal') && !it.action.form) it.action.form = ff.value; showAct(); rowUpd(); });
      ff.addEventListener('change', () => { it.action.form = ff.value; rowUpd(); });
      fm.addEventListener('input', () => { it.action.msg = fm.value; });
      fs.addEventListener('change', () => { it.shortcut = fs.value; });
      fk.addEventListener('change', () => { it.checked = fk.checked; });
      fe.addEventListener('change', () => { it.enabled = fe.checked; });
      fv.addEventListener('change', () => { it.visible = fv.checked; rowUpd(); });
      fn.addEventListener('input', () => { it.name = fn.value.trim(); it.nameTouched = true; showAct(); });
      fi.addEventListener('input', () => { const v = fi.value.trim(); it.index = v === '' ? undefined : (/^\d+$/.test(v) ? Number(v) : v); });
    };
    const select = (i, focusCap) => { cur = i; renderList(); renderDetails(); if (focusCap) { const f = $('.f-cap', det); if (f && !f.closest('.hide')) { f.focus(); f.select(); } } const row = list.children[cur]; if (row && row.scrollIntoView) row.scrollIntoView({ block: 'nearest' }); };

    // ----- criar / mover / apagar -----
    const newItem = (lvl, caption) => { const it = { node: null, oldName: null, lvl, caption, name: '', index: undefined, shortcut: '', checked: false, enabled: true, visible: true, action: { kind: 'none', form: '', msg: '' }, orig: null, origKind: 'none', nameTouched: false }; it.name = menuAutoName(caption, usedNames(it)); return it; };
    const insertAt = (pos, it) => { items.splice(pos, 0, it); select(pos, true); };
    $('.me-add', c).onclick = () => {
      if (cur < 0) { insertAt(items.length, newItem(0, items.length ? 'New item' : '&File')); return; }
      const it = items[cur]; insertAt(blockEnd(cur), newItem(it.lvl, 'New item'));
    };
    $('.me-sub', c).onclick = () => { if (cur < 0) return; insertAt(blockEnd(cur), newItem(items[cur].lvl + 1, 'New sub-item')); };
    $('.me-sep', c).onclick = () => {
      if (cur < 0) return IDE.ui.msgBox('Create a menu first (for example File), then add the separator inside it.', 64, 'Menu Editor');
      const it = items[cur];
      if (it.lvl === 0) insertAt(blockEnd(cur), newItem(1, '-')); else insertAt(blockEnd(cur), newItem(it.lvl, '-'));
    };
    const moveBlock = (from, to, newLvl) => {
      // move o item "from" com os subitens para a posição "to" (índice na lista sem o bloco) e o nível newLvl
      const end = blockEnd(from); const blk = items.splice(from, end - from); const d = newLvl - blk[0].lvl;
      blk.forEach(x => x.lvl += d); items.splice(to, 0, ...blk); cur = to; renderList(); renderDetails();
    };
    $('.me-up', c).onclick = () => { const p = prevSibling(cur); if (p >= 0) moveBlock(cur, p, items[cur].lvl); };
    $('.me-dn', c).onclick = () => { const n = nextSibling(cur); if (n < 0) return; const nEnd = blockEnd(n); const size = blockEnd(cur) - cur; moveBlock(cur, nEnd - size, items[cur].lvl); };
    $('.me-out', c).onclick = () => { if (cur < 0 || !items[cur].lvl) return; const end = blockEnd(cur); for (let j = cur; j < end; j++) items[j].lvl--; renderList(); renderDetails(); };
    $('.me-in', c).onclick = () => { if (cur < 0 || prevSibling(cur) < 0) return; const end = blockEnd(cur); for (let j = cur; j < end; j++) items[j].lvl++; renderList(); renderDetails(); };
    const delCur = async () => {
      if (cur < 0) return; const end = blockEnd(cur); const n = end - cur;
      if (n > 1 && (await IDE.ui.msgBox(`Delete "${stripMnemonic(items[cur].caption)}" and its ${n - 1} sub-item(s)?`, 4 + 32, 'Menu Editor')) !== 6) return;
      items.splice(cur, n); select(Math.min(cur, items.length - 1));
    };
    $('.me-del', c).onclick = delCur;
    list.addEventListener('keydown', ev => {
      if (ev.target !== list) return;
      if (ev.key === 'ArrowDown') { ev.preventDefault(); if (cur < items.length - 1) select(cur + 1); }
      else if (ev.key === 'ArrowUp') { ev.preventDefault(); if (cur > 0) select(cur - 1); }
      else if (ev.key === 'Delete') { ev.preventDefault(); delCur(); }
    });

    // ----- arrastar (como no WordPress): para cima/baixo muda a ordem, para a direita vira subitem -----
    const startDrag = (ev, i) => {
      if (ev.button !== 0) return;
      ev.preventDefault(); list.focus();
      if (cur !== i) { cur = i; renderList(); renderDetails(); }
      const x0 = ev.clientX, y0 = ev.clientY; let on = false, target = null;
      const end = blockEnd(i); const blk = items.slice(i, end); const baseLvl = items[i].lvl; const lastRel = blk[blk.length - 1].lvl - baseLvl;
      const line = h('div', { class: 'me-drop' });
      const rows = () => [...list.querySelectorAll('.me-row')];
      const mv = e => {
        if (!on && Math.abs(e.clientX - x0) + Math.abs(e.clientY - y0) < 5) return;
        if (!on) { on = true; rows().slice(i, end).forEach(r => r.classList.add('dragging')); list.appendChild(line); }
        const rest = items.filter((_, k) => k < i || k >= end);
        const restRows = rows().filter((_, k) => k < i || k >= end);
        let pos = rest.length;
        for (let k = 0; k < restRows.length; k++) { const r = restRows[k].getBoundingClientRect(); if (e.clientY < r.top + r.height / 2) { pos = k; break; } }
        const prev = rest[pos - 1], next = rest[pos];
        const maxL = prev ? prev.lvl + 1 : 0; const minL = next ? Math.max(0, next.lvl - 1 - lastRel) : 0;
        let lvl = baseLvl + Math.round((e.clientX - x0) / INDENT);
        lvl = Math.max(minL, Math.min(maxL, lvl)); if (lvl < 0) lvl = 0;
        target = { pos, lvl };
        const lr = list.getBoundingClientRect();
        let y;
        if (restRows.length === 0) y = 4; else if (pos < restRows.length) y = restRows[pos].getBoundingClientRect().top - lr.top + list.scrollTop - 2; else y = restRows[restRows.length - 1].getBoundingClientRect().bottom - lr.top + list.scrollTop + 1;
        Object.assign(line.style, { top: y + 'px', left: (6 + lvl * INDENT) + 'px' });
      };
      const up = () => {
        window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', up); line.remove();
        if (!on || !target) { renderList(); return; }
        moveBlock(i, target.pos, target.lvl);
      };
      window.addEventListener('mousemove', mv); window.addEventListener('mouseup', up);
    };

    // ----- OK: grava os menus no formulário e escreve o código dos cliques -----
    const [ok, ca] = c.querySelectorAll('.btns button');
    ok.onclick = async () => {
      fixKids();
      // conferências
      const seen = new Map();
      for (const it of items) {
        const where = isMenuSep(it) ? 'a separator' : `"${stripMnemonic(it.caption) || '(no text)'}"`;
        if (!/^[A-Za-z]\w{0,39}$/.test(it.name)) { select(items.indexOf(it)); return IDE.ui.msgBox(`The name "${it.name}" of ${where} is not valid.\nUse letters, numbers and _ (starting with a letter), for example mnuFile.`, 48, 'Menu Editor'); }
        if (ctlNames.has(it.name.toLowerCase())) { select(items.indexOf(it)); return IDE.ui.msgBox(`The name "${it.name}" is already used by a control of this form. Choose another name.`, 48, 'Menu Editor'); }
        if (it.index !== undefined && it.index !== null && it.index !== '' && typeof it.index !== 'number') { select(items.indexOf(it)); return IDE.ui.msgBox(`The Index of ${where} must be a number (or empty).`, 48, 'Menu Editor'); }
        const k = it.name.toLowerCase(); const prev = seen.get(k);
        const hasIdx = typeof it.index === 'number';
        if (prev) { if (!hasIdx || !prev.some(p => typeof p.index === 'number') || prev.some(p => p.index === it.index)) { select(items.indexOf(it)); return IDE.ui.msgBox(`Two menu items are named "${it.name}". Each item needs its own name.`, 48, 'Menu Editor'); } prev.push(it); }
        else seen.set(k, [it]);
        if (!it.hasKids && !isMenuSep(it) && (it.action.kind === 'open' || it.action.kind === 'modal') && !it.action.form) { select(items.indexOf(it)); return IDE.ui.msgBox(`Choose which form ${where} opens.`, 48, 'Menu Editor'); }
      }
      pushUndo(m);
      // 1) menus no formulário (reaproveita os nós antigos para não perder Tag, WindowList…)
      root.children = root.children.filter(ch => !/\.menu$/i.test(ch.type));
      const stack = [root];
      for (const it of items) {
        const n = it.node ? Object.assign(it.node, { children: [] }) : new CtlNode('VB.Menu', it.name);
        // só mexe no que mudou (o .frm continua igual ao do VB quando nada mudou)
        const put = (k, raw, cm) => { if (n.getRaw(k) !== raw) n.setRaw(k, raw, cm); };
        const isTrue = k => { const v = n.get(k); return v === true || v === -1; };
        n.name = it.name; put('Caption', quote(it.caption));
        if (typeof it.index === 'number') put('Index', String(it.index)); else n.remove('Index');
        if (it.checked) { if (!isTrue('Checked')) n.setRaw('Checked', '-1', 'True'); } else n.remove('Checked');
        if (!it.enabled) { if (n.get('Enabled', true) !== false && n.get('Enabled') !== 0) n.setRaw('Enabled', '0', 'False'); } else n.remove('Enabled');
        if (!it.visible) { if (n.get('Visible', true) !== false && n.get('Visible') !== 0) n.setRaw('Visible', '0', 'False'); } else n.remove('Visible');
        if (it.shortcut && !isMenuSep(it)) put('Shortcut', it.shortcut); else n.remove('Shortcut');
        const parent = stack[Math.min(it.lvl, stack.length - 1)]; n.parent = parent; parent.children.push(n);
        stack.length = Math.min(it.lvl, stack.length - 1) + 1; stack.push(n);
      }
      // 2) código dos cliques
      let lines = (getCode(m) || '').replace(/\r\n/g, '\n').split('\n');
      const removeSub = (nm) => { const r = findSubLines(lines, nm + '_Click'); if (!r) return; let s = r.s; while (s > 0 && !lines[s - 1].trim()) s--; lines.splice(s, r.e - s + 1); };
      const kept = new Set(items.map(x => x.name.toLowerCase()));
      // itens apagados: some o código que o editor tinha escrito (código seu continua lá)
      for (const x of oldList) if (!items.some(it => it.node === x.node) && !kept.has(x.name.toLowerCase())) { const a = detectMenuAction(lines, x.name, formNames); if (a.exists && a.kind !== 'custom') removeSub(x.name); }
      customToOpen = null;
      for (const it of items) {
        if (isMenuSep(it)) continue;
        // nome trocado: o Sub do clique acompanha
        if (it.oldName && it.oldName.toLowerCase() !== it.name.toLowerCase() && !items.some(o => o !== it && o.name.toLowerCase() === it.oldName.toLowerCase())) {
          const r = findSubLines(lines, it.oldName + '_Click');
          if (r && !findSubLines(lines, it.name + '_Click')) lines[r.s] = lines[r.s].replace(new RegExp('\\b' + it.oldName + '_Click\\b', 'i'), it.name + '_Click');
        }
        if (it.hasKids) continue;
        const now = JSON.stringify(it.action);
        if (it.orig === now && it.node) continue; // nada mudou
        const a = it.action;
        const isArr = typeof it.index === 'number' || items.some(o => o !== it && o.name.toLowerCase() === it.name.toLowerCase());
        const r = findSubLines(lines, it.name + '_Click');
        if (a.kind === 'none') { if (r) { const cur2 = detectMenuAction(lines, it.name, formNames); if (cur2.kind !== 'custom') removeSub(it.name); } continue; }
        if (a.kind === 'custom') { if (!r) { while (lines.length && !lines[lines.length - 1].trim()) lines.pop(); if (lines.length) lines.push(''); lines.push(`Private Sub ${it.name}_Click(${isArr ? 'Index As Integer' : ''})`, '    ', 'End Sub', ''); } if (!customToOpen) customToOpen = it.name; continue; }
        const body = menuActionCode(a);
        if (r) lines.splice(r.s + 1, r.e - r.s - 1, ...body);
        else { while (lines.length && !lines[lines.length - 1].trim()) lines.pop(); if (lines.length) lines.push(''); lines.push(`Private Sub ${it.name}_Click(${isArr ? 'Index As Integer' : ''})`, ...body, 'End Sub', ''); }
      }
      const newCode = lines.join('\n').replace(/\n/g, '\r\n');
      if (newCode !== (getCode(m) || '')) { setCode(m, newCode); for (const cd of IDE.docs.filter(x => x.mod === m && x.kind === 'code')) loadEditorText(cd); }
      // a altura do form muda quando ganha ou perde a barra de menus
      const P = nodeProps(root); setFormClientSize(root, P.clientwidth || 4680, P.clientheight || 3195);
      m.dirty = true; markDirty(); rerenderActive(); renderProps(); done(true);
      if (customToOpen) { const d = openCode(m); setSel(d.cobj, customToOpen); fillProcCombo(d, 'Click'); gotoProc(d, customToOpen, 'Click'); }
    };
    ca.onclick = () => done(false);
    c.parentNode._cancelValue = false;
    renderList(); renderDetails();
    return cur >= 0 ? list : $('.me-add', c);
  });
}
const MI = {
  up: I('<path d="M12 19V5M6 11l6-6 6 6"/>'), down: I('<path d="M12 5v14M6 13l6 6 6-6"/>'),
  left: I('<path d="M19 12H5M11 6l-6 6 6 6"/>'), right: I('<path d="M5 12h14M13 6l6 6-6 6"/>'),
  del: I('<path d="M4 7h16M9 7V4.5h6V7M6.5 7l1 13h9l1-13M10 11v6M14 11v6"/>'),
  grip: '<svg viewBox="0 0 10 16" width="8" height="14"><g fill="currentColor"><circle cx="2.5" cy="3" r="1.4"/><circle cx="7.5" cy="3" r="1.4"/><circle cx="2.5" cy="8" r="1.4"/><circle cx="7.5" cy="8" r="1.4"/><circle cx="2.5" cy="13" r="1.4"/><circle cx="7.5" cy="13" r="1.4"/></g></svg>',
};

// ---------- Barra de formatação do designer (pincel + alinhamento estilo Inkscape) ----------
const FI = {
  painter: I('<path d="M4 4h12a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z"/><path d="M17 6.5h2.5V12H11v2.5"/><rect x="9.5" y="14.5" width="3" height="6.5" rx="1"/>'),
  alignL: I('<path d="M4 3v18"/><rect x="7" y="6" width="10" height="4" rx="1"/><rect x="7" y="14" width="6" height="4" rx="1"/>'),
  alignCH: I('<path d="M12 3v18"/><rect x="6" y="6" width="12" height="4" rx="1"/><rect x="8.5" y="14" width="7" height="4" rx="1"/>'),
  alignR: I('<path d="M20 3v18"/><rect x="7" y="6" width="10" height="4" rx="1"/><rect x="11" y="14" width="6" height="4" rx="1"/>'),
  alignT: I('<path d="M3 4h18"/><rect x="6" y="7" width="4" height="10" rx="1"/><rect x="14" y="7" width="4" height="6" rx="1"/>'),
  alignCV: I('<path d="M3 12h18"/><rect x="6" y="6" width="4" height="12" rx="1"/><rect x="14" y="8.5" width="4" height="7" rx="1"/>'),
  alignB: I('<path d="M3 20h18"/><rect x="6" y="7" width="4" height="10" rx="1"/><rect x="14" y="11" width="4" height="6" rx="1"/>'),
  distH: I('<path d="M3 4v16M21 4v16"/><rect x="6" y="8" width="3.5" height="8" rx="1"/><rect x="14.5" y="8" width="3.5" height="8" rx="1"/>'),
  distV: I('<path d="M4 3h16M4 21h16"/><rect x="8" y="6" width="8" height="3.5" rx="1"/><rect x="8" y="14.5" width="8" height="3.5" rx="1"/>'),
};
function buildDesignBar() {
  const bar = h('div', { id: 'dbar' });
  const B = (icon, title, id) => { const b = h('button', { title, html: FI[icon], 'data-dcmd': id }); b.onmousedown = e => e.preventDefault(); b.onclick = () => cmd(id); return b; };
  const pb = B('painter', 'Format Painter — copies color, font, size and style of the selected control.\nClick: paint one control. Double-click: paint several (Esc stops).', 'painter');
  pb.ondblclick = () => startPainter(true);
  bar.append(pb, h('span', { class: 'sep' }),
    B('alignL', 'Align left edges', 'alignL'), B('alignCH', 'Center horizontally (on a vertical line)', 'alignCH'), B('alignR', 'Align right edges', 'alignR'), h('span', { class: 'sep' }),
    B('alignT', 'Align top edges', 'alignT'), B('alignCV', 'Center vertically (on a horizontal line)', 'alignCV'), B('alignB', 'Align bottom edges', 'alignB'), h('span', { class: 'sep' }),
    B('distH', 'Make horizontal gaps equal (3 or more controls)', 'distH'), B('distV', 'Make vertical gaps equal (3 or more controls)', 'distV'));
  bar.appendChild(h('span', { class: 'dref', id: 'dbref' }));
  return bar;
}
function refreshDesignBar() {
  if (!IDE.dbar) IDE.dbar = buildDesignBar();
  const tabs = $('#tabs'); if (tabs && IDE.dbar.parentNode !== tabs) tabs.appendChild(IDE.dbar);
  const d = IDE.activeDoc, on = !!(d && d.kind === 'design' && !IDE.running);
  IDE.dbar.style.display = on ? '' : 'none';
  if (!on) { if (IDE.painter) stopPainter(); return; }
  const nodes = on ? selNodes().filter(n => n.parent && IDE.sel.mod === d.mod) : [];
  const many = nodes.length;
  for (const b of IDE.dbar.querySelectorAll('button')) {
    const id = b.dataset.dcmd;
    b.disabled = id === 'painter' ? (many !== 1 && !IDE.painter) : id.startsWith('dist') ? many < 3 : many < 1;
    b.classList.toggle('on', id === 'painter' && !!IDE.painter);
  }
  const ref = $('#dbref', IDE.dbar);
  ref.textContent = IDE.painter ? (IDE.painter.sticky ? 'Painting — click controls, Esc stops' : 'Click a control to paint it') : many > 1 ? `Aligns to ${nodes[0].name} (first selected)` : many === 1 ? 'Aligns to the form' : '';
}

// ---------- Pincel de formatação ----------
const PAINT_KEYS = ['Appearance', 'BackColor', 'BackStyle', 'BorderColor', 'BorderStyle', 'BorderWidth', 'ForeColor', 'FillColor', 'FillStyle', 'Shape', 'Alignment', 'Corners', 'Style', 'Width', 'Height', 'MousePointer', 'AutoSize', 'WordWrap', 'Stretch'];
const PAINT_FAMILY = { 'VB.TextBox': 'input', 'VB.ComboBox': 'input', 'VB.ListBox': 'input', 'VB.DriveListBox': 'input', 'VB.DirListBox': 'input', 'VB.FileListBox': 'input', 'VB.CheckBox': 'check', 'VB.OptionButton': 'check', 'VB.Shape': 'shape', 'VB.Line': 'shape' };
const PAINT_COLORS = new Set(['backcolor', 'forecolor', 'bordercolor', 'fillcolor']);
const paintFamily = t => PAINT_FAMILY[t] || t;
const FAMILY_TEXT = { input: 'text boxes, combo boxes and lists', check: 'check boxes and option buttons', shape: 'shapes and lines' };
const hasProp = (type, key) => ctlDef(type).props.some(p => p.split(':')[0].toLowerCase() === key.toLowerCase());
function startPainter(sticky) {
  const d = IDE.activeDoc; if (!d || d.kind !== 'design' || IDE.running) return;
  if (IDE.painter && !sticky) { stopPainter(); return; }
  const nodes = selNodes().filter(n => n.parent);
  const src = IDE.painter ? IDE.painter.src : nodes[0];
  if (!src) { setStatus('Select the control whose format you want to copy, then click the brush.'); return; }
  IDE.painter = { src, mod: d.mod, sticky: !!sticky };
  document.body.classList.add('nb-painting');
  setStatus(sticky ? `Format of ${src.name} copied. Click the controls to paint them — Esc stops.` : `Format of ${src.name} copied. Click a control of the same kind to paint it.`);
  refreshDesignBar();
}
function stopPainter() { IDE.painter = null; document.body.classList.remove('nb-painting'); if (IDE.dbar) refreshDesignBar(); }
function paintNode(target) {
  const pt = IDE.painter; if (!pt) return false;
  const src = pt.src, m = pt.mod;
  if (target === src) return false;
  if (paintFamily(target.type) !== paintFamily(src.type)) {
    const f = paintFamily(src.type); const what = FAMILY_TEXT[f] || (ctlDef(src.type).tool || src.shortType) + ' controls';
    setStatus(`${target.name} is not of the same kind. The format of ${src.name} goes only to ${what}.`);
    return false;
  }
  pushUndo(m);
  const dS = defaultProps(src.type), dT = defaultProps(target.type);
  for (const key of PAINT_KEYS) {
    if (!hasProp(src.type, key) || !hasProp(target.type, key)) continue;
    if (key === 'Style' && src.type !== target.type) continue; // Style quer dizer coisas diferentes em cada controle
    if ((key === 'Width' || key === 'Height') && (ctlDef(target.type).fixedSize || target.type === 'VB.Line')) continue;
    const p = src.findProp(key), lk = key.toLowerCase();
    if (p) { target.setRaw(key, p.raw, p.comment); continue; }
    const v = dS[lk];
    if (v === undefined || v === dT[lk]) target.remove(key);
    else target.set(key, v, PAINT_COLORS.has(lk) ? 'color' : typeof v === 'boolean' ? 'bool' : undefined);
  }
  if (hasProp(src.type, 'Font') && hasProp(target.type, 'Font')) {
    const fb = src.block('Font');
    target.blocks = target.blocks.filter(b => b.name.toLowerCase() !== 'font');
    if (fb) target.blocks.push(cloneBlock(fb));
  }
  m.dirty = true; markDirty();
  return true;
}

// ---------- Alinhar e distribuir (como no Inkscape; vários itens = alinham ao primeiro selecionado) ----------
function ctlBox(n) {
  const P = nodeProps(n);
  if (n.type === 'VB.Line') return { l: Math.min(P.x1, P.x2), t: Math.min(P.y1, P.y2), r: Math.max(P.x1, P.x2), b: Math.max(P.y1, P.y2) };
  const def = ctlDef(n.type); const w = def.fixedSize ? (def.w || 420) : (P.width || 0), hh = def.fixedSize ? (def.h || 420) : (P.height || 0);
  return { l: P.left || 0, t: P.top || 0, r: (P.left || 0) + w, b: (P.top || 0) + hh };
}
function ctlShift(n, dx, dy) {
  dx = Math.round(dx); dy = Math.round(dy); if (!dx && !dy) return;
  if (n.type === 'VB.Line') { for (const [k, d] of [['X1', dx], ['X2', dx], ['Y1', dy], ['Y2', dy]]) n.setRaw(k, String(Math.round(Number(n.get(k, 0)) + d))); }
  else { n.setRaw('Left', String(Math.round(Number(n.get('Left', 0)) + dx))); n.setRaw('Top', String(Math.round(Number(n.get('Top', 0)) + dy))); }
}
function alignSel(op) {
  const d = IDE.activeDoc; if (!d || d.kind !== 'design' || IDE.running) return;
  const s = IDE.sel; if (!s || s.mod !== d.mod) return;
  const nodes = selNodes().filter(n => n.parent && !navDocked(n)); if (!nodes.length) { setStatus('Select one or more controls to align.'); return; }
  if (op.startsWith('dist') && nodes.length < 3) { setStatus('Select 3 or more controls to make the gaps equal.'); return; }
  const m = d.mod; pushUndo(m);
  if (op === 'distH' || op === 'distV') {
    const H = op === 'distH'; const L = H ? 'l' : 't', R = H ? 'r' : 'b';
    const arr = nodes.map(n => ({ n, b: ctlBox(n) })).sort((a, b) => (a.b[L] + a.b[R]) - (b.b[L] + b.b[R]));
    const first = Math.min(...arr.map(x => x.b[L])), last = Math.max(...arr.map(x => x.b[R]));
    const sum = arr.reduce((t, x) => t + (x.b[R] - x.b[L]), 0); const gap = (last - first - sum) / (arr.length - 1);
    let pos = first;
    for (const x of arr) { const dlt = pos - x.b[L]; ctlShift(x.n, H ? dlt : 0, H ? 0 : dlt); pos += (x.b[R] - x.b[L]) + gap; }
  } else {
    let ref;
    if (nodes.length === 1) { const par = nodes[0].parent; const PP = nodeProps(par); const isRoot = par === m.frm.root; ref = { l: 0, t: 0, r: isRoot ? (PP.clientwidth || 4680) : (PP.width || 0), b: isRoot ? (PP.clientheight || 3195) : (PP.height || 0) }; }
    else ref = ctlBox(nodes[0]);
    for (const n of nodes) {
      if (nodes.length > 1 && n === nodes[0]) continue;
      const b = ctlBox(n);
      const dx = op === 'alignL' ? ref.l - b.l : op === 'alignR' ? ref.r - b.r : op === 'alignCH' ? (ref.l + ref.r) / 2 - (b.l + b.r) / 2 : 0;
      const dy = op === 'alignT' ? ref.t - b.t : op === 'alignB' ? ref.b - b.b : op === 'alignCV' ? (ref.t + ref.b) / 2 - (b.t + b.b) / 2 : 0;
      ctlShift(n, dx, dy);
    }
  }
  m.dirty = true; markDirty(); renderDesigner(d); renderProps();
  setStatus(nodes.length > 1 && !op.startsWith('dist') ? `Aligned to ${nodes[0].name}.` : 'Done.');
}

// ---------- Novo projeto: escolher o form inicial (como no VB, o primeiro form que abre) ----------
function newProjectDialog() {
  return ideDialog('New Project', (c, done) => {
    c.innerHTML = `<div class="np-intro">A Standard EXE with one form. This is the <b>startup form</b>: the first window that opens when your program starts.</div>
      <div class="row"><label>Project name</label><input type="text" class="np-p" spellcheck="false" style="width:200px"></div>
      <div class="row"><label>Startup form name</label><input type="text" class="np-f" spellcheck="false" style="width:200px"></div>
      <div class="row"><label>Startup form title</label><input type="text" class="np-c" spellcheck="false" style="width:200px"></div>
      <div class="np-note">The startup form gets a ★ in the Project panel. To change it later: Project &gt; Project Properties &gt; Startup Object.</div>
      <div class="btns"><button class="nb-btn">Create</button><button class="nb-btn">Cancel</button></div>`;
    const pp = $('.np-p', c), pf = $('.np-f', c), pc = $('.np-c', c);
    pp.value = 'Project1'; pf.value = 'Form1'; pc.value = 'Form1'; let capTouched = false;
    pf.addEventListener('input', () => { if (!capTouched) pc.value = pf.value; });
    pc.addEventListener('input', () => { capTouched = true; });
    const [ok, ca] = c.querySelectorAll('.btns button');
    const go = async () => {
      const pn = pp.value.trim(), fn = pf.value.trim();
      if (!/^[A-Za-z]\w{0,39}$/.test(pn)) { await IDE.ui.msgBox('Invalid project name. Use letters, numbers and _ (starting with a letter).', 48, APP_NAME); pp.focus(); return; }
      if (!/^[A-Za-z]\w{0,39}$/.test(fn)) { await IDE.ui.msgBox('Invalid form name. Use letters, numbers and _ (starting with a letter), for example frmPrincipal.', 48, APP_NAME); pf.focus(); return; }
      if (fn.toLowerCase() === pn.toLowerCase()) { await IDE.ui.msgBox('The form cannot have the same name as the project.', 48, APP_NAME); pf.focus(); return; }
      done({ project: pn, form: fn, caption: pc.value });
    };
    ok.onclick = go; ca.onclick = () => done(null);
    c.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); go(); } if (e.key === 'Escape') { e.preventDefault(); done(null); } });
    c.parentNode._cancelValue = null;
    setTimeout(() => { pf.select(); }, 0);
    return pf;
  });
}

// ---------- Painéis da direita: botão de minimizar (telas pequenas, Linux…) ----------
const PMIN_ICON = I('<path d="M6 12h12"/>'), PMAX_ICON = I('<path d="M6 9.5l6 6 6-6"/>');
function setupPanelMin() {
  let st = {}; try { st = JSON.parse(localStorage.getItem('neobasic.panels') || '{}'); } catch (e) { }
  const save = () => { try { localStorage.setItem('neobasic.panels', JSON.stringify(st)); } catch (e) { } };
  for (const id of ['projpanel', 'datapanel', 'proppanel']) {
    const p = $('#' + id); if (!p) continue;
    let bx = $('.pbtns', p); if (!bx) { bx = h('div', { class: 'pbtns' }); p.insertBefore(bx, p.children[1] || null); }
    const b = h('button', { class: 'pmin' }); bx.appendChild(b);
    const apply = () => { const c = !!st[id]; p.classList.toggle('collapsed', c); b.innerHTML = c ? PMAX_ICON : PMIN_ICON; b.title = c ? 'Restore' : 'Minimize'; };
    const toggle = () => { st[id] = !st[id]; save(); apply(); updateSelection(); };
    b.onclick = toggle;
    $('.ptitle', p).addEventListener('dblclick', toggle);
    apply();
  }
  // janela Immediate: fica escondida (View > Immediate Window ou Ctrl+G mostra)
  const im = $('#immediate'); if (im && !st.immediate) im.style.display = 'none';
}
function rememberImmediate() { const im = $('#immediate'); let st = {}; try { st = JSON.parse(localStorage.getItem('neobasic.panels') || '{}'); } catch (e) { } st.immediate = im && im.style.display !== 'none'; try { localStorage.setItem('neobasic.panels', JSON.stringify(st)); } catch (e) { } }

// ---------- Posição e tamanho na barra: dá para digitar ----------
function setTbVals(l, t, w, hh, note) {
  const put = (id, v) => { const e = $('#' + id); if (e && document.activeElement !== e) e.value = String(Math.round(Number(v) || 0)); };
  put('tbL', l); put('tbT', t); put('tbW', w); put('tbH', hh);
  const n1 = $('#tbpos'); if (n1) n1.textContent = note || '';
}
function setupTbEdit() {
  for (const id of ['tbL', 'tbT', 'tbW', 'tbH']) {
    const e = $('#' + id); if (!e) continue;
    e.addEventListener('focus', () => setTimeout(() => e.select(), 0));
    e.addEventListener('keydown', ev => {
      ev.stopPropagation();
      if (ev.key === 'Enter') { ev.preventDefault(); applyTbEdit(id, e.value); e.blur(); }
      else if (ev.key === 'Escape') { ev.preventDefault(); e.blur(); updateSelection(); }
      else if (ev.key === 'Tab') { applyTbEdit(id, e.value); }
    });
    e.addEventListener('change', () => applyTbEdit(id, e.value));
    e.addEventListener('blur', () => setTimeout(() => updateSelection(), 0));
  }
}
function applyTbEdit(id, raw) {
  const d = IDE.activeDoc; if (!d || d.kind !== 'design' || IDE.running) return;
  const s = IDE.sel; if (!s || s.mod !== d.mod || !s.node) return;
  const v = Math.round(Number(String(raw).replace(',', '.').trim()));
  if (!isFinite(v) || String(raw).trim() === '') { updateSelection(); return; }
  const m = d.mod, root = m.frm.root;
  let nodes = s.node === root ? [root] : selNodes().filter(n => n.parent && !navDocked(n));
  if (!nodes.length) { setStatus('The navigation bar is docked (Align). Set Align = 0 - None to move it.'); updateSelection(); return; }
  if (id === 'tbH') nodes = nodes.filter(n => n.type !== 'NB.NavigationBar');
  // nada mudou? não mexe (evita Undo vazio)
  const cur = n => { const P = nodeProps(n); if (n === root) return { tbL: P.left || 0, tbT: P.top || 0, tbW: (P.clientwidth || 4680) + 120, tbH: (P.clientheight || 3195) + 405 }[id]; if (n.type === 'VB.Line') return { tbL: P.x1, tbT: P.y1, tbW: Math.abs(P.x2 - P.x1), tbH: Math.abs(P.y2 - P.y1) }[id]; return { tbL: P.left, tbT: P.top, tbW: P.width, tbH: P.height }[id]; };
  if (nodes.every(n => Math.round(cur(n)) === v)) return;
  pushUndo(m);
  for (const n of nodes) {
    const P = nodeProps(n);
    if (n === root) {
      if (id === 'tbL') n.setRaw('Left', String(v)); else if (id === 'tbT') n.setRaw('Top', String(v));
      else if (id === 'tbW') setFormClientSize(n, Math.max(600, v - 120), P.clientheight || 3195);
      else setFormClientSize(n, P.clientwidth || 4680, Math.max(300, v - 405));
    } else if (n.type === 'VB.Line') {
      if (id === 'tbL') { const dx = v - P.x1; n.setRaw('X1', String(v)); n.setRaw('X2', String(Math.round(P.x2 + dx))); }
      else if (id === 'tbT') { const dy = v - P.y1; n.setRaw('Y1', String(v)); n.setRaw('Y2', String(Math.round(P.y2 + dy))); }
      else if (id === 'tbW') n.setRaw('X2', String(Math.round(P.x1 + (P.x2 >= P.x1 ? 1 : -1) * Math.max(0, v))));
      else n.setRaw('Y2', String(Math.round(P.y1 + (P.y2 >= P.y1 ? 1 : -1) * Math.max(0, v))));
    } else {
      if (ctlDef(n.type).fixedSize && (id === 'tbW' || id === 'tbH')) continue;
      const k = { tbL: 'Left', tbT: 'Top', tbW: 'Width', tbH: 'Height' }[id];
      n.setRaw(k, String(k === 'Width' || k === 'Height' ? Math.max(30, v) : v));
    }
  }
  m.dirty = true; markDirty(); renderDesigner(d); renderProps();
  setStatus(nodes.length > 1 ? `${nodes.length} controls changed.` : `${nodes[0].name} changed.`);
}

// ---------- Trocar o nome do banco de dados do projeto ----------
async function renameDatabaseDialog(oldName) {
  const P = IDE.project; if (!P || IDE.running) return;
  const oldStem = oldName.replace(/\.[^.]*$/, '');
  const v = await ideDialog('Rename Database', (c, done) => {
    c.innerHTML = `<div style="margin-bottom:10px;max-width:360px">New name for <b>${esc(oldName)}</b>. Data controls and navigation bars that use it are updated too.</div>
      <div class="row"><label style="width:70px">Name</label><input type="text" class="rn" spellcheck="false" style="width:200px"><span style="color:var(--muted)">.db</span></div>
      <div class="btns"><button class="nb-btn">OK</button><button class="nb-btn">Cancel</button></div>`;
    const rn = $('.rn', c); rn.value = oldStem;
    const [ok, ca] = c.querySelectorAll('.btns button');
    ok.onclick = () => done(rn.value.trim().replace(/\.(db|sqlite3?|mdb|accdb)$/i, '')); ca.onclick = () => done(null);
    rn.addEventListener('keydown', e => { if (e.key === 'Enter') ok.click(); });
    c.parentNode._cancelValue = null; setTimeout(() => rn.select(), 0); return rn;
  });
  if (!v || v === oldStem) return;
  if (!/^[\w\- ]{1,60}$/.test(v)) { await IDE.ui.msgBox('Invalid name. Use letters, numbers, spaces, - and _.', 48, APP_NAME); return; }
  if (ideDbNames().some(n => n.replace(/\.[^.]*$/, '').toLowerCase() === v.toLowerCase())) { await IDE.ui.msgBox(`The project already has a database named ${v}.`, 48, APP_NAME); return; }
  try { await renameDatabase(oldName, v + '.db'); }
  catch (e) { IDE.ui.msgBox('Could not rename the database: ' + (e.description || e.message), 16, APP_NAME); }
}
async function renameDatabase(oldName, newName) {
  const P = IDE.project; syncEditors();
  const oldStem = oldName.toLowerCase().replace(/\.[^.]*$/, ''), newStem = newName.toLowerCase().replace(/\.[^.]*$/, '');
  const db = await ideOpenDb(oldName); const entry = db.entry || IDE.host.dbCache.get(oldStem);
  const bytes = entry.db.export();
  const oldFiles = (P.dbFiles || []).filter(f => f.name.toLowerCase().replace(/\.[^.]*$/, '') === oldStem).map(f => f.name);
  P.dbFiles = (P.dbFiles || []).filter(f => f.name.toLowerCase().replace(/\.[^.]*$/, '') !== oldStem);
  P.dbFiles.push({ name: newName, path: newName, bytes, inFolder: false });
  IDE.host.dbCache.delete(oldStem);
  Object.assign(entry, { name: newName, stem: newStem, dirty: true, fromAccess: false });
  IDE.host.dbCache.set(newStem, entry);
  // DatabaseName dos controles e nomes de arquivo escritos no código
  const isOld = s => { const b = String(s || '').replace(/\//g, '\\').split('\\').pop().toLowerCase(); return b.replace(/\.[^.]*$/, '') === oldStem && (b === oldStem || /\.(mdb|accdb|db|sqlite3?)$/.test(b)); };
  let nCtl = 0, nCode = 0;
  for (const m of P.modules) {
    let changed = false;
    if (m.kind === 'form') for (const n of allNodes(m)) { const dn = n.get('DatabaseName'); if (typeof dn === 'string' && dn && isOld(dn)) { n.setRaw('DatabaseName', quote(newName)); nCtl++; changed = true; } }
    const code = getCode(m) || '';
    const nc = code.replace(/"([^"\r\n]*)"/g, (all, s) => isOld(s) && /\.(mdb|accdb|db|sqlite3?)$/i.test(s) ? (nCode++, `"${s.replace(/[^\\/]*$/, newName)}"`) : all);
    if (nc !== code) { setCode(m, nc); changed = true; for (const cd of IDE.docs.filter(x => x.mod === m && x.kind === 'code')) loadEditorText(cd); }
    if (changed) m.dirty = true;
  }
  P.dbDirty = true; markDirty(); refreshExplorer(); refreshDataPanel(); rerenderActive(); renderProps();
  setStatus(`Database renamed to ${newName}` + (nCtl ? ` — ${nCtl} control(s) updated` : '') + (nCode ? `, ${nCode} name(s) in the code` : '') + '. Save to write it to the project folder' + (oldFiles.length ? ` (the old ${oldFiles.join(', ')} stays there)` : '') + '.');
}

// ---------- NavigationBar: ordem dos botões (arrastar) e quais aparecem ----------
const NAV_SHOWKEY = { new: 'ShowNew', copy: 'ShowCopy', paste: 'ShowPaste', undo: 'ShowUndo', redo: 'ShowRedo', save: 'ShowSave', edit: 'ShowEdit', del: 'ShowDelete', cancel: 'ShowCancel', first: 'ShowFirst', prev: 'ShowPrevious', rec: 'ShowRecordNumber', next: 'ShowNext', last: 'ShowLast' };
function navOrderDialog(node) {
  const P = nodeProps(node); const T = navText();
  const items = navOrderList(P).map(k => ({ k, on: k === '|' ? true : P[NAV_SHOWPROP[k]] !== false }));
  const label = k => k === '|' ? '' : (T.tip[k] || T[k]);
  return ideDialog('Button Order', (c, done) => {
    c.parentNode.classList.add('me-dlg');
    c.innerHTML = `<div style="max-width:380px;margin-bottom:8px;line-height:1.45">Drag the buttons to change the order. Uncheck to hide a button.</div>
      <div class="me-tools"><button class="nb-btn no-sep">+ Separator</button><span class="me-gap"></span><button class="nb-btn no-def" title="Back to the standard order">Default order</button></div>
      <div class="me-list no-list" tabindex="0" style="height:360px;width:380px"></div>
      <div class="btns"><button class="nb-btn">OK</button><button class="nb-btn">Cancel</button></div>`;
    const list = $('.no-list', c);
    const render = () => {
      list.innerHTML = '';
      items.forEach((it, i) => {
        const sep = it.k === '|';
        const row = h('div', { class: 'me-row' + (sep ? ' sep' : '') });
        row.innerHTML = `<span class="grip">${MI.grip}</span>${sep ? '<span class="cap"><span class="sepline"></span></span><span class="me-ib no-x" title="Remove separator">✕</span>' : `<label class="ck no-ck"><input type="checkbox"></label><span class="no-ic"><svg class="i" viewBox="0 0 24 24">${it.k === 'rec' ? '<rect x="4" y="7" width="16" height="10" rx="5"/><path d="M10 12h4"/>' : NAV_ICON[it.k]}</svg></span><span class="cap"></span>`}`;
        if (!sep) { $('.cap', row).textContent = label(it.k); const ck = $('input', row); ck.checked = it.on; ck.onchange = () => { it.on = ck.checked; row.classList.toggle('off', !it.on); }; ck.onmousedown = e => e.stopPropagation(); row.classList.toggle('off', !it.on); }
        else { const x = $('.no-x', row); x.onmousedown = e => e.stopPropagation(); x.onclick = () => { items.splice(i, 1); render(); }; }
        row.addEventListener('mousedown', ev => drag(ev, i));
        list.appendChild(row);
      });
    };
    const drag = (ev, i) => {
      if (ev.button !== 0) return; ev.preventDefault();
      const y0 = ev.clientY; let on = false, pos = null; const line = h('div', { class: 'me-drop' });
      const mv = e => {
        if (!on && Math.abs(e.clientY - y0) < 4) return;
        if (!on) { on = true; list.children[i].classList.add('dragging'); list.appendChild(line); }
        const rows = [...list.querySelectorAll('.me-row')]; pos = rows.length;
        for (let k = 0; k < rows.length; k++) { const r = rows[k].getBoundingClientRect(); if (e.clientY < r.top + r.height / 2) { pos = k; break; } }
        const lr = list.getBoundingClientRect(); const y = pos < rows.length ? rows[pos].getBoundingClientRect().top - lr.top + list.scrollTop - 2 : rows[rows.length - 1].getBoundingClientRect().bottom - lr.top + list.scrollTop + 1;
        Object.assign(line.style, { top: y + 'px', left: '6px' });
      };
      const up = () => { window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', up); line.remove(); if (on && pos !== null) { const [it] = items.splice(i, 1); items.splice(pos > i ? pos - 1 : pos, 0, it); } render(); };
      window.addEventListener('mousemove', mv); window.addEventListener('mouseup', up);
    };
    $('.no-sep', c).onclick = () => { items.push({ k: '|', on: true }); render(); list.scrollTop = list.scrollHeight; };
    $('.no-def', c).onclick = () => { const d = navOrderList({}); const on = new Map(items.map(x => [x.k, x.on])); items.length = 0; for (const k of d) items.push({ k, on: k === '|' ? true : on.get(k) !== false }); render(); };
    const [ok, ca] = c.querySelectorAll('.btns button');
    ok.onclick = () => {
      // tira separadores repetidos ou nas pontas
      const ks = []; for (const it of items) { if (it.k === '|' && (!ks.length || ks[ks.length - 1] === '|')) continue; ks.push(it.k); } while (ks[ks.length - 1] === '|') ks.pop();
      const show = {}; for (const it of items) if (it.k !== '|') show[NAV_SHOWKEY[it.k]] = it.on;
      done({ order: ks.join(','), show });
    };
    ca.onclick = () => done(null); c.parentNode._cancelValue = null;
    render(); return list;
  });
}

// ---------- NavigationBar: Align (0 None, 1 Top, 2 Bottom) ----------
function navAlign(n) { const v = n.get('Align'); return v === undefined ? 1 : Number(v) || 0; }
function navDocked(n) { return n && n.type === 'NB.NavigationBar' && navAlign(n) !== 0; }
const NAV_H = [480, 630, 810];
function navBarH(n) { return NAV_H[Number(n.get('ButtonSize', 1))] || 630; }
// quando a barra vai para o topo, os outros controles descem (e o form cresce) para nada ficar escondido;
// embaixo, o form cresce. Voltando, desfaz.
function navAfterChange(m, nav, key, oldV, newV) {
  const root = m.frm.root; if (nav.parent !== root) return;
  const hOld = key === 'buttonsize' ? (NAV_H[oldV] || 630) : navBarH(nav), hNew = key === 'buttonsize' ? (NAV_H[newV] || 630) : navBarH(nav);
  const aOld = key === 'align' ? oldV : navAlign(nav), aNew = key === 'align' ? newV : navAlign(nav);
  nav.setRaw('Height', String(hNew));
  if (key === 'align' && aNew === 0 && aOld !== 0) { nav.setRaw('Left', '120'); nav.setRaw('Top', String(aOld === 2 ? Math.max(0, (nodeProps(root).clientheight || 3195) - hOld - 120) : 120)); }
  const others = root.children.filter(c => c !== nav && !/\.menu$/i.test(c.type) && !navDocked(c));
  const shift = (dy) => { if (!dy) return; for (const c of others) { if (c.type === 'VB.Line') { c.setRaw('Y1', String(Math.round(Number(c.get('Y1', 0)) + dy))); c.setRaw('Y2', String(Math.round(Number(c.get('Y2', 0)) + dy))); } else c.setRaw('Top', String(Math.round(Number(c.get('Top', 0)) + dy))); } };
  const P = nodeProps(root); let ch = P.clientheight || 3195;
  const topOld = aOld === 1 ? hOld : 0, topNew = aNew === 1 ? hNew : 0, botOld = aOld === 2 ? hOld : 0, botNew = aNew === 2 ? hNew : 0;
  let dy = topNew - topOld;
  if (dy < 0) { const minTop = Math.min(...others.map(c => c.type === 'VB.Line' ? Math.min(Number(c.get('Y1', 0)), Number(c.get('Y2', 0))) : Number(c.get('Top', 0))), Infinity); if (minTop < -dy) dy = -Math.max(0, Math.min(-dy, minTop)); }
  shift(dy);
  ch = Math.max(300, ch + dy + (botNew - botOld));
  setFormClientSize(root, P.clientwidth || 4680, ch);
}

// ---------- lista para escolher banco, tabela, fonte de dados, campo e máscara ----------
const MASK_PRESETS = [['(##) ####-####', 'Telefone'], ['(##) #####-####', 'Celular'], ['###.###.###-##', 'CPF'], ['##.###.###/####-##', 'CNPJ'], ['#####-###', 'CEP'], ['##/##/####', 'Data'], ['##:##', 'Hora'], ['##/####', 'Mês/ano'], ['AAA-#A##', 'Placa (Mercosul)']];
function dataSrcNodes(m, except) { return allNodes(m).filter(n => n !== except && (n.type === 'VB.Data' || n.type === 'NB.NavigationBar')); }
function dataSrcOf(m, node) {
  // de onde vêm os dados de um controle (segue a barra até o Data quando ela comanda um Data)
  let name = String(node.get('DataSource', '') || '').trim(); let src = null, guard = 0;
  if (node.type === 'VB.Data' || node.type === 'NB.NavigationBar') { if (!name) return node; }
  while (name && guard++ < 5) { src = allNodes(m).find(n => n.name.toLowerCase() === name.toLowerCase() && (n.type === 'VB.Data' || n.type === 'NB.NavigationBar')); if (!src) return null; name = src.type === 'NB.NavigationBar' ? String(src.get('DataSource', '') || '').trim() : ''; }
  return src;
}
async function dataPickOptions(m, node, key) {
  try {
    if (key === 'mask') return MASK_PRESETS.map(([v, l]) => ({ v, label: `${l}  —  ${v}` })).concat([{ v: null, label: 'Your own: # = number, A = letter, & = letter or number; other characters appear as typed' }]);
    if (key === 'databasename') return ideDbNames();
    if (key === 'datasource') return dataSrcNodes(m, node).map(n => n.name);
    if (key === 'recordsource') { const dbn = String(node.get('DatabaseName', '') || ''); if (!dbn) return { msg: 'Choose the DatabaseName first.' }; const db = await ideOpenDb(dbn); return db.tables(); }
    if (key === 'datafield') {
      const src = dataSrcOf(m, node); if (!src) return { msg: 'Choose the DataSource first (the navigation bar or the Data control).' };
      const dbn = String(src.get('DatabaseName', '') || ''), tb = String(src.get('RecordSource', '') || ''); if (!dbn || !tb) return { msg: `${src.name} has no table yet: set its DatabaseName and RecordSource.` };
      const db = await ideOpenDb(dbn); const rs = new DAORecordset(db, tb, 4); rs.load(); return rs.cols.map(c => c.name);
    }
  } catch (e) { return { msg: e.description || e.message }; }
  return [];
}
function dataPickProp(m, node, pr, inp, commit) {
  const key = pr.key;
  const wrap = h('div', { style: 'position:relative;height:17px' }); wrap.appendChild(inp); inp.style.paddingRight = '20px';
  const b = h('button', { class: 'dots', title: 'Choose from the list' }, '▾'); wrap.appendChild(b);
  const set = v => commit(() => { if (v === '') node.remove(pr.name); else node.setRaw(pr.name, quote(v)); });
  inp.onchange = () => set(inp.value.trim());
  b.onclick = async (e) => {
    e.stopPropagation(); closeIdeMenu();
    const opts = await dataPickOptions(m, node, key);
    const pop = h('div', { class: 'vb-popup idem nb-root dpick' });
    if (!Array.isArray(opts)) pop.appendChild(h('div', { class: 'vb-mi dis' }, h('span', { class: 'ck' }), h('span', {}, opts.msg)));
    else if (!opts.length) pop.appendChild(h('div', { class: 'vb-mi dis' }, h('span', { class: 'ck' }), h('span', {}, key === 'databasename' ? 'The project has no database yet (Project > Add Database File… or Import Spreadsheet…).' : '(nothing to choose)')));
    else for (const o0 of ['', ...opts]) {
      const o = typeof o0 === 'object' ? o0.v : o0, lab = typeof o0 === 'object' ? o0.label : o0;
      if (o === null) { pop.appendChild(h('div', { class: 'vb-mi dis dpick-note' }, h('span', { class: 'ck' }), h('span', {}, lab))); continue; }
      const r = h('div', { class: 'vb-mi' }, h('span', { class: 'ck' }, o && String(inp.value).toLowerCase() === String(o).toLowerCase() ? '✓' : ''), h('span', {}, o === '' ? '(none)' : lab));
      r.addEventListener('mouseup', () => { closeIdeMenu(); set(o); }); pop.appendChild(r);
    }
    document.body.appendChild(pop);
    const rr = wrap.getBoundingClientRect(); const pr2 = pop.getBoundingClientRect();
    pop.style.left = Math.max(4, Math.min(rr.left, window.innerWidth - pr2.width - 4)) + 'px'; pop.style.top = Math.min(rr.bottom + 2, window.innerHeight - pr2.height - 4) + 'px'; pop.style.minWidth = rr.width + 'px';
    setTimeout(() => { IDE.menuCloser = ev => { if (!ev.target.closest('.vb-popup.idem')) closeIdeMenu(); }; window.addEventListener('mousedown', IDE.menuCloser, true); }, 0);
  };
  return wrap;
}
