namespace NeoBasic;

public sealed record ToolboxItem(string Name, string Glyph);
