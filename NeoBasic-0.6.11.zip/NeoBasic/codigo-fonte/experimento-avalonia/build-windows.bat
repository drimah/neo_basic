@echo off
setlocal
cd /d "%~dp0"
dotnet restore NeoBasic.Avalonia.sln
if errorlevel 1 exit /b 1
dotnet publish src\NeoBasic\NeoBasic.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o dist\windows-x64
if errorlevel 1 exit /b 1
echo Build completed: dist\windows-x64\NeoBasic.exe
