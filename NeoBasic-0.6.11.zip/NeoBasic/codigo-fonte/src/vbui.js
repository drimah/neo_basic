// ===== NeoBasic — controles visuais (designer + execução) =====
'use strict';

// ---------- Cores ----------
const SYSCOLORS = ['#d4d0c8', '#3a6ea5', '#0a246a', '#808080', '#d4d0c8', '#ffffff', '#000000', '#000000', '#000000', '#ffffff', '#d4d0c8', '#d4d0c8', '#808080', '#0a246a', '#ffffff', '#d4d0c8', '#808080', '#808080', '#000000', '#d4d0c8', '#ffffff', '#404040', '#d4d0c8', '#000000', '#ffffe1', '#b5b5b5', '#000080', '#0a246a', '#a6caf0'];
const SYSCOLOR_NAMES = ['Scroll Bars', 'Desktop', 'Active Title Bar', 'Inactive Title Bar', 'Menu Bar', 'Window Background', 'Window Frame', 'Menu Text', 'Window Text', 'Active Title Bar Text', 'Active Border', 'Inactive Border', 'Application Workspace', 'Highlight', 'Highlighted Text', 'Button Face', 'Button Shadow', 'Disabled Text', 'Button Text', 'Inactive Title Bar Text', 'Button Highlight', 'Button Dark Shadow', 'Button Light Shadow', 'ToolTip Text', 'ToolTip'];
// estilo visual dos programas: 'modern' (2026) ou 'classic' (Windows 2000)
let NB_SKIN = 'modern';
function setSkin(s) { NB_SKIN = s === 'classic' ? 'classic' : 'modern'; }
const SYSCOLORS_MODERN = ['#e9ebf0', '#1f2a44', '#f3f4f7', '#f3f4f7', '#f9fafc', '#ffffff', '#cdd2db', '#1b1f27', '#1b1f27', '#1b1f27', '#cdd2db', '#cdd2db', '#e4e7ed', '#2f6fed', '#ffffff', '#f3f4f7', '#b9bfcb', '#a0a6b3', '#1b1f27', '#9aa1af', '#ffffff', '#8e95a3', '#e9ebf0', '#1b1f27', '#fffbe6', '#c9cdd6', '#2f6fed', '#f3f4f7', '#f3f4f7'];
function vbColorCss(v) {
  if (v === undefined || v === null || v === '') return null;
  v = Number(v);
  if (v < 0 || v >= 0x80000000) { const i = (v >>> 0) & 0xFF; return NB_SKIN === 'modern' ? (SYSCOLORS_MODERN[i] || '#f3f4f7') : (SYSCOLORS[i] || '#d4d0c8'); }
  const r = v & 0xFF, g = (v >> 8) & 0xFF, b = (v >> 16) & 0xFF;
  return '#' + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('');
}
function cssToVbColor(hex) { const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex); if (!m) return 0; return parseInt(m[1], 16) | (parseInt(m[2], 16) << 8) | (parseInt(m[3], 16) << 16); }

// ---------- Fontes ----------
const FONT_MAP = { 'ms sans serif': "Tahoma, 'MS Sans Serif', 'Segoe UI', 'DejaVu Sans', sans-serif", 'system': "Tahoma, 'Segoe UI', sans-serif", 'ms serif': "'Times New Roman', serif", 'courier': "'Courier New', monospace", 'fixedsys': "'Courier New', monospace" };
function fontCss(f) {
  const name = (f && f.name) || 'MS Sans Serif';
  const ln = name.toLowerCase();
  const modernUI = NB_SKIN === 'modern' && (ln === 'ms sans serif' || ln === 'system' || ln === 'ms shell dlg' || ln === 'tahoma' || ln === 'segoe ui');
  const fam = modernUI ? "'NB Inter', Inter, 'Segoe UI', sans-serif" : (FONT_MAP[ln] || `'${name}', Tahoma, sans-serif`);
  const size = (f && f.size) || 8.25;
  return { fontFamily: fam, fontSize: (size * 96 / 72).toFixed(2) + 'px', fontWeight: (f && (f.bold || f.weight >= 600)) ? 'bold' : 'normal', fontStyle: f && f.italic ? 'italic' : 'normal', textDecoration: [f && f.underline ? 'underline' : '', f && f.strikethrough ? 'line-through' : ''].join(' ').trim() || 'none' };
}
function fontFromBlock(b) {
  const f = { name: 'MS Sans Serif', size: 8.25, bold: false, italic: false, underline: false, strikethrough: false };
  if (!b) return f;
  for (const p of b.props) {
    const k = p.key.toLowerCase(), v = rawToValue(p.raw);
    if (k === 'name') f.name = v; else if (k === 'size') f.size = Number(v); else if (k === 'weight') f.bold = Number(v) >= 600; else if (k === 'italic') f.italic = Number(v) !== 0; else if (k === 'underline') f.underline = Number(v) !== 0; else if (k === 'strikethrough') f.strikethrough = Number(v) !== 0; else if (k === 'charset') f.charset = v;
  }
  return f;
}
function fontToBlock(f) {
  return { name: 'Font', guid: '', props: [
    { key: 'Name', raw: quote(f.name || 'MS Sans Serif'), comment: '' }, { key: 'Size', raw: String(f.size || 8.25), comment: '' }, { key: 'Charset', raw: String(f.charset != null ? f.charset : 0), comment: '' },
    { key: 'Weight', raw: f.bold ? '700' : '400', comment: '' }, { key: 'Underline', raw: f.underline ? '-1' : '0', comment: f.underline ? 'True' : 'False' },
    { key: 'Italic', raw: f.italic ? '-1' : '0', comment: f.italic ? 'True' : 'False' }, { key: 'Strikethrough', raw: f.strikethrough ? '-1' : '0', comment: f.strikethrough ? 'True' : 'False' }], blocks: [] };
}
// ---------- Mask (formatação do TextBox): # número, A letra, & letra ou número; o resto aparece como está ----------
const MASK_SLOT = { '#': /\d/, '9': /\d/, 'A': /\p{L}/u, 'a': /\p{L}/u, '&': /[\p{L}\d]/u, '*': /[\p{L}\d]/u };
function nbMaskHint(mask) { return String(mask).replace(/[#9Aa&*]/g, '_'); }
function nbMaskFormat(mask, v) {
  mask = String(mask || ''); if (!mask) return String(v ?? '');
  const raw = [...String(v ?? '')].filter(ch => /[\p{L}\d]/u.test(ch));
  let out = '', i = 0;
  for (const m of mask) {
    if (i >= raw.length) break;
    const re = MASK_SLOT[m];
    if (re) { while (i < raw.length && !re.test(raw[i])) i++; if (i >= raw.length) break; out += m === 'A' ? raw[i].toUpperCase() : raw[i]; i++; }
    else { out += m; if (raw[i] === m) i++; }
  }
  return out;
}
// formata o que foi digitado mantendo o cursor no mesmo lugar
function nbMaskInput(inp, mask) {
  const v = inp.value, pos = inp.selectionStart ?? v.length;
  const before = [...v.slice(0, pos)].filter(ch => /[\p{L}\d]/u.test(ch)).length;
  const nv = nbMaskFormat(mask, v); if (nv === v) return v;
  inp.value = nv;
  let k = 0, p = 0; while (p < nv.length && k < before) { if (/[\p{L}\d]/u.test(nv[p])) k++; p++; }
  try { inp.setSelectionRange(p, p); } catch (e) { }
  return nv;
}
function applyFont(el, f) { Object.assign(el.style, fontCss(f)); }

// ---------- Esquema de controles ----------
const E = (...a) => a; // enumeração: [valor, rótulo]
const ENUMS = {
  borderstyle_form: E([0, '0 - None'], [1, '1 - Fixed Single'], [2, '2 - Sizable'], [3, '3 - Fixed Dialog'], [4, '4 - Fixed ToolWindow'], [5, '5 - Sizable ToolWindow']),
  borderstyle: E([0, '0 - None'], [1, '1 - Fixed Single']),
  alignment: E([0, '0 - Left Justify'], [1, '1 - Right Justify'], [2, '2 - Center']),
  backstyle: E([0, '0 - Transparent'], [1, '1 - Opaque']),
  scrollbars: E([0, '0 - None'], [1, '1 - Horizontal'], [2, '2 - Vertical'], [3, '3 - Both']),
  checkvalue: E([0, '0 - Unchecked'], [1, '1 - Checked'], [2, '2 - Grayed']),
  combostyle: E([0, '0 - Dropdown Combo'], [1, '1 - Simple Combo'], [2, '2 - Dropdown List']),
  liststyle: E([0, '0 - Standard'], [1, '1 - Checkbox']),
  multiselect: E([0, '0 - None'], [1, '1 - Simple'], [2, '2 - Extended']),
  shape: E([0, '0 - Rectangle'], [1, '1 - Square'], [2, '2 - Oval'], [3, '3 - Circle'], [4, '4 - Rounded Rectangle'], [5, '5 - Rounded Square']),
  fillstyle: E([0, '0 - Solid'], [1, '1 - Transparent'], [2, '2 - Horizontal Line'], [3, '3 - Vertical Line'], [4, '4 - Upward Diagonal'], [5, '5 - Downward Diagonal'], [6, '6 - Cross'], [7, '7 - Diagonal Cross']),
  borderstyle_shape: E([0, '0 - Transparent'], [1, '1 - Solid'], [2, '2 - Dash'], [3, '3 - Dot'], [4, '4 - Dash-Dot'], [5, '5 - Dash-Dot-Dot'], [6, '6 - Inside Solid']),
  scalemode: E([0, '0 - User'], [1, '1 - Twip'], [2, '2 - Point'], [3, '3 - Pixel'], [4, '4 - Character'], [5, '5 - Inch'], [6, '6 - Millimeter'], [7, '7 - Centimeter']),
  startup: E([0, '0 - Manual'], [1, '1 - CenterOwner'], [2, '2 - CenterScreen'], [3, '3 - Windows Default']),
  windowstate: E([0, '0 - Normal'], [1, '1 - Minimized'], [2, '2 - Maximized']),
  btnstyle: E([0, '0 - Standard'], [1, '1 - Graphical']),
  appearance: E([0, '0 - Flat'], [1, '1 - 3D']),
  corners: E([0, '0 - Square'], [1, '1 - Rounded'], [2, '2 - Capsule']),
  recordsettype: E([0, '0 - Table'], [1, '1 - Dynaset'], [2, '2 - Snapshot']),
  eofaction: E([0, '0 - Move Last'], [1, '1 - EOF'], [2, '2 - Add New']),
  bofaction: E([0, '0 - Move First'], [1, '1 - BOF']),
  navstyle: E([0, '0 - Icons'], [1, '1 - Icons and Text'], [2, '2 - Text']),
  navsize: E([0, '0 - Small'], [1, '1 - Normal'], [2, '2 - Large']),
  navalign: E([0, '0 - None'], [1, '1 - Top'], [2, '2 - Bottom']),
  mousepointer: E([0, '0 - Default'], [1, '1 - Arrow'], [2, '2 - Cross'], [3, '3 - I-Beam'], [11, '11 - Hourglass'], [99, '99 - Custom']),
};
const P_COMMON = ['Name', 'Index', 'Left', 'Top', 'Width', 'Height', 'Visible', 'Enabled', 'Tag', 'ToolTipText', 'TabIndex', 'TabStop', 'MousePointer'];
const PROP_TYPES = {
  name: 'name', mask: 'text', corners: 'enum', buttonstyle: 'enum', buttonsize: 'enum', buttonorder: 'text', showfirst: 'bool', showcopy: 'bool', showpaste: 'bool', showundo: 'bool', showredo: 'bool', showprevious: 'bool', shownext: 'bool', showlast: 'bool', showrecordnumber: 'bool', shownew: 'bool', showedit: 'bool', showdelete: 'bool', showsave: 'bool', showcancel: 'bool', lockfields: 'bool', confirmdelete: 'bool', databasename: 'text', recordsource: 'text', connect: 'text', recordsettype: 'enum', eofaction: 'enum', bofaction: 'enum', readonly: 'bool', exclusive: 'bool', caption: 'text', text: 'text', tag: 'text', tooltiptext: 'text', passwordchar: 'char', linktopic: 'text', datafield: 'text', datasource: 'text', helpcontextid: 'num',
  left: 'num', top: 'num', width: 'num', height: 'num', tabindex: 'num', index: 'num', maxlength: 'num', interval: 'num', min: 'num', max: 'num', value: 'num', smallchange: 'num', largechange: 'num',
  x1: 'num', y1: 'num', x2: 'num', y2: 'num', borderwidth: 'num', drawwidth: 'num', scalewidth: 'num', scaleheight: 'num', scaleleft: 'num', scaletop: 'num', clientwidth: 'num', clientheight: 'num', clientleft: 'num', clienttop: 'num',
  visible: 'bool', enabled: 'bool', tabstop: 'bool', multiline: 'bool', locked: 'bool', autosize: 'bool', wordwrap: 'bool', default: 'bool', cancel: 'bool', sorted: 'bool', stretch: 'bool', autoredraw: 'bool',
  controlbox: 'bool', minbutton: 'bool', maxbutton: 'bool', keypreview: 'bool', mdichild: 'bool', showintaskbar: 'bool', checked: 'bool', hideselection: 'bool', integralheight: 'bool', clipcontrols: 'bool', moveable: 'bool', whatsthishelp: 'bool', negotiate: 'bool', windowlist: 'bool', usemnemonic: 'bool', righttoleft: 'bool', causesvalidation: 'bool',
  backcolor: 'color', forecolor: 'color', fillcolor: 'color', bordercolor: 'color', maskcolor: 'color',
  font: 'font', picture: 'picture', icon: 'picture', downpicture: 'picture', disabledpicture: 'picture', mouseicon: 'picture',
  borderstyle: 'enum', alignment: 'enum', backstyle: 'enum', scrollbars: 'enum', style: 'enum', multiselect: 'enum', shape: 'enum', fillstyle: 'enum', scalemode: 'enum', startupposition: 'enum', windowstate: 'enum', appearance: 'enum', mousepointer: 'enum', drawstyle: 'enum', drawmode: 'num', shortcut: 'text',
};
// Tipo -> definição
const CTL = {
  'VB.Form': { tool: false, props: ['Name', 'Caption', 'BackColor', 'ForeColor', 'Font', 'BorderStyle:borderstyle_form', 'ControlBox', 'MinButton', 'MaxButton', 'Icon', 'Picture', 'StartUpPosition:startup', 'WindowState:windowstate', 'ScaleMode:scalemode', 'ScaleWidth', 'ScaleHeight', 'KeyPreview', 'AutoRedraw', 'Enabled', 'Visible', 'MDIChild', 'ShowInTaskbar', 'Moveable', 'Tag', 'Left', 'Top', 'Width', 'Height', 'ClientWidth', 'ClientHeight', 'DrawWidth', 'FillColor', 'FillStyle:fillstyle', 'MousePointer:mousepointer'],
    events: ['Activate', 'Click', 'DblClick', 'Deactivate', 'GotFocus', 'Initialize', 'KeyDown', 'KeyPress', 'KeyUp', 'Load', 'LostFocus', 'MouseDown', 'MouseMove', 'MouseUp', 'Paint', 'QueryUnload', 'Resize', 'Terminate', 'Unload'], defEvent: 'Load' },
  'VB.MDIForm': { tool: false, props: ['Name', 'Caption', 'BackColor', 'Icon', 'Picture', 'StartUpPosition:startup', 'WindowState:windowstate', 'Left', 'Top', 'Width', 'Height', 'Tag', 'AutoShowChildren'], events: ['Activate', 'Click', 'Deactivate', 'Initialize', 'Load', 'MouseDown', 'MouseMove', 'MouseUp', 'QueryUnload', 'Resize', 'Terminate', 'Unload'], defEvent: 'Load' },
  'VB.PictureBox': { tool: 'PictureBox', w: 1215, h: 975, props: [...P_COMMON, 'BackColor', 'ForeColor', 'Font', 'BorderStyle:borderstyle', 'Appearance:appearance', 'Picture', 'AutoSize', 'AutoRedraw', 'ScaleMode:scalemode', 'ScaleWidth', 'ScaleHeight', 'DrawWidth', 'FillColor', 'FillStyle:fillstyle', 'Align'], events: ['Change', 'Click', 'DblClick', 'GotFocus', 'KeyDown', 'KeyPress', 'KeyUp', 'LostFocus', 'MouseDown', 'MouseMove', 'MouseUp', 'Paint', 'Resize'], defEvent: 'Click', container: true },
  'VB.Label': { tool: 'Label', w: 1215, h: 255, props: [...P_COMMON.filter(p => p !== 'TabStop'), 'Caption', 'Alignment:alignment', 'AutoSize', 'WordWrap', 'BackColor', 'BackStyle:backstyle', 'BorderStyle:borderstyle', 'ForeColor', 'Font', 'Appearance:appearance', 'UseMnemonic', 'DataSource', 'DataField'], events: ['Change', 'Click', 'DblClick', 'MouseDown', 'MouseMove', 'MouseUp'], defEvent: 'Click' },
  'VB.TextBox': { tool: 'TextBox', w: 1215, h: 285, props: [...P_COMMON, 'Text', 'Alignment:alignment', 'BackColor', 'ForeColor', 'Font', 'BorderStyle:borderstyle', 'Appearance:appearance', 'Locked', 'MaxLength', 'MultiLine', 'PasswordChar', 'ScrollBars:scrollbars', 'HideSelection', 'Mask', 'DataSource', 'DataField', 'Corners:corners'], events: ['Change', 'Click', 'DblClick', 'GotFocus', 'KeyDown', 'KeyPress', 'KeyUp', 'LostFocus', 'MouseDown', 'MouseMove', 'MouseUp', 'Validate'], defEvent: 'Change' },
  'VB.Frame': { tool: 'Frame', w: 1695, h: 1215, props: [...P_COMMON.filter(p => p !== 'TabStop'), 'Caption', 'BackColor', 'ForeColor', 'Font', 'BorderStyle:borderstyle', 'Appearance:appearance'], events: ['Click', 'DblClick', 'MouseDown', 'MouseMove', 'MouseUp'], defEvent: 'Click', container: true },
  'VB.CommandButton': { tool: 'CommandButton', w: 1215, h: 495, props: [...P_COMMON, 'Caption', 'Alignment:alignment', 'Default', 'Cancel', 'Style:btnstyle', 'BackColor', 'Font', 'Picture', 'DownPicture', 'DisabledPicture', 'Corners:corners'], events: ['Click', 'GotFocus', 'KeyDown', 'KeyPress', 'KeyUp', 'LostFocus', 'MouseDown', 'MouseMove', 'MouseUp'], defEvent: 'Click' },
  'VB.CheckBox': { tool: 'CheckBox', w: 1215, h: 255, props: [...P_COMMON, 'Caption', 'Value:checkvalue', 'Alignment:alignment', 'BackColor', 'ForeColor', 'Font', 'Style:btnstyle', 'DataSource', 'DataField'], events: ['Click', 'GotFocus', 'KeyDown', 'KeyPress', 'KeyUp', 'LostFocus', 'MouseDown', 'MouseMove', 'MouseUp'], defEvent: 'Click' },
  'VB.OptionButton': { tool: 'OptionButton', w: 1215, h: 255, props: [...P_COMMON, 'Caption', 'Value', 'Alignment:alignment', 'BackColor', 'ForeColor', 'Font', 'Style:btnstyle'], events: ['Click', 'DblClick', 'GotFocus', 'KeyDown', 'KeyPress', 'KeyUp', 'LostFocus', 'MouseDown', 'MouseMove', 'MouseUp'], defEvent: 'Click', boolValue: true },
  'VB.ComboBox': { tool: 'ComboBox', w: 1455, h: 315, props: [...P_COMMON, 'Text', 'Style:combostyle', 'Sorted', 'BackColor', 'ForeColor', 'Font', 'List', 'ItemData', 'DataSource', 'DataField', 'Corners:corners'], events: ['Change', 'Click', 'DblClick', 'DropDown', 'GotFocus', 'KeyDown', 'KeyPress', 'KeyUp', 'LostFocus', 'Scroll'], defEvent: 'Change' },
  'VB.ListBox': { tool: 'ListBox', w: 1215, h: 1035, props: [...P_COMMON, 'BackColor', 'ForeColor', 'Font', 'MultiSelect:multiselect', 'Sorted', 'Style:liststyle', 'Columns', 'IntegralHeight', 'List', 'ItemData', 'DataSource', 'DataField', 'Corners:corners'], events: ['Click', 'DblClick', 'GotFocus', 'ItemCheck', 'KeyDown', 'KeyPress', 'KeyUp', 'LostFocus', 'MouseDown', 'MouseMove', 'MouseUp', 'Scroll'], defEvent: 'Click' },
  'VB.HScrollBar': { tool: 'HScrollBar', w: 1215, h: 255, props: [...P_COMMON, 'Min', 'Max', 'Value', 'SmallChange', 'LargeChange'], events: ['Change', 'GotFocus', 'KeyDown', 'KeyPress', 'KeyUp', 'LostFocus', 'Scroll'], defEvent: 'Change' },
  'VB.VScrollBar': { tool: 'VScrollBar', w: 255, h: 1215, props: [...P_COMMON, 'Min', 'Max', 'Value', 'SmallChange', 'LargeChange'], events: ['Change', 'GotFocus', 'KeyDown', 'KeyPress', 'KeyUp', 'LostFocus', 'Scroll'], defEvent: 'Change' },
  'VB.Timer': { tool: 'Timer', w: 420, h: 420, fixedSize: true, props: ['Name', 'Index', 'Enabled', 'Interval', 'Left', 'Top', 'Tag'], events: ['Timer'], defEvent: 'Timer', invisible: true },
  'VB.DriveListBox': { tool: 'DriveListBox', w: 1455, h: 315, props: [...P_COMMON, 'BackColor', 'ForeColor', 'Font'], events: ['Change', 'GotFocus', 'KeyDown', 'KeyPress', 'KeyUp', 'LostFocus', 'Scroll'], defEvent: 'Change' },
  'VB.DirListBox': { tool: 'DirListBox', w: 1215, h: 1215, props: [...P_COMMON, 'BackColor', 'ForeColor', 'Font'], events: ['Change', 'Click', 'GotFocus', 'KeyDown', 'KeyPress', 'KeyUp', 'LostFocus', 'MouseDown', 'MouseMove', 'MouseUp', 'Scroll'], defEvent: 'Change' },
  'VB.FileListBox': { tool: 'FileListBox', w: 1215, h: 1035, props: [...P_COMMON, 'BackColor', 'ForeColor', 'Font', 'Pattern', 'MultiSelect:multiselect'], events: ['Click', 'DblClick', 'GotFocus', 'KeyDown', 'KeyPress', 'KeyUp', 'LostFocus', 'MouseDown', 'MouseMove', 'MouseUp', 'PathChange', 'PatternChange', 'Scroll'], defEvent: 'Click' },
  'VB.Shape': { tool: 'Shape', w: 1215, h: 735, props: ['Name', 'Index', 'Shape:shape', 'BackColor', 'BackStyle:backstyle', 'BorderColor', 'BorderStyle:borderstyle_shape', 'BorderWidth', 'FillColor', 'FillStyle:fillstyle', 'Left', 'Top', 'Width', 'Height', 'Visible', 'Tag'], events: [], noFocus: true },
  'VB.Line': { tool: 'Line', w: 0, h: 0, props: ['Name', 'Index', 'BorderColor', 'BorderStyle:borderstyle_shape', 'BorderWidth', 'X1', 'Y1', 'X2', 'Y2', 'Visible', 'Tag'], events: [], noFocus: true, isLine: true },
  'VB.Image': { tool: 'Image', w: 975, h: 975, props: ['Name', 'Index', 'Picture', 'Stretch', 'BorderStyle:borderstyle', 'Appearance:appearance', 'Left', 'Top', 'Width', 'Height', 'Visible', 'Enabled', 'Tag', 'ToolTipText', 'MousePointer:mousepointer'], events: ['Click', 'DblClick', 'MouseDown', 'MouseMove', 'MouseUp'], defEvent: 'Click' },
  'VB.Data': { tool: 'Data', w: 1935, h: 345, props: [...P_COMMON, 'Caption', 'Connect', 'DatabaseName', 'RecordSource', 'RecordsetType:recordsettype', 'ReadOnly', 'Exclusive', 'BOFAction:bofaction', 'EOFAction:eofaction', 'BackColor', 'ForeColor', 'Font'], events: ['Reposition', 'Validate', 'Error'], defEvent: 'Validate' },
  'NB.NavigationBar': { tool: 'NavigationBar (record navigation bar)', w: 4680, h: 630, props: ['Name', 'Index', 'Align:navalign', 'Visible', 'Enabled', 'Tag', 'ToolTipText', 'DataSource', 'DatabaseName', 'RecordSource', 'ButtonOrder', 'ButtonSize:navsize', 'ButtonStyle:navstyle', 'ShowNew', 'ShowCopy', 'ShowPaste', 'ShowUndo', 'ShowRedo', 'ShowSave', 'ShowEdit', 'ShowDelete', 'ShowCancel', 'ShowFirst', 'ShowPrevious', 'ShowRecordNumber', 'ShowNext', 'ShowLast', 'LockFields', 'ConfirmDelete', 'BackColor', 'ForeColor', 'Font', 'Left', 'Top', 'Width', 'Height'], events: ['Reposition', 'Error'], defEvent: 'Reposition', noFocus: true },
  'VB.OLE': { tool: false, props: P_COMMON, events: [] },
  'VB.Menu': { tool: false, props: ['Name', 'Index', 'Caption', 'Checked', 'Enabled', 'Visible', 'Shortcut', 'WindowList', 'Tag'], events: ['Click'], defEvent: 'Click' },
};
const TOOL_ORDER = ['VB.PictureBox', 'VB.Label', 'VB.TextBox', 'VB.Frame', 'VB.CommandButton', 'VB.CheckBox', 'VB.OptionButton', 'VB.ComboBox', 'VB.ListBox', 'VB.HScrollBar', 'VB.VScrollBar', 'VB.Timer', 'VB.DriveListBox', 'VB.DirListBox', 'VB.FileListBox', 'VB.Shape', 'VB.Line', 'VB.Image', 'VB.Data', 'NB.NavigationBar'];
function ctlDef(type) { return CTL[type] || CTL[Object.keys(CTL).find(k => k.toLowerCase() === String(type).toLowerCase())] || { tool: false, props: P_COMMON, events: ['Click'], unknown: true }; }
function ctlBaseName(type) {
  const map = { 'VB.PictureBox': 'Picture', 'VB.Label': 'Label', 'VB.TextBox': 'Text', 'VB.Frame': 'Frame', 'VB.CommandButton': 'Command', 'VB.CheckBox': 'Check', 'VB.OptionButton': 'Option', 'VB.ComboBox': 'Combo', 'VB.ListBox': 'List', 'VB.HScrollBar': 'HScroll', 'VB.VScrollBar': 'VScroll', 'VB.Timer': 'Timer', 'VB.DriveListBox': 'Drive', 'VB.DirListBox': 'Dir', 'VB.FileListBox': 'File', 'VB.Shape': 'Shape', 'VB.Line': 'Line', 'VB.Image': 'Image', 'VB.Data': 'Data', 'NB.NavigationBar': 'NavigationBar' };
  return map[type] || type.split('.').pop();
}
// Valores padrão (como o VB os assume quando ausentes no .frm)
function defaultProps(type) {
  const d = { visible: true, enabled: true, tabstop: true, backcolor: -2147483633, forecolor: -2147483630, caption: '', text: '', tag: '', tooltiptext: '', index: null, left: 0, top: 0, width: 1215, height: 495, borderstyle: 0, alignment: 0, backstyle: 1, appearance: 1, mousepointer: 0 };
  switch (type) {
    case 'VB.Form': Object.assign(d, { borderstyle: 2, controlbox: true, minbutton: true, maxbutton: true, scalemode: 1, startupposition: 0, windowstate: 0, keypreview: false, autoredraw: false, clientwidth: 4680, clientheight: 3195, drawwidth: 1, fillstyle: 1, fillcolor: 0, mdichild: false, moveable: true }); break;
    case 'VB.MDIForm': Object.assign(d, { autoshowchildren: true, backcolor: -2147483636, startupposition: 0, windowstate: 0, borderstyle: 2, controlbox: true, minbutton: true, maxbutton: true }); break;
    case 'VB.TextBox': Object.assign(d, { corners: 2, backcolor: -2147483643, forecolor: -2147483640, borderstyle: 1, multiline: false, locked: false, maxlength: 0, passwordchar: '', scrollbars: 0, text: '' }); break;
    case 'VB.Label': Object.assign(d, { backstyle: 1, wordwrap: false, autosize: false, usemnemonic: true }); break;
    case 'VB.PictureBox': Object.assign(d, { backcolor: -2147483633, borderstyle: 1, scalemode: 1, autosize: false, autoredraw: false, drawwidth: 1, fillstyle: 1, fillcolor: 0 }); break;
    case 'VB.ListBox': Object.assign(d, { corners: 1, backcolor: -2147483643, forecolor: -2147483640, multiselect: 0, sorted: false, style: 0 }); break;
    case 'VB.ComboBox': Object.assign(d, { corners: 2, backcolor: -2147483643, forecolor: -2147483640, style: 0, sorted: false }); break;
    case 'VB.CommandButton': Object.assign(d, { alignment: 2, corners: 2 }); break; // NeoBasic: alinhamento do texto do botão (padrão: centro, como no VB)
    case 'VB.CheckBox': case 'VB.OptionButton': Object.assign(d, { value: 0, style: 0 }); break;
    case 'VB.HScrollBar': case 'VB.VScrollBar': Object.assign(d, { min: 0, max: 32767, value: 0, smallchange: 1, largechange: 1 }); break;
    case 'VB.Timer': Object.assign(d, { interval: 0, enabled: true }); break;
    case 'VB.Shape': Object.assign(d, { shape: 0, backstyle: 0, backcolor: -2147483643, bordercolor: -2147483640, borderstyle: 1, borderwidth: 1, fillcolor: 0, fillstyle: 1 }); break;
    case 'VB.Line': Object.assign(d, { bordercolor: -2147483640, borderstyle: 1, borderwidth: 1, x1: 0, y1: 0, x2: 0, y2: 0 }); break;
    case 'VB.Image': Object.assign(d, { stretch: false, borderstyle: 0 }); break;
    case 'VB.Frame': Object.assign(d, { borderstyle: 1 }); break;
    case 'VB.Data': Object.assign(d, { recordsettype: 1, readonly: false, exclusive: false, eofaction: 0, bofaction: 0, connect: '', databasename: '', recordsource: '' }); break;
    case 'VB.Menu': Object.assign(d, { checked: false }); break;
    case 'NB.NavigationBar': Object.assign(d, { datasource: '', databasename: '', recordsource: '', align: 1, buttonorder: '', buttonsize: 1, buttonstyle: 0, showcopy: true, showpaste: true, showundo: true, showredo: true, showfirst: true, showprevious: true, shownext: true, showlast: true, showrecordnumber: true, shownew: true, showedit: true, showdelete: true, showsave: true, showcancel: true, lockfields: true, confirmdelete: true, height: 630 }); break;
  }
  return d;
}

// Lê propriedades de um CtlNode para um objeto JS (chaves minúsculas)
function nodeProps(node, frxLookup) {
  const P = defaultProps(node.type);
  for (const p of node.props) {
    const k = p.key.toLowerCase(); let v = rawToValue(p.raw);
    if (v && typeof v === 'object' && v.frx !== undefined) {
      const bytes = frxLookup ? frxLookup(v.frx) : null;
      if (k === 'list') v = bytes ? (frxRead(bytes, v.offset, 'list') || []) : [];
      else if (k === 'itemdata') v = bytes ? (frxRead(bytes, v.offset, 'itemdata') || []) : [];
      else if (PROP_TYPES[k] === 'picture') { const img = bytes ? frxRead(bytes, v.offset, 'image') : null; const mime = imageMime(img); v = mime ? { url: bytesToDataURL(img, mime), bytes: img } : null; }
      else v = bytes ? (frxRead(bytes, v.offset, v.isString ? 'string4' : 'text') || '') : '';
    }
    if (PROP_TYPES[k] === 'bool') v = Number(v) !== 0;
    P[k] = v;
  }
  P.font = fontFromBlock(node.block('Font'));
  P.name = node.name;
  if (node._pending) for (const k in node._pending) P[k] = node._pending[k]; // imagens novas ainda não salvas
  return P;
}

// ---------- Escalas ----------
function unitPx(scaleMode, clientPx, scaleSize) {
  switch (Number(scaleMode)) {
    case 1: case undefined: return 1 / 15;
    case 2: return 4 / 3; case 3: return 1; case 4: return 1 / 15 * 120; case 5: return 96; case 6: return 96 / 25.4; case 7: return 96 / 2.54;
    case 0: return scaleSize ? clientPx / scaleSize : 1 / 15;
  }
  return 1 / 15;
}
function mnemonicHtml(cap, use) {
  const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  if (use === false) return esc(cap);
  let out = '';
  for (let i = 0; i < cap.length; i++) {
    if (cap[i] === '&') { if (cap[i + 1] === '&') { out += '&amp;'; i++; continue; } if (i + 1 < cap.length) { out += '<u>' + esc(cap[i + 1]) + '</u>'; i++; continue; } }
    else out += esc(cap[i]);
  }
  return out.replace(/\r?\n/g, '<br>');
}
function stripMnemonic(c) { return String(c || '').replace(/&(&?)/g, '$1'); }

// ---------- Renderização (mesma para designer e execução) ----------
// ctx: { design: bool, scale: px por unidade do contêiner }
function createCtlElement(type, P, ctx) {
  const el = document.createElement('div');
  el.className = 'vbc vbc-' + type.replace(/^(VB|NB)\./, '').toLowerCase();
  el.dataset.type = type;
  const inner = buildInner(type, P, ctx, el);
  if (inner) el.appendChild(inner);
  updateCtlElement(el, type, P, ctx);
  return el;
}
function buildInner(type, P, ctx, el) {
  switch (type) {
    case 'VB.TextBox': { const t = document.createElement(P.multiline ? 'textarea' : 'input'); if (!P.multiline) t.type = 'text'; t.className = 'vb-input'; t.spellcheck = false; if (ctx.design) { t.readOnly = true; t.tabIndex = -1; } return t; }
    case 'VB.CheckBox': case 'VB.OptionButton': { const l = document.createElement('label'); l.className = 'vb-check'; l.innerHTML = `<span class="vb-box ${type === 'VB.CheckBox' ? 'chk' : 'opt'}"></span><span class="vb-cap"></span>`; return l; }
    case 'VB.ListBox': case 'VB.FileListBox': case 'VB.DirListBox': { const d = document.createElement('div'); d.className = 'vb-list'; d.tabIndex = ctx.design ? -1 : 0; return d; }
    case 'VB.ComboBox': case 'VB.DriveListBox': { const d = document.createElement('div'); d.className = 'vb-combo'; d.innerHTML = `<input class="vb-input" spellcheck="false"><span class="vb-dd">▾</span>`; if (ctx.design) { d.firstChild.readOnly = true; d.firstChild.tabIndex = -1; } return d; }
    case 'VB.Frame': { const d = document.createElement('div'); d.className = 'vb-framecap'; return d; }
    case 'VB.HScrollBar': case 'VB.VScrollBar': { const d = document.createElement('div'); d.className = 'vb-sb'; d.innerHTML = `<span class="vb-sb-a1"></span><span class="vb-sb-track"><span class="vb-sb-thumb"></span></span><span class="vb-sb-a2"></span>`; return d; }
    case 'VB.Shape': case 'VB.Line': { const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); s.setAttribute('class', 'vb-svg'); return s; }
    case 'VB.Image': { const i = document.createElement('img'); i.className = 'vb-img'; i.draggable = false; return i; }
    case 'VB.PictureBox': { const c = document.createElement('canvas'); c.className = 'vb-canvas'; return c; }
    case 'VB.CommandButton': { const s = document.createElement('span'); s.className = 'vb-btncap'; return s; }
    case 'VB.Label': { const s = document.createElement('span'); s.className = 'vb-labelcap'; return s; }
    case 'VB.Timer': { const s = document.createElement('span'); s.className = 'vb-icon-timer'; s.textContent = '⏱'; return s; }
    case 'NB.NavigationBar': { const d = document.createElement('div'); d.className = 'nb-nav'; return d; }
    case 'VB.Data': { const d = document.createElement('div'); d.className = 'vb-data'; d.innerHTML = '<b>|◂</b><b>◂</b><span class="vb-datacap"></span><b>▸</b><b>▸|</b>'; return d; }
  }
  if (ctlDef(type).unknown) {
    const d = document.createElement('div'); d.className = 'vb-unknown';
    if (/progressbar/i.test(type)) d.innerHTML = '<div class="vb-pb"></div>';
    else if (/statusbar/i.test(type)) d.innerHTML = '<div class="vb-status"></div>';
    else d.textContent = type.split('.').pop();
    return d;
  }
  return null;
}
function px(v) { return Math.round(v * 100) / 100 + 'px'; }
function updateCtlElement(el, type, P, ctx) {
  const s = ctx.scale || 1 / 15;
  const def = ctlDef(type);
  const st = el.style;
  if (def.isLine) {
    const x1 = P.x1 * s, y1 = P.y1 * s, x2 = P.x2 * s, y2 = P.y2 * s, bw = Math.max(1, P.borderwidth || 1);
    const l = Math.min(x1, x2) - bw, t = Math.min(y1, y2) - bw, w = Math.abs(x2 - x1) + 2 * bw, h = Math.abs(y2 - y1) + 2 * bw;
    Object.assign(st, { left: px(l), top: px(t), width: px(w), height: px(h) });
    const svg = el.firstChild; svg.setAttribute('width', w); svg.setAttribute('height', h);
    svg.innerHTML = `<line x1="${x1 - l}" y1="${y1 - t}" x2="${x2 - l}" y2="${y2 - t}" stroke="${vbColorCss(P.bordercolor)}" stroke-width="${bw}" ${dashArray(P.borderstyle, bw)} ${P.borderstyle === 0 ? 'stroke-opacity="0"' : ''}/>`;
    st.display = (P.visible || ctx.design) ? '' : 'none';
    return;
  }
  const W = Math.max(0, (def.fixedSize && ctx.design ? 420 / 15 : P.width * s)), H = Math.max(0, (def.fixedSize && ctx.design ? 420 / 15 : P.height * s));
  Object.assign(st, { left: px(P.left * s), top: px(P.top * s), width: px(W), height: px(H) });
  st.display = (P.visible || ctx.design) ? '' : 'none';
  if (def.invisible && !ctx.design) st.display = 'none';
  if (type === 'VB.TextBox' || type === 'VB.ComboBox' || type === 'VB.ListBox' || type === 'VB.CommandButton') { el.classList.remove('nb-c0', 'nb-c1', 'nb-c2', 'nb-ml'); el.classList.add('nb-c' + (P.corners == null ? 1 : P.corners)); if (type === 'VB.TextBox' && P.multiline) el.classList.add('nb-ml'); }
  el.classList.toggle('vb-disabled', !P.enabled);
  el.classList.toggle('nb-navlock', !!P._navlock && !ctx.design);
  if (P.tooltiptext && !ctx.design) el.title = P.tooltiptext; else el.removeAttribute('title');
  applyFont(el, P.font);
  const bg = vbColorCss(P.backcolor), fg = vbColorCss(P.forecolor);
  const cursor = { 1: 'default', 2: 'crosshair', 3: 'text', 5: 'move', 7: 'ns-resize', 9: 'ew-resize', 11: 'wait', 12: 'no-drop', 13: 'progress', 14: 'help', 15: 'move' }[P.mousepointer];
  st.cursor = (!ctx.design && cursor) ? cursor : '';
  switch (type) {
    case 'VB.CommandButton': {
      // NeoBasic: no estilo moderno o botão é azul por padrão; uma BackColor escolhida vale mesmo sem Style = Graphical
      const sysFace = P.backcolor === -2147483633 || P.backcolor == null;
      const modern = typeof NB_SKIN !== 'undefined' && NB_SKIN === 'modern';
      el.classList.toggle('nb-blue', modern && sysFace);
      if (modern && !sysFace) { st.backgroundColor = bg; st.backgroundImage = 'none'; st.borderColor = 'rgba(0,0,0,.18)'; st.color = nbTextOn(bg); }
      else { st.backgroundColor = P.style === 1 ? bg : ''; st.backgroundImage = ''; st.borderColor = ''; st.color = ''; }
      const cap = el.querySelector('.vb-btncap');
      const captionHtml = mnemonicHtml(String(P.caption || ''));
      const pictureHtml = P.style === 1 && P.picture && P.picture.url
        ? `<img src="${P.picture.url}" draggable="false" alt="">` : '';
      cap.innerHTML = pictureHtml + `<span class="vb-btntext">${captionHtml}</span>`;
      el.classList.toggle('vb-default', !!P.default);
      const al = ['left', 'right', 'center'][P.alignment] || 'center';
      el.classList.remove('al-left', 'al-right', 'al-center'); el.classList.add('al-' + al);
      break;
    }
    case 'VB.Label': {
      st.backgroundColor = P.backstyle === 0 ? 'transparent' : bg; st.color = fg;
      st.textAlign = ['left', 'right', 'center'][P.alignment] || 'left';
      el.classList.toggle('vb-border1', P.borderstyle === 1);
      el.classList.toggle('vb-autosize', !!P.autosize);
      el.classList.toggle('vb-nowrap', !!P.autosize && !P.wordwrap);
      el.querySelector('.vb-labelcap').innerHTML = mnemonicHtml(String(P.caption ?? ''), P.usemnemonic !== false);
      if (P.autosize) { st.width = P.wordwrap ? px(W) : 'auto'; st.height = 'auto'; }
      break;
    }
    case 'VB.TextBox': {
      const t = el.firstChild;
      if ((t.tagName === 'TEXTAREA') !== !!P.multiline) { const n = buildInner(type, P, ctx, el); el.replaceChild(n, t); return updateCtlElement(el, type, P, ctx); }
      if (t.value !== String(P.text ?? '')) t.value = String(P.text ?? '');
      t.style.backgroundColor = bg; t.style.color = fg; t.style.textAlign = ['left', 'right', 'center'][P.alignment] || 'left';
      applyFont(t, P.font);
      el.classList.toggle('vb-border1', P.borderstyle === 1); el.classList.toggle('vb-flat', P.appearance === 0);
      if (!P.multiline && t.type !== undefined) t.type = P.passwordchar ? 'password' : 'text';
      if (P.multiline) t.style.overflowY = (P.scrollbars & 2) ? 'scroll' : 'hidden', t.style.overflowX = (P.scrollbars & 1) ? 'scroll' : 'hidden', t.wrap = (P.scrollbars & 1) ? 'off' : 'soft';
      if (!ctx.design) { t.readOnly = !!P.locked || !!P._navlock; t.disabled = !P.enabled; if (P.maxlength) t.maxLength = P.maxlength; else t.removeAttribute('maxlength'); }
      if (P.mask && !P.multiline) t.placeholder = nbMaskHint(P.mask); else t.removeAttribute('placeholder');
      break;
    }
    case 'VB.CheckBox': case 'VB.OptionButton': {
      st.backgroundColor = bg; st.color = fg;
      el.querySelector('.vb-cap').innerHTML = mnemonicHtml(String(P.caption || ''));
      const box = el.querySelector('.vb-box');
      const val = type === 'VB.OptionButton' ? !!(P.value && P.value !== 0) : Number(P.value) || 0;
      box.classList.toggle('on', type === 'VB.OptionButton' ? val : val === 1);
      box.classList.toggle('gray', val === 2);
      el.querySelector('.vb-check').classList.toggle('right', P.alignment === 1);
      break;
    }
    case 'VB.Frame': {
      st.backgroundColor = bg; st.color = fg;
      el.classList.toggle('vb-noborder', P.borderstyle === 0);
      const cap = el.querySelector('.vb-framecap'); cap.innerHTML = mnemonicHtml(String(P.caption || '')); cap.style.display = P.caption ? '' : 'none'; cap.style.backgroundColor = bg;
      break;
    }
    case 'VB.ListBox': case 'VB.FileListBox': case 'VB.DirListBox': {
      const d = el.firstChild; d.style.backgroundColor = bg; d.style.color = fg;
      let items = P.list || [];
      if (ctx.design && !items.length) items = [P.name];
      renderListItems(d, items, P, type === 'VB.ListBox' && P.style === 1);
      break;
    }
    case 'VB.ComboBox': case 'VB.DriveListBox': {
      const inp = el.querySelector('input'); inp.style.backgroundColor = bg; inp.style.color = fg; applyFont(inp, P.font);
      const txt = type === 'VB.DriveListBox' ? 'c: [NEOBASIC]' : (ctx.design ? (P.text || P.name) : (P.text ?? ''));
      if (inp.value !== txt) inp.value = txt;
      inp.readOnly = ctx.design || P.style === 2 || type === 'VB.DriveListBox' || !!P._navlock;
      el.classList.toggle('vb-combo-simple', P.style === 1);
      if (P.style !== 1) { st.height = px(Math.max(H, 21)); }
      break;
    }
    case 'VB.HScrollBar': case 'VB.VScrollBar': {
      const vert = type === 'VB.VScrollBar'; el.classList.toggle('vert', vert);
      const min = Number(P.min) || 0, max = Number(P.max), val = Number(P.value) || 0;
      const range = max - min; const frac = range === 0 ? 0 : (val - min) / range;
      const thumb = el.querySelector('.vb-sb-thumb');
      const track = el.querySelector('.vb-sb-track');
      const len = vert ? H - 2 * Math.min(W, 17) : W - 2 * Math.min(H, 17);
      const th = Math.max(8, Math.min(len, Math.min(vert ? W : H, 17)));
      thumb.style[vert ? 'height' : 'width'] = px(th); thumb.style[vert ? 'width' : 'height'] = '100%';
      thumb.style[vert ? 'top' : 'left'] = px(Math.max(0, (len - th) * frac)); thumb.style[vert ? 'left' : 'top'] = '0';
      const a = Math.min(vert ? W : H, 17);
      el.querySelectorAll('.vb-sb-a1,.vb-sb-a2').forEach(x => { x.style.width = vert ? '100%' : px(a); x.style.height = vert ? px(a) : '100%'; });
      track.dataset.len = len; track.dataset.th = th;
      break;
    }
    case 'VB.Shape': {
      const svg = el.firstChild; svg.setAttribute('width', W); svg.setAttribute('height', H);
      const bw = Math.max(1, P.borderwidth || 1), half = bw / 2;
      let sw = W, sh = H, x = 0, y = 0;
      if (P.shape === 1 || P.shape === 3 || P.shape === 5) { const m = Math.min(W, H); x = (W - m) / 2; y = (H - m) / 2; sw = sh = m; }
      const fill = P.fillstyle === 1 ? (P.backstyle === 1 ? vbColorCss(P.backcolor) : 'none') : (P.fillstyle === 0 ? vbColorCss(P.fillcolor) : `url(#hatch)`);
      const stroke = P.borderstyle === 0 ? 'none' : vbColorCss(P.bordercolor);
      let defs = '';
      if (P.fillstyle >= 2) { const c = vbColorCss(P.fillcolor); const pat = { 2: 'M0,4 L8,4', 3: 'M4,0 L4,8', 4: 'M0,8 L8,0', 5: 'M0,0 L8,8', 6: 'M0,4 L8,4 M4,0 L4,8', 7: 'M0,0 L8,8 M0,8 L8,0' }[P.fillstyle]; defs = `<defs><pattern id="hatch" width="8" height="8" patternUnits="userSpaceOnUse">${P.backstyle === 1 ? `<rect width="8" height="8" fill="${vbColorCss(P.backcolor)}"/>` : ''}<path d="${pat}" stroke="${c}" stroke-width="1"/></pattern></defs>`; }
      const attrs = `fill="${fill}" stroke="${stroke}" stroke-width="${bw}" ${dashArray(P.borderstyle, bw)}`;
      let shp;
      if (P.shape === 2 || P.shape === 3) shp = `<ellipse cx="${x + sw / 2}" cy="${y + sh / 2}" rx="${Math.max(0, sw / 2 - half)}" ry="${Math.max(0, sh / 2 - half)}" ${attrs}/>`;
      else { const r = (P.shape === 4 || P.shape === 5) ? Math.min(sw, sh) / 6 : 0; shp = `<rect x="${x + half}" y="${y + half}" width="${Math.max(0, sw - bw)}" height="${Math.max(0, sh - bw)}" rx="${r}" ${attrs}/>`; }
      svg.innerHTML = defs + shp;
      break;
    }
    case 'VB.Image': {
      const img = el.firstChild;
      if (P.picture && P.picture.url) { if (img.getAttribute('src') !== P.picture.url) img.src = P.picture.url; img.style.display = ''; }
      else { img.removeAttribute('src'); img.style.display = 'none'; }
      img.classList.toggle('stretch', !!P.stretch);
      el.classList.toggle('vb-border1', P.borderstyle === 1);
      el.classList.toggle('vb-design-empty', ctx.design && !(P.picture && P.picture.url));
      if (!P.stretch && P.picture && P.picture.url && !ctx.design) { /* tamanho natural */ }
      break;
    }
    case 'VB.PictureBox': {
      st.backgroundColor = bg; st.color = fg;
      el.classList.toggle('vb-border1', P.borderstyle === 1); el.classList.toggle('vb-flat', P.appearance === 0);
      st.backgroundImage = P.picture && P.picture.url ? `url(${P.picture.url})` : '';
      break;
    }
    case 'VB.Data': { el.querySelector('.vb-datacap').textContent = P.caption || ''; st.backgroundColor = bg; break; }
    case 'NB.NavigationBar': {
      // gruda no topo do formulário (abaixo do menu) e vai até o fim da largura
      if (typeof nbNavHtml === 'function') el.firstChild.innerHTML = nbNavHtml(P, ctx);
      el.classList.remove('nv-s0', 'nv-s1', 'nv-s2'); el.classList.add('nv-s' + (Number(P.buttonsize) >= 0 && Number(P.buttonsize) <= 2 ? Number(P.buttonsize) : 1));
      const nh = [32, 42, 54][Number(P.buttonsize) >= 0 && Number(P.buttonsize) <= 2 ? Number(P.buttonsize) : 1] + 'px';
      const al = P.align === undefined || P.align === null ? 1 : Number(P.align);
      if (al === 1) Object.assign(st, { left: '0px', top: '0px', bottom: '', width: '100%', height: nh });
      else if (al === 2) Object.assign(st, { left: '0px', top: 'auto', bottom: '0px', width: '100%', height: nh });
      else Object.assign(st, { bottom: '', height: nh });
      el.classList.toggle('nv-free', al !== 1 && al !== 2); el.classList.toggle('nv-bottom', al === 2);
      st.backgroundColor = P.backcolor === -2147483633 ? '' : bg; st.color = P.forecolor === -2147483630 ? '' : fg; break;
    }
    case 'VB.Timer': break;
    default:
      if (def.unknown) {
        const pb = el.querySelector('.vb-pb'); if (pb) { const mn = Number(P.min) || 0, mx = P.max !== undefined ? Number(P.max) : 100; pb.style.width = (Math.max(0, Math.min(1, ((Number(P.value) || 0) - mn) / ((mx - mn) || 1))) * 100) + '%'; }
        const sb = el.querySelector('.vb-status'); if (sb) sb.textContent = P.simpletext || '';
      }
  }
}
function nbTextOn(css) { const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})/i.exec(css || '') || /rgb\((\d+),\s*(\d+),\s*(\d+)/.exec(css || ''); if (!m) return ''; const [r, g, b] = m.slice(1, 4).map(x => /^\d+$/.test(x) && !/^#/.test(css) ? +x : parseInt(x, 16)); return (0.299 * r + 0.587 * g + 0.114 * b) > 150 ? '#1b1f27' : '#ffffff'; }
function dashArray(style, bw) { const m = { 2: [4, 2], 3: [1, 2], 4: [4, 2, 1, 2], 5: [4, 2, 1, 2, 1, 2] }[style]; return m ? `stroke-dasharray="${m.map(x => x * Math.max(1, bw)).join(',')}"` : ''; }
function renderListItems(d, items, P, checkStyle) {
  const sel = P._sel || new Set();
  d.innerHTML = '';
  items.forEach((it, i) => {
    const r = document.createElement('div'); r.className = 'vb-li' + (sel.has(i) ? ' sel' : '');
    r.dataset.i = i;
    r.innerHTML = (checkStyle ? `<span class="vb-box chk${P._checked && P._checked.has(i) ? ' on' : ''}"></span>` : '') + String(it).replace(/&/g, '&amp;').replace(/</g, '&lt;') + '&nbsp;';
    d.appendChild(r);
  });
}

if (typeof module !== 'undefined') module.exports = { vbColorCss, cssToVbColor, SYSCOLORS, CTL, ctlDef, defaultProps, nodeProps, ENUMS, PROP_TYPES, TOOL_ORDER, ctlBaseName, fontFromBlock, fontToBlock, unitPx, stripMnemonic };
