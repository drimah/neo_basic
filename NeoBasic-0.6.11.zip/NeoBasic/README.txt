NeoBasic 0.6.11 - free Visual Basic 5/6-style IDE
================================================

NeoBasic is a free development environment for Visual Basic 5/6-style projects.
It runs on Windows and Linux with the same interface.

This package includes:
- NeoBasic launcher and application
- Complete JavaScript/CSS source code
- Standalone HTML build
- Bundled fonts and application icon

Version 0.6.11:
- NavigationBar buttons match the IDE toolbar (rounded-square hover)
- TextBox Mask property with presets (phone, CPF, CNPJ, CEP, date, time...)
  and ClipText

Version 0.6.10:
- NavigationBar Align property (0 None, 1 Top, 2 Bottom); docking moves the
  other controls so nothing is hidden under the bar
- Pick lists for DatabaseName, RecordSource, DataSource and DataField

Version 0.6.9:
- DataNav renamed NavigationBar: docks at the top of the form (below the menu)
  and fills its width; toolbar-style line icons; ButtonOrder (drag to reorder),
  ButtonSize (Small/Normal/Large); new Copy, Paste, Undo and Redo buttons

Version 0.6.8:
- DataNav control: record navigation bar with First/Previous/Next/Last, New,
  Edit, Delete, Save and Cancel (icons, icons+text or text; each button can be
  hidden); works alone (DatabaseName + RecordSource) or with a Data control
- Rename a project database (double-click it)
- Position and size in the toolbar can be typed
- Right-side panels can be minimized; the Immediate window is hidden (Ctrl+G)

Version 0.6.7:
- New Menu Editor: items and sub-items with drag and drop, and what each item
  does (open a form, close, end, message or your own code)
- Format Painter: copies color, font, size and style to controls of the same kind
- Inkscape-style align and distribute buttons (several controls align to the
  first one selected)
- New Project asks for the startup form

Version 0.6.6 interface updates:
- Light blue-and-white visual theme by default
- Compact Toolbox with two columns of blue line icons
- Circular hover/selection highlight for Toolbox tools
- Capsule-shaped buttons throughout the interface
- English locale by default
- Existing project and runtime files retained

Build:
Run codigo-fonte/build.py with Python 3 to regenerate codigo-fonte/dist/NeoBasic.html.
