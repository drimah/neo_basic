// ===== NeoBasic — formulários e controles em execução =====
'use strict';

let HWND_SEQ = 1000;
const DEFAULT_PROP = { 'VB.TextBox': 'text', 'VB.Label': 'caption', 'VB.CommandButton': 'value', 'VB.CheckBox': 'value', 'VB.OptionButton': 'value', 'VB.ListBox': 'text', 'VB.ComboBox': 'text', 'VB.PictureBox': 'picture', 'VB.Image': 'picture', 'VB.Timer': 'enabled', 'VB.HScrollBar': 'value', 'VB.VScrollBar': 'value', 'VB.Frame': 'caption', 'VB.FileListBox': 'filename', 'VB.DirListBox': 'path', 'VB.DriveListBox': 'drive', 'VB.Data': 'caption', 'VB.Menu': 'caption' };
const BOOL_PROPS = new Set(Object.keys(PROP_TYPES).filter(k => PROP_TYPES[k] === 'bool'));
const NUM_PROPS = new Set(Object.keys(PROP_TYPES).filter(k => PROP_TYPES[k] === 'num' || PROP_TYPES[k] === 'enum' || PROP_TYPES[k] === 'color'));

class VBPicture extends VBObject {
  constructor(url, w, h, bytes) { super(); this.url = url; this.w = w || 0; this.h = h || 0; this.bytes = bytes; this.handle = url ? ++HWND_SEQ : 0; }
  get typeName() { return 'Picture'; }
  get defaultProp() { return 'handle'; }
  async getMember(n) { if (n === 'handle') return this.handle; if (n === 'width') return Math.round(this.w * 26.4583); if (n === 'height') return Math.round(this.h * 26.4583); if (n === 'type') return this.url ? 1 : 0; throw vbErr(438); }
  _sync(n) { return n === 'handle' ? this.handle : 0; }
}
function pictureOf(pv) {
  if (!pv) return null; if (pv instanceof VBPicture) return pv;
  const p = new VBPicture(pv.url, 0, 0, pv.bytes);
  if (typeof Image !== 'undefined' && pv.url) { const im = new Image(); im.onload = () => { p.w = im.naturalWidth; p.h = im.naturalHeight; }; im.src = pv.url; }
  return p;
}
class VBFont extends VBObject {
  constructor(owner) { super(); this.owner = owner; }
  get typeName() { return 'Font'; }
  get defaultProp() { return 'name'; }
  get f() { return this.owner.P.font; }
  _sync(n) { return this.f.name; }
  async getMember(n) { const f = this.f; switch (n) { case 'name': return f.name; case 'size': return f.size; case 'bold': return !!f.bold; case 'italic': return !!f.italic; case 'underline': return !!f.underline; case 'strikethrough': return !!f.strikethrough; case 'weight': return f.bold ? 700 : 400; case 'charset': return f.charset || 0; } throw vbErr(438); }
  async setMember(n, v) { const f = Object.assign({}, this.f); switch (n) { case 'name': f.name = toStr(v); break; case 'size': f.size = toNum(v); break; case 'bold': f.bold = toBool(v); break; case 'italic': f.italic = toBool(v); break; case 'underline': f.underline = toBool(v); break; case 'strikethrough': f.strikethrough = toBool(v); break; case 'weight': f.bold = toNum(v) >= 600; break; case 'charset': break; default: throw vbErr(438); } this.owner.P.font = f; this.owner.refresh(); }
}

// ---------- Superfície gráfica (Form e PictureBox) ----------
const Surface = {
  initSurface(canvas) {
    this.canvas = canvas; this.g = canvas.getContext('2d'); this.cx = 0; this.cy = 0;
  },
  sizeCanvas(wpx, hpx) {
    const c = this.canvas; if (!c) return;
    const dpr = 1; const W = Math.max(1, Math.round(wpx)), H = Math.max(1, Math.round(hpx));
    if (c.width === W && c.height === H) return;
    let old = null; if (c.width > 1 && c.height > 1) { old = document.createElement('canvas'); old.width = c.width; old.height = c.height; old.getContext('2d').drawImage(c, 0, 0); }
    c.width = W; c.height = H; c.style.width = W + 'px'; c.style.height = H + 'px';
    if (old) this.g.drawImage(old, 0, 0);
  },
  // coordenadas de escala -> px
  sx(x) { const P = this.P; return (x - (Number(P.scaleleft) || 0)) * this.selfScaleX(); },
  sy(y) { const P = this.P; return (y - (Number(P.scaletop) || 0)) * this.selfScaleY(); },
  selfScaleX() { const P = this.P; if (Number(P.scalemode) === 0 && P.scalewidth) return this.clientWpx() / P.scalewidth; return unitPx(P.scalemode); },
  selfScaleY() { const P = this.P; if (Number(P.scalemode) === 0 && P.scaleheight) return this.clientHpx() / P.scaleheight; return unitPx(P.scalemode); },
  fgColor() { return vbColorCss(this.P.forecolor) || '#000'; },
  vbCls() { if (!this.g) return; this.g.clearRect(0, 0, this.canvas.width, this.canvas.height); this.cx = Number(this.P.scaleleft) || 0; this.cy = Number(this.P.scaletop) || 0; },
  fontStr() { const c = fontCss(this.P.font); return `${c.fontStyle} ${c.fontWeight} ${c.fontSize} ${c.fontFamily}`; },
  vbPrint(text, newline) {
    if (!this.g) return;
    const g = this.g; g.font = this.fontStr(); g.fillStyle = this.fgColor(); g.textBaseline = 'top';
    const lh = parseFloat(fontCss(this.P.font).fontSize) * 1.2;
    const lines = String(text).split(/\r?\n/);
    lines.forEach((ln, i) => {
      const x = this.sx(this.cx), y = this.sy(this.cy);
      g.fillText(ln, x, y);
      if (i < lines.length - 1 || newline) { this.cx = Number(this.P.scaleleft) || 0; this.cy += lh / this.selfScaleY(); }
      else this.cx += g.measureText(ln).width / this.selfScaleX();
    });
  },
  vbLine(p1, p2, color, box, step1, step2) {
    if (!this.g) return;
    let x1, y1; if (p1) { x1 = p1[0]; y1 = p1[1]; if (step1) { x1 += this.cx; y1 += this.cy; } } else { x1 = this.cx; y1 = this.cy; }
    let x2 = p2[0], y2 = p2[1]; if (step2) { x2 += x1; y2 += y1; }
    const g = this.g; const col = color !== undefined ? vbColorCss(color) : this.fgColor();
    const lw = Math.max(1, Number(this.P.drawwidth) || 1);
    g.lineWidth = lw; g.strokeStyle = col;
    const X1 = this.sx(x1), Y1 = this.sy(y1), X2 = this.sx(x2), Y2 = this.sy(y2);
    if (box) {
      const L = Math.min(X1, X2), T = Math.min(Y1, Y2), W = Math.abs(X2 - X1) + 1, H = Math.abs(Y2 - Y1) + 1;
      if (box === 'bf') { g.fillStyle = col; g.fillRect(L, T, W, H); }
      else { if (Number(this.P.fillstyle) === 0) { g.fillStyle = vbColorCss(this.P.fillcolor); g.fillRect(L, T, W, H); } g.strokeRect(L + 0.5, T + 0.5, W - 1, H - 1); }
    } else {
      g.beginPath(); const o = lw % 2 ? 0.5 : 0; g.moveTo(X1 + o, Y1 + o); g.lineTo(X2 + o, Y2 + o); g.stroke();
      if (lw === 1) { g.fillStyle = col; }
    }
    this.cx = x2; this.cy = y2;
  },
  vbCircle(x, y, r, color, extra) {
    if (!this.g) return;
    const g = this.g; const col = color !== undefined ? vbColorCss(color) : this.fgColor();
    const [st, en, aspect] = extra || [];
    const R = r * this.selfScaleX(); const asp = aspect === undefined ? 1 : aspect;
    let rx = R, ry = R * asp; if (asp > 1) { ry = R; rx = R / asp; }
    g.lineWidth = Math.max(1, Number(this.P.drawwidth) || 1); g.strokeStyle = col;
    g.beginPath();
    if (st !== undefined || en !== undefined) g.ellipse(this.sx(x), this.sy(y), rx, ry, 0, -Math.abs(en || 0), -Math.abs(st || 0));
    else g.ellipse(this.sx(x), this.sy(y), Math.abs(rx), Math.abs(ry), 0, 0, Math.PI * 2);
    if (Number(this.P.fillstyle) === 0) { g.fillStyle = vbColorCss(this.P.fillcolor); g.fill(); }
    g.stroke();
    this.cx = x; this.cy = y;
  },
  vbPSet(x, y, color) {
    if (!this.g) return;
    const g = this.g; g.fillStyle = color !== undefined ? vbColorCss(color) : this.fgColor();
    const w = Math.max(1, Number(this.P.drawwidth) || 1);
    g.fillRect(Math.round(this.sx(x) - (w - 1) / 2), Math.round(this.sy(y) - (w - 1) / 2), w, w);
    this.cx = x; this.cy = y;
  },
  vbPoint(x, y) { if (!this.g) return -1; const d = this.g.getImageData(Math.round(this.sx(x)), Math.round(this.sy(y)), 1, 1).data; if (!d[3]) return toNum(this.P.backcolor) >= 0 ? this.P.backcolor : cssToVbColor(vbColorCss(this.P.backcolor)); return d[0] | (d[1] << 8) | (d[2] << 16); },
  textW(s) { const g = this.g || document.createElement('canvas').getContext('2d'); g.font = this.fontStr(); return g.measureText(toStr(s)).width / this.selfScaleX(); },
  textH(s) { return parseFloat(fontCss(this.P.font).fontSize) * 1.2 * Math.max(1, toStr(s).split(/\r?\n/).length) / this.selfScaleY(); },
  surfaceGet(n) {
    switch (n) {
      case 'currentx': return this.cx; case 'currenty': return this.cy;
      case 'scalewidth': return Number(this.P.scalemode) === 0 && this.P.scalewidth ? this.P.scalewidth : this.clientWpx() / unitPx(this.P.scalemode);
      case 'scaleheight': return Number(this.P.scalemode) === 0 && this.P.scaleheight ? this.P.scaleheight : this.clientHpx() / unitPx(this.P.scalemode);
      case 'scaleleft': return Number(this.P.scaleleft) || 0; case 'scaletop': return Number(this.P.scaletop) || 0;
      case 'image': return new VBPicture(this.canvas ? this.canvas.toDataURL() : '', this.canvas.width, this.canvas.height);
    }
    return undefined;
  },
  surfaceSet(n, v) {
    switch (n) {
      case 'currentx': this.cx = toNum(v); return true; case 'currenty': this.cy = toNum(v); return true;
      case 'scalewidth': this.P.scalewidth = toNum(v); this.P.scalemode = 0; return true;
      case 'scaleheight': this.P.scaleheight = toNum(v); this.P.scalemode = 0; return true;
      case 'scaleleft': this.P.scaleleft = toNum(v); this.P.scalemode = 0; return true;
      case 'scaletop': this.P.scaletop = toNum(v); this.P.scalemode = 0; return true;
      case 'scalemode': this.P.scalemode = toNum(v); if (this.P.scalemode !== 0) { this.P.scaleleft = 0; this.P.scaletop = 0; } this.refreshChildren && this.refreshChildren(); return true;
    }
    return false;
  },
  surfaceCall(n, a) {
    switch (n) {
      case 'cls': this.vbCls(); return { r: undefined };
      case 'textwidth': return { r: this.textW(a[0]) }; case 'textheight': return { r: this.textH(a[0]) };
      case 'point': return { r: this.vbPoint(toNum(a[0]), toNum(a[1])) };
      case 'scale': if (!a.length || a[0] === VBMissing) { this.P.scalemode = 1; this.P.scaleleft = 0; this.P.scaletop = 0; } else { /* Scale (x1,y1)-(x2,y2) via chamada */ } return { r: undefined };
      case 'scalex': case 'scaley': { const v = toNum(a[0]); const from = isMissV(a[1]) ? 8 : toNum(a[1]); const to = isMissV(a[2]) ? (Number(this.P.scalemode)) : toNum(a[2]); const toPx = m => m === 8 ? 1 / 15 * 15 / 15 : unitPx(m); const pxv = v * (from === 8 ? 96 / 2540 : unitPx(from)); return { r: pxv / (to === 8 ? 96 / 2540 : unitPx(to)) }; }
      case 'paintpicture': { const pic = a[0]; if (pic && pic.url) { const im = new Image(); const x = this.sx(toNum(a[1])), y = this.sy(toNum(a[2])); const w = isMissV(a[3]) ? null : toNum(a[3]) * this.selfScaleX(), h = isMissV(a[4]) ? null : toNum(a[4]) * this.selfScaleY(); im.onload = () => { if (w) this.g.drawImage(im, x, y, w, h); else this.g.drawImage(im, x, y); }; im.src = pic.url; } return { r: undefined }; }
    }
    return null;
  },
};
const isMissV = v => v === undefined || v === VBMissing;

// ---------- Controle ----------
class VBControl extends VBObject {
  constructor(form, node, parent) {
    super();
    this.form = form; this.node = node; this.type = node.type; this.def = ctlDef(node.type);
    this.P = nodeProps(node, form.frxLookup);
    this.vbName = node.name; this.lname = node.name.toLowerCase(); this.index = this.P.index;
    this.parentCtl = parent || null;
    this.hwnd = ++HWND_SEQ;
    this.children = [];
    if (this.type === 'VB.ListBox' || this.type === 'VB.ComboBox') { this.P.list = (this.P.list || []).slice(); this.P.itemdata = (this.P.itemdata || []).slice(); this.P._sel = new Set(); this.P._checked = new Set(); this.P.listindex = -1; this.P.newindex = -1; if (this.P.sorted) this.P.list.sort(cmpText); }
    this.el = createCtlElement(this.type, this.P, { design: false, scale: this.containerScale() });
    this.el.vbctl = this;
    if (this.type === 'VB.PictureBox') { this.initSurface(this.el.querySelector('canvas')); }
    if (!this.def.noFocus && this.P.tabindex !== undefined) this.el.dataset.tab = this.P.tabindex;
  }
  get typeName() { return this.type.split('.').pop(); }
  get ctlType() { return this.typeName; }
  get defaultProp() { return DEFAULT_PROP[this.type] || null; }
  _sync(n) { const v = this.syncGet(n); return v; }
  // o .frm guarda posições sempre em twips; em execução Left/Top/Width/Height seguem o ScaleMode do contêiner
  containerScale() { return 1 / 15; }
  cuScaleX() { if (this.parentCtl && this.parentCtl.type === 'VB.Frame') return 1 / 15; const c = this.parentCtl && this.parentCtl.type === 'VB.PictureBox' ? this.parentCtl : this.form; return c.selfScaleX ? c.selfScaleX() : 1 / 15; }
  cuScaleY() { if (this.parentCtl && this.parentCtl.type === 'VB.Frame') return 1 / 15; const c = this.parentCtl && this.parentCtl.type === 'VB.PictureBox' ? this.parentCtl : this.form; return c.selfScaleY ? c.selfScaleY() : 1 / 15; }
  toUnits(tw, axis) { const s = axis === 'y' ? this.cuScaleY() : this.cuScaleX(); const v = tw / 15 / s; return Math.abs(s - 1 / 15) < 1e-9 ? tw : Math.round(v * 1000) / 1000; }
  fromUnits(u, axis) { const s = axis === 'y' ? this.cuScaleY() : this.cuScaleX(); return u * s * 15; }
  clientWpx() { return this.el.clientWidth || this.P.width / 15; }
  clientHpx() { return this.el.clientHeight || this.P.height / 15; }
  refresh() {
    updateCtlElement(this.el, this.type, this.P, { design: false, scale: this.containerScale() });
    if (this.type === 'VB.PictureBox') { this.sizeCanvas(this.el.clientWidth, this.el.clientHeight); if (this.P.autosize && this.P.picture && this.P.picture.url) this.autosizePic(); }
    if (this.type === 'VB.Image' && !this.P.stretch && this.P.picture && this.P.picture.url) this.autosizePic();
    if (this.type === 'VB.Label' && this.P.autosize) { /* medido pelo navegador */ }
    if (this.wireAfterRefresh) this.wireAfterRefresh();
  }
  autosizePic() {
    const im = new Image(); im.onload = () => { const s = 1 / 15; const bw = this.el.offsetWidth - this.el.clientWidth; this.P.width = (im.naturalWidth + bw) / s; this.P.height = (im.naturalHeight + bw) / s; updateCtlElement(this.el, this.type, this.P, { design: false, scale: s }); if (this.canvas) this.sizeCanvas(this.el.clientWidth, this.el.clientHeight); }; im.src = this.P.picture.url;
  }
  refreshChildren() { for (const c of this.children) { c.refresh(); c.refreshChildren && c.refreshChildren(); } }
  rt() { return this.form.rt; }
  fire(ev, args) { return this.form.rt.fireEvent(this.form, this.lname, ev, args || [], this.index); }
  has(ev) { return this.form.rt.hasEvent(this.form, this.lname, ev); }
  get input() { return this.el.querySelector('input, textarea'); }

  // ------- propriedades -------
  syncGet(n) {
    const P = this.P;
    switch (n) {
      case 'name': return this.vbName;
      case 'index': if (this.index === null || this.index === undefined) throw vbErr(343); return this.index;
      case 'hwnd': return this.hwnd;
      case 'cliptext': { const t = this.input ? this.input.value : (P.text || ''); return P.mask ? [...t].filter(ch => /[\p{L}\d]/u.test(ch)).join('') : t; }
      case 'text':
        if (this.type === 'VB.TextBox') return this.input ? this.input.value : P.text;
        if (this.type === 'VB.ComboBox') return this.input ? this.input.value : P.text;
        if (this.type === 'VB.ListBox') return P.listindex >= 0 ? String(P.list[P.listindex] ?? '') : '';
        return P.text ?? '';
      case 'listcount': return (P.list || []).length;
      case 'listindex': return P.listindex ?? -1;
      case 'newindex': return P.newindex ?? -1;
      case 'selcount': return P._sel ? P._sel.size : 0;
      case 'topindex': return 0;
      case 'selstart': return this.input ? this.input.selectionStart : 0;
      case 'sellength': return this.input ? this.input.selectionEnd - this.input.selectionStart : 0;
      case 'seltext': return this.input ? this.input.value.substring(this.input.selectionStart, this.input.selectionEnd) : '';
      case 'value': if (this.type === 'VB.CommandButton') return false; if (this.type === 'VB.OptionButton') return !!(P.value && P.value !== 0); return P.value ?? 0;
      case 'fontname': return P.font.name; case 'fontsize': return P.font.size; case 'fontbold': return !!P.font.bold; case 'fontitalic': return !!P.font.italic; case 'fontunderline': return !!P.font.underline; case 'fontstrikethru': return !!P.font.strikethrough;
      case 'caption': return P.caption ?? '';
      case 'left': case 'width': case 'x1': case 'x2': return this.toUnits(Number(P[n]) || 0, 'x');
      case 'top': case 'height': case 'y1': case 'y2': return this.toUnits(Number(P[n]) || 0, 'y');
      case 'path': return 'C:\\NeoBasic'; case 'drive': return 'c:'; case 'filename': return P.listindex >= 0 ? P.list[P.listindex] : ''; case 'pattern': return P.pattern || '*.*';
    }
    if (n in P) { const v = P[n]; return v; }
    return undefined;
  }
  async getMember(n, rt) {
    if (this.type === 'VB.Data' && typeof nbDataGet === 'function') { const r = await nbDataGet(this, n, rt); if (r !== undefined) return r; }
    if (this.type === 'NB.NavigationBar' && typeof nbNavGet === 'function') { const r = await nbNavGet(this, n, rt); if (r !== undefined) return r; }
    switch (n) {
      case 'parent': return this.form;
      case 'container': return this.parentCtl || this.form;
      case 'font': return new VBFont(this);
      case 'picture': case 'downpicture': case 'disabledpicture': case 'icon': return pictureOf(this.P[n]);
      case 'setfocus': case 'refresh': case 'clear': case 'cls': case 'zorder': case 'drag': case 'showwhatsthis': return this.callMethod(n, [], rt);
      case 'list': case 'selected': case 'itemdata': throw vbErr(450);
      case 'object': return this;
    }
    if (this.canvas) { const v = this.surfaceGet(n); if (v !== undefined) return v; }
    const v = this.syncGet(n);
    if (v !== undefined) return (v && typeof v === 'object' && v.url !== undefined) ? pictureOf(v) : v;
    if (this.def.unknown) { this.warnUnknown(); return new StubObject(this.typeName); }
    if (PROP_TYPES[n] !== undefined || CTL_EXTRA_PROPS.has(n)) return this.P[n];
    throw vbErr(438, `Object doesn't support this property or method: ${n}`);
  }
  async setMember(n, v, rt, idx) {
    const P = this.P;
    if (idx && idx.length) {
      const i = vbRound(toNum(idx[0]));
      if (n === 'list') { if (i < 0) throw vbErr(381); while (P.list.length <= i) P.list.push(''); P.list[i] = toStr(v); this.refresh(); return; }
      if (n === 'selected') { if (i < 0 || i >= P.list.length) throw vbErr(381); if (toBool(v)) { if (!P.multiselect) P._sel.clear(); P._sel.add(i); P.listindex = i; } else P._sel.delete(i); if (P.style === 1) { if (toBool(v)) P._checked.add(i); else P._checked.delete(i); } this.refresh(); this.fire('click'); return; }
      if (n === 'itemdata') { if (i < 0 || i >= P.list.length) throw vbErr(381); P.itemdata[i] = toNum(v); return; }
      throw vbErr(438);
    }
    if (this.canvas && this.surfaceSet(n, v)) return;
    switch (n) {
      case 'name': throw vbErr(382, "'Name' property can't be set at run time");
      case 'index': throw vbErr(383);
      case 'text':
        if (this.type === 'VB.TextBox') { const s = P.mask && !P.multiline ? nbMaskFormat(P.mask, toStr(v)) : toStr(v); const old = this.input.value; P.text = s; this.input.value = s; if (old !== s) await this.fire('change'); return; }
        if (this.type === 'VB.ComboBox') { const s = toStr(v); const old = this.input.value; P.text = s; this.input.value = s; if (P.style === 2) { const i = P.list.indexOf(s); if (i < 0 && s !== '') throw vbErr(383, "'Text' property is read-only"); P.listindex = i; } if (old !== s) await this.fire('change'); return; }
        if (this.type === 'VB.ListBox') { const i = P.list.findIndex(x => String(x).toLowerCase() === toStr(v).toLowerCase()); if (i >= 0) await this.setMember('listindex', i, rt); return; }
        P.text = toStr(v); this.refresh(); return;
      case 'caption': P.caption = toStr(v); this.refresh(); if (this.type === 'VB.Label') await this.fire('change'); return;
      case 'value': {
        if (this.type === 'VB.CommandButton') { if (toBool(v)) { await this.fire('click'); } return; }
        if (this.type === 'VB.OptionButton') { const b = toBool(v); const was = !!P.value; P.value = b; if (b) this.uncheckSiblings(); this.refresh(); if (b && !was) await this.fire('click'); return; }
        if (this.type === 'VB.CheckBox') { const nv = vbRound(toNum(v)); if (nv < 0 || nv > 2) throw vbErr(380); const was = P.value; P.value = nv; this.refresh(); if (was !== nv) await this.fire('click'); return; }
        if (this.type === 'VB.HScrollBar' || this.type === 'VB.VScrollBar') { const nv = vbRound(toNum(v)); const lo = Math.min(P.min, P.max), hi = Math.max(P.min, P.max); if (nv < lo || nv > hi) throw vbErr(380); const was = P.value; P.value = nv; this.refresh(); if (was !== nv) await this.fire('change'); return; }
        P.value = v; this.refresh(); return;
      }
      case 'listindex': {
        const i = vbRound(toNum(v)); if (i < -1 || i >= P.list.length) throw vbErr(380);
        const was = P.listindex; P.listindex = i; P._sel.clear(); if (i >= 0) P._sel.add(i);
        if (this.type === 'VB.ComboBox') { this.input.value = i >= 0 ? P.list[i] : (P.style === 2 ? '' : this.input.value); P.text = this.input.value; }
        this.refresh(); this.scrollToSel();
        if (was !== i || this.type === 'VB.ListBox') await this.fire('click');
        return;
      }
      case 'selstart': if (this.input) { const p = vbRound(toNum(v)); this.input.setSelectionRange(p, p); } return;
      case 'sellength': if (this.input) { const s = this.input.selectionStart; this.input.setSelectionRange(s, s + vbRound(toNum(v))); } return;
      case 'seltext': if (this.input) { const t = this.input; const s = t.selectionStart, e = t.selectionEnd; const ins = toStr(v); t.value = t.value.slice(0, s) + ins + t.value.slice(e); t.setSelectionRange(s + ins.length, s + ins.length); P.text = t.value; await this.fire('change'); } return;
      case 'fontname': P.font = Object.assign({}, P.font, { name: toStr(v) }); this.refresh(); return;
      case 'fontsize': P.font = Object.assign({}, P.font, { size: toNum(v) }); this.refresh(); return;
      case 'fontbold': P.font = Object.assign({}, P.font, { bold: toBool(v) }); this.refresh(); return;
      case 'fontitalic': P.font = Object.assign({}, P.font, { italic: toBool(v) }); this.refresh(); return;
      case 'fontunderline': P.font = Object.assign({}, P.font, { underline: toBool(v) }); this.refresh(); return;
      case 'fontstrikethru': P.font = Object.assign({}, P.font, { strikethrough: toBool(v) }); this.refresh(); return;
      case 'picture': case 'downpicture': case 'disabledpicture': case 'icon': P[n] = v instanceof VBPicture ? { url: v.url, bytes: v.bytes } : (v ? v : null); this.refresh(); return;
      case 'font': return;
      case 'interval': case 'enabled':
        P[n] = n === 'enabled' ? toBool(v) : vbRound(toNum(v)); this.refresh(); if (this.type === 'VB.Timer') this.restartTimer(); else if (this.input) this.input.disabled = !P.enabled; return;
      case 'zorder': return;
      case 'sorted': case 'multiline': case 'style': case 'multiselect': throw vbErr(382, `'${n}' property can't be set at run time`);
    }
    if (['left', 'width', 'x1', 'x2'].includes(n)) P[n] = this.fromUnits(toNum(v), 'x');
    else if (['top', 'height', 'y1', 'y2'].includes(n)) P[n] = this.fromUnits(toNum(v), 'y');
    else if (BOOL_PROPS.has(n)) P[n] = toBool(v);
    else if (NUM_PROPS.has(n)) P[n] = toNum(v);
    else P[n] = (v instanceof VBObject) ? v : (typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean' ? v : toStr(v));
    if (n === 'min' || n === 'max') { /* ok */ }
    if (this.def.unknown && n === 'simpletext') P.simpletext = toStr(v);
    this.refresh();
    if (n === 'left' || n === 'top' || n === 'width' || n === 'height') { if (this.refreshChildren) this.refreshChildren(); if (n === 'width' || n === 'height') await this.fire('resize'); }
  }
  async callMethod(n, a, rt) {
    const P = this.P;
    if (this.type === 'VB.Data' && typeof nbDataCall === 'function') { const r = await nbDataCall(this, n, a, rt || this.form.rt); if (r !== undefined) return r === NB_DONE ? undefined : r; }
    if (this.type === 'NB.NavigationBar' && typeof nbNavCall === 'function') { const r = await nbNavCall(this, n, a, rt || this.form.rt); if (r !== undefined) return r === NB_DONE ? undefined : r; }
    if (this.canvas) { const r = this.surfaceCall(n, a); if (r) return r.r; }
    switch (n) {
      case '': throw vbErr(343);
      case 'setfocus': { const t = this.input || this.el.querySelector('[tabindex]') || this.el; if (!this.P.visible || !this.P.enabled) throw vbErr(5, "Invalid procedure call or argument (can't move focus to a control because it is invisible or not enabled)"); if (t.focus) t.focus(); return; }
      case 'refresh': this.refresh(); return;
      case 'move': {
        if (!isMissV(a[0])) P.left = this.fromUnits(toNum(a[0]), 'x'); if (!isMissV(a[1])) P.top = this.fromUnits(toNum(a[1]), 'y'); if (!isMissV(a[2])) P.width = Math.max(0, this.fromUnits(toNum(a[2]), 'x')); if (!isMissV(a[3])) P.height = Math.max(0, this.fromUnits(toNum(a[3]), 'y'));
        this.refresh(); if (this.refreshChildren) this.refreshChildren(); if (!isMissV(a[2]) || !isMissV(a[3])) await this.fire('resize'); return;
      }
      case 'zorder': { const pos = isMissV(a[0]) ? 0 : toNum(a[0]); const par = this.el.parentNode; if (par) { if (pos === 0) par.appendChild(this.el); else par.insertBefore(this.el, par.firstChild); } return; }
      case 'additem': {
        const item = toStr(a[0]);
        let i;
        if (!isMissV(a[1])) { i = vbRound(toNum(a[1])); if (i < 0 || i > P.list.length) throw vbErr(5); }
        else if (P.sorted) { i = P.list.findIndex(x => cmpText(x, item) > 0); if (i < 0) i = P.list.length; }
        else i = P.list.length;
        P.list.splice(i, 0, item); P.itemdata.splice(i, 0, 0);
        const shift = s => new Set([...s].map(x => x >= i ? x + 1 : x));
        P._sel = shift(P._sel); P._checked = shift(P._checked);
        if (P.listindex >= i) P.listindex++;
        P.newindex = i; this.refreshList(); return;
      }
      case 'removeitem': {
        const i = vbRound(toNum(a[0])); if (i < 0 || i >= P.list.length) throw vbErr(5);
        P.list.splice(i, 1); P.itemdata.splice(i, 1);
        const shift = s => new Set([...s].filter(x => x !== i).map(x => x > i ? x - 1 : x));
        P._sel = shift(P._sel); P._checked = shift(P._checked);
        if (P.listindex === i) P.listindex = -1; else if (P.listindex > i) P.listindex--;
        this.refreshList(); return;
      }
      case 'clear':
        if (P.list) { P.list = []; P.itemdata = []; P._sel.clear(); P._checked.clear(); P.listindex = -1; if (this.type === 'VB.ComboBox' && P.style !== 2) { /* mantém texto? VB limpa */ this.input.value = ''; P.text = ''; } this.refreshList(); return; }
        if (this.type === 'VB.TextBox') { await this.setMember('text', '', rt); return; }
        return;
      case 'list': { const i = vbRound(toNum(a[0])); if (!P.list) throw vbErr(438); if (i < 0 || i >= P.list.length) return ''; return P.list[i]; }
      case 'itemdata': { const i = vbRound(toNum(a[0])); if (i < 0 || i >= P.list.length) throw vbErr(381); return P.itemdata[i] || 0; }
      case 'selected': { const i = vbRound(toNum(a[0])); if (i < 0 || i >= P.list.length) throw vbErr(381); return P.style === 1 ? P._checked.has(i) : P._sel.has(i); }
      case 'drag': case 'showwhatsthis': case 'linkexecute': case 'linkpoke': case 'linkrequest': case 'linksend': case 'oledrag': case 'refreshdata': return;
      case 'item': return this;
    }
    if (this.def.unknown) { this.warnUnknown(); if (!a.length && n in this.P) return this.P[n]; return new StubObject(this.typeName); }
    if (!a.length) return this.getMember(n, rt);
    throw vbErr(438, `Object doesn't support this property or method: ${n}`);
  }
  warnUnknown() { if (this.form.warned && this.form.warned.has(this.type)) return; (this.form.warned || (this.form.warned = new Set())).add(this.type); if (this.form.host.debugPrint) this.form.host.debugPrint(`' Warning: control ${this.type} (${this.vbName}) is not supported yet; calls to it are ignored.\r\n`); }
  refreshList() { const d = this.el.querySelector('.vb-list'); if (d) renderListItems(d, this.P.list, this.P, this.type === 'VB.ListBox' && this.P.style === 1); }
  scrollToSel() { const d = this.el.querySelector('.vb-list'); if (!d) return; const r = d.querySelector('.vb-li.sel'); if (r && r.scrollIntoView) r.scrollIntoView({ block: 'nearest' }); }
  uncheckSiblings() {
    const sibs = (this.parentCtl ? this.parentCtl.children : this.form.topControls).filter(c => c !== this && c.type === 'VB.OptionButton');
    for (const s of sibs) if (s.P.value) { s.P.value = false; s.refresh(); }
  }
  restartTimer() {
    if (this.timerId) { clearInterval(this.timerId); this.timerId = null; }
    if (this.form.dead) return;
    const P = this.P; if (!P.enabled || !(P.interval > 0)) return;
    this.timerId = setInterval(async () => {
      if (this.busy || this.form.rt.stopped) return; this.busy = true;
      try { await this.fire('timer'); } finally { this.busy = false; }
    }, Math.max(10, P.interval));
  }
  destroy() { if (this.timerId) clearInterval(this.timerId); this.timerId = null; }

  // ------- eventos do DOM -------
  wire() {
    const el = this.el, t = this.type, P = this.P;
    const mouseArgs = (ev) => { const r = el.getBoundingClientRect(); const sc = this.canvas ? this.selfScaleX() : this.cuScaleX(); const scy = this.canvas ? this.selfScaleY() : this.cuScaleY(); return [buttonOf(ev), shiftOf(ev), (ev.clientX - r.left) / sc, (ev.clientY - r.top) / scy]; };
    el.addEventListener('mousedown', ev => { if (!P.enabled) return; if (this.has('mousedown')) this.fire('mousedown', mouseArgs(ev)); });
    el.addEventListener('mouseup', ev => { if (!P.enabled) return; if (this.has('mouseup')) this.fire('mouseup', mouseArgs(ev)); });
    el.addEventListener('mousemove', ev => { if (!P.enabled || this.mmBusy) return; if (this.has('mousemove')) { this.mmBusy = true; Promise.resolve(this.fire('mousemove', mouseArgs(ev))).finally(() => { this.mmBusy = false; }); } });
    el.addEventListener('dblclick', ev => { if (!P.enabled) return; this.fire('dblclick'); });
    el.addEventListener('contextmenu', ev => { if (this.has('mousedown') || this.has('mouseup')) ev.preventDefault(); });
    const focusEl = this.input || el.querySelector('.vb-list') || el;
    if (!this.def.noFocus && t !== 'VB.Label' && t !== 'VB.Frame' && t !== 'VB.Image' && t !== 'VB.Shape' && t !== 'VB.Line' && t !== 'VB.Timer') {
      if (!this.input && focusEl === el) el.tabIndex = P.tabstop === false ? -1 : 0;
      focusEl.addEventListener('focus', () => { this.form.activeCtl = this; this.fire('gotfocus'); });
      focusEl.addEventListener('blur', () => { this.fire('lostfocus'); });
      focusEl.addEventListener('keydown', ev => this.onKeyDown(ev));
      focusEl.addEventListener('keyup', ev => { this.form.formKey('keyup', ev); if (this.has('keyup')) this.fire('keyup', [ev.keyCode, shiftOf(ev)]); });
    }
    switch (t) {
      case 'VB.CommandButton': el.tabIndex = P.tabstop === false ? -1 : 0; el.addEventListener('click', () => { if (P.enabled && !this.form.modalBlocked()) { el.focus(); this.fire('click'); } }); break;
      case 'VB.CheckBox': el.tabIndex = 0; el.addEventListener('click', ev => { ev.preventDefault(); if (!P.enabled) return; P.value = P.value === 1 ? 0 : 1; this.refresh(); this.fire('click'); }); break;
      case 'VB.OptionButton': el.tabIndex = 0; el.addEventListener('click', ev => { ev.preventDefault(); if (!P.enabled) return; const was = !!P.value; P.value = true; this.uncheckSiblings(); this.refresh(); if (!was) this.fire('click'); }); break;
      case 'VB.TextBox': {
        const inp = this.input;
        inp.addEventListener('input', () => { if (P.mask && !P.multiline) nbMaskInput(inp, P.mask); P.text = inp.value; this.fire('change'); });
        el.addEventListener('click', () => { if (P.enabled) this.fire('click'); });
        break;
      }
      case 'VB.ListBox': case 'VB.FileListBox': case 'VB.DirListBox': {
        const d = el.querySelector('.vb-list');
        d.addEventListener('mousedown', ev => {
          const li = ev.target.closest('.vb-li'); if (!li || !P.enabled) return;
          const i = Number(li.dataset.i);
          if (P.style === 1 && ev.target.classList.contains('vb-box')) { if (P._checked.has(i)) P._checked.delete(i); else P._checked.add(i); this.fire('itemcheck', [i]); }
          if (P.multiselect === 1) { if (P._sel.has(i)) P._sel.delete(i); else P._sel.add(i); }
          else if (P.multiselect === 2 && (ev.ctrlKey || ev.shiftKey)) { if (ev.shiftKey && P.listindex >= 0) { const [a, b] = [Math.min(P.listindex, i), Math.max(P.listindex, i)]; for (let k = a; k <= b; k++) P._sel.add(k); } else if (P._sel.has(i)) P._sel.delete(i); else P._sel.add(i); }
          else { P._sel.clear(); P._sel.add(i); }
          P.listindex = i; this.refreshList(); this.fire('click');
        });
        d.addEventListener('keydown', ev => {
          if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') { ev.preventDefault(); const n = Math.max(0, Math.min(P.list.length - 1, (P.listindex < 0 ? -1 : P.listindex) + (ev.key === 'ArrowDown' ? 1 : -1))); if (n !== P.listindex) this.setMember('listindex', n, this.rt()); }
          if (ev.key === ' ' && P.style === 1 && P.listindex >= 0) { ev.preventDefault(); const i = P.listindex; if (P._checked.has(i)) P._checked.delete(i); else P._checked.add(i); this.refreshList(); this.fire('itemcheck', [i]); }
        });
        break;
      }
      case 'VB.ComboBox': case 'VB.DriveListBox': {
        const inp = this.input; const dd = el.querySelector('.vb-dd');
        inp.addEventListener('input', () => { P.text = inp.value; this.fire('change'); });
        const open = async () => { if (!P.enabled) return; await this.fire('dropdown'); this.form.host.showComboPopup(this, async (i) => { await this.setMember('listindex', i, this.rt()); }); };
        dd.addEventListener('mousedown', ev => { ev.preventDefault(); open(); });
        if (P.style === 2) inp.addEventListener('mousedown', ev => { ev.preventDefault(); inp.focus(); open(); });
        inp.addEventListener('keydown', ev => { if ((ev.key === 'ArrowDown' || ev.key === 'ArrowUp') && P.list.length) { ev.preventDefault(); const n = Math.max(0, Math.min(P.list.length - 1, P.listindex + (ev.key === 'ArrowDown' ? 1 : -1))); this.setMember('listindex', n, this.rt()); } });
        if (P.style === 1) { /* lista sempre visível: simplificado */ }
        break;
      }
      case 'VB.HScrollBar': case 'VB.VScrollBar': this.wireScroll(); break;
      case 'NB.NavigationBar':
        el.addEventListener('click', ev => { const b = ev.target.closest('[data-a]'); if (!b || b.classList.contains('dis') || !P.enabled || this.form.modalBlocked()) return; ev.stopPropagation(); if (typeof nbNavAction === 'function') nbNavAction(this, b.dataset.a); });
        el.addEventListener('keydown', ev => { const inp = ev.target.closest('.nv-recin'); if (!inp) return; ev.stopPropagation(); if (ev.key === 'Enter') { ev.preventDefault(); if (typeof nbNavGoto === 'function') nbNavGoto(this, inp.value); } });
        el.addEventListener('focusout', ev => { if (ev.target.closest && ev.target.closest('.nv-recin') && typeof nbNavRender === 'function') setTimeout(() => nbNavRender(this), 0); });
        break;
      case 'VB.Data':
        el.querySelectorAll('.vb-data > b').forEach((b, i) => b.addEventListener('click', ev => { ev.stopPropagation(); if (P.enabled && !this.form.modalBlocked() && typeof nbDataNav === 'function') nbDataNav(this, ['first', 'prev', 'next', 'last'][i]); }));
        // fall through
      case 'VB.Label': case 'VB.Image': case 'VB.Frame': case 'VB.PictureBox':
        el.addEventListener('click', ev => { if (P.enabled && !this.form.modalBlocked()) { if (t === 'VB.Frame' && ev.target.closest('.vbc') !== el) return; if (t === 'VB.PictureBox' && ev.target.closest('.vbc') !== el) return; this.fire('click'); } });
        break;
      case 'VB.Timer': this.restartTimer(); break;
    }
    if (this.def.unknown) el.addEventListener('click', () => this.fire('click'));
  }
  async onKeyDown(ev) {
    const P = this.P, t = this.type;
    if (await this.form.formKey('keydown', ev, this)) return;
    if (this.has('keydown')) {
      const r = await this.fire('keydown', [ev.keyCode, shiftOf(ev)]);
    }
    const printable = ev.key.length === 1 && !ev.ctrlKey && !ev.altKey;
    const isEnter = ev.key === 'Enter';
    if ((printable || isEnter || ev.key === 'Backspace' || ev.key === 'Escape') && (this.has('keypress') || this.form.P.keypreview && this.form.rt.hasEvent(this.form, 'form', 'keypress'))) {
      let code = printable ? cp1252Code(ev.key) : isEnter ? 13 : ev.key === 'Backspace' ? 8 : 27;
      const inp = this.input;
      const canInsert = inp && printable;
      if (canInsert || isEnter && inp && inp.tagName !== 'TEXTAREA') ev.preventDefault();
      if (this.form.P.keypreview) { const r = await this.form.rt.fireEvent(this.form, 'form', 'keypress', [code]); if (r && r.cells[0]) code = vbRound(toNum(r.cells[0].v)); }
      if (code && this.has('keypress')) { const r = await this.fire('keypress', [code]); if (r && r.cells) { const c = r.cells[this.index !== null && this.index !== undefined ? 1 : 0]; if (c) code = vbRound(toNum(c.v)); } }
      if (canInsert && code) {
        const ch = cp1252Char(code); const s = inp.selectionStart, e = inp.selectionEnd;
        if (P.maxlength && inp.value.length - (e - s) >= P.maxlength) return;
        if (P.locked || P._navlock) return;
        inp.value = inp.value.slice(0, s) + ch + inp.value.slice(e); inp.setSelectionRange(s + 1, s + 1);
        if (P.mask && !P.multiline && t === 'VB.TextBox') nbMaskInput(inp, P.mask);
        P.text = inp.value; await this.fire('change');
      }
      if (code === 13 && isEnter) await this.form.pressDefault();
      return;
    }
    if (isEnter && !(this.input && this.input.tagName === 'TEXTAREA') && t !== 'VB.CommandButton') { ev.preventDefault(); await this.form.pressDefault(); }
    if (ev.key === 'Escape') await this.form.pressCancel();
    if (t === 'VB.CommandButton' && (ev.key === ' ' || isEnter)) { ev.preventDefault(); this.fire('click'); }
    if ((t === 'VB.CheckBox' || t === 'VB.OptionButton') && ev.key === ' ') { ev.preventDefault(); this.el.click(); }
  }
  wireScroll() {
    const el = this.el, P = this.P; const vert = this.type === 'VB.VScrollBar';
    const a1 = el.querySelector('.vb-sb-a1'), a2 = el.querySelector('.vb-sb-a2'), track = el.querySelector('.vb-sb-track'), thumb = el.querySelector('.vb-sb-thumb');
    const dir = () => P.max >= P.min ? 1 : -1;
    const setV = async (nv, scroll) => { const lo = Math.min(P.min, P.max), hi = Math.max(P.min, P.max); nv = Math.max(lo, Math.min(hi, Math.round(nv))); if (nv === P.value) return; P.value = nv; this.refresh(); await this.fire(scroll ? 'scroll' : 'change'); };
    const repeat = (fn) => { fn(); let t2; const t1 = setTimeout(() => { t2 = setInterval(fn, 50); }, 350); const up = () => { clearTimeout(t1); clearInterval(t2); window.removeEventListener('mouseup', up); }; window.addEventListener('mouseup', up); };
    a1.addEventListener('mousedown', ev => { ev.preventDefault(); if (P.enabled) repeat(() => setV(P.value - dir() * (P.smallchange || 1))); });
    a2.addEventListener('mousedown', ev => { ev.preventDefault(); if (P.enabled) repeat(() => setV(P.value + dir() * (P.smallchange || 1))); });
    track.addEventListener('mousedown', ev => {
      if (ev.target === thumb || !P.enabled) return; ev.preventDefault();
      const r = thumb.getBoundingClientRect(); const before = vert ? ev.clientY < r.top : ev.clientX < r.left;
      repeat(() => setV(P.value + (before ? -1 : 1) * dir() * (P.largechange || 1)));
    });
    thumb.addEventListener('mousedown', ev => {
      ev.preventDefault(); if (!P.enabled) return;
      const start = vert ? ev.clientY : ev.clientX; const v0 = P.value; const len = Number(track.dataset.len) - Number(track.dataset.th);
      const mv = e => { const d = (vert ? e.clientY : e.clientX) - start; setV(v0 + d / Math.max(1, len) * (P.max - P.min), true); };
      const up = () => { window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', up); this.fire('change'); };
      window.addEventListener('mousemove', mv); window.addEventListener('mouseup', up);
    });
    el.tabIndex = 0;
    el.addEventListener('keydown', ev => { const k = ev.key; if ((vert && k === 'ArrowDown') || (!vert && k === 'ArrowRight')) { ev.preventDefault(); setV(P.value + dir() * (P.smallchange || 1)); } if ((vert && k === 'ArrowUp') || (!vert && k === 'ArrowLeft')) { ev.preventDefault(); setV(P.value - dir() * (P.smallchange || 1)); } });
  }
}
Object.assign(VBControl.prototype, Surface);
const CTL_EXTRA_PROPS = new Set(['columns', 'align', 'datafield', 'datasource', 'helpcontextid', 'whatsthishelpid', 'appearance', 'dragmode', 'dragicon', 'linkitem', 'linkmode', 'linktimeout', 'linktopic', 'oledragmode', 'oledropmode', 'righttoleft', 'causesvalidation', 'drawmode', 'drawstyle', 'fontransparent', 'hasdc', 'hdc', 'clipcontrols', 'maskcolor', 'usemaskcolor', 'archive', 'hidden', 'normal', 'readonly', 'system', 'databasename', 'recordsource', 'connect', 'exclusive', 'options', 'recordsettype', 'eofaction', 'bofaction']);
function cmpText(a, b) { a = String(a).toLowerCase(); b = String(b).toLowerCase(); return a < b ? -1 : a > b ? 1 : 0; }
function buttonOf(ev) { return ev.buttons ? ((ev.buttons & 1 ? 1 : 0) | (ev.buttons & 2 ? 2 : 0) | (ev.buttons & 4 ? 4 : 0)) : ({ 0: 1, 1: 4, 2: 2 }[ev.button] || 0); }
function shiftOf(ev) { return (ev.shiftKey ? 1 : 0) | (ev.ctrlKey ? 2 : 0) | (ev.altKey ? 4 : 0); }

// ---------- Matriz de controles ----------
class StubObject extends VBObject {
  constructor(label) { super(); this.label = label; }
  get typeName() { return this.label || 'Object'; }
  async getMember(n) { if (n === 'count') return 0; return new StubObject(this.label); }
  async setMember() { }
  async callMember(n, args, frame, rt) { if (n === 'count') return 0; return new StubObject(this.label); }
  async callMethod(n) { if (n === 'count') return 0; return new StubObject(this.label); }
  enumerate() { return []; }
  _sync() { return ''; }
}
class ControlArray extends VBObject {
  constructor(form, name) { super(); this.form = form; this.vbName = name; this.items = new Map(); }
  get typeName() { const f = this.first(); return f ? f.typeName : 'Object'; }
  first() { const ks = [...this.items.keys()].sort((a, b) => a - b); return this.items.get(ks[0]); }
  get(i) { const c = this.items.get(vbRound(toNum(i))); if (!c) throw vbErr(340, `Control array element '${i}' doesn't exist (${this.vbName})`); return c; }
  async getMember(n) { const ks = [...this.items.keys()]; if (n === 'count') return ks.length; if (n === 'ubound') return Math.max(...ks); if (n === 'lbound') return Math.min(...ks); throw vbErr(438); }
  async callMethod(n, a) { if (n === '' || n === 'item') return this.get(a[0]); return this.getMember(n); }
  async callMember(n, args, frame, rt) { const vals = await rt.argValues(args, frame); return this.callMethod(n, vals, rt); }
  enumerate() { return [...this.items.keys()].sort((a, b) => a - b).map(k => this.items.get(k)); }
}

// ---------- Menus ----------
class VBMenu extends VBObject {
  constructor(form, node, parent) {
    super(); this.form = form; this.node = node; this.vbName = node.name; this.lname = node.name.toLowerCase(); this.parentMenu = parent;
    this.P = nodeProps(node, form.frxLookup); this.index = this.P.index; this.items = [];
    for (const c of node.children) if (/menu$/i.test(c.type)) this.items.push(new VBMenu(form, c, this));
  }
  get typeName() { return 'Menu'; }
  get ctlType() { return 'Menu'; }
  get defaultProp() { return 'caption'; }
  _sync(n) { return this.P[n]; }
  async getMember(n) { if (n === 'name') return this.vbName; if (n === 'index') { if (this.index == null) throw vbErr(343); return this.index; } if (n === 'parent') return this.form; if (n in this.P) return this.P[n]; if (['caption', 'checked', 'enabled', 'visible', 'tag', 'windowlist', 'shortcut', 'helpcontextid', 'negotiateposition'].includes(n)) return this.P[n]; throw vbErr(438); }
  async setMember(n, v) { if (BOOL_PROPS.has(n)) this.P[n] = toBool(v); else this.P[n] = toStr(v); this.form.renderMenubar(); }
  async callMethod(n, a) { return this.getMember(n); }
  fire() { return this.form.rt.fireEvent(this.form, this.lname, 'click', [], this.index); }
}

// ---------- Coleção Controls ----------
class ControlsCollection extends VBObject {
  constructor(form) { super(); this.form = form; }
  get typeName() { return 'Object'; }
  list() { return this.form.allControls.concat(this.form.allMenus); }
  async getMember(n) { if (n === 'count') return this.list().length; throw vbErr(438); }
  async callMethod(n, a) {
    if (n === 'count') return this.list().length;
    if (n === '' || n === 'item') { const k = a[0]; if (typeof k === 'string') { const f = this.list().find(c => c.lname === k.toLowerCase()); if (!f) throw vbErr(730, 'Control not found: ' + k); return f; } const c = this.list()[vbRound(toNum(k))]; if (!c) throw vbErr(9); return c; }
    throw vbErr(438);
  }
  enumerate() { return this.list(); }
}

// ---------- CommonDialog ----------
class VBCommonDialog extends VBControl {
  async callMethod(n, a, rt) {
    const P = this.P; const host = this.form.host;
    const cancel = () => { if (P.cancelerror) throw vbErr(32755); };
    switch (n) {
      case 'showopen': { const r = await host.pickFileToVFS(P.filter || ''); if (!r) return cancel(); P.filename = r.path; P.filetitle = r.name; return; }
      case 'showsave': { const nm = await host.inputBox('File name:', P.dialogtitle || 'Save As', P.filetitle || P.filename ? (String(P.filename).split('\\').pop()) : ('file.' + (P.defaultext || 'txt'))); if (!nm) return cancel(); const path = 'C:\\NeoBasic\\' + nm.replace(/^.*[\\/]/, ''); P.filename = path; P.filetitle = nm; host.markDownload(path); return; }
      case 'showcolor': { const c = await host.pickColor(vbColorCss(P.color || 0)); if (c === null) return cancel(); P.color = cssToVbColor(c); return; }
      case 'showfont': case 'showprinter': case 'showhelp': case 'action': return;
    }
    return super.callMethod(n, a, rt);
  }
  async getMember(n, rt) { if (['filename', 'filetitle', 'filter', 'filterindex', 'dialogtitle', 'initdir', 'flags', 'cancelerror', 'defaultext', 'color', 'fontname', 'fontsize', 'fontbold', 'fontitalic', 'copies', 'frompage', 'topage', 'min', 'max', 'maxfilesize', 'helpfile', 'helpcommand', 'helpkey', 'printerdefault', 'orientation', 'hdc'].includes(n)) return this.P[n] ?? (['filterindex', 'flags', 'color', 'copies', 'frompage', 'topage', 'min', 'max', 'maxfilesize', 'hdc'].includes(n) ? 0 : (n === 'cancelerror' ? false : '')); return super.getMember(n, rt); }
  async setMember(n, v, rt, idx) { if (n === 'cancelerror') { this.P[n] = toBool(v); return; } this.P[n] = v; }
}

// ---------- Formulário ----------
class VBForm extends VBObject {
  constructor(def, rt, host) {
    super();
    this.def = def; this.rt = rt; this.host = host; this.isForm = true; this.formId = def.name.toLowerCase();
    const data = def.data; this.frm = data.frm; this.frxLookup = data.frxLookup || (() => null);
    this.node = this.frm.root; this.type = this.node.type; this.isMDI = /mdiform/i.test(this.type);
    this.vbName = def.name; this.lname = 'form';
    this.P = nodeProps(this.node, this.frxLookup);
    this.hwnd = ++HWND_SEQ;
    this.byName = new Map(); this.allControls = []; this.allMenus = []; this.topControls = []; this.menus = [];
    this.controlsColl = new ControlsCollection(this);
    this.buildWindow();
    for (const ch of this.node.children) this.addChildNode(ch, null, this.client);
    this.fixTabOrder();
    this.renderMenubar();
    this.layout();
    for (const c of this.allControls) c.wire();
  }
  get typeName() { return this.vbName; }
  get ctlType() { return this.isMDI ? 'MDIForm' : 'Form'; }
  get defaultProp() { return null; }
  getControl(name) { return this.byName.get(name); }
  addChildNode(node, parent, containerEl) {
    if (/\.menu$/i.test(node.type)) { const m = new VBMenu(this, node, null); this.menus.push(m); this.registerMenu(m); return; }
    const C = /commondialog/i.test(node.type) ? VBCommonDialog : VBControl;
    const c = new C(this, node, parent);
    if (/commondialog|imagelist/i.test(node.type)) c.el.style.display = 'none';
    containerEl.appendChild(c.el);
    this.allControls.push(c);
    if (parent) parent.children.push(c); else this.topControls.push(c);
    this.register(c.lname, c, c.index, c.vbName);
    for (const ch of node.children) this.addChildNode(ch, c, c.el);
    return c;
  }
  register(lname, obj, index, vbName) {
    if (index !== null && index !== undefined) {
      let arr = this.byName.get(lname);
      if (!(arr instanceof ControlArray)) { arr = new ControlArray(this, vbName); this.byName.set(lname, arr); }
      arr.items.set(index, obj);
    } else this.byName.set(lname, obj);
  }
  registerMenu(m) { this.allMenus.push(m); this.register(m.lname, m, m.index, m.vbName); for (const s of m.items) this.registerMenu(s); }
  fixTabOrder() {
    const focusables = this.allControls.filter(c => c.P.tabindex !== undefined).sort((a, b) => a.P.tabindex - b.P.tabindex);
    // DOM: tabindex positivo respeita a ordem do VB
    focusables.forEach((c, i) => { const t = c.input || c.el.querySelector('.vb-list') || c.el; if (c.P.tabstop !== false) t.tabIndex = i + 1; else t.tabIndex = -1; });
  }
  // ----- janela -----
  buildWindow() {
    const w = document.createElement('div'); w.className = 'vb-window skin-' + NB_SKIN; w.vbform = this; this.skin = NB_SKIN;
    w.innerHTML = `<div class="vb-title"><span class="vb-ticon"></span><span class="vb-tcap"></span><span class="vb-tbtns"><b class="tb-min">0</b><b class="tb-max">1</b><b class="tb-close">r</b></span></div><div class="vb-menubar"></div><div class="vb-client"><canvas class="vb-canvas"></canvas></div><div class="vb-grip"></div>`;
    this.win = w; this.title = w.querySelector('.vb-title'); this.client = w.querySelector('.vb-client'); this.menubar = w.querySelector('.vb-menubar');
    this.initSurface(w.querySelector('.vb-canvas'));
    this.el = w;
    // arrastar pela barra de título
    this.title.addEventListener('mousedown', ev => {
      if (ev.target.closest('.vb-tbtns') || this.P.windowstate === 2 || this.P.moveable === false) return;
      ev.preventDefault(); this.activate();
      const sx = ev.clientX, sy = ev.clientY, l0 = this.P.left, t0 = this.P.top;
      const mv = e => { this.P.left = l0 + (e.clientX - sx) * 15; this.P.top = t0 + (e.clientY - sy) * 15; this.place(); };
      const up = () => { window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', up); };
      window.addEventListener('mousemove', mv); window.addEventListener('mouseup', up);
    });
    this.title.addEventListener('dblclick', () => { if (this.P.maxbutton && this.isSizable()) this.setMember('windowstate', this.P.windowstate === 2 ? 0 : 2, this.rt); });
    w.querySelector('.tb-close').addEventListener('click', () => { if (this.P.controlbox) this.vbUnload(0); });
    w.querySelector('.tb-max').addEventListener('click', () => { if (this.P.maxbutton) this.setMember('windowstate', this.P.windowstate === 2 ? 0 : 2, this.rt); });
    w.querySelector('.tb-min').addEventListener('click', () => { if (this.P.minbutton) this.setMember('windowstate', 1, this.rt); });
    w.addEventListener('mousedown', () => this.activate(), true);
    // redimensionar
    w.querySelector('.vb-grip').addEventListener('mousedown', ev => {
      ev.preventDefault(); const sx = ev.clientX, sy = ev.clientY, w0 = this.outerW(), h0 = this.outerH();
      const mv = e => { this.setOuter(Math.max(120, w0 + e.clientX - sx), Math.max(this.chromeH() + 2, h0 + e.clientY - sy)); this.layout(); };
      const up = () => { window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', up); this.fireResize(); };
      window.addEventListener('mousemove', mv); window.addEventListener('mouseup', up);
    });
    // eventos do próprio form
    const ma = (ev) => { const r = this.client.getBoundingClientRect(); return [buttonOf(ev), shiftOf(ev), this.toScaleX(ev.clientX - r.left), this.toScaleY(ev.clientY - r.top)]; };
    this.client.addEventListener('mousedown', ev => { if (ev.target === this.client || ev.target === this.canvas) this.rt.fireEvent(this, 'form', 'mousedown', ma(ev)); });
    this.client.addEventListener('mouseup', ev => { if (ev.target === this.client || ev.target === this.canvas) this.rt.fireEvent(this, 'form', 'mouseup', ma(ev)); });
    this.client.addEventListener('mousemove', ev => { if ((ev.target === this.client || ev.target === this.canvas) && !this.mmBusy && this.rt.hasEvent(this, 'form', 'mousemove')) { this.mmBusy = true; Promise.resolve(this.rt.fireEvent(this, 'form', 'mousemove', ma(ev))).finally(() => { this.mmBusy = false; }); } });
    this.client.addEventListener('click', ev => { if (ev.target === this.client || ev.target === this.canvas) this.rt.fireEvent(this, 'form', 'click', []); });
    this.client.addEventListener('dblclick', ev => { if (ev.target === this.client || ev.target === this.canvas) this.rt.fireEvent(this, 'form', 'dblclick', []); });
    this.client.addEventListener('contextmenu', ev => { if (this.rt.hasEvent(this, 'form', 'mousedown') || this.rt.hasEvent(this, 'form', 'mouseup')) ev.preventDefault(); });
    w.tabIndex = -1;
    w.addEventListener('keydown', ev => { if (ev.target === w || ev.target === this.client) this.formKey('keydown', ev, null); });
  }
  toScaleX(pxv) { return pxv / this.selfScaleX() + (Number(this.P.scaleleft) || 0); }
  toScaleY(pxv) { return pxv / this.selfScaleY() + (Number(this.P.scaletop) || 0); }
  isSizable() { return this.P.borderstyle === 2 || this.P.borderstyle === 5; }
  borderPx() { const b = this.P.borderstyle; if (this.skin === 'modern') return b === 0 ? 0 : 1; return b === 0 ? 0 : (b === 2 || b === 5) ? 4 : 3; }
  titlePx() { const b = this.P.borderstyle; if (b === 0) return 0; if (!this.P.controlbox && !this.P.caption && b !== 4 && b !== 5) return 0; if (this.skin === 'modern') return (b === 4 || b === 5) ? 26 : 32; return (b === 4 || b === 5) ? 16 : 19; }
  menuPx() { if (this.P.mdichild) return 0; return this.menuSource().some(m => m.P.visible) ? (this.skin === 'modern' ? 29 : 20) : 0; }
  menuSource() { if (this.isMDI) { const a = this.host.active; if (a && a.P && a.P.mdichild && !a.dead && a.shown && a.menus.some(m => m.P.visible)) return a.menus; } return this.menus; }
  chromeH() { return 2 * this.borderPx() + this.titlePx() + this.menuPx(); }
  clientWpx() { return this.cw != null ? this.cw : (this.P.clientwidth || 4680) / 15; }
  clientHpx() { return this.ch != null ? this.ch : (this.P.clientheight || 3195) / 15; }
  outerW() { return this.clientWpx() + 2 * this.borderPx(); }
  outerH() { return this.clientHpx() + this.chromeH(); }
  setOuter(wpx, hpx) { this.cw = Math.max(0, wpx - 2 * this.borderPx()); this.ch = Math.max(0, hpx - this.chromeH()); }
  layout() {
    const w = this.win, P = this.P;
    w.classList.toggle('bs0', P.borderstyle === 0); w.classList.toggle('sizable', this.isSizable()); w.classList.toggle('tool', P.borderstyle === 4 || P.borderstyle === 5); w.classList.toggle('dialog', P.borderstyle === 3);
    this.title.style.display = this.titlePx() ? '' : 'none';
    w.querySelector('.vb-tcap').textContent = P.caption ?? '';
    const icon = w.querySelector('.vb-ticon'); icon.style.backgroundImage = P.icon && P.icon.url ? `url(${P.icon.url})` : ''; icon.style.display = (P.borderstyle === 3 || P.borderstyle === 4 || P.borderstyle === 5 || !P.controlbox) ? 'none' : '';
    const bt = w.querySelector('.vb-tbtns'); bt.style.display = P.controlbox ? '' : 'none';
    w.querySelector('.tb-min').style.display = (P.minbutton && P.borderstyle !== 3 && P.borderstyle < 4) ? '' : 'none';
    w.querySelector('.tb-max').style.display = (P.maxbutton && P.borderstyle !== 3 && P.borderstyle < 4) ? '' : 'none';
    w.querySelector('.tb-max').textContent = P.windowstate === 2 ? '2' : '1';
    w.querySelector('.vb-grip').style.display = this.isSizable() && P.windowstate !== 2 ? '' : 'none';
    this.menubar.style.display = this.menuPx() ? '' : 'none';
    this.client.style.backgroundColor = vbColorCss(P.backcolor);
    this.client.style.backgroundImage = P.picture && P.picture.url ? `url(${P.picture.url})` : '';
    this.client.style.color = vbColorCss(P.forecolor);
    applyFont(this.client, P.font);
    w.classList.toggle('vb-disabled', P.enabled === false);
    if (P.windowstate === 2 && this.host.stageSize) { const s = this.host.stageSize(this); this.setOuter(s.w + 2 * this.borderPx(), s.h + 2 * this.borderPx()); }
    this.client.style.width = this.clientWpx() + 'px'; this.client.style.height = this.clientHpx() + 'px';
    this.sizeCanvas(this.clientWpx(), this.clientHpx());
    this.layoutAligned();
    this.place();
  }
  layoutAligned() {
    let t = 0, b = 0, l = 0, r = 0; const W = this.clientWpx(), H = this.clientHpx();
    for (const c of this.topControls) {
      const al = Number(c.P.align) || 0; if (!al || !c.P.visible) continue;
      const P = c.P;
      if (al === 1) { P.left = l * 15; P.top = t * 15; P.width = (W - l - r) * 15; t += P.height / 15; }
      else if (al === 2) { P.left = l * 15; P.width = (W - l - r) * 15; b += P.height / 15; P.top = (H - b) * 15; }
      else if (al === 3) { P.top = t * 15; P.left = l * 15; P.height = (H - t - b) * 15; l += P.width / 15; }
      else if (al === 4) { P.top = t * 15; P.height = (H - t - b) * 15; r += P.width / 15; P.left = (W - r) * 15; }
      c.refresh();
    }
    if (this.isMDI) {
      if (!this.mdiArea) { this.mdiArea = document.createElement('div'); this.mdiArea.className = 'vb-mdiarea'; this.client.appendChild(this.mdiArea); }
      Object.assign(this.mdiArea.style, { position: 'absolute', left: l + 'px', top: t + 'px', width: Math.max(0, W - l - r) + 'px', height: Math.max(0, H - t - b) + 'px', overflow: 'hidden' });
    }
  }
  place() {
    const w = this.win;
    if (this.P.windowstate === 2) { w.style.left = -this.borderPx() + 'px'; w.style.top = -this.borderPx() + 'px'; return; }
    w.style.left = (this.P.left / 15) + 'px'; w.style.top = (this.P.top / 15) + 'px';
  }
  activate() { this.host.bringToFront(this); }
  modalBlocked() { return this.host.isModalBlocked && this.host.isModalBlocked(this); }
  refreshChildren() { for (const c of this.allControls) c.refresh(); }
  async fireResize() { await this.rt.fireEvent(this, 'form', 'resize', []); }

  // ----- menus -----
  renderMenubar() {
    const bar = this.menubar; if (!bar) return;
    bar.innerHTML = '';
    if (this.P.mdichild) { const par = this.rt.loadedForms().find(x => x.isMDI); if (par && par !== this) par.renderMenubar(); return; }
    for (const m of this.menuSource()) {
      if (!m.P.visible) continue;
      const it = document.createElement('span'); it.className = 'vb-mtop' + (m.P.enabled ? '' : ' dis'); it.innerHTML = mnemonicHtml(m.P.caption || '');
      it.addEventListener('mousedown', async ev => { ev.preventDefault(); if (!m.P.enabled || this.modalBlocked()) return; await m.fire(); const r = it.getBoundingClientRect(); this.host.showMenu(m.items, r.left, r.bottom, m.form, it); });
      bar.appendChild(it);
    }
    if (this.win) this.layoutIfShown();
  }
  layoutIfShown() { if (this.shown) { const ch = this.ch; this.layout(); } }

  // ----- membros -----
  syncGet(n) {
    const P = this.P;
    switch (n) {
      case 'caption': return P.caption ?? ''; case 'name': return this.vbName; case 'hwnd': return this.hwnd;
      case 'left': return P.left; case 'top': return P.top;
      case 'width': return this.outerW() * 15; case 'height': return this.outerH() * 15;
      case 'visible': return !!this.shown; case 'windowstate': return P.windowstate || 0;
      case 'fontname': return P.font.name; case 'fontsize': return P.font.size; case 'fontbold': return !!P.font.bold; case 'fontitalic': return !!P.font.italic; case 'fontunderline': return !!P.font.underline;
      case 'count': return this.allControls.length + this.allMenus.length;
    }
    if (n in P) return P[n];
    return undefined;
  }
  _sync(n) { return this.syncGet(n); }
  async getMember(n, rt) {
    switch (n) {
      case 'controls': return this.controlsColl;
      case 'activecontrol': return this.activeCtl || null;
      case 'font': return new VBFont(this);
      case 'picture': case 'icon': return pictureOf(this.P[n]);
      case 'show': case 'hide': case 'refresh': case 'setfocus': case 'cls': case 'zorder': case 'printform': return this.callMethod(n, [], rt);
      case 'me': return this;
    }
    const sv = this.surfaceGet(n); if (sv !== undefined) return sv;
    const c = this.byName.get(n); if (c) return c;
    const v = this.syncGet(n); if (v !== undefined) return v;
    // variáveis/procedimentos públicos do formulário
    if (this.mi) {
      const cell = this.mi.vars.get(n); if (cell && cell.pub) return cell.v;
      const p = this.mi.ast.procs[n]; if (p) return rt.callProc(p.isProperty ? p.propget : p, this.mi, [], null, this);
    }
    if (PROP_TYPES[n] !== undefined || CTL_EXTRA_PROPS.has(n) || ['mdichild', 'keypreview', 'autoredraw', 'showintaskbar', 'startupposition', 'scalemode', 'drawwidth', 'drawstyle', 'drawmode', 'fillcolor', 'fillstyle', 'fontransparent', 'palettemode', 'whatsthisbutton', 'clipcontrols', 'linkmode', 'linktopic', 'hdc'].includes(n)) return this.P[n] ?? 0;
    throw vbErr(438, `Object doesn't support this property or method: ${n}`);
  }
  async setMember(n, v, rt, idx, isSet) {
    const P = this.P;
    if (this.surfaceSet(n, v)) { this.refreshChildren(); return; }
    switch (n) {
      case 'caption': P.caption = toStr(v); this.layout(); this.host.formsChanged && this.host.formsChanged(); return;
      case 'left': P.left = toNum(v); this.place(); return;
      case 'top': P.top = toNum(v); this.place(); return;
      case 'width': this.cw = Math.max(0, toNum(v) / 15 - 2 * this.borderPx()); this.layout(); await this.fireResize(); return;
      case 'height': this.ch = Math.max(0, toNum(v) / 15 - this.chromeH()); this.layout(); await this.fireResize(); return;
      case 'visible': if (toBool(v)) await this.callMethod('show', [], rt); else await this.callMethod('hide', [], rt); return;
      case 'windowstate': { const ws = vbRound(toNum(v)); if (ws === 2 && P.windowstate !== 2) this.restore = { cw: this.clientWpx(), ch: this.clientHpx() }; if (ws === 0 && this.restore) { this.cw = this.restore.cw; this.ch = this.restore.ch; } P.windowstate = ws; this.win.classList.toggle('minimized', ws === 1); this.layout(); await this.fireResize(); return; }
      case 'backcolor': case 'forecolor': P[n] = toNum(v); this.layout(); return;
      case 'picture': case 'icon': P[n] = v instanceof VBPicture ? { url: v.url } : null; this.layout(); return;
      case 'enabled': P.enabled = toBool(v); this.layout(); return;
      case 'fontname': P.font = Object.assign({}, P.font, { name: toStr(v) }); this.layout(); return;
      case 'fontsize': P.font = Object.assign({}, P.font, { size: toNum(v) }); this.layout(); return;
      case 'fontbold': P.font = Object.assign({}, P.font, { bold: toBool(v) }); this.layout(); return;
      case 'fontitalic': P.font = Object.assign({}, P.font, { italic: toBool(v) }); this.layout(); return;
      case 'fontunderline': P.font = Object.assign({}, P.font, { underline: toBool(v) }); this.layout(); return;
    }
    if (this.mi) {
      const p = this.mi.ast.procs[n];
      if (p && p.isProperty) { const t = isSet && p.propset ? p.propset : (p.proplet || p.propset); return rt.callProcValues(t, this.mi, (idx || []).concat([v]), this); }
      const cell = this.mi.vars.get(n); if (cell && cell.pub) { if (idx && cell.v instanceof VBArray) { cell.v.set(idx.map(x => vbRound(toNum(x))), v); return; } rt.setCell(cell, v, isSet); return; }
    }
    const c = this.byName.get(n);
    if (c && c.defaultProp) return c.setMember(c.defaultProp, v, rt);
    P[n] = BOOL_PROPS.has(n) ? toBool(v) : v;
    this.layout();
  }
  async callMember(n, args, frame, rt) {
    if (this.mi) {
      const p = this.mi.ast.procs[n];
      if (p && !p.isProperty) return rt.callProc(p, this.mi, args, frame, this);
      if (p && p.isProperty && p.propget) return rt.callProc(p.propget, this.mi, args, frame, this);
      const cell = this.mi.vars.get(n); if (cell && cell.pub && args.length) { const vals = await rt.argValues(args, frame); if (cell.v instanceof VBArray) return cell.v.get(vals.map(x => vbRound(toNum(x)))); }
    }
    const c = this.byName.get(n);
    if (c) { const vals = await rt.argValues(args, frame); if (!vals.length) return c; return c.callMethod('', vals, rt); }
    const vals = await rt.argValues(args, frame);
    return this.callMethod(n, vals, rt);
  }
  async callMethod(n, a, rt) {
    const r = this.surfaceCall(n, a); if (r) return r.r;
    switch (n) {
      case 'show': {
        const modal = !isMissV(a[0]) && toNum(a[0]) === 1;
        const firstShow = !this.everShown;
        if (!this.shown) { this.shown = true; this.host.showForm(this, modal, firstShow); this.layout(); }
        this.everShown = true; this.activate();
        if (firstShow) { await this.fireResize(); await this.rt.fireEvent(this, 'form', 'activate', []); this.focusFirst(); if (this.rt.hasEvent(this, 'form', 'paint')) await this.rt.fireEvent(this, 'form', 'paint', []); }
        if (modal) { this.modal = true; await new Promise(res => { this.modalResolve = res; }); }
        return;
      }
      case 'hide': if (this.shown) { this.shown = false; this.host.hideForm(this); if (this.modalResolve) { const r2 = this.modalResolve; this.modalResolve = null; this.modal = false; r2(); } } return;
      case 'refresh': this.layout(); return;
      case 'setfocus': this.win.focus(); return;
      case 'move': { if (!isMissV(a[0])) this.P.left = toNum(a[0]); if (!isMissV(a[1])) this.P.top = toNum(a[1]); if (!isMissV(a[2])) this.cw = Math.max(0, toNum(a[2]) / 15 - 2 * this.borderPx()); if (!isMissV(a[3])) this.ch = Math.max(0, toNum(a[3]) / 15 - this.chromeH()); this.layout(); if (!isMissV(a[2]) || !isMissV(a[3])) await this.fireResize(); return; }
      case 'zorder': this.activate(); return;
      case 'printform': case 'whatsthismode': case 'linkexecute': case 'validatecontrols': return;
      case 'popupmenu': { const m = a[0]; if (m instanceof VBMenu) { await m.fire(); const pos = this.host.lastMouse || { x: 100, y: 100 }; this.host.showMenu(m.items, pos.x, pos.y, this); } return; }
      case 'arrange': return;
    }
    if (!a.length) return this.getMember(n, rt);
    throw vbErr(438, `Object doesn't support this property or method: ${n}`);
  }
  focusFirst() {
    const c = this.allControls.filter(c => c.P.tabindex !== undefined && c.P.visible && c.P.enabled && c.P.tabstop !== false && !c.def.noFocus && !['VB.Label', 'VB.Frame', 'VB.Image', 'VB.Timer'].includes(c.type) && isShown(c)).sort((x, y) => x.P.tabindex - y.P.tabindex)[0];
    if (c) { const t = c.input || c.el.querySelector('.vb-list') || c.el; try { t.focus(); } catch (e) { } }
  }
  async formKey(kind, ev, ctl) {
    // tecla de atalho de um menu (Shortcut do Menu Editor: Ctrl+O, F5…)
    if (kind === 'keydown') { const mn = this.menuForKey(ev); if (mn) { ev.preventDefault(); ev.stopPropagation(); await mn.fire(); return true; } }
    if (!this.P.keypreview) {
      if (kind === 'keydown' && !ctl) { if (ev.key === 'Enter') await this.pressDefault(); if (ev.key === 'Escape') await this.pressCancel(); }
      return false;
    }
    if (kind === 'keydown') { if (this.rt.hasEvent(this, 'form', 'keydown')) await this.rt.fireEvent(this, 'form', 'keydown', [ev.keyCode, shiftOf(ev)]); }
    if (kind === 'keyup') { if (this.rt.hasEvent(this, 'form', 'keyup')) await this.rt.fireEvent(this, 'form', 'keyup', [ev.keyCode, shiftOf(ev)]); }
    if (kind === 'keydown' && !ctl && ev.key.length === 1 && this.rt.hasEvent(this, 'form', 'keypress')) await this.rt.fireEvent(this, 'form', 'keypress', [cp1252Code(ev.key)]);
    return false;
  }
  menuForKey(ev) {
    const k = ev.key; let base;
    if (/^F([1-9]|1[0-2])$/.test(k)) base = '{' + k.toUpperCase() + '}';
    else if (k === 'Insert') base = '{INSERT}'; else if (k === 'Delete') base = '{DEL}'; else if (k === 'Backspace') base = '{BKSP}';
    else if (/^[a-z]$/i.test(k) && (ev.ctrlKey || ev.metaKey)) base = k.toUpperCase();
    else return null;
    const code = (ev.shiftKey ? '+' : '') + (ev.ctrlKey || ev.metaKey ? '^' : '') + (ev.altKey ? '%' : '') + base;
    const norm = s => { const m = /^([\^+%]*)(.*)$/.exec(String(s || '').toUpperCase()); return [...m[1]].sort().join('') + m[2]; };
    const want = norm(code);
    const pool = this.isMDI && this.host.active && this.host.active.P && this.host.active.P.mdichild && !this.host.active.dead ? this.host.active.allMenus.concat(this.allMenus) : this.allMenus;
    const ok = mn => { for (let x = mn; x; x = x.parentMenu) if (x.P.enabled === false || x.P.visible === false) return false; return true; };
    return pool.find(mn => mn.P.shortcut && !mn.items.length && norm(mn.P.shortcut) === want && ok(mn)) || null;
  }
  async pressDefault() { const b = this.allControls.find(c => c.type === 'VB.CommandButton' && c.P.default && c.P.visible && c.P.enabled); if (b) { b.el.focus(); await b.fire('click'); } }
  async pressCancel() { const b = this.allControls.find(c => c.type === 'VB.CommandButton' && c.P.cancel && c.P.visible && c.P.enabled); if (b) { b.el.focus(); await b.fire('click'); } }
  async vbUnload(mode) {
    if (this.dead) return true;
    if (this.unloading) return false;
    this.unloading = true;
    try {
      if (this.rt.hasEvent(this, 'form', 'queryunload')) { const r = await this.rt.fireEvent(this, 'form', 'queryunload', [0, mode || 1]); if (r && r.cells[0] && toNum(r.cells[0].v) !== 0) return false; }
      if (this.isMDI) { for (const f of this.rt.loadedForms()) if (f !== this && f.P.mdichild) { const ok = await f.vbUnload(4); if (!ok) return false; } }
      if (this.rt.hasEvent(this, 'form', 'unload')) { const r = await this.rt.fireEvent(this, 'form', 'unload', [0]); if (r && r.cells[0] && toNum(r.cells[0].v) !== 0) return false; }
    } finally { this.unloading = false; }
    this.destroy();
    this.rt.formUnloaded(this);
    return true;
  }
  destroy() {
    if (this.dead) return; this.dead = true;
    for (const c of this.allControls) c.destroy();
    if (this.modalResolve) { const r = this.modalResolve; this.modalResolve = null; r(); }
    this.host.removeForm(this);
  }
  refresh() { this.layout(); }
}
Object.assign(VBForm.prototype, Surface);
function isShown(c) { let p = c; while (p) { if (!p.P.visible) return false; p = p.parentCtl; } return true; }

if (typeof module !== 'undefined') module.exports = { VBForm, VBControl, ControlArray, VBMenu, VBPicture };
