NeoBasic 0.4.8 - free Visual Basic 5/6-style IDE
================================================

NeoBasic is a free development environment for Visual Basic 5/6-style projects.
It runs on Windows and Linux with the same interface.

This package includes:
- NeoBasic launcher and application
- Complete JavaScript/CSS source code
- Standalone HTML build
- Bundled fonts and application icon

Version 0.4.8 interface updates:
- Light blue-and-white visual theme by default
- Compact Toolbox with two columns of blue line icons
- Circular hover/selection highlight for Toolbox tools
- Capsule-shaped buttons throughout the interface
- English locale by default
- Existing project and runtime files retained

Build:
Run codigo-fonte/build.py with Python 3 to regenerate codigo-fonte/dist/NeoBasic.html.
