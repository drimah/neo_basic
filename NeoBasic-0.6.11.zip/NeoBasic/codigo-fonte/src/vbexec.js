// ===== NeoBasic — motor de execução =====
'use strict';
/* depende de vbparse.js e vbrun.js (no navegador ficam no mesmo escopo; no node via require) */
if (typeof module !== 'undefined' && typeof require !== 'undefined' && typeof Parser === 'undefined') {
  Object.assign(globalThis, require('./vbparse.js'), require('./vbrun.js'));
}
if (typeof module !== 'undefined' && typeof require !== 'undefined' && typeof daoOpenDatabase === 'undefined') Object.assign(globalThis, require('./vbdata.js'));

class Cell { constructor(v, t) { this.v = v; this.t = t || 'variant'; } }
class ExitSig { constructor(what) { this.exit = what; } }
const SIG_EXIT = { sub: new ExitSig('sub'), function: new ExitSig('function'), property: new ExitSig('property'), for: new ExitSig('for'), do: new ExitSig('do') };

class ModuleInstance {
  constructor(rt, name, kind, ast, me) {
    this.rt = rt; this.name = name; this.kind = kind; this.ast = ast; this.me = me || null;
    this.vars = new Map(); this.consts = new Map(); this.statics = new Map();
    this.compareText = !!(ast && ast.compareText);
  }
}

class ClassInstance extends VBObject {
  constructor(rt, cls) { super(); this.rt = rt; this.cls = cls; this.mi = new ModuleInstance(rt, cls.name, 'class', cls.ast, this); }
  get typeName() { return this.cls.name; }
  get defaultProp() { const d = this.cls.defaultMember; return d || null; }
  proc(name) { return this.mi.ast.procs[name]; }
  async getMember(name, rt) {
    const p = this.proc(name);
    if (p) {
      if (p.isProperty) { if (!p.propget) throw vbErr(451); return rt.callProc(p.propget, this.mi, [], null, this); }
      return rt.callProc(p, this.mi, [], null, this);
    }
    const c = this.mi.vars.get(name); if (c && c.pub) return c.v;
    throw vbErr(438);
  }
  async setMember(name, v, rt, idx, isSet) {
    const p = this.proc(name);
    if (p && p.isProperty) {
      const target = (isSet && p.propset) ? p.propset : (p.proplet || p.propset);
      if (!target) throw vbErr(451);
      const vals = (idx || []).concat([v]);
      return rt.callProcValues(target, this.mi, vals, this);
    }
    const c = this.mi.vars.get(name);
    if (c && c.pub) { if (idx) { if (!(c.v instanceof VBArray)) throw vbErr(13); c.v.set(idx.map(x => vbRound(toNum(x))), coerce(v, c.v.type, rt)); return; } rt.setCell(c, v, isSet); return; }
    throw vbErr(438);
  }
  async callMember(name, args, frame, rt) {
    const p = this.proc(name);
    if (p) {
      if (p.isProperty) { if (!p.propget) throw vbErr(451); return rt.callProc(p.propget, this.mi, args, frame, this); }
      return rt.callProc(p, this.mi, args, frame, this);
    }
    const c = this.mi.vars.get(name);
    if (c && c.pub) { const vals = await rt.argValues(args, frame); if (c.v instanceof VBArray) return c.v.get(vals.map(x => vbRound(toNum(x)))); if (c.v instanceof VBObject) return c.v.callMethod('', vals, rt); throw vbErr(13); }
    if (!name && this.defaultProp) return this.callMember(this.defaultProp, args, frame, rt);
    throw vbErr(438);
  }
  async callMethod(name, vals, rt) { return rt.callProcValues(this.proc(name) && (this.proc(name).propget || this.proc(name)), this.mi, vals, this); }
}

// ---------- Builtins ----------
const VBCONST = {
  vbcrlf: '\r\n', vbnewline: '\r\n', vbcr: '\r', vblf: '\n', vbtab: '\t', vbnullstring: '', vbnullchar: '\0', vbback: '\b', vbformfeed: '\f', vbverticaltab: '\v',
  vbokonly: 0, vbokcancel: 1, vbabortretryignore: 2, vbyesnocancel: 3, vbyesno: 4, vbretrycancel: 5, vbcritical: 16, vbquestion: 32, vbexclamation: 48, vbinformation: 64,
  vbdefaultbutton1: 0, vbdefaultbutton2: 256, vbdefaultbutton3: 512, vbapplicationmodal: 0, vbsystemmodal: 4096, vbmsgboxhelpbutton: 16384,
  vbok: 1, vbcancel: 2, vbabort: 3, vbretry: 4, vbignore: 5, vbyes: 6, vbno: 7,
  vbblack: 0, vbred: 255, vbgreen: 65280, vbyellow: 65535, vbblue: 16711680, vbmagenta: 16711935, vbcyan: 16776960, vbwhite: 16777215,
  vbscrollbars: -2147483648, vbdesktop: -2147483647, vbactivetitlebar: -2147483646, vbinactivetitlebar: -2147483645, vbmenubar: -2147483644, vbwindowbackground: -2147483643,
  vbwindowframe: -2147483642, vbmenutext: -2147483641, vbwindowtext: -2147483640, vbtitlebartext: -2147483639, vbactiveborder: -2147483638, vbinactiveborder: -2147483637,
  vbapplicationworkspace: -2147483636, vbhighlight: -2147483635, vbhighlighttext: -2147483634, vbbuttonface: -2147483633, vbbuttonshadow: -2147483632, vbgraytext: -2147483631,
  vbbuttontext: -2147483630, vbinactivecaptiontext: -2147483629, vb3dhighlight: -2147483628, vb3ddkshadow: -2147483627, vb3dlight: -2147483626, vbinfotext: -2147483625, vbinfobackground: -2147483624,
  vbbinarycompare: 0, vbtextcompare: 1, vbuppercase: 1, vblowercase: 2, vbpropercase: 3,
  vbempty: 0, vbnull: 1, vbinteger: 2, vblong: 3, vbsingle: 4, vbdouble: 5, vbcurrency: 6, vbdate: 7, vbstring: 8, vbobject: 9, vberror: 10, vbboolean: 11, vbvariant: 12, vbbyte: 17, vbarray: 8192,
  vbsunday: 1, vbmonday: 2, vbtuesday: 3, vbwednesday: 4, vbthursday: 5, vbfriday: 6, vbsaturday: 7, vbusesystem: 0, vbusesystemdayofweek: 0, vbfirstjan1: 1,
  vbgeneraldate: 0, vblongdate: 1, vbshortdate: 2, vblongtime: 3, vbshorttime: 4,
  vbleftbutton: 1, vbrightbutton: 2, vbmiddlebutton: 4, vbshiftmask: 1, vbctrlmask: 2, vbaltmask: 4,
  vbmodal: 1, vbmodeless: 0, vbdefault: 0, vbarrow: 1, vbcrosshair: 2, vbibeam: 3, vbsizepointer: 5, vbsizenesw: 6, vbsizens: 7, vbsizenwse: 8, vbsizewe: 9, vbuparrow: 10, vbhourglass: 11, vbnodrop: 12, vbarrowhourglass: 13, vbarrowquestion: 14, vbsizeall: 15, vbcustom: 99,
  vbobjecterror: -2147221504, vbtrue: -1, vbfalse: 0, vbusedefault: -2,
  vbformcontrolmenu: 0, vbformcode: 1, vbappwindows: 2, vbapptaskmanager: 3, vbformmdiform: 4,
  vbtwips: 1, vbpoints: 2, vbpixels: 3, vbcharacters: 4, vbinches: 5, vbmillimeters: 6, vbcentimeters: 7, vbuser: 0,
  vbfssolid: 0, vbfstransparent: 1, vbhorizontalline: 2, vbverticalline: 3, vbupwarddiagonal: 4, vbdownwarddiagonal: 5, vbcross: 6, vbdiagonalcross: 7,
  vbsolid: 0, vbdash: 1, vbdot: 2, vbdashdot: 3, vbdashdotdot: 4, vbinvisible: 5, vbinsidesolid: 6,
  vbleftjustify: 0, vbrightjustify: 1, vbcenter: 2, vbnormal: 0, vbminimized: 1, vbmaximized: 2, vbreadonly: 1, vbhidden: 2, vbsystem: 4, vbdirectory: 16, vbarchive: 32,
  vbcfText: 1, vbcftext: 1, vbcfbitmap: 2, vbunchecked: 0, vbchecked: 1, vbgrayed: 2, vbbeginDrag: 1, vbbegindrag: 1, vbcancel_: 0, vbenddrag: 2, vbenter: 0, vbleave: 1, vbover: 2,
  vbstrconvuppercase: 1, vbunicode: 64, vbfromunicode: 128, vbwide: 4, vbnarrow: 8,
  vbquerycancel: 0,
};
Object.assign(VBCONST, DAO_CONST);
for (let i = 0; i < 26; i++) VBCONST['vbkey' + String.fromCharCode(97 + i)] = 65 + i;
for (let i = 0; i < 10; i++) { VBCONST['vbkey' + i] = 48 + i; VBCONST['vbkeynumpad' + i] = 96 + i; }
for (let i = 1; i <= 16; i++) VBCONST['vbkeyf' + i] = 111 + i;
Object.assign(VBCONST, { vbkeyback: 8, vbkeytab: 9, vbkeyclear: 12, vbkeyreturn: 13, vbkeyshift: 16, vbkeycontrol: 17, vbkeymenu: 18, vbkeypause: 19, vbkeycapital: 20, vbkeyescape: 27, vbkeyspace: 32, vbkeypageup: 33, vbkeypagedown: 34, vbkeyend: 35, vbkeyhome: 36, vbkeyleft: 37, vbkeyup: 38, vbkeyright: 39, vbkeydown: 40, vbkeyinsert: 45, vbkeydelete: 46, vbkeymultiply: 106, vbkeyadd: 107, vbkeysubtract: 109, vbkeydecimal: 110, vbkeydivide: 111, vbkeynumlock: 144 });

const QB = [0x000000, 0x800000, 0x008000, 0x808000, 0x000080, 0x800080, 0x008080, 0xC0C0C0, 0x808080, 0xFF0000, 0x00FF00, 0xFFFF00, 0x0000FF, 0xFF00FF, 0x00FFFF, 0xFFFFFF];
const isMiss = a => a === undefined || a === VBMissing;
function argN(a, i, d) { return isMiss(a[i]) ? d : a[i]; }
function intArg(v) { return vbRound(toNum(v)); }
function nullStr(fn) { return (a) => (a[0] === VBNull ? VBNull : fn(a)); }
function dateOf(v) { if (v instanceof VBDate) return v; if (typeof v === 'string') return parseDate(v); return VBDate.fromSerial(toNum(v)); }
function addInterval(intv, n, d) {
  const x = new Date(d.d.getTime()); n = Math.trunc(n);
  switch (intv.toLowerCase()) {
    case 'yyyy': x.setFullYear(x.getFullYear() + n); break;
    case 'q': x.setMonth(x.getMonth() + 3 * n); break;
    case 'm': x.setMonth(x.getMonth() + n); break;
    case 'y': case 'd': case 'w': x.setDate(x.getDate() + n); break;
    case 'ww': x.setDate(x.getDate() + 7 * n); break;
    case 'h': x.setHours(x.getHours() + n); break;
    case 'n': x.setMinutes(x.getMinutes() + n); break;
    case 's': x.setSeconds(x.getSeconds() + n); break;
    default: throw vbErr(5);
  }
  return new VBDate(x);
}
function diffInterval(intv, a, b) {
  const A = a.d, B = b.d;
  switch (intv.toLowerCase()) {
    case 'yyyy': return B.getFullYear() - A.getFullYear();
    case 'q': return (B.getFullYear() - A.getFullYear()) * 4 + Math.floor(B.getMonth() / 3) - Math.floor(A.getMonth() / 3);
    case 'm': return (B.getFullYear() - A.getFullYear()) * 12 + B.getMonth() - A.getMonth();
    case 'y': case 'd': return Math.trunc(b.serial) - Math.trunc(a.serial);
    case 'w': return Math.trunc((Math.trunc(b.serial) - Math.trunc(a.serial)) / 7);
    case 'ww': return Math.floor((Math.trunc(b.serial) - B.getDay()) / 7) - Math.floor((Math.trunc(a.serial) - A.getDay()) / 7);
    case 'h': return Math.floor((B - A) / 3600000);
    case 'n': return Math.floor((B - A) / 60000);
    case 's': return Math.floor((B - A) / 1000);
  }
  throw vbErr(5);
}
function vbInStr(a, rt) {
  let start = 1, s1, s2, cmp = 0;
  if (typeof a[0] === 'number' && a.length >= 3) { start = intArg(a[0]); s1 = a[1]; s2 = a[2]; cmp = argN(a, 3, 0); }
  else { s1 = a[0]; s2 = a[1]; cmp = argN(a, 2, 0); }
  if (s1 === VBNull || s2 === VBNull) return VBNull;
  if (start < 1) throw vbErr(5);
  s1 = toStr(s1); s2 = toStr(s2);
  if (toNum(cmp) === 1) { s1 = s1.toLowerCase(); s2 = s2.toLowerCase(); }
  if (s2 === '') return start <= s1.length ? start : 0;
  return s1.indexOf(s2, start - 1) + 1;
}
let rndSeed = 0.5, rndLast = 0;
function vbRnd(a) {
  if (a.length && !isMiss(a[0])) { const n = toNum(a[0]); if (n === 0) return rndLast; if (n < 0) { rndSeed = Math.abs(Math.sin(n)); } }
  rndLast = Math.random(); return rndLast;
}

const BUILTINS = {
  opendatabase: (a, rt) => daoOpenDatabase(rt, toStr(a[0]), a[2] !== undefined && a[2] !== VBMissing && toBool(a[2])),
  len: a => a[0] === VBNull ? VBNull : (a[0] instanceof VBRecord ? 0 : toStr(a[0]).length),
  lenb: a => toStr(a[0]).length * 2,
  left: nullStr(a => { const n = intArg(a[1]); if (n < 0) throw vbErr(5); return toStr(a[0]).slice(0, n); }),
  right: nullStr(a => { const s = toStr(a[0]); const n = intArg(a[1]); if (n < 0) throw vbErr(5); return n ? s.slice(-n) : ''; }),
  mid: nullStr(a => { const s = toStr(a[0]); const st = intArg(a[1]); if (st < 1) throw vbErr(5); const n = isMiss(a[2]) ? undefined : intArg(a[2]); return n === undefined ? s.slice(st - 1) : s.substr(st - 1, Math.max(0, n)); }),
  ucase: nullStr(a => toStr(a[0]).toUpperCase()), lcase: nullStr(a => toStr(a[0]).toLowerCase()),
  trim: nullStr(a => toStr(a[0]).replace(/^ +| +$/g, '')), ltrim: nullStr(a => toStr(a[0]).replace(/^ +/, '')), rtrim: nullStr(a => toStr(a[0]).replace(/ +$/, '')),
  space: a => ' '.repeat(Math.max(0, intArg(a[0]))),
  string: a => { const n = intArg(a[0]); const c = typeof a[1] === 'number' ? String.fromCharCode(a[1]) : toStr(a[1])[0] || ''; return c.repeat(Math.max(0, n)); },
  strreverse: a => [...toStr(a[0])].reverse().join(''),
  instr: vbInStr,
  instrrev: a => { const s = toStr(a[0]), f = toStr(a[1]); let st = isMiss(a[2]) ? -1 : intArg(a[2]); let S = s, F = f; if (toNum(argN(a, 3, 0)) === 1) { S = s.toLowerCase(); F = f.toLowerCase(); } if (st === -1) st = s.length; return S.lastIndexOf(F, st - F.length) + 1; },
  replace: a => {
    let s = toStr(a[0]); const f = toStr(a[1]), r = toStr(a[2]); const st = intArg(argN(a, 3, 1)); let cnt = intArg(argN(a, 4, -1)); const tc = toNum(argN(a, 5, 0)) === 1;
    s = s.slice(st - 1); if (f === '') return s;
    let out = '', i = 0; const S = tc ? s.toLowerCase() : s, F = tc ? f.toLowerCase() : f;
    while (cnt !== 0) { const j = S.indexOf(F, i); if (j < 0) break; out += s.slice(i, j) + r; i = j + f.length; cnt--; }
    return out + s.slice(i);
  },
  split: a => { const s = toStr(a[0]); const d = isMiss(a[1]) ? ' ' : toStr(a[1]); let lim = intArg(argN(a, 2, -1)); if (s === '') { const e = new VBArray([[0, -1]], 'string'); return e; } let parts = d === '' ? [s] : s.split(d); if (lim > 0 && parts.length > lim) parts = parts.slice(0, lim - 1).concat([parts.slice(lim - 1).join(d)]); const r = arrFrom(parts); r.type = 'string'; return r; },
  join: a => { if (!(a[0] instanceof VBArray)) throw vbErr(13); return a[0].data.map(toStr).join(isMiss(a[1]) ? ' ' : toStr(a[1])); },
  filter: a => { const src = a[0]; const m = toStr(a[1]); const inc = isMiss(a[2]) ? true : toBool(a[2]); const tc = toNum(argN(a, 3, 0)) === 1; return arrFrom(src.data.map(toStr).filter(x => ((tc ? x.toLowerCase().includes(m.toLowerCase()) : x.includes(m)) === inc))); },
  strcomp: a => { if (a[0] === VBNull || a[1] === VBNull) return VBNull; let x = toStr(a[0]), y = toStr(a[1]); if (toNum(argN(a, 2, 0)) === 1) { x = x.toLowerCase(); y = y.toLowerCase(); } return x < y ? -1 : x > y ? 1 : 0; },
  strconv: a => { const s = toStr(a[0]); const m = toNum(a[1]); if (m & 3) { if ((m & 3) === 1) return s.toUpperCase(); if ((m & 3) === 2) return s.toLowerCase(); return s.toLowerCase().replace(/(^|[\s\-])(\S)/g, (x, p, c) => p + c.toUpperCase()); } return s; },
  asc: a => { const s = toStr(a[0]); if (!s.length) throw vbErr(5); const c = s.charCodeAt(0); return c > 255 ? cp1252Code(s[0]) : c; }, ascw: a => { const s = toStr(a[0]); if (!s.length) throw vbErr(5); return s.charCodeAt(0); }, ascb: a => toStr(a[0]).charCodeAt(0) & 255,
  chr: a => { const n = intArg(a[0]); if (n < 0 || n > 255) throw vbErr(5); return cp1252Char(n); }, chrw: a => String.fromCharCode(intArg(a[0]) & 0xFFFF), chrb: a => String.fromCharCode(intArg(a[0]) & 255),
  val: a => { const s = toStr(a[0]).replace(/[ \t\r\n]/g, ''); const hm = /^&H([0-9a-f]+)/i.exec(s); if (hm) { let v = parseInt(hm[1], 16); if (v > 0x7fff && hm[1].length <= 4) v -= 0x10000; return v; } const om = /^&O([0-7]+)/i.exec(s); if (om) return parseInt(om[1], 8); const m = /^[+\-]?(\d+\.?\d*|\.\d+)([eEdD][+\-]?\d+)?/.exec(s); return m ? Number(m[0].replace(/[dD]/, 'e')) : 0; },
  str: a => { if (a[0] === VBNull) return VBNull; const n = toNum(a[0]); return (n >= 0 ? ' ' : '') + numToStr(n, '.'); },
  cstr: a => toStr(a[0]),
  cint: a => coerce(a[0], 'integer'), clng: a => coerce(a[0], 'long'), cbyte: a => coerce(a[0], 'byte'), clnglng: a => coerce(a[0], 'longlong'),
  csng: a => toNum(a[0]), cdbl: a => toNum(a[0]), ccur: a => coerce(a[0], 'currency'), cdec: a => toNum(a[0]),
  cbool: a => toBool(a[0]), cdate: a => coerce(a[0], 'date'), cvdate: a => coerce(a[0], 'date'), cvar: a => a[0], cverr: a => toNum(a[0]),
  int: a => a[0] === VBNull ? VBNull : Math.floor(toNum(a[0])), fix: a => a[0] === VBNull ? VBNull : Math.trunc(toNum(a[0])),
  abs: a => a[0] === VBNull ? VBNull : Math.abs(toNum(a[0])), sgn: a => Math.sign(toNum(a[0])),
  sqr: a => { const n = toNum(a[0]); if (n < 0) throw vbErr(5); return Math.sqrt(n); },
  exp: a => Math.exp(toNum(a[0])), log: a => { const n = toNum(a[0]); if (n <= 0) throw vbErr(5); return Math.log(n); },
  sin: a => Math.sin(toNum(a[0])), cos: a => Math.cos(toNum(a[0])), tan: a => Math.tan(toNum(a[0])), atn: a => Math.atan(toNum(a[0])),
  round: a => { const n = toNum(a[0]); const d = intArg(argN(a, 1, 0)); const f = Math.pow(10, d); return vbRound(Number((n * f).toPrecision(15))) / f; },
  rnd: vbRnd,
  hex: a => { let n = vbRound(toNum(a[0])); if (n < 0) n = (n >= -32768 && n <= 32767 && Number.isInteger(n) && a[0] !== undefined && Math.abs(n) <= 32768) ? (n & 0xFFFF) : (n >>> 0); return n.toString(16).toUpperCase(); },
  oct: a => { let n = vbRound(toNum(a[0])); if (n < 0) n = n >>> 0; return n.toString(8); },
  isnumeric: a => { const v = a[0]; if (typeof v === 'number' || typeof v === 'boolean') return true; if (typeof v === 'string') return v.trim() !== '' && isNumericStr(v); if (v === undefined) return true; return false; },
  isempty: a => a[0] === undefined, isnull: a => a[0] === VBNull, isarray: a => a[0] instanceof VBArray, isobject: a => a[0] === null || a[0] instanceof VBObject,
  isdate: a => { if (a[0] instanceof VBDate) return true; if (typeof a[0] !== 'string') return false; try { parseDate(a[0]); return true; } catch (e) { return false; } },
  ismissing: a => a[0] === VBMissing, iserror: a => false,
  typename: a => typeNameOf(a[0]), vartype: a => varTypeOf(a[0]),
  ubound: a => { const arr = a[0]; if (!(arr instanceof VBArray)) throw vbErr(13); const d = intArg(argN(a, 1, 1)); if (!arr.dims.length || d < 1 || d > arr.dims.length) throw vbErr(9); return arr.dims[d - 1][1]; },
  lbound: a => { const arr = a[0]; if (!(arr instanceof VBArray)) throw vbErr(13); const d = intArg(argN(a, 1, 1)); if (!arr.dims.length || d < 1 || d > arr.dims.length) throw vbErr(9); return arr.dims[d - 1][0]; },
  array: a => arrFrom(a.map(x => x === VBMissing ? undefined : x)),
  now: () => new VBDate(new Date()),
  date: () => { const d = new Date(); return new VBDate(new Date(d.getFullYear(), d.getMonth(), d.getDate())); },
  time: () => { const d = new Date(); const t = new Date(EPOCH_BASE()); t.setHours(d.getHours(), d.getMinutes(), d.getSeconds()); return new VBDate(t); },
  timer: () => { const d = new Date(); return (d - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / 1000; },
  year: a => dateOf(a[0]).d.getFullYear(), month: a => dateOf(a[0]).d.getMonth() + 1, day: a => dateOf(a[0]).d.getDate(),
  hour: a => dateOf(a[0]).d.getHours(), minute: a => dateOf(a[0]).d.getMinutes(), second: a => dateOf(a[0]).d.getSeconds(),
  weekday: a => { const fd = intArg(argN(a, 1, 1)) || 1; return ((dateOf(a[0]).d.getDay() + 1 - fd + 7) % 7) + 1; },
  dateserial: a => new VBDate(new Date(intArg(a[0]) < 100 ? 1900 + intArg(a[0]) : intArg(a[0]), intArg(a[1]) - 1, intArg(a[2]))),
  timeserial: a => { const t = new Date(EPOCH_BASE()); t.setHours(intArg(a[0]), intArg(a[1]), intArg(a[2])); return new VBDate(t); },
  datevalue: a => { const d = dateOf(a[0]).d; return new VBDate(new Date(d.getFullYear(), d.getMonth(), d.getDate())); },
  timevalue: a => { const d = dateOf(a[0]).d; const t = new Date(EPOCH_BASE()); t.setHours(d.getHours(), d.getMinutes(), d.getSeconds()); return new VBDate(t); },
  dateadd: a => addInterval(toStr(a[0]), toNum(a[1]), dateOf(a[2])),
  datediff: a => diffInterval(toStr(a[0]), dateOf(a[1]), dateOf(a[2])),
  datepart: a => { const i = toStr(a[0]).toLowerCase(), d = dateOf(a[1]).d; return { yyyy: d.getFullYear(), q: Math.floor(d.getMonth() / 3) + 1, m: d.getMonth() + 1, d: d.getDate(), w: d.getDay() + 1, h: d.getHours(), n: d.getMinutes(), s: d.getSeconds(), y: Math.floor((d - new Date(d.getFullYear(), 0, 1)) / 86400000) + 1, ww: Math.ceil(((d - new Date(d.getFullYear(), 0, 1)) / 86400000 + new Date(d.getFullYear(), 0, 1).getDay() + 1) / 7) }[i]; },
  monthname: a => { const n = (typeof LOCALE !== 'undefined' && LOCALE === 'en-US' ? ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'] : ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'])[intArg(a[0]) - 1]; return toBool(argN(a, 1, false)) ? n.slice(0, 3) : n; },
  weekdayname: a => { const n = (typeof LOCALE !== 'undefined' && LOCALE === 'en-US' ? ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'] : ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'])[(intArg(a[0]) - 1) % 7]; return toBool(argN(a, 1, false)) ? n.slice(0, 3) : n; },
  format: a => vbFormat(a[0], a[1]), format$: a => vbFormat(a[0], a[1]),
  formatnumber: a => fmtFixed(toNum(a[0]), intArg(argN(a, 1, 2)), toNum(argN(a, 4, -1)) !== 0),
  formatcurrency: a => { const n = toNum(a[0]); return (n < 0 ? '-' : '') + curSym() + fmtFixed(Math.abs(n), intArg(argN(a, 1, 2)), true); },
  formatpercent: a => fmtFixed(toNum(a[0]) * 100, intArg(argN(a, 1, 2)), true) + '%',
  formatdatetime: a => vbFormat(dateOf(a[0]), ['General Date', 'Long Date', 'Short Date', 'Long Time', 'Short Time'][intArg(argN(a, 1, 0))]),
  iif: a => toBool(a[0]) ? a[1] : a[2],
  choose: a => { const i = intArg(a[0]); return (i >= 1 && i < a.length) ? a[i] : VBNull; },
  switch: a => { for (let i = 0; i + 1 < a.length; i += 2) if (toBool(a[i])) return a[i + 1]; return VBNull; },
  rgb: a => (Math.max(0, Math.min(255, intArg(a[0])))) | (Math.max(0, Math.min(255, intArg(a[1]))) << 8) | (Math.max(0, Math.min(255, intArg(a[2]))) << 16),
  qbcolor: a => { const c = QB[intArg(a[0]) & 15]; return ((c & 0xFF) << 16) | (c & 0xFF00) | ((c >> 16) & 0xFF); },
  environ: a => '', command: () => '', curdir: () => 'C:\\NeoBasic', 'environ$': () => '',
  nz: a => (a[0] === VBNull || a[0] === undefined) ? argN(a, 1, '') : a[0],
  loadpicture: a => (typeof VBPicture !== 'undefined' ? new VBPicture('', 0, 0) : null), savepicture: a => undefined, loadrespicture: a => (typeof VBPicture !== 'undefined' ? new VBPicture('', 0, 0) : null), loadresstring: a => '',
  getsetting: (a, rt) => { const v = rt.host.getSetting ? rt.host.getSetting(toStr(a[0]), toStr(a[1]), toStr(a[2])) : null; return v == null ? (isMiss(a[3]) ? '' : a[3]) : v; },
  savesetting: (a, rt) => { if (rt.host.saveSetting) rt.host.saveSetting(toStr(a[0]), toStr(a[1]), toStr(a[2]), toStr(a[3])); },
  deletesetting: (a, rt) => { if (rt.host.deleteSetting) rt.host.deleteSetting(toStr(a[0]), isMiss(a[1]) ? null : toStr(a[1]), isMiss(a[2]) ? null : toStr(a[2])); },
  beep: (a, rt) => { if (rt.host.beep) rt.host.beep(); },
  sendkeys: () => undefined, appactivate: () => undefined,
  shell: () => { throw vbErr(1002, 'Shell is not supported by NeoBasic (programs run in a sandbox and cannot start other programs)'); },
  createobject: (a, rt) => rt.createObject(toStr(a[0]).toLowerCase(), true),
  getobject: () => { throw vbErr(429); },
  error: a => ERR_MSG[intArg(argN(a, 0, 0))] || 'Erro definido pelo aplicativo ou pelo objeto',
  // arquivos (sistema de arquivos virtual)
  freefile: (a, rt) => rt.files.freeFile(), eof: (a, rt) => rt.files.eof(intArg(a[0])), lof: (a, rt) => rt.files.lof(intArg(a[0])), loc: (a, rt) => rt.files.loc(intArg(a[0])),
  filelen: (a, rt) => rt.files.fileLen(toStr(a[0])), dir: (a, rt) => rt.files.dir(isMiss(a[0]) ? null : toStr(a[0])), filedatetime: () => new VBDate(new Date()),
  getattr: () => 0, chdir: () => undefined, chdrive: () => undefined, mkdir: () => undefined, rmdir: () => undefined,
  filecopy: (a, rt) => { const c = rt.files.read(toStr(a[0])); if (c == null) throw vbErr(53); rt.files.write(toStr(a[1]), c); }, input: (a, rt) => rt.files.inputChars(intArg(a[0]), intArg(a[1])),
};
const SCREEN_FONTS = ['Arial', 'Comic Sans MS', 'Courier New', 'Georgia', 'Impact', 'Lucida Console', 'MS Sans Serif', 'MS Serif', 'Tahoma', 'Times New Roman', 'Trebuchet MS', 'Verdana'];
function EPOCH_BASE() { return new Date(1899, 11, 30).getTime(); }
const CP1252 = { 128: 0x20AC, 130: 0x201A, 131: 0x0192, 132: 0x201E, 133: 0x2026, 134: 0x2020, 135: 0x2021, 136: 0x02C6, 137: 0x2030, 138: 0x0160, 139: 0x2039, 140: 0x0152, 142: 0x017D, 145: 0x2018, 146: 0x2019, 147: 0x201C, 148: 0x201D, 149: 0x2022, 150: 0x2013, 151: 0x2014, 152: 0x02DC, 153: 0x2122, 154: 0x0161, 155: 0x203A, 156: 0x0153, 158: 0x017E, 159: 0x0178 };
const CP1252_REV = {}; for (const k in CP1252) CP1252_REV[CP1252[k]] = +k;
function cp1252Char(n) { return String.fromCharCode(CP1252[n] || n); }
function cp1252Code(ch) { const c = ch.charCodeAt(0); return CP1252_REV[c] || (c < 256 ? c : 63); }
const ASYNC_BUILTINS = new Set(['msgbox', 'inputbox', 'doevents', 'unload', 'load']);
const FORM_IMPLICIT = new Set(['caption', 'width', 'height', 'left', 'top', 'backcolor', 'forecolor', 'cls', 'show', 'hide', 'move', 'refresh', 'setfocus', 'scalewidth', 'scaleheight', 'scalemode', 'scaleleft', 'scaletop', 'currentx', 'currenty', 'windowstate', 'visible', 'enabled', 'controls', 'activecontrol', 'fontname', 'fontsize', 'fontbold', 'fontitalic', 'fontunderline', 'font', 'drawwidth', 'drawstyle', 'drawmode', 'fillcolor', 'fillstyle', 'autoredraw', 'keypreview', 'picture', 'icon', 'mousepointer', 'textwidth', 'textheight', 'point', 'popupmenu', 'zorder', 'tag', 'hwnd', 'printform', 'scalex', 'scaley', 'paintpicture', 'windowstate', 'image', 'count', 'arrange']);
const NODEREF = new Set(['isobject', 'typename', 'vartype', 'isarray', 'ismissing', 'isempty', 'isnull', 'array', 'iif', 'choose', 'switch', 'ubound', 'lbound', 'join', 'filter']);

// ---------- Arquivos virtuais ----------
class VirtualFS {
  constructor(host) { this.host = host; this.handles = new Map(); }
  norm(p) { return p.replace(/\//g, '\\').toLowerCase(); }
  read(p) { return this.host.vfsRead ? this.host.vfsRead(this.norm(p)) : null; }
  write(p, s) { if (this.host.vfsWrite) this.host.vfsWrite(this.norm(p), s); }
  freeFile() { for (let i = 1; i < 512; i++) if (!this.handles.has(i)) return i; throw vbErr(67); }
  open(path, mode, n) {
    if (this.handles.has(n)) throw vbErr(55);
    let content = this.read(path);
    if (mode === 'input' || mode === 'binary' || mode === 'random') { if (content == null) { if (mode === 'input') throw vbErr(53); content = ''; } }
    if (mode === 'output') content = '';
    if (mode === 'append' && content == null) content = '';
    this.handles.set(n, { path, mode, buf: content, pos: 0 });
  }
  h(n) { const h = this.handles.get(n); if (!h) throw vbErr(52); return h; }
  close(n) { if (n == null) { for (const k of [...this.handles.keys()]) this.close(k); return; } const h = this.handles.get(n); if (!h) return; if (h.mode !== 'input') this.write(h.path, h.buf); this.handles.delete(n); }
  print(n, s) { const h = this.h(n); if (h.mode === 'input') throw vbErr(54); h.buf += s; }
  eof(n) { const h = this.h(n); return h.pos >= h.buf.length; }
  lof(n) { return this.h(n).buf.length; }
  loc(n) { return this.h(n).pos; }
  lineInput(n) { const h = this.h(n); if (h.pos >= h.buf.length) throw vbErr(62); let j = h.buf.indexOf('\n', h.pos); let line; if (j < 0) { line = h.buf.slice(h.pos); h.pos = h.buf.length; } else { line = h.buf.slice(h.pos, j); h.pos = j + 1; } return line.replace(/\r$/, ''); }
  inputField(n) {
    const h = this.h(n); const b = h.buf;
    while (h.pos < b.length && (b[h.pos] === ' ' || b[h.pos] === '\t')) h.pos++;
    if (h.pos >= b.length) throw vbErr(62);
    let v;
    if (b[h.pos] === '"') { const j = b.indexOf('"', h.pos + 1); v = b.slice(h.pos + 1, j < 0 ? b.length : j); h.pos = j < 0 ? b.length : j + 1; }
    else { let j = h.pos; while (j < b.length && b[j] !== ',' && b[j] !== '\r' && b[j] !== '\n') j++; v = b.slice(h.pos, j).trim(); h.pos = j; }
    while (h.pos < b.length && (b[h.pos] === ' ')) h.pos++;
    if (b[h.pos] === ',') h.pos++; else { if (b[h.pos] === '\r') h.pos++; if (b[h.pos] === '\n') h.pos++; }
    return v;
  }
  inputChars(cnt, n) { const h = this.h(n); const s = h.buf.substr(h.pos, cnt); h.pos += s.length; return s; }
  fileLen(p) { const c = this.read(p); if (c == null) throw vbErr(53); return c.length; }
  kill(p) { if (this.read(p) == null) throw vbErr(53); if (this.host.vfsDelete) this.host.vfsDelete(this.norm(p)); }
  dir(pattern) {
    if (pattern !== null) {
      const all = this.host.vfsList ? this.host.vfsList() : [];
      const pat = this.norm(pattern); const re = likeToRegexCI(pat);
      this.dirList = all.filter(f => re.test(f)).map(f => f.split('\\').pop());
      this.dirPos = 0;
    }
    if (!this.dirList || this.dirPos >= this.dirList.length) return '';
    return this.dirList[this.dirPos++];
  }
}
function likeToRegexCI(p) { return new RegExp('^' + p.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\?/g, '.') + '$', 'i'); }

// ---------- Runtime ----------
class VBRuntime {
  constructor(host) {
    this.host = host || {};
    this.err = new ErrObject();
    this.files = new VirtualFS(this.host);
    this.tick = 0; this.stopped = false; this.depth = 0;
    this.stdModules = []; this.classes = new Map(); this.forms = new Map(); this.types = new Map(); this.enumConsts = new Map();
    this.globals = this.makeGlobals();
  }
  makeGlobals() {
    const rt = this;
    const debug = new SimpleObject('Debug', {}, { print: (a) => rt.host.debugPrint && rt.host.debugPrint(a.map(toStr).join(' ') + '\r\n'), assert: (a) => { if (!toBool(a[0])) throw vbErr(1002, 'Debug.Assert failed'); } });
    debug.isDebug = true;
    const app = new SimpleObject('App', { path: () => rt.host.appPath || 'C:\\NeoBasic', exename: () => rt.projectName || 'Projeto1', title: () => rt.projectTitle || rt.projectName || 'Projeto1', major: 1, minor: 0, revision: 0, previnstance: false, helpfile: '', comments: '', companyname: '', productname: '', legalcopyright: '', taskvisible: true, hinstance: 0, threadid: 0 }, {});
    const screen = new SimpleObject('Screen', { width: () => (rt.host.screenW ? rt.host.screenW() : 1366) * 15, height: () => (rt.host.screenH ? rt.host.screenH() : 768) * 15, twipsperpixelx: 15, twipsperpixely: 15, mousepointer: 0, activeform: () => rt.host.activeForm ? rt.host.activeForm() : null, activecontrol: () => (rt.host.activeForm && rt.host.activeForm() ? rt.host.activeForm().activeCtl || null : null), fontcount: SCREEN_FONTS.length }, { fonts: (a) => SCREEN_FONTS[intArg(a[0])] || '' });
    let clip = '';
    const clipboard = new SimpleObject('Clipboard', {}, { settext: (a) => { clip = toStr(a[0]); try { navigator.clipboard.writeText(clip); } catch (e) { } }, gettext: () => clip, clear: () => { clip = ''; }, getformat: () => clip !== '' });
    const printer = new SimpleObject('Printer', { currentx: 0, currenty: 0, fontsize: 10, fontname: 'Arial', width: 11906, height: 16838, scalewidth: 11906, scaleheight: 16838, orientation: 1, copies: 1, fontbold: false, fontitalic: false }, { enddoc: () => rt.host.printerEnd && rt.host.printerEnd(), newpage: () => rt.host.printerPrint && rt.host.printerPrint('\f'), killdoc: () => undefined, textwidth: (a) => toStr(a[0]).length * 100, textheight: () => 240 });
    printer.isPrinter = true;
    const forms = new SimpleObject('Forms', { count: () => rt.loadedForms().length }, { item: (a) => rt.loadedForms()[intArg(a[0])] });
    forms.enumerate = () => rt.loadedForms();
    return { debug, err: this.err, app, screen, clipboard, printer, forms, dbengine: makeDBEngine(rt) };
  }
  loadedForms() { const out = []; for (const f of this.forms.values()) if (f.instance) out.push(f.instance); if (this.extraForms) out.push(...this.extraForms.filter(x => !x.dead)); return out; }

  // ----- carregar projeto -----
  load(project) {
    // project: { name, title, startup, modules: [{name, kind:'std'|'class'|'form', source, formData}] }
    this.projectName = project.name; this.projectTitle = project.title;
    this.startup = (project.startup || '').toLowerCase();
    const parsed = [];
    for (const m of project.modules) {
      let ast;
      try { ast = parseModuleSource(m.source, m.name); }
      catch (e) { if (e.isSyntax) { const err = new VBError(1000, e.message, e.line, m.name); err.isCompile = true; throw err; } throw e; }
      parsed.push({ m, ast });
      for (const k in ast.types) this.types.set(k, ast.types[k]);
    }
    for (const { m, ast } of parsed) {
      const key = m.name.toLowerCase();
      if (m.kind === 'std') { const mi = new ModuleInstance(this, m.name, 'std', ast, null); this.stdModules.push(mi); }
      else if (m.kind === 'class') this.classes.set(key, { name: m.name, ast, defaultMember: m.defaultMember || null });
      else if (m.kind === 'form') this.forms.set(key, { name: m.name, ast, data: m.formData, instance: null, mi: null });
    }
    // enums (globais) e constantes
    this.pendingInit = parsed;
  }
  async init() {
    for (const { ast } of this.pendingInit) {
      for (const k in ast.enums) { let v = -1; for (const it of ast.enums[k].items) { v = it.expr ? toNum(await this.evalConst(it.expr)) : v + 1; this.enumConsts.set(it.name.toLowerCase(), v); } }
    }
    for (const mi of this.stdModules) await this.initModule(mi);
  }
  async evalConst(expr, mi) { const frame = this.newFrame(mi || this.stdModules[0] || new ModuleInstance(this, '', 'std', { procs: {}, decls: [], consts: [] }), null); return this.evalExpr(expr, frame); }
  async initModule(mi) {
    const ast = mi.ast;
    const frame = this.newFrame(mi, null);
    for (const c of ast.consts) { const cell = new Cell(await this.evalExpr(c.expr, frame), 'variant'); cell.isConst = true; cell.pub = c.vis !== 'private'; mi.consts.set(c.name.toLowerCase(), cell); }
    for (const d of ast.decls) { const cell = await this.makeDimCell(d, frame); cell.pub = d.vis !== 'private'; mi.vars.set(d.name.toLowerCase(), cell); }
  }
  findType(name) { return this.types.get(name); }
  makeArray(dims, type, frame) {
    // dims já avaliados? aceita nós AST (sincrono não) — usado só com literais em tipos
    const evald = dims.map(d => [d.lb ? toNum(d.lb.v) : 0, toNum(d.ub.v !== undefined ? d.ub.v : 0)]);
    return new VBArray(evald, type, this);
  }
  async makeDimCell(d, frame) {
    let cell;
    if (d.dims) {
      if (!d.dims.length) { const a = new VBArray([], d.type, this); a.dynamic = true; if (d.isNew) a.autoNew = d.type; cell = new Cell(a, d.type); }
      else {
        const dims = [];
        for (const dd of d.dims) { const lb = dd.lb ? intArg(await this.evalExpr(dd.lb, frame)) : (frame.mi.ast.optionBase || 0); const ub = intArg(await this.evalExpr(dd.ub, frame)); dims.push([lb, ub]); }
        cell = new Cell(new VBArray(dims, d.type, this), d.type); cell.fixedArray = true; if (d.isNew) cell.v.autoNew = d.type;
      }
      cell.isArray = true;
    } else {
      cell = new Cell(defaultValue(d.type, this), d.type);
      if (d.isNew) { cell.autoNew = d.type; cell.v = null; }
    }
    return cell;
  }

  // ----- formulários -----
  async getForm(key, noLoad) {
    const f = this.forms.get(key);
    if (!f) return undefined;
    if (!f.instance && !noLoad) await this.loadForm(f);
    return f.instance;
  }
  async loadForm(f) {
    if (f.instance) return f.instance;
    if (!this.host.createForm) throw vbErr(1002, 'Forms are not available here');
    const inst = this.host.createForm(f, this);
    f.instance = inst;
    const mi = new ModuleInstance(this, f.name, 'form', f.ast, inst);
    f.mi = mi; inst.mi = mi;
    await this.initModule(mi);
    await this.fireEvent(inst, 'form', 'initialize', []);
    await this.fireEvent(inst, 'form', 'load', []);
    if (typeof nbInitFormData === 'function' && !this.stopped) await nbInitFormData(inst, this);
    await this.autoShowMDIChild(inst);
    return inst;
  }
  async newFormInstance(f) {
    // instância adicional de um formulário (Dim x As New Form1 / Set x = New Form1)
    const inst = this.host.createForm(f, this);
    inst.extraInstance = true;
    const mi = new ModuleInstance(this, f.name, 'form', f.ast, inst); inst.mi = mi;
    (this.extraForms || (this.extraForms = [])).push(inst);
    await this.initModule(mi);
    await this.fireEvent(inst, 'form', 'initialize', []);
    await this.fireEvent(inst, 'form', 'load', []);
    if (typeof nbInitFormData === 'function' && !this.stopped) await nbInitFormData(inst, this);
    await this.autoShowMDIChild(inst);
    return inst;
  }
  async autoShowMDIChild(inst) {
    if (!inst || inst.dead || !inst.P || !inst.P.mdichild || inst.shown) return;
    const mdi = this.loadedForms().find(x => x.isMDI);
    if (mdi && mdi.P.autoshowchildren === false) return;
    await inst.callMethod('show', [], this);
  }
  formUnloaded(f) {
    if (f.extraInstance && this.extraForms) this.extraForms = this.extraForms.filter(x => x !== f); const def = this.forms.get(f.formId); if (def && def.instance === f) { def.instance = null; def.mi = null; } if (!this.loadedForms().length && !this.mainRunning) this.end(); }

  // ----- objetos -----
  async createObject(cls, viaCreate) {
    if (cls === 'collection' || cls === 'vba.collection') return new VBCollection();
    if (cls === 'scripting.dictionary' || cls === 'dictionary') return new VBDictionary();
    const key = cls.split('.').pop();
    const c = this.classes.get(key);
    if (c) { const o = new ClassInstance(this, c); await this.initModule(o.mi); const ini = c.ast.procs['class_initialize']; if (ini) await this.callProc(ini, o.mi, [], null, o); return o; }
    const f = this.forms.get(key);
    if (f) return this.newFormInstance(f);
    if (viaCreate) throw vbErr(429, `ActiveX component can't create object: ${cls}`);
    throw vbErr(429, `User-defined type not defined: ${cls}`);
  }

  // ----- execução -----
  newFrame(mi, proc, me) { return { mi, proc, me: me !== undefined ? me : mi.me, locals: new Map(), withStack: [], errMode: null, inHandler: false }; }

  async run() {
    this.stopped = false;
    try {
      await this.init();
      let main = null, mainMi = null;
      for (const mi of this.stdModules) if (mi.ast.procs['main']) { main = mi.ast.procs['main']; mainMi = mi; }
      if (this.startup === 'sub main' || (!this.startup && main)) {
        if (!main) throw vbErr(35, 'Sub Main not found');
        this.mainRunning = true;
        await this.callProc(main, mainMi, [], null, null);
        this.mainRunning = false;
        if (!this.loadedForms().length) this.end();
      } else {
        let key = this.startup || [...this.forms.keys()][0];
        if (!this.forms.has(key)) key = [...this.forms.keys()][0];
        if (!key) throw vbErr(1002, 'The project has no startup form or Sub Main');
        const f = await this.getForm(key);
        if (f && !this.stopped) await f.callMethod('show', [], this);
      }
    } catch (e) { this.handleTopError(e); }
  }
  end() { if (this.stopped) return; this.stopped = true; this.files.close(null); for (const f of this.forms.values()) { if (f.instance && f.instance.destroy) f.instance.destroy(); f.instance = null; } for (const x of this.extraForms || []) x.destroy && x.destroy(); this.extraForms = []; if (this.host.onEnd) this.host.onEnd(); }
  handleTopError(e) {
    if (e instanceof EndSignal) { this.end(); return; }
    if (this.stopped) return;
    this.end();
    if (this.host.onError) this.host.onError(e); else console.error(e);
  }
  // Dispara um evento: obj é o formulário; ctlName o nome do controle ('form' para o próprio form)
  async fireEvent(form, ctlName, evName, values, index) {
    if (this.stopped || !form || !form.mi) return null;
    const mi = form.mi;
    const pname = (ctlName === 'form' ? (mi.kind === 'form' && form.isMDI ? 'mdiform' : 'form') : ctlName) + '_' + evName;
    const proc = mi.ast.procs[pname];
    if (!proc) return null;
    const vals = index !== undefined && index !== null ? [index].concat(values) : values;
    try { return await this.callProcValues(proc, mi, vals, form, true); }
    catch (e) { this.handleTopError(e); return null; }
  }
  hasEvent(form, ctlName, evName) { return !!(form && form.mi && form.mi.ast.procs[(ctlName === 'form' ? (form.isMDI ? 'mdiform' : 'form') : ctlName) + '_' + evName]); }

  async yieldNow() {
    const now = (typeof performance !== 'undefined' ? performance.now() : Date.now());
    if (!this._lastPaint) this._lastPaint = now;
    if (typeof setImmediate === 'undefined' && now - this._lastPaint > 40) { this._lastPaint = now; await new Promise(r => setTimeout(r, 0)); return; }
    await new Promise(r => (typeof setImmediate !== 'undefined' ? setImmediate(r) : (this._mc || (this._mc = this.makeMC()))(r)));
  }
  makeMC() { const ch = new MessageChannel(); const q = []; ch.port1.onmessage = () => { const r = q.shift(); r && r(); }; return (r) => { q.push(r); ch.port2.postMessage(0); }; }

  // valores de argumentos (para builtins/métodos)
  async argValues(args, frame, noDeref) {
    const out = [];
    for (const a of args || []) {
      if (!a) { out.push(VBMissing); continue; }
      let v = await this.evalExpr(a.e, frame);
      if (!noDeref) v = await this.deref(v);
      out.push(v);
    }
    return out;
  }
  async deref(v) {
    if (v instanceof VBObject) { const d = v.defaultProp; if (d && !(v instanceof VBCollection)) return this.deref(await v.getMember(d, this)); }
    return v;
  }

  // chamada de procedimento com nós AST (suporta ByRef)
  async callProc(proc, mi, args, callerFrame, me) {
    if (!proc) throw vbErr(35);
    const frame = this.newFrame(mi, proc, me);
    const writeBacks = [];
    args = args || [];
    const named = args.some(a => a && a.name);
    let ordered = args;
    if (named) { ordered = []; let pos = 0; for (const a of args) { if (a && a.name) { const i = proc.params.findIndex(p => p.name.toLowerCase() === a.name); if (i < 0) throw vbErr(448, 'Named argument not found: ' + a.name); ordered[i] = a; } else ordered[pos++] = a; } }
    for (let i = 0; i < proc.params.length; i++) {
      const p = proc.params[i]; const key = p.name.toLowerCase();
      if (p.paramArray) {
        const vals = []; for (let j = i; j < ordered.length; j++) vals.push(ordered[j] ? await this.deref(await this.evalExpr(ordered[j].e, callerFrame)) : VBMissing);
        frame.locals.set(key, new Cell(arrFrom(vals), 'variant')); break;
      }
      const a = ordered[i];
      if (!a) {
        if (!p.optional) throw vbErr(449);
        const v = p.def ? await this.evalExpr(p.def, frame) : (p.type === 'variant' ? VBMissing : defaultValue(p.type, this));
        frame.locals.set(key, new Cell(p.type === 'variant' ? v : coerce(v, p.type, this), p.type)); continue;
      }
      const e = a.e;
      if (!p.byVal && e.k === 'id' && callerFrame) {
        const r = await this.lookup(e.name, callerFrame, true);
        if (r && r.kind === 'var' && !r.cell.isConst) { frame.locals.set(key, r.cell); continue; }
      }
      let v = await this.evalExpr(e, callerFrame);
      if (!(v instanceof VBObject) || p.byVal || !['variant', 'object'].includes(p.type)) {
        if (p.type !== 'variant' && p.type !== 'object' && !this.classes.has(p.type) && !this.isObjType(p.type)) v = await this.deref(v);
      }
      const cell = new Cell(p.type === 'variant' || p.isArray ? cloneArgValue(v, p) : coerce(v, p.type, this), p.isArray ? 'variant' : p.type);
      if (!p.byVal && (e.k === 'call' || e.k === 'mem') && callerFrame) writeBacks.push({ e, cell, orig: v });
      frame.locals.set(key, cell);
    }
    if (!proc.params.length || !proc.params[proc.params.length - 1].paramArray) {
      if (ordered.length > proc.params.length && ordered.slice(proc.params.length).some(x => x)) throw vbErr(450);
    }
    return this.runProc(proc, mi, frame, async () => {
      for (const wb of writeBacks) { if (wb.cell.v !== wb.orig && !(wb.orig instanceof VBArray)) { try { await this.assign(wb.e, wb.cell.v, callerFrame, false); } catch (e) { } } }
    });
  }
  isObjType(t) { return ['database', 'recordset', 'field', 'tabledef', 'workspace', 'querydef', 'data', 'object', 'collection', 'dictionary', 'form', 'control', 'textbox', 'label', 'commandbutton', 'listbox', 'combobox', 'picturebox', 'checkbox', 'optionbutton', 'frame', 'timer', 'image', 'shape', 'line', 'menu'].includes(t); }
  // chamada com valores já calculados (eventos, Property Let)
  async callProcValues(proc, mi, vals, me, returnCells) {
    if (!proc) throw vbErr(438);
    const frame = this.newFrame(mi, proc, me);
    const cells = [];
    for (let i = 0; i < proc.params.length; i++) {
      const p = proc.params[i]; let v = vals[i];
      if (p.paramArray) { frame.locals.set(p.name.toLowerCase(), new Cell(arrFrom(vals.slice(i)), 'variant')); break; }
      if (v === undefined && i >= vals.length) { if (!p.optional) throw vbErr(449); v = p.def ? await this.evalExpr(p.def, frame) : (p.type === 'variant' ? VBMissing : defaultValue(p.type, this)); }
      const cell = new Cell(p.type === 'variant' ? v : coerce(v, p.type, this), p.type);
      cells.push(cell); frame.locals.set(p.name.toLowerCase(), cell);
    }
    const ret = await this.runProc(proc, mi, frame);
    return returnCells ? { ret, cells } : ret;
  }
  async runProc(proc, mi, frame, after) {
    let retCell = null;
    if (proc.kind === 'function' || proc.kind === 'propget') {
      retCell = new Cell(defaultValue(proc.retType, this), proc.retType); retCell.isRet = true;
      frame.locals.set(proc.name.toLowerCase(), retCell);
    }
    if (++this.depth > 3000) { this.depth = 0; throw vbErr(28); }
    try {
      const r = await this.runBody(proc.body, frame);
      if (r instanceof EndSignal) throw r;
    } finally { this.depth--; }
    if (after) await after();
    return retCell ? retCell.v : undefined;
  }
  labelsOf(stmts) {
    if (stmts._labels) return stmts._labels;
    const m = {}; stmts.forEach((s, i) => { if (s.k === 'label') m[s.name] = i; });
    Object.defineProperty(stmts, '_labels', { value: m, enumerable: false });
    return m;
  }
  async runBody(stmts, frame) {
    frame.top = stmts;
    const labels = this.labelsOf(stmts);
    let i = 0;
    for (;;) {
      try {
        const r = await this.execList(stmts, frame, i);
        if (r && r.goto !== undefined) { const j = labels[r.goto]; if (j === undefined) throw vbErr(1002, `Label not defined: ${r.goto}`); i = j + 1; continue; }
        if (r && r.resume) {
          if (!frame.inHandler) throw vbErr(20);
          frame.inHandler = false; const at = frame.errTop; this.err.clear();
          if (r.resume === 'next') i = at + 1; else if (r.resume === 'retry') i = at; else { const j = labels[r.label]; if (j === undefined) throw vbErr(1002, 'Label not defined'); i = j + 1; }
          continue;
        }
        return r;
      } catch (e) {
        if (!(e instanceof VBError) || e.isCompile || !frame.errMode || frame.errMode.mode !== 'goto' || frame.inHandler) throw e;
        this.setErr(e); frame.inHandler = true; frame.errTop = frame.curTop;
        const j = labels[frame.errMode.label]; if (j === undefined) throw vbErr(1002, 'Label not defined: ' + frame.errMode.label);
        i = j + 1;
      }
    }
  }
  setErr(e) { this.err.number = e.number; this.err.description = e.description || e.message; this.err.source = e.source || this.projectName || ''; this.err.line = e.line || 0; }
  // passo de laço: deixa a janela respirar e permite parar mesmo em laços vazios (Do: Loop, For ... Next)
  async loopStep() {
    if (++this.tick >= 400) { this.tick = 0; await this.yieldNow(); }
    if (this.stopped) throw new EndSignal();
  }
  async execList(stmts, frame, start) {
    const isTop = stmts === frame.top;
    for (let idx = start || 0; idx < stmts.length; idx++) {
      const s = stmts[idx];
      if (isTop) frame.curTop = idx;
      if (++this.tick >= 400) { this.tick = 0; await this.yieldNow(); }
      if (this.stopped) throw new EndSignal();
      let r;
      try { r = await this.exec(s, frame); }
      catch (e) {
        if (e instanceof VBError) {
          if (e.line == null) { e.line = s.line; e.module = frame.mi.name; e.proc = frame.proc ? frame.proc.name : ''; }
          if (frame.errMode && frame.errMode.mode === 'next' && !e.isCompile) { this.setErr(e); continue; }
        } else if (!(e instanceof EndSignal) && !e.isSyntax) {
          const ve = new VBError(1002, 'Internal error: ' + (e && e.message)); ve.line = s.line; ve.module = frame.mi.name; ve.internal = e; throw ve;
        }
        throw e;
      }
      if (r) {
        if (r.goto !== undefined && !isTop) { const L = this.labelsOf(stmts); if (L[r.goto] !== undefined) { idx = L[r.goto]; continue; } }
        return r;
      }
    }
    return null;
  }

  // ----- instruções -----
  async exec(s, frame) {
    switch (s.k) {
      case 'label': return null;
      case 'dims':
        for (const d of s.list) {
          const key = d.name.toLowerCase();
          if (d.isStatic) {
            const sk = (frame.proc ? frame.proc.name.toLowerCase() : '') + '.' + key;
            let c = frame.mi.statics.get(sk);
            if (!c) { c = await this.makeDimCell(d, frame); frame.mi.statics.set(sk, c); }
            frame.locals.set(key, c);
          } else frame.locals.set(key, await this.makeDimCell(d, frame));
        }
        return null;
      case 'consts': for (const c of s.list) { const cell = new Cell(await this.evalExpr(c.expr, frame)); cell.isConst = true; frame.locals.set(c.name.toLowerCase(), cell); } return null;
      case 'assign': {
        let v = await this.evalExpr(s.value, frame);
        await this.assign(s.target, v, frame, !!s.isSet);
        return null;
      }
      case 'call': await this.execCall(s.expr, frame, s.bare); return null;
      case 'if': {
        for (const arm of s.arms) { if (toBool(await this.deref(await this.evalExpr(arm.cond, frame)))) return this.execList(arm.body, frame, 0); }
        if (s.els) return this.execList(s.els, frame, 0);
        return null;
      }
      case 'for': {
        const from = await this.deref(await this.evalExpr(s.from, frame));
        const to = toNum(await this.deref(await this.evalExpr(s.to, frame)));
        const step = s.step ? toNum(await this.deref(await this.evalExpr(s.step, frame))) : 1;
        await this.assign(s.v, toNum(from), frame, false);
        for (;;) {
          await this.loopStep();
          const cur = toNum(await this.evalExpr(s.v, frame));
          if (step >= 0 ? cur > to : cur < to) break;
          const r = await this.execList(s.body, frame, 0);
          if (r) { if (r === SIG_EXIT.for) break; return r; }
          await this.assign(s.v, toNum(await this.evalExpr(s.v, frame)) + step, frame, false);
        }
        return null;
      }
      case 'foreach': {
        const coll = await this.evalExpr(s.coll, frame);
        let items;
        if (coll instanceof VBArray) items = coll.data.slice();
        else if (coll instanceof VBObject) items = coll.enumerate();
        else if (coll === null) throw vbErr(91);
        else throw vbErr(92, 'For Each may only iterate over a collection object or an array');
        for (const it of items) {
          await this.loopStep();
          await this.assign(s.v, it, frame, it instanceof VBObject);
          const r = await this.execList(s.body, frame, 0);
          if (r) { if (r === SIG_EXIT.for) break; return r; }
        }
        return null;
      }
      case 'do': {
        for (;;) {
          await this.loopStep();
          if (s.pre) { const c = toBool(await this.deref(await this.evalExpr(s.pre.cond, frame))); if (s.pre.until ? c : !c) break; }
          const r = await this.execList(s.body, frame, 0);
          if (r) { if (r === SIG_EXIT.do) break; return r; }
          if (s.post) { const c = toBool(await this.deref(await this.evalExpr(s.post.cond, frame))); if (s.post.until ? c : !c) break; }
        }
        return null;
      }
      case 'while': {
        while (toBool(await this.deref(await this.evalExpr(s.cond, frame)))) {
          await this.loopStep();
          const r = await this.execList(s.body, frame, 0);
          if (r) return r;
        }
        return null;
      }
      case 'select': {
        const v = await this.deref(await this.evalExpr(s.subj, frame));
        const tc = frame.mi.compareText;
        for (const c of s.cases) {
          for (const t of c.tests) {
            let ok;
            if (t.range) { const a = await this.deref(await this.evalExpr(t.range[0], frame)), b = await this.deref(await this.evalExpr(t.range[1], frame)); ok = cmpValues(v, a, tc) >= 0 && cmpValues(v, b, tc) <= 0; }
            else ok = binop(t.op, v, await this.deref(await this.evalExpr(t.e, frame)), tc) === true;
            if (ok) return this.execList(c.body, frame, 0);
          }
        }
        if (s.els) return this.execList(s.els, frame, 0);
        return null;
      }
      case 'with': {
        const o = await this.evalExpr(s.obj, frame);
        frame.withStack.push(o);
        try { return await this.execList(s.body, frame, 0); } finally { frame.withStack.pop(); }
      }
      case 'exit': return SIG_EXIT[s.what] || SIG_EXIT.sub;
      case 'end': throw new EndSignal();
      case 'stop': if (this.host.debugPrint) this.host.debugPrint('[Stop] execution stopped at line ' + s.line + '\r\n'); throw new EndSignal();
      case 'goto': return { goto: s.label };
      case 'gosub': throw vbErr(1002, 'GoSub is not supported yet; use a Sub or Function');
      case 'return': throw vbErr(3);
      case 'onerror': frame.errMode = s.mode === 'off' ? null : { mode: s.mode, label: s.label }; if (s.mode !== 'goto') this.err.clear(); return null;
      case 'resume': return { resume: s.mode, label: s.label };
      case 'randomize': return null;
      case 'erase': for (const n of s.names) { const r = await this.lookup(n.toLowerCase(), frame, true); if (r && r.kind === 'var' && r.cell.v instanceof VBArray) { const a = r.cell.v; if (a.dynamic) { a.dims = []; a.data = []; } else a.alloc(); } } return null;
      case 'redim': {
        for (const it of s.list) {
          const dims = [];
          for (const dd of it.dims) { const lb = dd.lb ? intArg(await this.evalExpr(dd.lb, frame)) : (frame.mi.ast.optionBase || 0); const ub = intArg(await this.evalExpr(dd.ub, frame)); dims.push([lb, ub]); }
          let r = await this.lookup(it.name, frame, true);
          if (!r || r.kind !== 'var') { const c = new Cell(new VBArray([], it.type || 'variant', this), it.type || 'variant'); c.v.dynamic = true; c.isArray = true; frame.locals.set(it.name, c); r = { kind: 'var', cell: c }; }
          const cell = r.cell;
          if (cell.fixedArray) throw vbErr(10);
          if (!(cell.v instanceof VBArray)) { cell.v = new VBArray([], it.type || cell.t || 'variant', this); cell.v.dynamic = true; }
          if (it.type) cell.v.type = it.type;
          if (it.isNew) cell.v.autoNew = it.type;
          cell.v.redim(dims, s.preserve);
        }
        return null;
      }
      case 'print': {
        const target = s.obj ? await this.evalExpr(s.obj, frame) : (frame.me || this.globals.debug);
        const { text, newline } = await this.printText(s.items, frame);
        if (target && target.isDebug) { if (this.host.debugPrint) this.host.debugPrint(text + (newline ? '\r\n' : '')); }
        else if (target && target.isPrinter) { if (this.host.printerPrint) this.host.printerPrint(text + (newline ? '\r\n' : '')); }
        else if (target && target.vbPrint) target.vbPrint(text, newline);
        else throw vbErr(438);
        return null;
      }
      case 'fileprint': { const n = intArg(await this.evalExpr(s.fnum, frame)); const { text, newline } = await this.printText(s.items, frame); this.files.print(n, text + (newline ? '\r\n' : '')); return null; }
      case 'fwrite': {
        const n = intArg(await this.evalExpr(s.fnum, frame)); const parts = [];
        for (const e of s.items) { const v = await this.deref(await this.evalExpr(e, frame)); parts.push(typeof v === 'string' ? '"' + v + '"' : v instanceof VBDate ? '#' + toStr(v) + '#' : typeof v === 'boolean' ? (v ? '#TRUE#' : '#FALSE#') : v === VBNull ? '#NULL#' : numToStr(toNum(v), '.')); }
        this.files.print(n, parts.join(',') + '\r\n'); return null;
      }
      case 'fopen': { const p = toStr(await this.evalExpr(s.path, frame)); const n = intArg(await this.evalExpr(s.fnum, frame)); this.files.open(p, s.mode, n); return null; }
      case 'fclose': { if (!s.nums.length) this.files.close(null); else for (const e of s.nums) this.files.close(intArg(await this.evalExpr(e, frame))); return null; }
      case 'lineinput': { const n = intArg(await this.evalExpr(s.fnum, frame)); await this.assign(s.target, this.files.lineInput(n), frame, false); return null; }
      case 'finput': { const n = intArg(await this.evalExpr(s.fnum, frame)); for (const t of s.targets) { const raw = this.files.inputField(n); await this.assign(t, isNumericStr(raw) && !/^".*"$/.test(raw) ? raw : raw, frame, false); } return null; }
      case 'fbin': throw vbErr(1002, 'Binary and random files (Get/Put/Seek) are not supported yet');
      case 'fname': { const a = toStr(await this.evalExpr(s.from, frame)), b = toStr(await this.evalExpr(s.to, frame)); const c = this.files.read(a); if (c == null) throw vbErr(53); this.files.write(b, c); this.files.kill(a); return null; }
      case 'kill': this.files.kill(toStr(await this.evalExpr(s.path, frame))); return null;
      case 'midassign': {
        const a = s.args; const target = a[0].e;
        const cur = toStr(await this.evalExpr(target, frame)); const st = intArg(await this.evalExpr(a[1].e, frame));
        let val = toStr(await this.deref(await this.evalExpr(s.value, frame)));
        let len = a[2] ? intArg(await this.evalExpr(a[2].e, frame)) : val.length;
        len = Math.min(len, val.length, cur.length - st + 1);
        const out = cur.slice(0, st - 1) + val.slice(0, len) + cur.slice(st - 1 + len);
        await this.assign(target, out, frame, false); return null;
      }
      case 'gline': {
        const target = s.obj ? await this.evalExpr(s.obj, frame) : frame.me;
        if (!target || !target.vbLine) throw vbErr(438);
        const p1 = s.p1 ? [toNum(await this.evalExpr(s.p1.x, frame)), toNum(await this.evalExpr(s.p1.y, frame))] : null;
        const p2 = [toNum(await this.evalExpr(s.p2.x, frame)), toNum(await this.evalExpr(s.p2.y, frame))];
        const color = s.color ? toNum(await this.deref(await this.evalExpr(s.color, frame))) : undefined;
        target.vbLine(p1, p2, color, s.box, s.step1, s.step2); return null;
      }
      case 'circle': {
        const target = s.obj ? await this.evalExpr(s.obj, frame) : frame.me;
        if (!target || !target.vbCircle) throw vbErr(438);
        const x = toNum(await this.evalExpr(s.c.x, frame)), y = toNum(await this.evalExpr(s.c.y, frame)), r = toNum(await this.evalExpr(s.r, frame));
        const color = s.color ? toNum(await this.deref(await this.evalExpr(s.color, frame))) : undefined;
        const extra = []; for (const e of s.extra) extra.push(e ? toNum(await this.evalExpr(e, frame)) : undefined);
        target.vbCircle(x, y, r, color, extra); return null;
      }
      case 'pset': {
        const target = s.obj ? await this.evalExpr(s.obj, frame) : frame.me;
        if (!target || !target.vbPSet) throw vbErr(438);
        const x = toNum(await this.evalExpr(s.c.x, frame)), y = toNum(await this.evalExpr(s.c.y, frame));
        const color = s.color ? toNum(await this.deref(await this.evalExpr(s.color, frame))) : undefined;
        target.vbPSet(x, y, color); return null;
      }
    }
    throw vbErr(1002, 'Statement not supported: ' + s.k);
  }
  async printText(items, frame) {
    let text = '', newline = true;
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      if (it.sep) { if (it.sep === ',') { const col = text.length - (text.lastIndexOf('\n') + 1); text += ' '.repeat(14 - (col % 14)); } newline = i !== items.length - 1 ? true : false; continue; }
      newline = true;
      if (it.fn === 'spc') { text += ' '.repeat(Math.max(0, intArg(await this.evalExpr(it.arg, frame)))); continue; }
      if (it.fn === 'tab') { const col = text.length - (text.lastIndexOf('\n') + 1); if (!it.arg) { text += ' '.repeat(14 - (col % 14)); continue; } const n = intArg(await this.evalExpr(it.arg, frame)); text += ' '.repeat(Math.max(0, n - 1 - col)); continue; }
      const v = await this.deref(await this.evalExpr(it.expr, frame));
      if (typeof v === 'number') text += (v >= 0 ? ' ' : '') + numToStr(v) + ' ';
      else if (typeof v === 'boolean') text += v ? 'True' : 'False';
      else if (v === VBNull) text += 'Null';
      else text += toStr(v);
    }
    if (items.length && items[items.length - 1].sep) newline = false;
    return { text, newline };
  }

  async execCall(e, frame, bare) {
    // e: id | mem | call
    if (e.k === 'id') {
      const r = await this.lookup(e.name, frame);
      if (!r) throw vbErr(35, `Sub or Function not defined: ${e.raw}`);
      if (r.kind === 'proc') return this.callProc(r.proc, r.mi, [], frame, r.me);
      if (r.kind === 'builtin') return this.callBuiltin(e.name, r.fn, [], frame);
      if (r.kind === 'value' && r.v instanceof VBObject) return; // apenas referência
      if (r.kind === 'me') return r.me.callMember(r.name, [], frame, this);
      if (r.kind === 'declare') throw vbErr(1002, `Windows API calls are not supported: ${r.name}`);
      throw vbErr(35, `Sub or Function not defined: ${e.raw}`);
    }
    if (e.k === 'mem') {
      const obj = await this.memObject(e, frame);
      if (obj instanceof VBObject) return obj.callMember(e.name, [], frame, this);
      if (obj instanceof VBRecord) return;
      if (obj === null) throw vbErr(91);
      throw vbErr(424);
    }
    if (e.k === 'call') return this.evalCall(e, frame, true);
    return this.evalExpr(e, frame);
  }

  async memObject(e, frame) {
    if (e.obj === null) { if (!frame.withStack.length) throw vbErr(91); return frame.withStack[frame.withStack.length - 1]; }
    let o = await this.evalExpr(e.obj, frame);
    if (o === undefined) throw vbErr(424);
    return o;
  }

  // ----- resolução de nomes -----
  async lookup(name, frame, varsOnly) {
    let c = frame.locals.get(name); if (c) return { kind: 'var', cell: c };
    const mi = frame.mi;
    c = mi.vars.get(name); if (c) return { kind: 'var', cell: c };
    c = mi.consts.get(name); if (c) return { kind: 'var', cell: c };
    if (mi.me && mi.me.getControl) { const ctl = mi.me.getControl(name); if (ctl) return { kind: 'value', v: ctl }; }
    if (!varsOnly) { const p = mi.ast.procs[name]; if (p) return { kind: 'proc', proc: p.isProperty ? (p.propget || p.proplet) : p, mi, me: mi.me }; }
    if (mi.me && mi.me.isForm && FORM_IMPLICIT.has(name)) return { kind: 'me', name, me: mi.me };
    for (const sm of this.stdModules) {
      if (sm === mi) continue;
      let cc = sm.vars.get(name); if (cc && cc.pub) return { kind: 'var', cell: cc };
      cc = sm.consts.get(name); if (cc && cc.pub) return { kind: 'var', cell: cc };
    }
    if (varsOnly) return null;
    for (const sm of this.stdModules) { const p = sm.ast.procs[name]; if (p && p.vis !== 'private') return { kind: 'proc', proc: p.isProperty ? (p.propget || p.proplet) : p, mi: sm, me: null }; }
    if (this.enumConsts.has(name)) return { kind: 'value', v: this.enumConsts.get(name) };
    if (this.forms.has(name)) return { kind: 'value', v: await this.getForm(name) };
    if (name in VBCONST) return { kind: 'value', v: VBCONST[name] };
    if (name in this.globals) return { kind: 'value', v: this.globals[name] };
    if (name in BUILTINS || ASYNC_BUILTINS.has(name)) return { kind: 'builtin', fn: BUILTINS[name] };
    for (const sm of [mi, ...this.stdModules]) if (sm.ast.declares && sm.ast.declares[name]) return { kind: 'declare', name: sm.ast.declares[name].name };
    return null;
  }
  explicitOn(frame) { return frame.mi.ast.optionExplicit; }

  async callBuiltin(name, fn, args, frame) {
    if (name === 'msgbox') {
      const a = await this.argValues(args, frame);
      return this.host.msgBox ? this.host.msgBox(toStr(argN(a, 0, '')), toNum(argN(a, 1, 0)), isMiss(a[2]) ? (this.projectTitle || this.projectName || 'NeoBasic') : toStr(a[2])) : 1;
    }
    if (name === 'inputbox') {
      const a = await this.argValues(args, frame);
      return this.host.inputBox ? this.host.inputBox(toStr(argN(a, 0, '')), isMiss(a[1]) ? (this.projectTitle || this.projectName || 'NeoBasic') : toStr(a[1]), isMiss(a[2]) ? '' : toStr(a[2])) : '';
    }
    if (name === 'unload') {
      if (!args.length || !args[0]) throw vbErr(449);
      const a0 = args[0].e;
      // Unload Text1(3) -> remove elemento dinâmico de matriz de controles
      if (a0.k === 'call' && a0.fn.k === 'id') { const r = await this.lookup(a0.fn.name, frame); if (r && r.kind === 'value' && r.v && r.v.items) { const idx = intArg((await this.argValues(a0.args, frame))[0]); const c = r.v.get(idx); if (c.typeName === 'Menu' && c.items) { const list = c.parentMenu ? c.parentMenu.items : r.v.form.menus; list.splice(list.indexOf(c), 1); r.v.items.delete(idx); r.v.form.allMenus = r.v.form.allMenus.filter(x => x !== c); r.v.form.renderMenubar(); return; } if (c.el && c.el.parentNode) c.el.remove(); c.destroy && c.destroy(); r.v.items.delete(idx); const f = r.v.form; f.allControls = f.allControls.filter(x => x !== c); if (c.parentCtl) c.parentCtl.children = c.parentCtl.children.filter(x => x !== c); else f.topControls = f.topControls.filter(x => x !== c); return; } }
      const o = await this.evalExpr(a0, frame);
      if (o && o.vbUnload) { await o.vbUnload(1); return; }
      throw vbErr(361);
    }
    if (name === 'load') {
      if (!args.length || !args[0]) throw vbErr(449);
      const a0 = args[0].e;
      if (a0.k === 'call' && a0.fn.k === 'id') {
        const r = await this.lookup(a0.fn.name, frame);
        if (r && r.kind === 'value' && r.v && r.v.items) {
          const idx = intArg((await this.argValues(a0.args, frame))[0]);
          if (r.v.items.has(idx)) throw vbErr(360);
          const base = r.v.first(); const f = r.v.form;
          if (base.typeName === 'Menu' && base.items) {
            const node = base.node.clone(); node.setRaw('Index', String(idx));
            const mm = new base.constructor(f, node, base.parentMenu); mm.P.visible = true;
            const list = base.parentMenu ? base.parentMenu.items : f.menus;
            const siblings = list.filter(x => x.lname === base.lname); const after = siblings[siblings.length - 1];
            list.splice(list.indexOf(after) + 1, 0, mm); f.allMenus.push(mm); r.v.items.set(idx, mm); f.renderMenubar();
            return;
          }
          const node = base.node.clone(); node.setRaw('Index', String(idx));
          const C = base.constructor; const c = new C(f, node, base.parentCtl);
          c.P.visible = false; c.P.tabindex = undefined; c.refresh();
          (base.el.parentNode).appendChild(c.el); f.allControls.push(c); if (base.parentCtl) base.parentCtl.children.push(c); else f.topControls.push(c);
          r.v.items.set(idx, c); c.wire();
          if (c.type === 'VB.Menu') {}
          return;
        }
        if (r && r.kind === 'value' && r.v instanceof VBObject && r.v.isForm) return;
      }
      const o = await this.evalExpr(a0, frame); // formulário: carrega sem mostrar
      return;
    }
    if (name === 'doevents') { await this.yieldNow(); await new Promise(r => setTimeout(r, 0)); return 0; }
    const a = await this.argValues(args, frame, NODEREF.has(name));
    return fn(a, this, frame);
  }

  // ----- expressões -----
  async evalExpr(n, frame) {
    switch (n.k) {
      case 'lit': return n.v;
      case 'nulllit': return VBNull;
      case 'datelit': return parseDate(n.v, true);
      case 'paren': return this.evalExpr(n.e, frame);
      case 'me': if (!frame.me) throw vbErr(1002, "Invalid use of Me keyword"); return frame.me;
      case 'id': {
        const r = await this.lookup(n.name, frame);
        if (r) {
          switch (r.kind) {
            case 'var': if (r.cell.autoNew && r.cell.v === null) r.cell.v = await this.createObject(r.cell.autoNew); return r.cell.v;
            case 'value': return r.v;
            case 'proc': return this.callProc(r.proc, r.mi, [], frame, r.me);
            case 'builtin': return this.callBuiltin(n.name, r.fn, [], frame);
            case 'declare': throw vbErr(1002, `Windows API calls are not supported: ${r.name}`);
            case 'me': return r.me.getMember(r.name, this);
          }
        }
        if (this.explicitOn(frame)) throw vbErr(1001, `Variable not defined: ${n.raw}`);
        const c = new Cell(undefined, 'variant'); frame.locals.set(n.name, c); return undefined;
      }
      case 'mem': {
        const o = await this.memObject(n, frame);
        if (o instanceof VBRecord) { if (!o.fields.has(n.name)) throw vbErr(438); return o.fields.get(n.name); }
        if (n.bang && o && o.bangGet) return o.bangGet(n.raw || n.name, this);
        if (o instanceof VBObject) return o.getMember(n.name, this);
        if (o === null) throw vbErr(91);
        throw vbErr(424);
      }
      case 'call': return this.evalCall(n, frame, false);
      case 'new': return this.createObject(n.cls);
      case 'typeof': { const o = await this.evalExpr(n.obj, frame); if (!(o instanceof VBObject)) return false; const tn = o.typeName.toLowerCase(); return tn === n.cls || n.cls === 'object' || (o.ctlType && o.ctlType.toLowerCase() === n.cls) || (n.cls === 'form' && o.isForm) || (n.cls === 'control' && !!o.ctlType); }
      case 'un': {
        const v = await this.deref(await this.evalExpr(n.e, frame));
        if (n.op === '-') { if (v === VBNull) return VBNull; return -toNum(v); }
        if (n.op === 'not') { if (v === VBNull) return VBNull; if (typeof v === 'boolean') return !v; return ~toLong(v, -2147483648, 2147483647); }
        break;
      }
      case 'bin': {
        if (n.op === 'is') { const a = await this.evalExpr(n.l, frame), b = await this.evalExpr(n.r, frame); return a === b; }
        if (n.op === 'andalso') { const a = toBool(await this.deref(await this.evalExpr(n.l, frame))); if (!a) return false; return toBool(await this.deref(await this.evalExpr(n.r, frame))); }
        if (n.op === 'orelse') { const a = toBool(await this.deref(await this.evalExpr(n.l, frame))); if (a) return true; return toBool(await this.deref(await this.evalExpr(n.r, frame))); }
        const a = await this.deref(await this.evalExpr(n.l, frame));
        const b = await this.deref(await this.evalExpr(n.r, frame));
        return binop(n.op, a, b, frame.mi.compareText);
      }
    }
    throw vbErr(1002, 'Expression not supported: ' + n.k);
  }

  async evalCall(n, frame, isStmt) {
    const fn = n.fn;
    if (fn.k === 'id') {
      const r = await this.lookup(fn.name, frame);
      if (!r) {
        if (this.explicitOn(frame)) throw vbErr(35, `Sub, Function, or array not defined: ${fn.raw}`);
        throw vbErr(35, `Sub or Function not defined: ${fn.raw}`);
      }
      if (r.kind === 'var') {
        const v = r.cell.v;
        if (r.cell.isRet && !(v instanceof VBArray)) {
          const p = frame.mi.ast.procs[fn.name];
          if (p) return this.callProc(p.isProperty ? p.propget : p, frame.mi, n.args, frame, frame.me);
        }
        return this.indexValue(v, n.args, frame);
      }
      if (r.kind === 'proc') return this.callProc(r.proc, r.mi, n.args, frame, r.me);
      if (r.kind === 'builtin') return this.callBuiltin(fn.name, r.fn, n.args, frame);
      if (r.kind === 'value') return this.indexValue(r.v, n.args, frame);
      if (r.kind === 'me') { if (n.args.length && BUILTINS[fn.name]) return this.callBuiltin(fn.name, BUILTINS[fn.name], n.args, frame); return r.me.callMember(r.name, n.args, frame, this); }
      if (r.kind === 'declare') throw vbErr(1002, `Windows API calls are not supported: ${r.name}`);
    }
    if (fn.k === 'mem') {
      const o = await this.memObject(fn, frame);
      if (o instanceof VBRecord) { if (!o.fields.has(fn.name)) throw vbErr(438); return this.indexValue(o.fields.get(fn.name), n.args, frame); }
      if (o instanceof VBObject) return o.callMember(fn.name, n.args, frame, this);
      if (o === null) throw vbErr(91);
      throw vbErr(424);
    }
    // ex.: (expr)(i) ou chamada aninhada a(1)(2)
    const v = await this.evalExpr(fn, frame);
    return this.indexValue(v, n.args, frame);
  }
  async indexValue(v, args, frame) {
    if (v instanceof VBArray) { const idx = (await this.argValues(args, frame)).map(intArg); let x = v.get(idx); if ((x === null || x === undefined) && v.autoNew) { x = await this.createObject(v.autoNew); v.set(idx, x); } return x; }
    if (v instanceof VBObject) return v.callMember('', args, frame, this);
    if (v === null) throw vbErr(91);
    if (typeof v === 'string' && !args.length) return v;
    throw vbErr(13, 'Type mismatch: not an array or a function');
  }

  setCell(cell, v, isSet) {
    if (cell.isConst) throw vbErr(1002, 'Assignment to constant not permitted');
    if (cell.fixedArray && v instanceof VBArray) throw vbErr(10);
    if (isSet) { if (v !== null && !(v instanceof VBObject)) throw vbErr(424); cell.v = v; return; }
    if (cell.t === 'variant') { cell.v = cloneValue(v); return; }
    if (cell.isArray) { if (!(v instanceof VBArray)) throw vbErr(13); cell.v = v.clone(); return; }
    cell.v = coerce(v, cell.t, this);
  }
  async assign(target, v, frame, isSet) {
    if (!isSet) {
      if (v instanceof VBObject) {
        // atribuição sem Set: usa a propriedade padrão (Text1 -> Text1.Text)
        const d = v.defaultProp;
        if (d) v = await this.deref(v);
        else if (target.k !== 'mem') throw vbErr(91, 'Object has no default property; use Set');
      }
    }
    switch (target.k) {
      case 'id': {
        const r = await this.lookup(target.name, frame, false);
        if (r && r.kind === 'var') { this.setCell(r.cell, v, isSet); return; }
        if (r && r.kind === 'value' && r.v instanceof VBObject) {
          if (isSet) throw vbErr(1002, "Invalid use of Set with a control");
          const d = r.v.defaultProp; if (!d) throw vbErr(438); return r.v.setMember(d, v, this);
        }
        if (r && r.kind === 'proc' && r.proc.kind === 'proplet') return this.callProcValues(r.proc, r.mi, [v], r.me);
        if (r && r.kind === 'me') return r.me.setMember(r.name, v, this, null, isSet);
        if (r && (r.kind === 'proc' || r.kind === 'builtin' || r.kind === 'value')) throw vbErr(1002, `Invalid assignment to '${target.raw}'`);
        if (this.explicitOn(frame)) throw vbErr(1001, `Variable not defined: ${target.raw}`);
        const c = new Cell(undefined, 'variant'); frame.locals.set(target.name, c); this.setCell(c, v, isSet); return;
      }
      case 'mem': {
        const o = await this.memObject(target, frame);
        if (o instanceof VBRecord) {
          if (!o.fields.has(target.name)) throw vbErr(438);
          const td = o.typeDef.fields.find(f => f.name.toLowerCase() === target.name);
          o.fields.set(target.name, isSet ? v : coerce(v, td ? td.type : 'variant', this)); return;
        }
        if (target.bang && o && o.bangSet) return o.bangSet(target.raw || target.name, v, this);
        if (o instanceof VBObject) return o.setMember(target.name, v, this, null, isSet);
        if (o === null) throw vbErr(91);
        throw vbErr(424);
      }
      case 'call': {
        const fn = target.fn;
        if (fn.k === 'id') {
          const r = await this.lookup(fn.name, frame, false);
          if (r && r.kind === 'var' && r.cell.v instanceof VBArray) {
            const a = r.cell.v; const idx = (await this.argValues(target.args, frame)).map(intArg);
            a.set(idx, isSet ? v : coerce(v, a.type, this)); return;
          }
          if (r && r.kind === 'var' && r.cell.v instanceof VBObject) { const vals = await this.argValues(target.args, frame); return r.cell.v.setMember('', v, this, vals, isSet); }
          if (r && r.kind === 'value' && r.v instanceof VBObject) {
            // controle de matriz: Text1(0) = "x"
            const vals = await this.argValues(target.args, frame);
            const ctl = await r.v.callMethod('', vals, this);
            if (ctl instanceof VBObject) { const d = ctl.defaultProp; if (!d) throw vbErr(438); return ctl.setMember(d, v, this); }
            throw vbErr(424);
          }
          if (r && r.kind === 'proc' && r.proc.kind === 'proplet') { const vals = await this.argValues(target.args, frame); return this.callProcValues(r.proc, r.mi, vals.concat([v]), r.me); }
          if (r && r.kind === 'proc') {
            const pp = frame.mi.ast.procs[fn.name];
            if (pp && pp.isProperty && pp.proplet) { const vals = await this.argValues(target.args, frame); return this.callProcValues(pp.proplet, frame.mi, vals.concat([v]), frame.me); }
          }
          throw vbErr(9, `Expected array: '${fn.raw}'`);
        }
        if (fn.k === 'mem') {
          const o = await this.memObject(fn, frame);
          if (o instanceof VBRecord) { const arr = o.fields.get(fn.name); if (!(arr instanceof VBArray)) throw vbErr(13); const idx = (await this.argValues(target.args, frame)).map(intArg); arr.set(idx, coerce(v, arr.type, this)); return; }
          if (o instanceof VBObject) {
            const vals = await this.argValues(target.args, frame);
            // matriz pública dentro de classe/forms: obj.arr(i) = v
            return o.setMember(fn.name, v, this, vals, isSet);
          }
          if (o === null) throw vbErr(91);
          throw vbErr(424);
        }
        // a(1)(2) = v
        const base = await this.evalCall(fn.k === 'call' ? fn : target, frame);
        if (base instanceof VBArray) { const idx = (await this.argValues(target.args, frame)).map(intArg); base.set(idx, v); return; }
        throw vbErr(1002, 'Assignment not supported');
      }
      case 'paren': return this.assign(target.e, v, frame, isSet);
    }
    throw vbErr(1002, 'Invalid assignment target');
  }
}
function cloneArgValue(v, p) { return v instanceof VBRecord ? v.clone() : v; }
if (typeof module !== 'undefined') module.exports = { VBRuntime, ClassInstance, ModuleInstance, Cell, BUILTINS, VBCONST, cp1252Char, cp1252Code, VirtualFS };
