// NeoBasic.exe — abre o NeoBasic em janela própria (modo aplicativo do Edge/Chrome/Brave),
// sem barra de endereço nem menus do navegador. Cria também o atalho no Menu Iniciar.
#define UNICODE
#define _UNICODE
#define COBJMACROS
#include <windows.h>
#include <shlobj.h>
#include <shobjidl.h>
#include <objbase.h>
#include <wchar.h>
#include <stdio.h>

static int file_exists(const wchar_t *p) { DWORD a = GetFileAttributesW(p); return a != INVALID_FILE_ATTRIBUTES && !(a & FILE_ATTRIBUTE_DIRECTORY); }

static int app_path_from_registry(const wchar_t *exe, wchar_t *out, DWORD cap) {
    wchar_t key[300];
    swprintf(key, 300, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\%ls", exe);
    HKEY roots[2] = { HKEY_CURRENT_USER, HKEY_LOCAL_MACHINE };
    for (int i = 0; i < 2; i++) {
        DWORD sz = cap * sizeof(wchar_t);
        if (RegGetValueW(roots[i], key, NULL, RRF_RT_REG_SZ, NULL, out, &sz) == ERROR_SUCCESS && file_exists(out)) return 1;
    }
    return 0;
}

static int find_browser(wchar_t *out, DWORD cap) {
    // Edge vem em todo Windows 10/11; depois Chrome e Brave
    const wchar_t *exes[3] = { L"msedge.exe", L"chrome.exe", L"brave.exe" };
    for (int i = 0; i < 3; i++) if (app_path_from_registry(exes[i], out, cap)) return 1;
    const wchar_t *guesses[] = {
        L"%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe",
        L"%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe",
        L"%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe",
        L"%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe",
        L"%LOCALAPPDATA%\\Google\\Chrome\\Application\\chrome.exe",
        L"%ProgramFiles%\\BraveSoftware\\Brave-Browser\\Application\\brave.exe",
        L"%LOCALAPPDATA%\\BraveSoftware\\Brave-Browser\\Application\\brave.exe",
    };
    for (int i = 0; i < (int)(sizeof(guesses) / sizeof(guesses[0])); i++) {
        if (ExpandEnvironmentStringsW(guesses[i], out, cap) && file_exists(out)) return 1;
    }
    return 0;
}

// caminho do Windows -> file:///C:/... (UTF-8 com %XX), aceita acentos como em "MAÍRA"
static void path_to_url(const wchar_t *path, char *url, int cap) {
    char utf8[4096];
    WideCharToMultiByte(CP_UTF8, 0, path, -1, utf8, sizeof(utf8), NULL, NULL);
    int n = snprintf(url, cap, "file:///");
    for (unsigned char *p = (unsigned char *)utf8; *p && n < cap - 4; p++) {
        unsigned char c = *p;
        if (c == '\\') c = '/';
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || strchr("-._~/:", c)) url[n++] = (char)c;
        else n += snprintf(url + n, cap - n, "%%%02X", c);
    }
    url[n] = 0;
}

static void ensure_shortcut(const wchar_t *exePath, const wchar_t *workDir) {
    wchar_t lnk[MAX_PATH];
    if (FAILED(SHGetFolderPathW(NULL, CSIDL_PROGRAMS, NULL, 0, lnk))) return;
    wcscat(lnk, L"\\NeoBasic.lnk");
    if (file_exists(lnk)) {
        // atualiza se o programa mudou de pasta
        IShellLinkW *sl0 = NULL;
        if (SUCCEEDED(CoCreateInstance(&CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, &IID_IShellLinkW, (void **)&sl0))) {
            IPersistFile *pf0 = NULL; wchar_t cur[MAX_PATH] = L"";
            if (SUCCEEDED(IShellLinkW_QueryInterface(sl0, &IID_IPersistFile, (void **)&pf0))) {
                if (SUCCEEDED(IPersistFile_Load(pf0, lnk, STGM_READ))) IShellLinkW_GetPath(sl0, cur, MAX_PATH, NULL, 0);
                IPersistFile_Release(pf0);
            }
            IShellLinkW_Release(sl0);
            if (_wcsicmp(cur, exePath) == 0) return;
        }
    }
    IShellLinkW *sl = NULL;
    if (FAILED(CoCreateInstance(&CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, &IID_IShellLinkW, (void **)&sl))) return;
    IShellLinkW_SetPath(sl, exePath);
    IShellLinkW_SetWorkingDirectory(sl, workDir);
    IShellLinkW_SetDescription(sl, L"NeoBasic - ambiente estilo Visual Basic");
    IShellLinkW_SetIconLocation(sl, exePath, 0);
    IPersistFile *pf = NULL;
    if (SUCCEEDED(IShellLinkW_QueryInterface(sl, &IID_IPersistFile, (void **)&pf))) { IPersistFile_Save(pf, lnk, TRUE); IPersistFile_Release(pf); }
    IShellLinkW_Release(sl);
}

int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE hPrev, PWSTR cmd, int show) {
    (void)hInst; (void)hPrev; (void)cmd; (void)show;
    wchar_t exe[MAX_PATH], dir[MAX_PATH], html[MAX_PATH], browser[MAX_PATH], profile[MAX_PATH];
    GetModuleFileNameW(NULL, exe, MAX_PATH);
    wcscpy(dir, exe);
    wchar_t *slash = wcsrchr(dir, L'\\'); if (slash) *slash = 0;
    swprintf(html, MAX_PATH, L"%ls\\NeoBasic.html", dir);
    if (!file_exists(html)) {
        MessageBoxW(NULL, L"Não encontrei o arquivo NeoBasic.html.\n\nDeixe o NeoBasic.exe na mesma pasta do NeoBasic.html.", L"NeoBasic", MB_ICONERROR);
        return 1;
    }
    if (!find_browser(browser, MAX_PATH)) {
        MessageBoxW(NULL, L"O NeoBasic usa o motor do Microsoft Edge (que já vem no Windows), do Chrome ou do Brave, e nenhum deles foi encontrado.\n\nInstale o Microsoft Edge ou o Google Chrome e tente de novo.", L"NeoBasic", MB_ICONERROR);
        return 1;
    }
    // perfil próprio: o NeoBasic vira um aplicativo separado do seu navegador
    ExpandEnvironmentStringsW(L"%LOCALAPPDATA%\\NeoBasic\\Perfil", profile, MAX_PATH);
    SHCreateDirectoryExW(NULL, profile, NULL);

    CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
    ensure_shortcut(exe, dir);
    CoUninitialize();

    char url8[8192];
    path_to_url(html, url8, sizeof(url8));
    strcat(url8, "?app=1");
    wchar_t url[8192];
    MultiByteToWideChar(CP_UTF8, 0, url8, -1, url, 8192);

    wchar_t cmdline[16384];
    swprintf(cmdline, 16384,
        L"\"%ls\" --app=\"%ls\" --user-data-dir=\"%ls\" --start-maximized --no-first-run --no-default-browser-check "
        L"--lang=pt-BR --disable-features=Translate,msEdgeSidebarV2,msHubApps,msUndersideButton --disable-sync --hide-crash-restore-bubble",
        browser, url, profile);
    STARTUPINFOW si; PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si); ZeroMemory(&pi, sizeof(pi));
    if (!CreateProcessW(NULL, cmdline, NULL, NULL, FALSE, 0, NULL, dir, &si, &pi)) {
        MessageBoxW(NULL, L"Não foi possível abrir a janela do NeoBasic.", L"NeoBasic", MB_ICONERROR);
        return 1;
    }
    CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
    return 0;
}
