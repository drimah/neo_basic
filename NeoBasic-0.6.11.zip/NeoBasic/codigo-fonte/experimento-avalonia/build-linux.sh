#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
dotnet restore NeoBasic.Avalonia.sln
dotnet publish src/NeoBasic/NeoBasic.csproj -c Release -r linux-x64 --self-contained true -p:PublishSingleFile=true -o dist/linux-x64
echo "Build completed: dist/linux-x64/NeoBasic"
