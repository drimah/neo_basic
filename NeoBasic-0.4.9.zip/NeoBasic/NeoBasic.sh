#!/bin/sh
# NeoBasic para Linux (Mint, Ubuntu, etc.) — abre o NeoBasic em janela própria,
# igual à do Windows, usando um navegador Chromium (Chrome, Chromium, Brave ou Edge).
# Na primeira vez cria o atalho no menu de aplicativos.

DIR="$(cd "$(dirname "$0")" && pwd)"
HTML="$DIR/NeoBasic.html"
ICON="$DIR/icone/neobasic.png"
PERFIL="${XDG_DATA_HOME:-$HOME/.local/share}/neobasic/perfil"

aviso() {
  if command -v zenity >/dev/null 2>&1; then zenity --error --title="NeoBasic" --width=420 --text="$1" 2>/dev/null
  elif command -v notify-send >/dev/null 2>&1; then notify-send "NeoBasic" "$1"
  else echo "NeoBasic: $1" >&2; fi
}

[ -f "$HTML" ] || { aviso "Não encontrei o NeoBasic.html. Deixe o NeoBasic.sh na mesma pasta dele."; exit 1; }

# atalho no menu (uma vez, ou se a pasta mudou)
APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
DESK="$APPS/neobasic.desktop"
if [ -z "$NEOBASIC_DRYRUN" ] && ! grep -qF "Exec=\"$DIR/NeoBasic.sh\"" "$DESK" 2>/dev/null; then
  mkdir -p "$APPS"
  cat > "$DESK" <<EOF
[Desktop Entry]
Type=Application
Name=NeoBasic
Comment=Ambiente estilo Visual Basic
Exec="$DIR/NeoBasic.sh"
Icon=$ICON
Terminal=false
Categories=Development;IDE;
StartupWMClass=NeoBasic
EOF
  chmod +x "$DESK" 2>/dev/null
  command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APPS" >/dev/null 2>&1
fi

# endereço file:// (com acentos e espaços codificados)
if command -v python3 >/dev/null 2>&1; then
  URL="file://$(python3 -c 'import sys,urllib.parse;print(urllib.parse.quote(sys.argv[1]))' "$HTML")?app=1"
else
  URL="file://$(printf '%s' "$HTML" | sed 's/ /%20/g')?app=1"
fi

ARGS="--app=$URL --user-data-dir=$PERFIL --class=NeoBasic --start-maximized --no-first-run --no-default-browser-check --disable-features=Translate --lang=pt-BR --hide-crash-restore-bubble $NEOBASIC_EXTRA"

mkdir -p "$PERFIL"
for B in google-chrome google-chrome-stable chromium chromium-browser brave-browser brave microsoft-edge microsoft-edge-stable vivaldi; do
  if command -v "$B" >/dev/null 2>&1; then
    [ -n "$NEOBASIC_DRYRUN" ] && { echo "$B $ARGS"; exit 0; }
    # shellcheck disable=SC2086
    exec "$B" $ARGS
  fi
done
for F in com.google.Chrome org.chromium.Chromium com.brave.Browser com.microsoft.Edge; do
  if command -v flatpak >/dev/null 2>&1 && flatpak info "$F" >/dev/null 2>&1; then
    [ -n "$NEOBASIC_DRYRUN" ] && { echo "flatpak run $F $ARGS"; exit 0; }
    # shellcheck disable=SC2086
    exec flatpak run --filesystem=home "$F" $ARGS
  fi
done

aviso "O NeoBasic precisa de um navegador Chromium (Chromium, Chrome ou Brave) para abrir em janela própria.

No Linux Mint, instale com:
    sudo apt install chromium

Por enquanto vou abrir no navegador padrão."
exec xdg-open "$HTML"
